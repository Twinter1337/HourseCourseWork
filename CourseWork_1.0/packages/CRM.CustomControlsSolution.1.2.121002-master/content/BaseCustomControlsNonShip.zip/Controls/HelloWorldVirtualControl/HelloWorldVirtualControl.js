/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var Dyn365;
(function (Dyn365) {
    var SampleControls;
    (function (SampleControls) {
        "use strict";
        var HelloWorldVirtualControl = (function () {
            function HelloWorldVirtualControl() {
            }
            HelloWorldVirtualControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this._value = context.parameters.value.raw;
                this._notifyOutputChanged = notifyOutputChanged;
            };
            HelloWorldVirtualControl.prototype.updateView = function (context) {
                return this.getView(context);
            };
            HelloWorldVirtualControl.prototype.getView = function (context) {
                var COMPONENT_PREFIX = "SampleHelloWorldVDOM";
                var uniqueId = context.accessibility.getUniqueId(COMPONENT_PREFIX);
                var labelValue = "Hello World VDOM " + this._value != null ? this._value.toString() : "";
                var label = context.factory.createElement("LABEL", {
                    id: COMPONENT_PREFIX + "LBL",
                    absoluteId: uniqueId + "LBL",
                    key: COMPONENT_PREFIX + "LBL",
                }, labelValue);
                this.button = context.factory.createElement("BUTTON", {
                    id: COMPONENT_PREFIX + "BTN",
                    absoluteId: uniqueId + "BTN",
                    key: COMPONENT_PREFIX + "BTN",
                    onClick: this.onButtonClick.bind(this),
                }, "Click");
                var inContainer = context.factory.createElement("CONTAINER", {
                    id: "SampleHelloWorldVDOM",
                }, [label, this.button]);
                return inContainer;
            };
            HelloWorldVirtualControl.prototype.onButtonClick = function (event) {
                this._value = this._value + 1;
                this._notifyOutputChanged();
            };
            HelloWorldVirtualControl.prototype.getOutputs = function () {
                var result = {
                    value: this._value,
                };
                return result;
            };
            HelloWorldVirtualControl.prototype.destroy = function () { };
            return HelloWorldVirtualControl;
        }());
        SampleControls.HelloWorldVirtualControl = HelloWorldVirtualControl;
    })(SampleControls = Dyn365.SampleControls || (Dyn365.SampleControls = {}));
})(Dyn365 || (Dyn365 = {}));
