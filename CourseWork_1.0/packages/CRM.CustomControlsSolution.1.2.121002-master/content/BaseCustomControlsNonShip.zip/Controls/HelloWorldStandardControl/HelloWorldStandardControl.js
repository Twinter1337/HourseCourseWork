/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var Dyn365;
(function (Dyn365) {
    var SampleControls;
    (function (SampleControls) {
        "use strict";
        var HelloWorldStandardControl = (function () {
            function HelloWorldStandardControl() {
            }
            HelloWorldStandardControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                this.label = document.createElement("input");
                this.label.setAttribute("id", "SampleHelloWorldStandard");
                this.label.setAttribute("type", "label");
                this.button = document.createElement("input");
                this.button.setAttribute("id", "SampleHelloWorldIncrementButton");
                this.button.setAttribute("type", "button");
                this.button.setAttribute("value", "Increment");
                this._notifyOutputChanged = notifyOutputChanged;
                this.button.addEventListener("click", this.onButtonClick.bind(this));
                container.appendChild(this.label);
                container.appendChild(this.button);
            };
            HelloWorldStandardControl.prototype.onButtonClick = function (event) {
                this._value = this._value + 1;
                this._notifyOutputChanged();
            };
            HelloWorldStandardControl.prototype.updateView = function (context) {
                this._value = context.parameters.value.raw;
                this.label.setAttribute("value", "Hello World " + this._value != null ? this._value.toString() : "");
            };
            HelloWorldStandardControl.prototype.getOutputs = function () {
                var result = {
                    value: this._value,
                };
                return result;
            };
            HelloWorldStandardControl.prototype.destroy = function () {
                this.button.removeEventListener("click", this.onButtonClick);
            };
            return HelloWorldStandardControl;
        }());
        SampleControls.HelloWorldStandardControl = HelloWorldStandardControl;
    })(SampleControls = Dyn365.SampleControls || (Dyn365.SampleControls = {}));
})(Dyn365 || (Dyn365 = {}));
