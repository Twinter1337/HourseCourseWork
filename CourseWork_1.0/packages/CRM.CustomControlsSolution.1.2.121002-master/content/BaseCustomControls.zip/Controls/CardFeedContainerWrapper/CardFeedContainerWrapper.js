/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainerWrapper;
    (function (CardFeedContainerWrapper_1) {
        "use strict";
        var CardFeedContainerWrapper = (function () {
            function CardFeedContainerWrapper() {
            }
            CardFeedContainerWrapper.prototype.init = function (context, notifyOutputChanged, state) {
                this._onKeyboardCloseHandler = this._onKeyboardCloseHandler.bind(this);
                this.context = context;
                document.addEventListener("keydown", this._onKeyboardCloseHandler);
            };
            CardFeedContainerWrapper.prototype.updateView = function (context) {
                var params = {
                    SubGrid: {
                        TargetEntityType: "actioncard",
                        ViewId: "{92AFD454-0F2E-4397-A1C8-05E37C6AD699}",
                        EnableViewPicker: false,
                        RelationshipName: "",
                        Type: "Grid",
                    },
                    Location: {
                        Static: true,
                        Value: "0",
                        Type: "Decimal",
                    },
                };
                var componentName = "MscrmControls.CardFeedContainer.CardFeedContainer";
                var component = context.factory.createComponent(componentName, componentName, {
                    parameters: params,
                    childeventlisteners: [
                        {
                            eventname: "close",
                            eventhandler: function (data) {
                                context.utils.fireEvent("close", {});
                                return;
                            },
                        },
                    ],
                });
                var wrapper = context.factory.createElement("CONTAINER", { absoluteId: "cardfeedcontainerwrapper", className: "cardwrapper" }, [component]);
                var OuterWrapper = context.factory.createElement("CONTAINER", { absoluteId: "cardfeedcontainerwrapperouter", className: "cardwrapperouter" }, [wrapper]);
                return OuterWrapper;
            };
            CardFeedContainerWrapper.prototype.getOutputs = function () {
                return null;
            };
            CardFeedContainerWrapper.prototype.destroy = function () {
                this.raiseEvent("raglobalpanelclosed");
                document.removeEventListener("keydown", this._onKeyboardCloseHandler);
            };
            CardFeedContainerWrapper.prototype.raiseEvent = function (eventName) {
                var event = document.createEvent("Event");
                event.initEvent(eventName, true, true);
                document.dispatchEvent(event);
            };
            CardFeedContainerWrapper.prototype._onKeyboardCloseHandler = function (event) {
                if (event.keyCode === 27 &&
                    event.srcElement.className != "menuContent" &&
                    event.srcElement.id.indexOf("menuSnoozeContainer") == -1 &&
                    event.srcElement.id.indexOf("menuDismissContainer") == -1 &&
                    event.srcElement.id.indexOf("menuShowAllContainer") == -1) {
                    this.context.utils.fireEvent("close", {});
                    setTimeout(function () {
                        document.getElementById("cardFeedContainerLauncher").focus();
                    }, 500);
                    return;
                }
            };
            return CardFeedContainerWrapper;
        }());
        CardFeedContainerWrapper_1.CardFeedContainerWrapper = CardFeedContainerWrapper;
    })(CardFeedContainerWrapper = MscrmControls.CardFeedContainerWrapper || (MscrmControls.CardFeedContainerWrapper = {}));
})(MscrmControls || (MscrmControls = {}));
