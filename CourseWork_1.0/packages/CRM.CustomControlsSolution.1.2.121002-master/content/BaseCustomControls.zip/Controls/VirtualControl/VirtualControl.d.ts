/// <reference path="../../../../../../src/Shared/mscrm.d.ts" />
declare module MscrmControls.FieldControls {
    class VirtualControl<TInputBag, TOutputBag> implements Mscrm.Control<TInputBag, TOutputBag> {
        protected context: Mscrm.ControlData<TInputBag>;
        protected notifyOutputChanged: (doNotUpdateSystem?: boolean) => void;
        static NO_VALUE_LABEL: string;
        constructor();
        init(context: Mscrm.ControlData<TInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        destroy(): void;
        onPreNavigation(): void;
        updateView(context: Mscrm.ControlData<TInputBag>): Mscrm.Component;
        getOutputs(): TOutputBag;
    }
}
declare module MscrmControls.FieldControls {
    interface IOptionSetIDBundle {
        arrow: string;
        arrowContainer: string;
        select: string;
        selectContainer: string;
        container: string;
    }
    type IOptionSetValue = Mscrm.OptionSetValue;
    class VirtualOptionSetControl<TInputBag extends IOptionSetInputBag, TOutputBag> extends VirtualControl<TInputBag, TOutputBag> implements IModeTransitionDataSource, IModeTransitionDelegate {
        protected waitingForValueSaved: boolean;
        protected modeManager: ModeTransitionManager;
        protected _onChange: (value: IOptionSetValue) => void;
        protected _onFocus: (event?: FocusEvent) => void;
        protected _onBlur: (event?: FocusEvent) => void;
        protected _onContainerPointerEnter: (event?: MouseEvent) => void;
        protected _onContainerPointerLeave: (event?: MouseEvent) => void;
        protected _pointerEnd: boolean;
        protected _value: number;
        protected static UNASSIGNED_OPTION_VALUE: number;
        protected static UNASSIGNED_OPTION_LABEL: string;
        protected static UNASSIGNED_OPTION_LABEL_PROMPT: string;
        protected static NOT_READABLE_VALUE: string;
        protected static OPTION_SET_ARROW_SIZE: string;
        constructor();
        init(context: Mscrm.ControlData<TInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        getOutputs(): TOutputBag;
        updateView(context: Mscrm.ControlData<TInputBag>): Mscrm.Component;
        protected onChangeHandler(value: IOptionSetValue): void;
        protected onFocusHandler(): void;
        protected onBlurHandler(): void;
        protected onContainerPointerEnterHandler(): void;
        protected onContainerPointerLeaveHandler(): void;
        protected idBundle(): IOptionSetIDBundle;
        protected valueForMode(mode: IModeDescriptor): number;
        protected setControlValue(candidate: IOptionSetValue): void;
        protected isError(): boolean;
        protected optionsList(): IOptionSetValue[];
        protected arrowStyle(): Mscrm.Dictionary;
        protected arrowContainerStyle(): Mscrm.Dictionary;
        protected arrowComponent(): Mscrm.Component;
        protected selectStyle(): Mscrm.Dictionary;
        protected selectComponent(): Mscrm.Component;
        protected containerStyle(): Mscrm.Dictionary;
        protected component(): Mscrm.Component;
        protected unassignedOptionWithPrompt(prompt?: boolean): IOptionSetValue;
        protected nonReadableOption(isActive?: boolean, value?: IOptionSetValue): IOptionSetValue;
        protected optionWithValue(value: number, options: IOptionSetValue[]): IOptionSetValue;
        protected static isUnassigned(candidate: IOptionSetValue): boolean;
        defaultMode(): IModeDescriptor;
        isTransitionAllowed(from: IModeDescriptor, to: IModeDescriptor): boolean;
        transitionWillApply(from: IModeDescriptor, to: IModeDescriptor): void;
        transitionDidApply(from: IModeDescriptor, to: IModeDescriptor): void;
        protected isControlDisabled(): boolean;
    }
}
declare module MscrmControls.FieldControls {
    interface INumberIDBundle {
        input: string;
    }
    class VirtualNumberControl<TInputBag extends INumberInputBag, TOutputBag> extends VirtualControl<TInputBag, TOutputBag> implements IModeTransitionDataSource, IModeTransitionDelegate {
        protected modeManager: ModeTransitionManager;
        protected waitingForValueSaved: boolean;
        private _pointerEnd;
        private _changeHandler;
        private _focusHandler;
        private _clickHandler;
        private _blurHandler;
        private _keyDownHandler;
        private _pointerEnterHandler;
        private _pointerLeaveHandler;
        static UPDATE_LABEL_EVENT: string;
        static DEFAULT_VALUE_LABEL: string;
        static NOT_READABLE_VALUE: string;
        static Enter_KEY_CODE: number;
        constructor();
        init(context: Mscrm.ControlData<TInputBag>, notifyOutputChanged?: (alertSystem?: boolean) => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        getOutputs(): TOutputBag;
        protected idBundle(): INumberIDBundle;
        protected setControlValue(candidate: number | string): void;
        protected valueForMode(mode: IModeDescriptor): number | string;
        protected isError(): boolean;
        protected tryConvertToNumber(candidate: string): number | string;
        protected component(): Mscrm.Component;
        protected propsForMode(mode: IModeDescriptor): Mscrm.Dictionary;
        protected styleForMode(mode: IModeDescriptor): Mscrm.Dictionary;
        protected restStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean): Mscrm.Dictionary;
        protected hoverStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean): Mscrm.Dictionary;
        protected activeStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean): Mscrm.Dictionary;
        updateView(context: Mscrm.ControlData<TInputBag>): Mscrm.Component;
        protected onFocus(): void;
        protected onClick(event: any): void;
        protected onBlur(): void;
        protected onKeyDown(event: any): void;
        protected onChange(event: Event): void;
        protected onPointerEnter(): void;
        protected onPointerLeave(): void;
        defaultMode(): IModeDescriptor;
        isTransitionAllowed(from: IModeDescriptor, to: IModeDescriptor): boolean;
        transitionWillApply(from: IModeDescriptor, to: IModeDescriptor): void;
        transitionDidApply(from: IModeDescriptor, to: IModeDescriptor): void;
        protected isControlDisabled(): boolean;
    }
}
declare module MscrmControls.FieldControls {
    interface IActionControlIDBundle {
        container: string;
        input: string;
        icon: string;
        ariaDescriptor: string;
    }
    interface IActionIconProps {
        accessibilityLabel: string;
        type: number;
    }
    class VirtualActionControl<TInputBag extends IActionInputBag, TOutputBag> extends VirtualControl<TInputBag, TOutputBag> implements IModeTransitionDataSource, IModeTransitionDelegate {
        protected waitingForValueSaved: boolean;
        protected _pointerEnd: boolean;
        protected modeManager: IModeTransitionManager;
        protected _focusInputHandler: (event?: FocusEvent) => void;
        protected _blurInputHandler: (event?: FocusEvent) => void;
        protected _changeInputHandler: (event?: Event) => void;
        protected _keyDownInputHandler: (event?: KeyboardEvent) => void;
        protected _focusButtonHandler: (event?: FocusEvent) => void;
        protected _blurButtonHandler: (event?: FocusEvent) => void;
        protected _keyDownButtonHandler: (event?: FocusEvent) => void;
        protected _clickButtonHandler: (event?: MouseEvent) => void;
        protected _pointerDownButtonHandler: (event?: MouseEvent) => void;
        protected _pointerEnterContainerHandler: (event?: MouseEvent) => void;
        protected _pointerLeaveContainerHandler: (event?: MouseEvent) => void;
        protected _accessibilityNotificationMessage: string;
        static UPDATE_LABEL_EVENT: string;
        static DEFAULT_VALUE_LABEL: string;
        constructor();
        init(context: Mscrm.ControlData<TInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        getOutputs(): TOutputBag;
        protected action(): void;
        protected idBundle(): IActionControlIDBundle;
        protected actionIconProps(): IActionIconProps;
        protected ariaDescription(): string;
        protected placeholder(): string;
        protected setControlValue(candidate: string): void;
        protected valueForMode(mode: IModeDescriptor): string;
        protected isError(): boolean;
        protected propsForMode(mode: IModeDescriptor, ariaDescriptorId: string): Mscrm.Dictionary;
        protected styleForMode(mode: IModeDescriptor): Mscrm.Dictionary;
        protected isValueSet(mode: ModeDescriptorID): boolean;
        protected restStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, error: boolean): Mscrm.Dictionary;
        protected hoverStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, error: boolean): Mscrm.Dictionary;
        protected activeStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, error: boolean): Mscrm.Dictionary;
        protected actionButtonStyle(theming: Mscrm.Theme, isRTL: boolean, error: boolean, mode: IModeDescriptor): Mscrm.Dictionary;
        protected getLiveContainerProps(): Mscrm.Dictionary;
        protected setLiveContainerNotification(message: string): void;
        protected actionButtonType(): "MICROSOFTICON" | "CRMICON";
        protected inputComponent(): Mscrm.Component;
        protected liveRegionComponent(): Mscrm.Component;
        protected ariaDescriptorComponent(): Mscrm.Component;
        protected actionButtonComponent(): Mscrm.Component;
        protected component(): Mscrm.Component;
        updateView(context: Mscrm.ControlData<TInputBag>): Mscrm.Component;
        protected onInputFocus(): void;
        protected onInputBlur(): void;
        protected onInputChange(event: Event): void;
        protected onInputKeyDown(event: KeyboardEvent): void;
        protected onContainerPointerEnter(): void;
        protected onContainerPointerLeave(): void;
        protected onActionTrigger(): void;
        protected onPointerDownButton(): void;
        protected onButtonFocus(): void;
        protected onButtonBlur(): void;
        protected onButtonKeyDown(event: KeyboardEvent): void;
        defaultMode(): IModeDescriptor;
        isTransitionAllowed(from: IModeDescriptor, to: IModeDescriptor): boolean;
        transitionWillApply(from: IModeDescriptor, to: IModeDescriptor): void;
        transitionDidApply(from: IModeDescriptor, to: IModeDescriptor): void;
        protected isControlDisabled(): boolean;
    }
}
declare module MscrmControls.FieldControls {
    enum ModeDescriptorID {
        NONE = -1,
        REST = 1,
        HOVER = 2,
        ACTIVE = 3,
    }
    interface IModeTransitionDataSource {
        defaultMode(): IModeDescriptor;
    }
    interface IModeTransitionDelegate {
        isTransitionAllowed(from: IModeDescriptor, to: IModeDescriptor): boolean;
        transitionWillApply(from: IModeDescriptor, to: IModeDescriptor): void;
        transitionDidApply(from: IModeDescriptor, to: IModeDescriptor): void;
    }
    interface IModeDescriptor {
        id: number;
    }
    interface IModeTransitionManager {
        mode(): IModeDescriptor;
        resetManager(dataSource: IModeTransitionDataSource, delegate: IModeTransitionDelegate): void;
        requestTransitionTo(to: IModeDescriptor, forceAsync?: boolean): void;
    }
    class ModeTransitionManager implements IModeTransitionManager {
        private static _EMPTY_MODE;
        private _mode;
        private _transition;
        private _delegate;
        constructor();
        mode(): IModeDescriptor;
        resetManager(dataSource: IModeTransitionDataSource, delegate: IModeTransitionDelegate): void;
        requestTransitionTo(to: IModeDescriptor, forceAsync?: boolean): void;
        private static _isEmptyMode(candidate);
        private _flushTransition();
    }
}
declare module MscrmControls.FieldControls {
    class ThemingHelper {
        static isHeaderCell(scope: Mscrm.BaseProperty): boolean;
        static isFooterCell(scope: Mscrm.BaseProperty): boolean;
        static getCommonStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean, isIconAvailable?: boolean): {
            boxSizing: string;
            height: string;
            lineHeight: string;
            width: string;
            textOverflow: string;
            fontSize: string;
            fontWeight: number;
            color: string;
            paddingLeft: string;
            paddingRight: string;
            paddingTop: string;
            paddingBottom: string;
            marginLeft: string;
            marginRight: string;
            borderStyle: string;
            borderWidth: string;
        };
        static getDisableStyle(theming: Mscrm.Theme): {
            [key: string]: any;
        };
        static getEditModeStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean, isIconAvailable?: boolean): {
            [key: string]: any;
        };
        static getReadModeStyle(theming: Mscrm.Theme, deviceSizeMode: Mscrm.BaseProperty, scope: Mscrm.BaseProperty, isRTL: boolean, error: boolean, isControlDisabled?: boolean, isIconAvailable?: boolean): {
            [key: string]: any;
        };
        static getHeaderStyle(theming: Mscrm.Theme): {
            color: string;
            fontSize: string;
            fontFamily: string;
            fontWeight: number;
        };
        static getFooterStyle(theming: Mscrm.Theme): {
            fontWeight: number;
            color: string;
            fontSize: string;
            fontFamily: string;
            backgroundColor: string;
            ":hover": {
                backgroundColor: string;
                borderColor: string;
            };
        };
        static getActionIconStyle(theming: Mscrm.Theme, isRTL: boolean, error: boolean, isRestMode: boolean): {
            position: string;
            top: string;
            right: string;
            left: string;
            bottom: string;
            cursor: string;
            color: any;
            background: any;
            lineHeight: string;
            width: string;
            textAlign: string;
            paddingLeft: string;
            paddingRight: string;
            paddingTop: string;
            paddingBottom: string;
        };
        static getActionIconWidth(theming: Mscrm.Theme): string;
        static getOutlineStyle(theming: Mscrm.Theme): {
            outlineColor: string;
            outlineWidth: string;
            outlineStyle: string;
        };
        private static getHighContrastEnabled();
    }
}
declare module MscrmControls.FieldControls {
    interface INumberInputBag {
        value: Mscrm.NumberProperty;
        describedByElementId: Mscrm.StringProperty;
        deviceSizeMode: Mscrm.BaseProperty;
        scope: Mscrm.BaseProperty;
    }
    interface IOptionSetInputBag {
        value: Mscrm.BaseProperty;
        describedByElementId: Mscrm.StringProperty;
        deviceSizeMode: Mscrm.BaseProperty;
        scope: Mscrm.BaseProperty;
    }
    interface IActionInputBag {
        value: Mscrm.BaseProperty;
        describedByElementId: Mscrm.StringProperty;
        deviceSizeMode: Mscrm.BaseProperty;
        scope: Mscrm.BaseProperty;
    }
}
