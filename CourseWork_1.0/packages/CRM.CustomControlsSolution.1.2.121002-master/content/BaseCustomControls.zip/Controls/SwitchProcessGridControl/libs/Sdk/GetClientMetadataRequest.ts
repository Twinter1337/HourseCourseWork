﻿/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */

module MscrmControls.Containers {
	export class MetadataQuery {
		public MetadataType: string = null;
		public MetadataSubtype: string = null;
		public EntityLogicalName: string = null;
		public MetadataId: Mscrm.Guid = null;
		public MetadataName: string = null;
		public GetDefault = true;
		public DependencyDepth = 2;
		public ChangedAfter: Date = null;
		public Exclude: Mscrm.Guid[] = [];
		public AppId: string = null;

		constructor(metadataType: string, metadataSubType: string, entityLogicalName: string) {
			if (!metadataType || !metadataSubType) {
				throw new Error("Can't construct metadata query");
			}
			this.MetadataType = metadataType;
			this.MetadataSubtype = metadataSubType;
			this.EntityLogicalName = entityLogicalName;
		}

		public getMetadata() {
			return {
				boundParameter: null as string,
				parameterTypes: {
					MetadataType: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					MetadataSubtype: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					EntityLogicalName: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					MetadataId: {
						typeName: "Edm.Guid",
						structuralProperty: 1,
					},
					MetadataName: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					GetDefault: {
						typeName: "Edm.Boolean",
						structuralProperty: 1,
					},
					DependencyDepth: {
						typeName: "Microsoft.Dynamics.CRM.DependencyDepth",
						structuralProperty: 3,
						enumProperties: [
							{
								name: "Unknown",
								value: 0,
							},
							{
								name: "OnDemandWithContext",
								value: 1,
							},
							{
								name: "OnDemandWithoutContext",
								value: 2,
							},
							{
								name: "OnDemandContextOnly",
								value: 3,
							},
							{
								name: "Offline",
								value: 4,
							},
							{
								name: "Mobile",
								value: 5,
							},
						],
					},
					ChangedAfter: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					Exclude: {
						typeName: "Edm.Guid",
						structuralProperty: 4,
					},
					AppId: {
						typeName: "Edm.Guid",
						structuralProperty: 1,
					},
				},
				operationName: null as string,
				operationType: null as string,
			};
		}
	}

	export class GetClientMetadataRequest implements WebApi.ODataContract {
		public ClientMetadataQuery: MetadataQuery;

		constructor(metadataType: string, metadataSubType: string, entityLogicalName: string) {
			this.ClientMetadataQuery = new MetadataQuery(metadataType, metadataSubType, entityLogicalName);
		}

		public getMetadata() {
			return {
				boundParameter: null as string,
				parameterTypes: {
					ClientMetadataQuery: {
						typeName: "Microsoft.Dynamics.CRM.MetadataQuery",
						structuralProperty: 2,
					},
				},
				operationName: "GetClientMetadata",
				operationType: 1,
			};
		}
	}
}
