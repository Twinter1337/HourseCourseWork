/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
//import { Guid } from "Core/Utils/Guid";
//import { ODataContract, ODataContractMetadata } from "Storage/DataSource/WebAPISerialization/ODataRequest";

/* tslint:disable:crm-force-fields-private */
module MscrmControls.Containers {
	export class RetrieveProcessInstancesRequest implements WebApi.ODataContract {
		[parameter: string]: any;
		public EntityId: Guid;
		public EntityLogicalName: string;

		constructor(entityId: Guid, entityLogicalName: string) {
			this.EntityId = entityId;
			this.EntityLogicalName = entityLogicalName;
		}

		public getMetadata(): WebApi.ODataContractMetadata {
			const metadata: WebApi.ODataContractMetadata = {
				boundParameter: null,
				parameterTypes: {
					EntityId: {
						typeName: "Edm.Guid",
						structuralProperty: 1,
					},
					EntityLogicalName: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
				},
				operationName: "RetrieveProcessInstances",
				operationType: 1,
			};
			return metadata;
		}
	}
}
