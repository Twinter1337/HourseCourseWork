/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
//import { ODataContract, ODataContractMetadata } from "Storage/DataSource/WebAPISerialization/ODataRequest";

/* tslint:disable:crm-force-fields-private */
module MscrmControls.Containers {
	export class RetrieveFilteredProcessesRequest implements WebApi.ODataContract {
		[parameter: string]: any;
		public EntityLogicalName: string;
		public AppModuleId: Guid;

		constructor(entityLogicalName: string, appModuleId: Guid) {
			this.EntityLogicalName = entityLogicalName;
			this.AppModuleId = appModuleId;
		}

		public getMetadata(): WebApi.ODataContractMetadata {
			const metadata: WebApi.ODataContractMetadata = {
				boundParameter: null,
				parameterTypes: {
					EntityLogicalName: {
						typeName: "Edm.String",
						structuralProperty: 1,
					},
					AppModuleId: {
						typeName: "Edm.Guid",
						structuralProperty: 1,
					},
				},
				operationName: "RetrieveFilteredProcesses",
				operationType: 1,
			};
			return metadata;
		}
	}
}
