/// <reference path="../../../../../../src/Typings/jquery.d.ts" />
declare module MscrmControls.KbContentControl {
    class Constants {
        static ContentPaneArticleContentContainerPrefix: string;
        static ContentPaneTextResourceName: string;
    }
}
declare module MscrmControls.KbContentControl {
    interface IInputBag {
        record: Mscrm.IKbSearchRecord;
        quickview: Mscrm.SingleLineProperty;
    }
    interface IOutputBag {
    }
}
declare module MscrmControls.KbContentControl {
    class KbContentControl implements Mscrm.Control<IInputBag, IOutputBag> {
        private _context;
        private isHostedInQuickform;
        private contentKey;
        constructor();
        init(context: Mscrm.ControlData<IInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        updateView(context: Mscrm.ControlData<IInputBag>): Mscrm.Component;
        updateIframe(): void;
        setAnchorTagBindings(setHandlers: boolean, iFrame: HTMLIFrameElement): void;
        anchorClicked(evt: any): void;
        renderArticleContent(): Mscrm.Component;
        render(isPopupControl: boolean): Mscrm.Component;
        getOutputs(): Mscrm.ControlData<IOutputBag>;
        destroy(): void;
    }
}
