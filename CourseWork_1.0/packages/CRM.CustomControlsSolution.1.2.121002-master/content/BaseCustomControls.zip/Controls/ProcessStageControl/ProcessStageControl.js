/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var ProcessStageControl = (function () {
            function ProcessStageControl() {
                this._stageFlyout = new Containers.StageFlyout();
                this._stageDockContainer = new Containers.StageDockContainer();
            }
            ProcessStageControl.prototype._setExternalContext = function (context) {
                this.externalContext = context;
                ProcessStageControl.context = {
                    parameters: null,
                    children: this.externalContext.children,
                    client: this.externalContext.client,
                    factory: this.externalContext.factory,
                    formatting: this.externalContext.formatting,
                    mode: this.externalContext.mode,
                    navigation: this.externalContext.navigation,
                    refs: this.externalContext.refs,
                    resources: this.externalContext.resources,
                    theming: this.externalContext.theming,
                    updatedProperties: this.externalContext.updatedProperties,
                    utils: this.externalContext.utils,
                    offline: this.externalContext.offline,
                    webAPI: this.externalContext.webAPI,
                    externalContext: this.externalContext.externalContext,
                    orgSettings: this.externalContext.orgSettings,
                    userSettings: this.externalContext.userSettings,
                    accessibility: this.externalContext.accessibility,
                    page: this.externalContext.page,
                    device: this.externalContext.device,
                    reporting: this.externalContext.reporting,
                    learningPath: this.externalContext.learningPath,
                    performance: this.externalContext.performance,
                };
            };
            ProcessStageControl.prototype.init = function (context, notifyOutputChanged, state, container) {
            };
            ProcessStageControl.prototype.updateView = function (context) {
                this._setExternalContext(context);
                Containers.ProcessControlManager.Instance.init(this.externalContext.parameters.value.ProcessWrapper, ProcessStageControl.context, Containers.ControlMode.stage);
                if (context.parameters.value.ProcessWrapper && Containers.ProcessControlManager.Instance.isVisible()) {
                    var currentSelectedStageId = Containers.ProcessControlManager.Instance.getSelectedStageId();
                    if (currentSelectedStageId) {
                        if (Containers.ProcessControlManager.Instance.getDisplayState() === Containers.DisplayState.floating &&
                            !Containers.ProcessControlManager.Instance.getIsFormHeaderCollapsed()) {
                            return this._stageFlyout.render(currentSelectedStageId, this._closeStageFlyoutHandler.bind(this));
                        }
                        else if (Containers.ProcessControlManager.Instance.getDisplayState() === Containers.DisplayState.expanded) {
                            return this._stageDockContainer.render();
                        }
                    }
                }
                return ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "displayNoneStage",
                }, null);
            };
            ProcessStageControl.prototype.onPreNavigation = function () {
            };
            ProcessStageControl.prototype.getOutputs = function () {
                return null;
            };
            ProcessStageControl.prototype.destroy = function () {
            };
            ProcessStageControl.prototype._closeStageFlyoutHandler = function (event) {
                var navigationButtonId = Containers.ProcessControlManager.Instance.contextManager.getUniqueId(Containers.ControlMode.breadCrumb, "" + Containers.ContextManager.navigationButtonKey);
                var target = event.target;
                if (target && (target.id.indexOf(navigationButtonId) !== -1 || this._isElementPresentInStageFlyout(target))) {
                    return;
                }
                if (event.target &&
                    event.target.id &&
                    event.target.id.indexOf(Containers.StageFlyoutHeaderContainer.stageDockModeButton) != -1) {
                    Containers.ProcessControlManager.Instance.setDisplayState(Containers.DisplayState.expanded);
                }
                else {
                    Containers.ProcessControlManager.Instance.setDisplayState(Containers.DisplayState.collapsed);
                }
            };
            ProcessStageControl.prototype._isElementPresentInStageFlyout = function (target) {
                for (var i = 0; i < 50 && target; i++) {
                    if (target.id && target.id.indexOf(Containers.StageFlyoutHeaderContainer.businessProcessFlowControlName) !== -1) {
                        return true;
                    }
                    target = target.parentElement;
                }
                return false;
            };
            return ProcessStageControl;
        }());
        Containers.ProcessStageControl = ProcessStageControl;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var actionbuttonIconString = "actionButtonIcon";
        var ActionContainer = (function () {
            function ActionContainer() {
            }
            ActionContainer.prototype._getIconforStatus = function (status) {
                switch (status) {
                    case 0:
                    case 1:
                        return Containers.ProcessControlIconSymbol.None;
                    case 2:
                        return Containers.ProcessControlIconSymbol.Completed;
                    default:
                        return Containers.ProcessControlIconSymbol.Failure;
                }
            };
            ActionContainer.prototype.render = function (actionStepLabel, stepIdKey, index, controlId, actionId) {
                var actionLog = Containers.ProcessControlManager.Instance.getActionLog(actionId);
                var status = !!actionLog ? actionLog.status : 0;
                var icon = this._getIconforStatus(status);
                var actionLogToolTip = !!actionLog && !!actionLog.message ? actionLog.message : "";
                var iconColor = "";
                if (status === 2) {
                    iconColor = Containers.ProcessStageControl.context.theming.colors.basecolor.green["green4"];
                }
                else if (status === 3) {
                    iconColor = Containers.ProcessStageControl.context.theming.colors.basecolor.red["red3"];
                }
                var actionButtonIconStyle = {
                    transform: Containers.ProcessStageControl.context.client.isRTL ? "scale(-1,1)" : null,
                    alignSelf: "flex-start",
                    color: iconColor,
                    width: "1em",
                    height: "1em",
                    fontSize: "",
                };
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "actionContainer_" + stepIdKey,
                    id: "actionContainer_" + stepIdKey,
                    accessibilityLabel: "Action Step",
                    style: {
                        display: "flex",
                        flexBasis: "100%",
                        borderBottomColor: "#DDDDDD",
                        borderBottomWidth: "1px",
                        borderBottomStyle: "solid",
                        paddingBottom: "0.25em",
                        paddingTop: "0.25em",
                        alignItems: "baseline",
                        width: "100%",
                    },
                }, [
                    !!icon
                        ? new Containers.ProcessControlIcon().render(actionbuttonIconString, icon, function () { }, actionButtonIconStyle, "img", actionLogToolTip)
                        : null,
                    new Containers.ActionButton().render(actionStepLabel, stepIdKey, index, status, controlId, actionId, actionLogToolTip),
                ]);
            };
            return ActionContainer;
        }());
        Containers.ActionContainer = ActionContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var actionButtonName = "actionButton";
        var actionStepLabelContainerName = "actionStepLabelContainer";
        var actionStepLabelKey = "actionStepLabelKey";
        var businessProcessFlowControlName = "header_process";
        var businessProcessFlowControlPrefix = businessProcessFlowControlName + "_";
        var ActionButton = (function () {
            function ActionButton() {
            }
            ActionButton.prototype.render = function (actionStepLabel, stepIdKey, index, status, controlId, actionId, tooltip) {
                this._controlId = businessProcessFlowControlPrefix + controlId;
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "actionButton_" + stepIdKey,
                    id: "actionButton_" + stepIdKey,
                    style: {
                        flexDirection: "column",
                    },
                    accessibilityLabel: "ActionStep",
                }, [
                    this._renderActionStepLabel(actionStepLabel, stepIdKey, index),
                    this._renderActionButton(stepIdKey, index, status, actionStepLabel, tooltip),
                ]);
            };
            ActionButton.prototype._renderActionButton = function (stepIdKey, index, status, label, tooltip) {
                var _this = this;
                var telemetryComponent = "BPF.ActionStepButtonClick";
                var processing = status === 1;
                var disabled = processing || Containers.ProcessStageControl.context.mode.isOffline || this._isNewRecord();
                var actionButtonTooltip = Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.ActionStepExecute);
                var messageString = processing
                    ? Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.ProcessingActionStepData)
                    : Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.ActionStepExecute);
                return Containers.ProcessStageControl.context.factory.createElement("BUTTON", {
                    key: "actionButton_" + index + "_" + actionButtonName,
                    id: "actionButton_" + index + "_" + actionButtonName,
                    accessibilityLabel: ["Action Step", label, messageString, tooltip].join(" "),
                    onClick: function (event) {
                        var eventParameters = {};
                        eventParameters["ActionStepIdKey"] = stepIdKey;
                        Containers.ProcessStageControl.context.performance.addKeyPerformanceIndicatorOnIdle(telemetryComponent, eventParameters);
                        _this._clickHandler(event, actionButtonName);
                    },
                    style: this._getStyle(actionButtonName, disabled),
                    disabled: disabled,
                    title: actionButtonTooltip,
                }, messageString);
            };
            ActionButton.prototype._isNewRecord = function () {
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(Containers.ProcessStageControl.context.mode.contextInfo)) {
                    var entityId = Guid.tryParse(Containers.ProcessStageControl.context.mode.contextInfo.entityId);
                    if (entityId !== Guid.EMPTY) {
                        return false;
                    }
                }
                return true;
            };
            ActionButton.prototype._renderActionStepLabel = function (actionStepLabelName, stepIdKey, index) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "actionButton_" + index + "_" + stepIdKey + "_" + actionStepLabelContainerName,
                    id: "actionButton_" + index + "_" + stepIdKey + "_" + actionStepLabelContainerName,
                    style: {
                        paddingLeft: Containers.ProcessStageControl.context.client.isRTL
                            ? Containers.ProcessStageControl.context.theming.measures.measure125
                            : "0em",
                        paddingRight: Containers.ProcessStageControl.context.client.isRTL
                            ? "0em"
                            : Containers.ProcessStageControl.context.theming.measures.measure125,
                    },
                    accessibilityLabel: actionStepLabelName,
                }, Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                    key: actionStepLabelKey,
                    id: actionStepLabelKey,
                    style: {
                        marginBottom: "0.31rem",
                        marginLeft: "0.43rem",
                        color: Containers.StyleHelper.getShade(Shades.Grey6),
                    },
                }, actionStepLabelName));
            };
            ActionButton.prototype._getStyle = function (key, disabled) {
                var backgroundColor = disabled
                    ? Containers.StyleHelper.getShade(Shades.Grey4)
                    : Containers.StyleHelper.getShade(Shades.MainThemeDark);
                var textColor = disabled
                    ? Containers.StyleHelper.getShade(Shades.Grey6)
                    : Containers.StyleHelper.getShade(Shades.MainThemeDarkText);
                var style = {
                    backgroundColor: backgroundColor,
                    borderColor: "transparent",
                    justifyContent: "center",
                    alignItems: "center",
                    width: Containers.ProcessStageControl.context.theming.measures.measure550,
                    height: Containers.ProcessStageControl.context.theming.measures.measure150,
                    marginLeft: "0.437rem",
                    marginBottom: "0.31rem",
                    overflow: "hidden",
                    marginTop: Containers.ProcessControlManager.Instance.isMobileMode() ? "1.5em" : null,
                    cursor: disabled ? "default" : "pointer",
                    color: textColor,
                };
                return style;
            };
            ActionButton.prototype._clickHandler = function (event, actionButton) {
                Containers.ProcessControlManager.Instance.triggerActionStepClick(this._controlId);
            };
            return ActionButton;
        }());
        Containers.ActionButton = ActionButton;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var StringUtil = MscrmCommon.ControlUtils.String;
        var headerButtonsContainer = "flyoutHeaderButtonsContainer";
        var stageCloseButton = "stageContentClose";
        var stageStatusLabel = "stageStatus";
        var flyoutStageNameLabel = "flyoutStageName";
        var stageActiveForLabel = "stageActiveForStatus";
        var flyoutHeaderContainer = "businessProcessFlowFlyoutHeaderContainer";
        var stageNameContainerKey = "processStageStageNameContainer";
        var StageFlyoutHeaderContainer = (function () {
            function StageFlyoutHeaderContainer() {
            }
            StageFlyoutHeaderContainer.prototype._renderSelectedStageIcons = function (stageId) {
                var dockButton = null;
                var isStageLocked = Containers.ProcessControlManager.Instance.isStageLocked(stageId);
                if (!Containers.ProcessControlManager.Instance.isSelectedStage(stageId) ||
                    Containers.ProcessControlManager.Instance.getDisplayState() !== Containers.DisplayState.floating) {
                    return null;
                }
                if (!Containers.ProcessControlManager.Instance.isMobileMode()) {
                    var pinLabel = MscrmCommon.ControlUtils.String.Format(Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.Pin));
                    var dockButtonProps = {
                        key: StageFlyoutHeaderContainer.stageDockModeButton,
                        id: StageFlyoutHeaderContainer.stageDockModeButton,
                        style: this._getStyle(StageFlyoutHeaderContainer.stageDockModeButton),
                        role: "button",
                        tabIndex: 0,
                        accessibilityLabel: pinLabel,
                        title: pinLabel,
                        autoFocus: isStageLocked,
                        onClick: this._closeStageFlyoutHandler.bind(this),
                        onKeyDown: this._keyDownHandler.bind(this),
                    };
                    dockButtonProps[Containers.ProcessStageControl.context.learningPath.DOMAttributeName] =
                        Containers.ProcessStageControl.context.learningPath.baseControlId + "|" + dockButtonProps.id + "|" + stageId.guid;
                    dockButton = Containers.ProcessStageControl.context.factory.createElement("BUTTON", dockButtonProps, new Containers.ProcessControlIcon().render(StageFlyoutHeaderContainer.stageDockModeButton, Containers.ProcessControlIconSymbol.Dock));
                }
                var closeLabel = Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.Close);
                var closeBtnProps = {
                    key: stageCloseButton,
                    id: stageCloseButton,
                    style: this._getStyle(stageCloseButton),
                    role: "button",
                    tabIndex: 0,
                    accessibilityLabel: closeLabel,
                    title: closeLabel,
                    onClick: this._closeStageFlyoutHandler.bind(this),
                    onKeyDown: this._keyDownHandler.bind(this),
                };
                closeBtnProps[Containers.ProcessStageControl.context.learningPath.DOMAttributeName] =
                    Containers.ProcessStageControl.context.learningPath.baseControlId + "|" + closeBtnProps.id + "|" + stageId.guid;
                var closeButton = Containers.ProcessStageControl.context.factory.createElement("BUTTON", closeBtnProps, new Containers.ProcessControlIcon().render(stageCloseButton, Containers.ProcessControlIconSymbol.Close));
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: headerButtonsContainer,
                    style: this._getStyle(headerButtonsContainer),
                    id: headerButtonsContainer,
                }, [dockButton, closeButton]);
            };
            StageFlyoutHeaderContainer.prototype._getStyle = function (key) {
                var style = {};
                var isMobileMode = Containers.ProcessControlManager.Instance.isMobileMode();
                if (key === StageFlyoutHeaderContainer.stageDockModeButton || key === stageCloseButton) {
                    style = {
                        color: Containers.StyleHelper.getShade(Shades.Grey6),
                        cursor: "pointer",
                        padding: "0 0.5em 0 0.5em",
                        backgroundColor: "transparent",
                        borderWidth: "0px",
                    };
                    if (key === stageCloseButton) {
                        if (Containers.ProcessStageControl.context.client.isRTL) {
                            style.padding = "0 0.5em 0 0";
                        }
                        else {
                            style.padding = "0 0 0 0.5em";
                        }
                    }
                }
                else if (key === headerButtonsContainer) {
                    style = {
                        justifyContent: "flex-end",
                        paddingTop: "0.65em",
                        width: "40%",
                    };
                }
                else if (key === flyoutHeaderContainer) {
                    style = {
                        backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                        color: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                        borderBottomColor: Containers.StyleHelper.getShade(Shades.Grey3),
                        flexDirection: "row",
                        borderBottomWidth: "1px",
                        borderStyle: "solid",
                        height: "2.5em",
                        minHeight: "2.5em",
                        padding: "0 1em 0 1em",
                    };
                    if (isMobileMode) {
                        style.borderStyle = "none";
                        style.padding = "0 1.5em 0 1.5em";
                        style.height = "4em";
                        style.minHeight = "4em";
                    }
                }
                else if (key === stageStatusLabel) {
                    style = {
                        fontSize: Containers.StyleHelper.getStatusFontSize(),
                        fontFamily: Containers.ProcessStageControl.context.theming.fontfamilies.regular,
                    };
                    if (isMobileMode) {
                        style.color = Containers.StyleHelper.getShade(Shades.Black);
                        style.paddingTop = "0.25em";
                    }
                }
                else if (key === stageActiveForLabel) {
                    style = {
                        fontSize: Containers.StyleHelper.getStatusFontSize(),
                        fontFamily: Containers.ProcessStageControl.context.theming.fontfamilies.regular,
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                    };
                    if (isMobileMode) {
                        style.color = Containers.StyleHelper.getShade(Shades.Black);
                        style.paddingTop = "0.25em";
                    }
                }
                else if (key === stageNameContainerKey) {
                    style = {
                        color: Containers.StyleHelper.getShade(Shades.Grey6),
                        flexDirection: "row",
                        paddingTop: "0.75em",
                        width: "60%",
                    };
                    if (isMobileMode) {
                        style.flexDirection = "column";
                        style.paddingTop = "1em";
                    }
                }
                else if (key === flyoutStageNameLabel) {
                    style = {
                        fontSize: Containers.StyleHelper.getprocessNameFontSize(),
                        fontFamily: Containers.ProcessStageControl.context.theming.fontfamilies.semibold,
                        whiteSpace: "nowrap",
                    };
                    if (isMobileMode) {
                        style.overflow = "hidden";
                        style.textOverflow = "ellipsis";
                    }
                }
                return style;
            };
            StageFlyoutHeaderContainer.prototype._closeStageFlyoutHandler = function (event) {
                var dockButtonId = Containers.ProcessStageControl.context.accessibility.getUniqueId(StageFlyoutHeaderContainer.stageDockModeButton);
                if (event.target &&
                    (event.target.id && event.target.id.indexOf(dockButtonId) !== -1)) {
                    Containers.AccessibilityHelper.addDockedNotification = true;
                    Containers.ProcessControlManager.Instance.setDisplayState(Containers.DisplayState.expanded);
                }
                else {
                    this.closeFlyoutWithFocus();
                }
            };
            StageFlyoutHeaderContainer.prototype._renderStageStatus = function (stageId) {
                var stageStatus = Containers.ProcessControlManager.Instance.getStageStatusText(stageId);
                var isMobileMode = Containers.ProcessControlManager.Instance.isMobileMode();
                var stageName = Containers.ProcessControlManager.Instance.getStageName(stageId);
                var stageActiveForStatus = isMobileMode
                    ? StringUtil.Format("({0})", Containers.ProcessControlManager.Instance.getActiveStageActiveFor())
                    : Containers.ProcessControlManager.Instance.getActiveStageActiveFor();
                var stageHeaderElement;
                var stageStatusElement;
                var accessibilityLabelForStageStatus = stageStatus;
                if (isMobileMode) {
                    stageHeaderElement = Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                        key: flyoutStageNameLabel,
                        id: flyoutStageNameLabel,
                        style: this._getStyle(flyoutStageNameLabel),
                        role: "presentation",
                    }, stageName);
                }
                if (Containers.ProcessControlManager.Instance.getBPFStatus() !== 2 &&
                    Containers.ProcessControlManager.Instance.getActiveStageId().guid === stageId.guid) {
                    accessibilityLabelForStageStatus = stageActiveForStatus;
                    stageStatusElement = Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                        key: stageActiveForLabel,
                        id: stageActiveForLabel,
                        style: this._getStyle(stageActiveForLabel),
                        role: "presentation",
                    }, stageActiveForStatus);
                }
                else {
                    stageStatusElement = Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                        key: stageStatusLabel,
                        id: stageStatusLabel,
                        style: this._getStyle(stageStatusLabel),
                        role: "presentation",
                    }, stageStatus);
                }
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    id: stageNameContainerKey,
                    key: stageNameContainerKey,
                    style: this._getStyle(stageNameContainerKey),
                }, [stageHeaderElement, stageStatusElement]);
            };
            StageFlyoutHeaderContainer.prototype.render = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: flyoutHeaderContainer,
                    id: flyoutHeaderContainer,
                    style: this._getStyle(flyoutHeaderContainer),
                }, [this._renderStageStatus(stageId), this._renderSelectedStageIcons(stageId)]);
            };
            StageFlyoutHeaderContainer.prototype._keyDownHandler = function (event) {
                var element = event.currentTarget;
                switch (event.keyCode) {
                    case 13:
                        element.click();
                        break;
                }
            };
            StageFlyoutHeaderContainer.prototype.closeFlyoutWithFocus = function () {
                Containers.ProcessControlManager.Instance.setDisplayState(Containers.DisplayState.collapsed);
                if (StageFlyoutHeaderContainer._timer !== null) {
                    window.clearInterval(StageFlyoutHeaderContainer._timer);
                }
                StageFlyoutHeaderContainer._timer = window.setInterval(this._closeFlyoutHandler.bind(this), 300);
            };
            StageFlyoutHeaderContainer.prototype._closeFlyoutHandler = function () {
                if (Containers.ProcessControlManager.Instance.getIsFormHeaderCollapsed()) {
                    window.clearInterval(StageFlyoutHeaderContainer._timer);
                    StageFlyoutHeaderContainer._timer = null;
                }
                var selectedStageElementId = "processHeaderStage_" + Containers.ProcessControlManager.Instance.getSelectedStageId().guid;
                var selectedStage = document.getElementById(Containers.ProcessControlManager.Instance.contextManager.getUniqueId(Containers.ControlMode.breadCrumb, selectedStageElementId));
                if (selectedStage) {
                    if (selectedStage.hasAttribute("tabIndex")) {
                        window.clearInterval(StageFlyoutHeaderContainer._timer);
                        StageFlyoutHeaderContainer._timer = null;
                        selectedStage.focus();
                    }
                }
            };
            StageFlyoutHeaderContainer.stageDockModeButton = "stageDockModeButton";
            StageFlyoutHeaderContainer.businessProcessFlowControlName = "header_process";
            return StageFlyoutHeaderContainer;
        }());
        Containers.StageFlyoutHeaderContainer = StageFlyoutHeaderContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var buttonInnerContainer = "buttonInnerContainer";
        var nextButtonContainerName = "nextButtonContainer";
        var previousButtonContainerName = "previousButtonContainer";
        var finishButtonContainerName = "finishButtonContainer";
        var setActiveButtonContainerName = "setActiveButtonContainer";
        var finishedLabelContainerName = "finishedLabelContainer";
        var stageButtonLabelName = "stageButtonLabelName";
        var StageButtons = (function () {
            function StageButtons() {
                this._stageButtonIcon = new Containers.ProcessControlIcon();
                this._crossEntityFlyout = new Containers.CrossEntityFlyout();
                this._clickPromise = null;
                this._isClickPromisePending = true;
            }
            StageButtons.prototype.render = function (stageId) {
                this._stageId = stageId;
                var stageButtons = [];
                var isCreateCase = !Containers.ProcessControlManager.Instance.getCurrentEntity().Id ||
                    Guid.EMPTY.toString() === Containers.ProcessControlManager.Instance.getCurrentEntity().Id.toString();
                if (isCreateCase) {
                    return stageButtons;
                }
                if (Containers.ProcessStageControl.context.client.getClient() == "Mobile" &&
                    Containers.ProcessStageControl.context.client.isOffline() &&
                    !this._isCrossEntityBPFSupportedInOffline() &&
                    this._isCrossEntityBpFInOffline()) {
                    return stageButtons;
                }
                if (Containers.ProcessControlManager.Instance.isBusinessProcessCompleted()) {
                    if (Containers.ProcessControlManager.Instance.isLastStage(stageId)) {
                        if (!(Containers.ProcessStageControl.context.client.getClient() == "Mobile" &&
                            Containers.ProcessStageControl.context.client.isOffline())) {
                            stageButtons.push(this._renderStageButton(Containers.ResourceStrings.Finished, finishedLabelContainerName, Containers.ProcessControlIconSymbol.CheckMark));
                        }
                    }
                }
                else if (Containers.ProcessControlManager.Instance.isActiveStage(stageId)) {
                    if (!Containers.ProcessControlManager.Instance.isFirstStage(stageId)) {
                        stageButtons.push(this._renderStageButton(Containers.ResourceStrings.Back, previousButtonContainerName, Containers.ProcessControlIconSymbol.Previous));
                    }
                    if (Containers.ProcessControlManager.Instance.isLastStage(stageId)) {
                        if (!(Containers.ProcessStageControl.context.client.getClient() == "Mobile" &&
                            Containers.ProcessStageControl.context.client.isOffline())) {
                            stageButtons.push(this._renderStageButton(Containers.ResourceStrings.Finish, finishButtonContainerName, Containers.ProcessControlIconSymbol.Flag));
                        }
                    }
                    else {
                        var currentStageRelatedEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(Containers.ProcessControlManager.Instance.getActiveStageId());
                        var nextStageRelatedEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(Containers.ProcessControlManager.Instance.getNextStage().id);
                        if (!(Containers.ProcessStageControl.context.client.getClient() == "Mobile" &&
                            Containers.ProcessStageControl.context.client.isOffline()) ||
                            (!currentStageRelatedEntityReference ||
                                !nextStageRelatedEntityReference ||
                                currentStageRelatedEntityReference.LogicalName === nextStageRelatedEntityReference.LogicalName)) {
                            stageButtons.push(this._renderStageButton(Containers.ResourceStrings.Advance, nextButtonContainerName, Containers.ProcessControlIconSymbol.Next));
                            if (this._crossEntityFlyoutShouldBeRendered(Containers.ProcessControlIconSymbol.Next)) {
                                var nextButtonContainerElement = document.getElementById(Containers.ProcessStageControl.context.accessibility.getUniqueId(nextButtonContainerName));
                                if (nextButtonContainerElement && nextButtonContainerElement.clientWidth) {
                                    Containers.StyleHelper.setCrossEntityFlyoutWidth(nextButtonContainerElement.getClientRects()[0].width);
                                }
                            }
                            this._crossEntityFlyoutShouldBeRendered(Containers.ProcessControlIconSymbol.Next)
                                ? stageButtons.push(this._crossEntityFlyout.render(nextButtonContainerName))
                                : null;
                        }
                    }
                }
                else {
                    var activeStageIndex = Containers.ProcessControlManager.Instance.getStageIndex(Containers.ProcessControlManager.Instance.getActiveStageId());
                    var selectedStageIndex = Containers.ProcessControlManager.Instance.getStageIndex(stageId);
                    if (selectedStageIndex < activeStageIndex) {
                        stageButtons.push(this._renderStageButton(Containers.ResourceStrings.SetActive, setActiveButtonContainerName, null));
                    }
                }
                return stageButtons;
            };
            StageButtons.prototype._isCrossEntityBpFInOffline = function () {
                var activePath = Containers.ProcessControlManager.Instance.getActivePath();
                for (var index = 0; index < activePath.length - 1 && 0 < activePath.length; index++) {
                    var currentStageRelatedEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(activePath[index]);
                    var nextStageRelatedEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(activePath[index + 1]);
                    if (currentStageRelatedEntityReference &&
                        nextStageRelatedEntityReference &&
                        currentStageRelatedEntityReference.LogicalName !== nextStageRelatedEntityReference.LogicalName) {
                        return true;
                    }
                }
                return false;
            };
            StageButtons.prototype._isCrossEntityBPFSupportedInOffline = function () {
                var leadToOpportunitySalesProcessBPFId = "919E14D1-6489-4852-ABD0-A63A6ECAAC5D";
                return Containers.ProcessControlManager.Instance.getBPFId().guid.toUpperCase() == leadToOpportunitySalesProcessBPFId;
            };
            StageButtons.prototype._renderStageButton = function (stageButton, stageButtonContainerName, stageButtonIcon) {
                var _this = this;
                var telemetryComponent = "BPF.StageButtonClick";
                var stageButtonName = stageButton !== null ? Containers.ProcessControlIconSymbol[stageButtonIcon] : "";
                var stageButtonIconName = stageButtonName + "Icon";
                var stageButtonIconStyle = {};
                if (Containers.ProcessStageControl.context.client.isRTL &&
                    (stageButtonIcon === Containers.ProcessControlIconSymbol.Next || stageButtonIcon === Containers.ProcessControlIconSymbol.Previous)) {
                    stageButtonIconStyle.transform = "scale(-1,1)";
                }
                if (this._crossEntityFlyoutShouldBeRendered(Containers.ProcessControlIconSymbol.Next) &&
                    stageButtonContainerName === nextButtonContainerName) {
                    stageButtonIconStyle.transform = "rotate(90deg)";
                }
                if (this._crossEntityFlyoutShouldBeRendered(Containers.ProcessControlIconSymbol.Next) &&
                    stageButtonContainerName === nextButtonContainerName &&
                    !Containers.StyleHelper.isEnoughSpaceAvailableForFlyout(nextButtonContainerName, Containers.ControlMode.stage, 190)) {
                    stageButtonIconStyle.transform = "rotate(-90deg)";
                }
                var isButton = stageButton !== Containers.ResourceStrings.Finished;
                var enableEvents = isButton && Containers.ProcessControlManager.Instance.isBusinessProcessDisabled();
                var stageButtonLabel = Containers.ResourceStrings.getResourceString(stageButton);
                var stageBtnProps = {
                    key: stageButtonContainerName,
                    id: stageButtonContainerName,
                    tabIndex: 0,
                    role: isButton ? "button" : null,
                    accessibilityLabel: stageButtonLabel,
                    title: Containers.ProcessStageControl.context.client.getClient() == "Mobile" ? "" : stageButtonLabel,
                    onClick: enableEvents
                        ? null
                        : function (event) {
                            _this._clickHandler(event, stageButton);
                            var eventParameters = {};
                            eventParameters["StageButtonName"] = stageButton;
                            eventParameters["StageId"] = Guid.toString(_this._stageId);
                            Containers.ProcessStageControl.context.performance.addKeyPerformanceIndicatorOnIdle(telemetryComponent, eventParameters);
                        },
                    onKeyDown: enableEvents ? null : this._keyDownHandler.bind(this),
                    style: this._getStyle(stageButtonContainerName),
                };
                stageBtnProps[Containers.ProcessStageControl.context.learningPath.DOMAttributeName] =
                    Containers.ProcessStageControl.context.learningPath.baseControlId + "|" + stageBtnProps.id;
                return Containers.ProcessStageControl.context.factory.createElement(stageButton === Containers.ResourceStrings.Finished ? "CONTAINER" : "BUTTON", stageBtnProps, Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    id: "" + stageButtonContainerName + buttonInnerContainer,
                    key: "" + stageButtonContainerName + buttonInnerContainer,
                    style: {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        width: "100%",
                    },
                }, [
                    this._renderStageButtonLabel(stageButton),
                    stageButtonIcon !== null
                        ? this._stageButtonIcon.render(stageButtonIconName, stageButtonIcon, function () { }, stageButtonIconStyle, null)
                        : null,
                ]));
            };
            StageButtons.prototype._renderStageButtonLabel = function (stageButton) {
                if (stageButton === Containers.ResourceStrings.Back) {
                    return null;
                }
                return Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                    key: Containers.ResourceStrings.getResourceString(stageButton),
                    id: Containers.ResourceStrings.getResourceString(stageButton),
                    style: this._getStyle(stageButtonLabelName),
                }, Containers.ResourceStrings.getResourceString(stageButton));
            };
            StageButtons.prototype._getStyle = function (key) {
                var backgroundColor = Containers.StyleHelper.getShade(Containers.ProcessControlManager.Instance.isBusinessProcessDisabled() ? Shades.Grey6 : Shades.MainThemeDark);
                var style = {
                    backgroundColor: backgroundColor,
                    justifyContent: "center",
                    alignItems: "center",
                    width: "100%",
                    height: "2.5em",
                    marginTop: Containers.ProcessControlManager.Instance.isMobileMode() ? "1.5em" : null,
                    cursor: "pointer",
                    borderWidth: Containers.StyleHelper.borderWidth + "px",
                    borderColor: Containers.StyleHelper.getShade(Shades.Transparent),
                    borderStyle: "solid",
                    boxSizing: "border-box",
                    color: Containers.StyleHelper.getShade(Containers.ProcessControlManager.Instance.isBusinessProcessDisabled() ? Shades.WhiteBackGround : Shades.MainThemeDarkText),
                    ":hover": {
                        backgroundColor: Containers.StyleHelper.getShade(Shades.MainThemeColor3),
                        color: Containers.StyleHelper.getShade(Shades.MainThemeColor3Text),
                    },
                    ":focus": {
                        backgroundColor: Containers.StyleHelper.getShade(Shades.MainThemeColor3),
                        color: Containers.StyleHelper.getShade(Shades.MainThemeColor3Text),
                    },
                };
                if (key === previousButtonContainerName) {
                    style.width = "2.5em";
                    style.backgroundColor = Containers.StyleHelper.getShade(Containers.ProcessControlManager.Instance.isBusinessProcessDisabled() ? Shades.Grey6 : Shades.MainThemeLight);
                    style.color = Containers.StyleHelper.getShade(Containers.ProcessControlManager.Instance.isBusinessProcessDisabled()
                        ? Shades.WhiteBackGround
                        : Shades.MainThemeLightText);
                    style.borderColor = Containers.StyleHelper.getShade(Containers.ProcessControlManager.Instance.isBusinessProcessDisabled() ? Shades.Grey6 : Shades.MainThemeLight);
                }
                else if (key === finishedLabelContainerName) {
                    style.backgroundColor = Containers.StyleHelper.getShade(Shades.Green);
                    style.color = Containers.StyleHelper.getShade(Shades.WhiteBackGround);
                    style.cursor = "default";
                    style.borderColor = Containers.StyleHelper.getShade(Shades.Green);
                    (style[":hover"] = {
                        backgroundColor: Containers.StyleHelper.getShade(Shades.Green),
                        color: Containers.StyleHelper.getShade(Shades.MainThemeColor3Text),
                    }),
                        (style[":focus"] = {
                            backgroundColor: Containers.StyleHelper.getShade(Shades.Green),
                            color: Containers.StyleHelper.getShade(Shades.MainThemeColor3Text),
                        });
                }
                else if (key === stageButtonLabelName) {
                    if (Containers.ProcessStageControl.context.client.isRTL) {
                        return {
                            cursor: "inherit",
                            paddingLeft: "1em",
                        };
                    }
                    else {
                        return {
                            cursor: "inherit",
                            paddingRight: "1em",
                            fontFamily: Containers.ProcessControlManager.Instance.isMobileMode()
                                ? Containers.ProcessStageControl.context.theming.fontfamilies.semibold
                                : "",
                        };
                    }
                }
                return style;
            };
            StageButtons.prototype._keyDownHandler = function (event) {
                var element = event.currentTarget;
                switch (event.keyCode) {
                    case 13:
                        element.click();
                        break;
                }
            };
            StageButtons.prototype._crossEntityFlyoutShouldBeRendered = function (stageButton) {
                return Containers.ProcessControlManager.Instance.isCrossEntityFlyoutOpen() && stageButton === Containers.ProcessControlIconSymbol.Next;
            };
            StageButtons.prototype._clickHandler = function (event, stageButton) {
                var _this = this;
                if (this._clickPromise && this._isClickPromisePending) {
                    return;
                }
                if (Containers.ProcessControlManager.Instance.isBusinessProcessDisabled()) {
                    return;
                }
                Containers.ProcessControlManager.Instance.waitForOngoingWork().then(function () {
                    _this._onClickActions(event, stageButton);
                }, function (error) {
                    _this._onClickActions(event, stageButton);
                });
            };
            StageButtons.prototype._onClickActions = function (event, stageButton) {
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(Containers.ProcessControlManager.Instance)) {
                    MscrmCommon.ErrorHandling.ExceptionHandler.throwException("ProcessControlManager cannot be null");
                }
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(Containers.ProcessControlManager.Instance.getBPFInstanceId())) {
                    MscrmCommon.ErrorHandling.ExceptionHandler.throwException("processInstanceId cannot be null");
                }
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(Containers.ProcessControlManager.Instance.getBPFId())) {
                    MscrmCommon.ErrorHandling.ExceptionHandler.throwException("processId cannot be null");
                }
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(this._stageId)) {
                    MscrmCommon.ErrorHandling.ExceptionHandler.throwException("stageId cannot be null");
                }
                var processInstanceId = Containers.ProcessControlManager.Instance.getBPFInstanceId().guid;
                var processId = Containers.ProcessControlManager.Instance.getBPFId().guid;
                var selectedStageId = this._stageId.guid;
                if (stageButton === Containers.ResourceStrings.Advance && Containers.ProcessControlManager.Instance.validateRequiredFields()) {
                    var currentStageId = Containers.ProcessControlManager.Instance.getActiveStageId();
                    var currentStageRelatedEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(currentStageId);
                    var nextStageId = Containers.ProcessControlManager.Instance.getNextStage().id;
                    var nextStageRelatedEntityReference_1 = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(nextStageId);
                    if (!currentStageRelatedEntityReference ||
                        !nextStageRelatedEntityReference_1 ||
                        currentStageRelatedEntityReference.LogicalName === nextStageRelatedEntityReference_1.LogicalName) {
                        this._clickPromise = Containers.ProcessControlManager.Instance.moveToNextStage();
                    }
                    else {
                        if (nextStageRelatedEntityReference_1.Id.toString() != Guid.EMPTY.toString() &&
                            this._isClosedLoopForCrossEntityNavigation(currentStageId, nextStageId)) {
                            var processId_1 = Containers.ProcessControlManager.Instance.getBPFId();
                            var processInstanceId_1 = Containers.ProcessControlManager.Instance.getBPFInstanceId();
                            Containers.ProcessControlManager.Instance.getNavigateToNextEntityPromise(nextStageRelatedEntityReference_1).then(function (response) {
                                var formOptions = {
                                    entityName: nextStageRelatedEntityReference_1.LogicalName,
                                    entityId: nextStageRelatedEntityReference_1.Id.toString(),
                                };
                                Containers.ProcessControlManager.Instance.contextManager.context().navigation.openForm(formOptions);
                            });
                        }
                        else {
                            Containers.ProcessControlManager.Instance.setCrossEntityDisplayState(Containers.DisplayState.floating);
                            Containers.ProcessControlManager.Instance.getForwardNavigationEntitiesPromise().then(function (response) {
                                Containers.ProcessControlManager.Instance.forwardNavigationEntitiesData = response;
                                Containers.ProcessStageControl.context.utils.requestRender();
                            });
                            event.stopPropagation();
                            return;
                        }
                    }
                }
                else if (stageButton === Containers.ResourceStrings.Finish) {
                    if (Containers.ProcessControlManager.Instance.validateRequiredFields()) {
                        this._clickPromise = Containers.ProcessControlManager.Instance.completeProcess();
                    }
                }
                else if (stageButton === Containers.ResourceStrings.SetActive) {
                    this._clickPromise = Containers.ProcessControlManager.Instance.setActiveStage(this._stageId);
                    if (Containers.ProcessControlManager.Instance.isCrossEntityNavigation(false)) {
                        var selectedStageEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(this._stageId);
                        this._openCrossEntity(this._clickPromise, processInstanceId, processId, selectedStageId, selectedStageEntityReference);
                        return;
                    }
                }
                else if (stageButton === Containers.ResourceStrings.Back) {
                    this._clickPromise = Containers.ProcessControlManager.Instance.moveToPreviousStage();
                    if (Containers.ProcessControlManager.Instance.isCrossEntityNavigation(false)) {
                        var previousStageId = Containers.ProcessControlManager.Instance.getNextOrPreviousSelectedStageId(false, Containers.ProcessControlManager.Instance.getActiveStageId());
                        var selectedStageEntityReference = Containers.ProcessControlManager.Instance.getStageRelatedEntityReference(previousStageId);
                        this._openCrossEntity(this._clickPromise, processInstanceId, processId, previousStageId.guid, selectedStageEntityReference);
                        return;
                    }
                }
                this._setActionNotificationAndFlag(this._clickPromise);
            };
            StageButtons.prototype._openCrossEntity = function (promise, processInstanceId, processId, selectedStageId, selectedStageEntityReference) {
                promise.then(function (response) {
                    var formOptions = {
                        entityName: selectedStageEntityReference.LogicalName,
                        entityId: selectedStageEntityReference.Id.toString(),
                        processInstanceId: processInstanceId,
                        processId: processId,
                        selectedStageId: selectedStageId,
                        isCrossEntityNavigate: true,
                    };
                    Containers.ProcessControlManager.Instance.contextManager.context().navigation.openForm(formOptions);
                }, function (error) {
                    if (error) {
                        Containers.ProcessStageControl.context.navigation.openErrorDialog(error);
                    }
                });
            };
            StageButtons.prototype._setActionNotificationAndFlag = function (promise) {
                var _this = this;
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(promise)) {
                    promise.then(function (response) {
                        var stageName = Containers.ProcessControlManager.Instance.getStageName(Containers.ProcessControlManager.Instance.getActiveStageId());
                        var notifticationString = Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.NarratorNotification);
                        Containers.ProcessControlManager.Instance.setNarratorNotification(MscrmCommon.ControlUtils.String.Format(notifticationString, stageName));
                        _this._isClickPromisePending = false;
                    }, function (error) {
                        Containers.ProcessControlManager.Instance.contextManager
                            .context()
                            .utils.setNotification(Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.RequiredStepWarningMesage), _this._stageId.toString());
                        Containers.ProcessStageControl.context.navigation.openErrorDialog(error);
                        _this._isClickPromisePending = false;
                    });
                }
            };
            StageButtons.prototype._isClosedLoopForCrossEntityNavigation = function (currentStageId, nextStageId) {
                var activePath = Containers.ProcessControlManager.Instance.getActivePath();
                var nextStageEntityLogicalName = Containers.ProcessControlManager.Instance.getStageEntityName(nextStageId);
                var currentStageEntityLogicalName = Containers.ProcessControlManager.Instance.getStageEntityName(currentStageId);
                if (nextStageEntityLogicalName === currentStageEntityLogicalName) {
                    return false;
                }
                var i = 0;
                for (; i < activePath.length && activePath[i].guid !== Guid.toString(nextStageId); i++)
                    ;
                if (activePath.length === i) {
                    return false;
                }
                i--;
                for (; i >= 0; i--) {
                    var stage = activePath[i];
                    if (Containers.ProcessControlManager.Instance.getStageEntityName(Guid.tryParse(stage.guid)) === nextStageEntityLogicalName) {
                        return true;
                    }
                }
                return false;
            };
            return StageButtons;
        }());
        Containers.StageButtons = StageButtons;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockFooterContainer = "stageDockFooterContainer";
        var StageDockFooterContainer = (function () {
            function StageDockFooterContainer() {
                this._stageButtons = new Containers.StageButtons();
            }
            StageDockFooterContainer.prototype.render = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: stageDockFooterContainer,
                    id: stageDockFooterContainer,
                    style: {
                        backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                        color: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                        height: "35px",
                        margin: "25px 0px",
                    },
                }, this._stageButtons.render(stageId));
            };
            return StageDockFooterContainer;
        }());
        Containers.StageDockFooterContainer = StageDockFooterContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockColumnContainer = "stageDockColumnContainer";
        var StageDockColumn = (function () {
            function StageDockColumn() {
            }
            StageDockColumn.prototype.render = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("SCROLLCONTAINER", {
                    id: stageDockColumnContainer + "_" + stageId.guid,
                    key: stageDockColumnContainer + "_" + stageId.guid,
                    style: this._getStyle(),
                }, Containers.ProcessRenderingUtils.renderFieldSectionItems(stageId));
            };
            StageDockColumn.prototype._getStyle = function () {
                return {
                    backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                    overflowY: "auto",
                    overflowX: "hidden",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    paddingBottom: "2em",
                    alignContent: "stretch",
                    maxHeight: "80%",
                };
            };
            return StageDockColumn;
        }());
        Containers.StageDockColumn = StageDockColumn;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockInnerContainer = "stageDockInnerContainer";
        var StageDockContainer = (function () {
            function StageDockContainer() {
                this._stageDockCancelContainer = new Containers.StageDockCancelContainer();
                this._stageDockColumn = new Containers.StageDockColumn();
                this._stageDockHeaderContainer = new Containers.StageDockHeaderContainer();
                this._stageDockFooterContainer = new Containers.StageDockFooterContainer();
            }
            StageDockContainer.prototype.render = function () {
                var dockStyle = {
                    backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                    maxWidth: "320px",
                    minWidth: "320px",
                    justifyContent: "space-around",
                };
                var borderStyle = Containers.ProcessStageControl.context.theming.borders.border02;
                if (Containers.ProcessStageControl.context.client.isRTL) {
                    dockStyle.borderRight = borderStyle;
                }
                else {
                    dockStyle.borderLeft = borderStyle;
                }
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: Containers.StyleHelper.stageDockContainer,
                    id: Containers.StyleHelper.stageDockContainer,
                    role: "region",
                    labelledByElementId: Containers.ProcessStageControl.context.accessibility.getUniqueId("" + Containers.StageDockHeaderContainer.stageDockStageNameContainer + Containers.StageDockHeaderNameContainer.stageDockHeaderNameLabelName),
                    style: dockStyle,
                    onClick: this._clickHandler.bind(this),
                }, this._renderStageDockContainer());
            };
            StageDockContainer.prototype._clickHandler = function (event) {
                if (Containers.ProcessControlManager.Instance.isCrossEntityFlyoutOpen()) {
                    Containers.ProcessControlManager.Instance.setCrossEntityDisplayState(Containers.DisplayState.collapsed);
                    Containers.ProcessStageControl.context.utils.requestRender();
                }
            };
            StageDockContainer.prototype._renderStageDockContainer = function () {
                var selectedStageId = Containers.ProcessControlManager.Instance.getSelectedStageId();
                var isTabletMode = Containers.ProcessControlManager.Instance.isTabletMode();
                if (!Containers.ProcessControlManager.Instance.getStageIndex(selectedStageId)) {
                    return null;
                }
                Containers.ProcessStageFocusHandler._setFocus(selectedStageId);
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: stageDockInnerContainer,
                    id: stageDockInnerContainer,
                    style: {
                        flexDirection: "column",
                        minWidth: "250px",
                        width: "100%",
                        paddingLeft: "1em",
                        paddingRight: "1em",
                        borderWidth: Containers.StyleHelper.borderWidth + "px",
                        borderColor: Containers.StyleHelper.getShade(Shades.Transparent),
                        borderStyle: "solid",
                        boxSizing: "border-box",
                    },
                }, [
                    this._stageDockCancelContainer.render(),
                    this._stageDockHeaderContainer.render(selectedStageId),
                    this._stageDockColumn.render(selectedStageId),
                    this._stageDockFooterContainer.render(selectedStageId),
                ]);
            };
            return StageDockContainer;
        }());
        Containers.StageDockContainer = StageDockContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockHeaderContainer = "stageDockHeaderContainer";
        var stageDockProcessNameContainer = "stageDockProcess";
        var StageDockHeaderContainer = (function () {
            function StageDockHeaderContainer() {
                this._stageDockHeaderNameContainer = new Containers.StageDockHeaderNameContainer();
            }
            StageDockHeaderContainer.prototype.render = function (stageId) {
                var processName = Containers.ProcessControlManager.Instance.getBPFName();
                var stageName = Containers.ProcessControlManager.Instance.getStageName(stageId) +
                    " " +
                    Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.Stage);
                var processStatus = Containers.ProcessControlManager.Instance.getBpfInstanceActiveFor();
                var stageStatus = "";
                if (Containers.ProcessControlManager.Instance.getBPFStatus() !== 2 &&
                    Containers.ProcessControlManager.Instance.getActiveStageId().guid === stageId.guid) {
                    stageStatus = Containers.ProcessControlManager.Instance.getActiveStageActiveFor();
                }
                else {
                    stageStatus = Containers.ProcessControlManager.Instance.getStageStatusText(stageId);
                }
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    id: stageDockHeaderContainer + "_" + stageId.guid,
                    key: stageDockHeaderContainer + "_" + stageId.guid,
                    style: {
                        flexDirection: "column",
                        minHeight: "5em",
                    },
                }, [
                    this._stageDockHeaderNameContainer.render(processName, processStatus, stageDockProcessNameContainer),
                    this._stageDockHeaderNameContainer.render(stageName, stageStatus, StageDockHeaderContainer.stageDockStageNameContainer),
                ]);
            };
            StageDockHeaderContainer.stageDockStageNameContainer = "stageDockStage";
            return StageDockHeaderContainer;
        }());
        Containers.StageDockHeaderContainer = StageDockHeaderContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockCancelContainer = "stageDockCancelContainer";
        var stageDockCancelButton = "stageDockCancelButton";
        var stageDockCancelIcon = "stageDockCancelIcon";
        var StageDockCancelContainer = (function () {
            function StageDockCancelContainer() {
                this.stageDockCancelIcon = new Containers.ProcessControlIcon();
            }
            StageDockCancelContainer.prototype.render = function () {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "" + stageDockCancelContainer,
                    id: "" + stageDockCancelContainer,
                    style: {
                        paddingTop: "1em",
                        flexDirection: "row-reverse",
                        paddingBottom: "0.5em",
                    },
                }, this._renderCancelButton());
            };
            StageDockCancelContainer.prototype._renderCancelButton = function () {
                var dockCancelButtonHandler = function () {
                    new Containers.StageFlyoutHeaderContainer().closeFlyoutWithFocus();
                };
                var cancelLabel = Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.Close);
                return Containers.ProcessStageControl.context.factory.createElement("BUTTON", {
                    key: stageDockCancelButton,
                    id: stageDockCancelButton,
                    accessibilityLabel: cancelLabel,
                    title: cancelLabel,
                    tabIndex: 0,
                    style: {
                        backgroundColor: "transparent",
                        borderWidth: "0px",
                        cursor: "pointer",
                        padding: "0px",
                        color: "inherit",
                    },
                    onClick: dockCancelButtonHandler.bind(this),
                }, this.stageDockCancelIcon.render(stageDockCancelIcon, Containers.ProcessControlIconSymbol.Close));
            };
            return StageDockCancelContainer;
        }());
        Containers.StageDockCancelContainer = StageDockCancelContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageDockHeaderNameContainer = "NameContainer";
        var stageDockHeaderStatusLabelName = "StatusLabel";
        var StageDockHeaderNameContainer = (function () {
            function StageDockHeaderNameContainer() {
            }
            StageDockHeaderNameContainer.prototype.render = function (headerName, headerStatus, containerName) {
                this._stageDockContainerName = containerName;
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    id: "" + containerName + stageDockHeaderNameContainer,
                    key: "" + containerName + stageDockHeaderNameContainer,
                    style: this._getStyle(stageDockHeaderNameContainer),
                }, [this._renderHeaderName(headerName), this._renderHeaderStatus(headerStatus)]);
            };
            StageDockHeaderNameContainer.prototype._renderHeaderName = function (headerName) {
                return new Containers.ProcessHeaderNameLabel().render("" + this._stageDockContainerName + StageDockHeaderNameContainer.stageDockHeaderNameLabelName, headerName, {
                    id: "" + this._stageDockContainerName + StageDockHeaderNameContainer.stageDockHeaderNameLabelName,
                    key: "" + this._stageDockContainerName + StageDockHeaderNameContainer.stageDockHeaderNameLabelName,
                    title: headerName,
                    style: this._getStyle(StageDockHeaderNameContainer.stageDockHeaderNameLabelName),
                });
            };
            StageDockHeaderNameContainer.prototype._renderHeaderStatus = function (headerStatus) {
                return new Containers.ProcessHeaderNameLabel().render("" + this._stageDockContainerName + stageDockHeaderStatusLabelName, headerStatus, {
                    id: "" + this._stageDockContainerName + stageDockHeaderStatusLabelName,
                    key: "" + this._stageDockContainerName + stageDockHeaderStatusLabelName,
                    title: headerStatus,
                    style: this._getStyle(stageDockHeaderStatusLabelName),
                });
            };
            StageDockHeaderNameContainer.prototype._getStyle = function (key) {
                var style = {};
                if (key === stageDockHeaderNameContainer) {
                    style = {
                        color: Containers.StyleHelper.getShade(Shades.AccentDark),
                        flexDirection: "row",
                        paddingBottom: ".75em",
                        paddingTop: "0.28em",
                    };
                }
                else if (key === StageDockHeaderNameContainer.stageDockHeaderNameLabelName) {
                    style = {
                        fontSize: Containers.StyleHelper.getprocessNameFontSize(),
                        fontFamily: Containers.ProcessStageControl.context.theming.fontfamilies.semibold,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        width: "50%",
                    };
                }
                else if (key === stageDockHeaderStatusLabelName) {
                    style = {
                        color: Containers.StyleHelper.getShade(Shades.Grey7),
                        fontSize: Containers.StyleHelper.getStatusFontSize(),
                        fontFamily: Containers.StyleHelper.statusFontFamily,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        width: "46%",
                        justifyContnet: "flex-end",
                        textAlign: "right",
                        paddingLeft: "4%",
                    };
                    if (Containers.ProcessStageControl.context.client.isRTL) {
                        style.paddingRight = "4%";
                        style.paddingLeft = "";
                    }
                }
                return style;
            };
            StageDockHeaderNameContainer.stageDockHeaderNameLabelName = "NameLabel";
            return StageDockHeaderNameContainer;
        }());
        Containers.StageDockHeaderNameContainer = StageDockHeaderNameContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var headerStageFlyout = "processHeaderStageFlyout";
        var stageFlyoutDirection = 3;
        var BPFCUSTOMCONTROL_FCB = "EnableBPFNonDefaultCustomControls";
        var StageFlyout = (function () {
            function StageFlyout() {
                this.flyoutContainer = new Containers.StageFlyoutContainer();
            }
            StageFlyout.prototype.render = function (stageId, flyoutCloseHandler) {
                if (Containers.ProcessControlManager.Instance.getDisplayState() !== Containers.DisplayState.floating) {
                    return null;
                }
                if (!Containers.ProcessControlManager.Instance.getStageIndex(stageId)) {
                    return null;
                }
                var stageElementId = "MscrmControls.Containers.ProcessBreadCrumb-stageNameContainer_" + stageId.guid;
                var processHeaderContainerElement = Containers.ProcessControlManager.Instance.contextManager.getUniqueId(Containers.ControlMode.breadCrumb, "processHeaderContainer");
                var isMobileMode = Containers.ProcessControlManager.Instance.isMobileMode();
                var relativeToElementId = isMobileMode ? processHeaderContainerElement : stageElementId;
                Containers.ProcessStageFocusHandler._setFocus(stageId);
                return Containers.ProcessStageControl.context.factory.createElement("FLYOUT", {
                    id: headerStageFlyout + "_" + stageId.guid,
                    flyoutStyle: {
                        boxShadow: Containers.ProcessControlManager.Instance.contextManager.context().theming.shadows.shadow01,
                    },
                    flyoutDirection: stageFlyoutDirection,
                    positionType: "relative",
                    absoluteId: relativeToElementId,
                    onOutsideClick: flyoutCloseHandler,
                    size: this._getFlyoutSize(),
                    key: headerStageFlyout + "_" + stageId.guid,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.StageStatusTitleTemplate), Containers.ProcessControlManager.Instance.getStageEntityDisplayName(stageId), Containers.ProcessControlManager.Instance.getStageName(stageId), Containers.ProcessControlManager.Instance.getStageStatus(stageId)),
                    hasDynamicContent: true,
                    keepOpenOnWindowBlur: this._isBPFCustomControlFCBEnabled(),
                }, this.flyoutContainer.render(stageId));
            };
            StageFlyout.prototype._getFlyoutSize = function () {
                var size = {};
                if (Containers.ProcessControlManager.Instance.isMobileMode()) {
                    var ProcessBreadCrumbContainer = (document.getElementById(Containers.ProcessControlManager.Instance.contextManager.getUniqueId(Containers.ControlMode.breadCrumb, "processHeaderContainer")));
                    var processBreadCrumbTopPoistion = ProcessBreadCrumbContainer.getBoundingClientRect().top;
                    var processBreadCrumbHeight = ProcessBreadCrumbContainer.offsetHeight;
                    size.height = window.innerHeight - processBreadCrumbTopPoistion - processBreadCrumbHeight - 3;
                    size.width = "100vw";
                }
                else {
                    return null;
                }
                return size;
            };
            StageFlyout.prototype._isBPFCustomControlFCBEnabled = function () {
                if (Containers.ProcessStageControl.context.utils.isFeatureEnabled(BPFCUSTOMCONTROL_FCB)) {
                    return true;
                }
                return false;
            };
            return StageFlyout;
        }());
        Containers.StageFlyout = StageFlyout;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageFlyoutInnerContainerClass = "processHeaderStageFlyoutInnerContainer";
        var StageFlyoutContainer = (function () {
            function StageFlyoutContainer() {
            }
            StageFlyoutContainer.prototype.render = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: Containers.StyleHelper.getFlyoutContainerId(stageId),
                    id: Containers.StyleHelper.getFlyoutContainerId(stageId),
                    labelledByElementId: Containers.ProcessControlManager.Instance.contextManager.getUniqueId(Containers.ControlMode.breadCrumb, Containers.StyleHelper.processHeaderStageContent + "_" + stageId.guid),
                    style: this._getStyle(),
                    onKeyDown: this._keyDownHandler.bind(this),
                    onClick: this._clickHandler.bind(this),
                    role: "dialog",
                }, [
                    new Containers.StageFlyoutHeaderContainer().render(stageId),
                    this._renderStageFlyoutInnerContainer(stageId),
                    new Containers.StageFlyoutFooterContainer().render(stageId),
                ]);
            };
            StageFlyoutContainer.prototype._renderStageFlyoutInnerContainer = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: stageFlyoutInnerContainerClass,
                    id: stageFlyoutInnerContainerClass,
                    style: {
                        flexDirection: "column",
                        padding: Containers.ProcessControlManager.Instance.isMobileMode() ? "0.75em 1.5em 0 1.5em" : "1em 1em 1em 1em",
                        backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                    },
                }, new Containers.StageFlyoutItemsContainer().render(stageId));
            };
            StageFlyoutContainer.prototype._getStyle = function () {
                var style = {
                    backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                    flexDirection: "column",
                    padding: "0px 1px 1px 1px",
                    width: "25em",
                    boxSizing: "border-box",
                };
                if (Containers.ProcessControlManager.Instance.isMobileMode()) {
                    style.width = "100vw";
                    style.height = "100%";
                    style.backgroundColor = Containers.StyleHelper.getShade(Shades.WhiteBackGround);
                }
                return style;
            };
            StageFlyoutContainer.prototype._clickHandler = function (event) {
                if (Containers.ProcessControlManager.Instance.isCrossEntityFlyoutOpen()) {
                    Containers.ProcessControlManager.Instance.setCrossEntityDisplayState(Containers.DisplayState.collapsed);
                    Containers.ProcessStageControl.context.utils.requestRender();
                }
            };
            StageFlyoutContainer.prototype._keyDownHandler = function (event) {
                var element = event.target;
                if (Containers.ProcessControlManager.Instance.getDisplayState() !== Containers.DisplayState.floating) {
                    return;
                }
                switch (event.keyCode) {
                    case 27:
                        new Containers.StageFlyoutHeaderContainer().closeFlyoutWithFocus();
                        break;
                    case 9:
                        Containers.FlyoutTabbingHelper.addCircularTabbing(event, Containers.ProcessStageControl.context.accessibility.getUniqueId(Containers.StyleHelper.getFlyoutContainerId(Containers.ProcessControlManager.Instance.getSelectedStageId())));
                        break;
                }
            };
            return StageFlyoutContainer;
        }());
        Containers.StageFlyoutContainer = StageFlyoutContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var flyoutFooterContainer = "businessProcessFlowFlyoutFooterContainer";
        var StageFlyoutFooterContainer = (function () {
            function StageFlyoutFooterContainer() {
                this._stageButtons = new Containers.StageButtons();
            }
            StageFlyoutFooterContainer.prototype.render = function (stageId) {
                if (!Containers.ProcessControlManager.Instance.isStageComplete(stageId) &&
                    !Containers.ProcessControlManager.Instance.isActiveStage(stageId)) {
                    return null;
                }
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: flyoutFooterContainer,
                    id: flyoutFooterContainer,
                    style: this._getStyle(),
                }, this._stageButtons.render(stageId));
            };
            StageFlyoutFooterContainer.prototype._getStyle = function () {
                return {
                    marginBottom: "1.5em",
                    padding: "0em 1em 0em 1em",
                };
            };
            return StageFlyoutFooterContainer;
        }());
        Containers.StageFlyoutFooterContainer = StageFlyoutFooterContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var stageFlyoutItems = "processHeaderStageFlyoutItems";
        var StageFlyoutItemsContainer = (function () {
            function StageFlyoutItemsContainer() {
            }
            StageFlyoutItemsContainer.prototype.render = function (stageId) {
                return Containers.ProcessStageControl.context.factory.createElement("SCROLLCONTAINER", {
                    id: stageFlyoutItems + "_" + stageId.guid,
                    key: stageFlyoutItems + "_" + stageId.guid,
                    style: this._getStyle(),
                    role: "presentation",
                }, Containers.ProcessRenderingUtils.renderFieldSectionItems(stageId));
            };
            StageFlyoutItemsContainer.prototype._getStyle = function () {
                var height = 100;
                var element = document.getElementById("MscrmControls.Containers.ProcessBreadCrumb-processHeader");
                if (element && element.getBoundingClientRect()) {
                    height = Math.max(window.innerHeight - element.getBoundingClientRect().bottom - 10 * Containers.StyleHelper.getFontSize(), height);
                    height = Math.min(310, height);
                }
                var style = {
                    backgroundColor: Containers.StyleHelper.getShade(Shades.WhiteBackGround),
                    paddingTop: "1em",
                    overflowY: "auto",
                    overflowX: "hidden",
                    maxHeight: height + "px",
                    flexDirection: "row",
                    flexWrap: "wrap",
                };
                if (Containers.ProcessControlManager.Instance.isMobileMode()) {
                    style.paddingTop = "0.75em";
                }
                return style;
            };
            return StageFlyoutItemsContainer;
        }());
        Containers.StageFlyoutItemsContainer = StageFlyoutItemsContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var flowbuttonIconString = "flowButtonIcon";
        var FlowContainer = (function () {
            function FlowContainer() {
            }
            FlowContainer.prototype._getIconforStatus = function (status) {
                switch (status) {
                    case 0:
                    case 1:
                        return Containers.ProcessControlIconSymbol.None;
                    case 2:
                        return Containers.ProcessControlIconSymbol.Completed;
                    default:
                        return Containers.ProcessControlIconSymbol.Failure;
                }
            };
            FlowContainer.prototype.render = function (flowStepLabel, stepIdKey, index, controlId, flowId) {
                var flowLog = Containers.ProcessControlManager.Instance.getActionLog(flowId);
                var status = !!flowLog ? flowLog.status : 0;
                var icon = this._getIconforStatus(status);
                var flowLogToolTip = !!flowLog && !!flowLog.message ? flowLog.message : "";
                var iconColor = "";
                if (status === 2) {
                    iconColor = Containers.ProcessStageControl.context.theming.colors.basecolor.green["green4"];
                }
                else if (status === 3) {
                    iconColor = Containers.ProcessStageControl.context.theming.colors.basecolor.red["red3"];
                }
                var flowButtonIconStyle = {
                    transform: Containers.ProcessStageControl.context.client.isRTL ? "scale(-1,1)" : null,
                    alignSelf: "flex-start",
                    color: iconColor,
                    width: "1em",
                    height: "1em",
                    fontSize: "",
                };
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "flowContainer_" + stepIdKey,
                    id: "flowContainer_" + stepIdKey,
                    accessibilityLabel: "Flow Step",
                    style: {
                        display: "flex",
                        borderBottomColor: "#DDDDDD",
                        borderBottomWidth: "1px",
                        borderBottomStyle: "solid",
                        paddingBottom: "0.25em",
                        paddingTop: "0.25em",
                        alignItems: "baseline",
                        width: "100%",
                    },
                }, [
                    !!icon
                        ? new Containers.ProcessControlIcon().render(flowbuttonIconString, icon, function () { }, flowButtonIconStyle, "img", flowLogToolTip)
                        : null,
                    new Containers.FlowButton().render(flowStepLabel, stepIdKey, index, status, controlId, flowId, flowLogToolTip),
                ]);
            };
            return FlowContainer;
        }());
        Containers.FlowContainer = FlowContainer;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        "use strict";
        var flowButtonName = "flowButton";
        var flowStepLabelContainerName = "flowStepLabelContainer";
        var flowStepLabelKey = "flowStepLabelKey";
        var businessProcessFlowControlPrefix = "header_process_";
        var FlowButton = (function () {
            function FlowButton() {
            }
            FlowButton.prototype.render = function (flowStepLabel, stepIdKey, index, status, controlId, flowId, tooltip) {
                this._flowStepId = flowId;
                this._controlId = businessProcessFlowControlPrefix + controlId;
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "flowButton_" + stepIdKey,
                    id: "flowButton_" + stepIdKey,
                    style: {
                        flexDirection: "column",
                    },
                    accessibilityLabel: "FlowStep",
                }, [
                    this._renderFlowStepLabel(flowStepLabel, stepIdKey, index),
                    this._renderFlowButton(stepIdKey, index, status, flowStepLabel, tooltip),
                ]);
            };
            FlowButton.prototype._renderFlowButton = function (stepIdKey, index, status, label, tooltip) {
                var _this = this;
                var processing = status === 1;
                var disabled = processing ||
                    Containers.ProcessStageControl.context.mode.isOffline ||
                    Containers.ProcessRenderingUtils.isNewRecord(Containers.ProcessStageControl.context.mode.contextInfo);
                var flowButtonTooltip = Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.FlowStepExecute);
                var messageString = processing
                    ? Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.ProcessingFlowStepData)
                    : Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.FlowStepExecute);
                return Containers.ProcessStageControl.context.factory.createElement("BUTTON", {
                    key: "flowButton_" + index + "_" + flowButtonName,
                    id: "flowButton_" + index + "_" + flowButtonName,
                    accessibilityLabel: ["Flow Step", label, messageString, tooltip].join(" "),
                    onClick: function (event) {
                        _this._clickHandler(event, flowButtonName);
                    },
                    style: this._getStyle(flowButtonName, disabled),
                    disabled: disabled,
                    title: flowButtonTooltip,
                }, messageString);
            };
            FlowButton.prototype._renderFlowStepLabel = function (flowStepLabelName, stepIdKey, index) {
                return Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                    key: "flowButton_" + index + "_" + stepIdKey + "_" + flowStepLabelContainerName,
                    id: "fkiwButton_" + index + "_" + stepIdKey + "_" + flowStepLabelContainerName,
                    style: {
                        paddingLeft: Containers.ProcessStageControl.context.client.isRTL
                            ? Containers.ProcessStageControl.context.theming.measures.measure125
                            : "0em",
                        paddingRight: Containers.ProcessStageControl.context.client.isRTL
                            ? "0em"
                            : Containers.ProcessStageControl.context.theming.measures.measure125,
                    },
                    accessibilityLabel: flowStepLabelName,
                }, Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                    key: flowStepLabelKey,
                    id: flowStepLabelKey,
                    style: {
                        marginBottom: "0.31rem",
                        marginLeft: "0.43rem",
                        color: Containers.StyleHelper.getShade(Shades.Grey6),
                    },
                }, flowStepLabelName));
            };
            FlowButton.prototype._getStyle = function (key, disabled) {
                var backgroundColor = disabled
                    ? Containers.StyleHelper.getShade(Shades.Grey4)
                    : Containers.StyleHelper.getShade(Shades.MainThemeDark);
                var textColor = disabled
                    ? Containers.StyleHelper.getShade(Shades.Grey6)
                    : Containers.StyleHelper.getShade(Shades.MainThemeDarkText);
                var style = {
                    backgroundColor: backgroundColor,
                    borderColor: "transparent",
                    justifyContent: "center",
                    alignItems: "center",
                    width: Containers.ProcessStageControl.context.theming.measures.measure550,
                    height: Containers.ProcessStageControl.context.theming.measures.measure150,
                    marginLeft: "0.437rem",
                    marginBottom: "0.31rem",
                    overflow: "hidden",
                    marginTop: Containers.ProcessControlManager.Instance.isMobileMode() ? "1.5em" : null,
                    cursor: disabled ? "default" : "pointer",
                    color: textColor,
                };
                return style;
            };
            FlowButton.prototype._clickHandler = function (event, flowButton) {
                Containers.ProcessControlManager.Instance.triggerFlowStepClick(this._flowStepId, this._controlId);
            };
            return FlowButton;
        }());
        Containers.FlowButton = FlowButton;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var actionStepType = "action";
        var flowStepType = "modernflow";
        var ProcessRenderingUtils = (function () {
            function ProcessRenderingUtils() {
            }
            ProcessRenderingUtils.renderFieldSectionItems = function (stageId) {
                var flyoutFieldSectionItems = [];
                var stepIdsAndProperties = Containers.ProcessControlManager.Instance.getStepIdsAndProperties(stageId);
                var fieldSectionItemContainerStyle = {
                    width: "100%",
                };
                if (Containers.ProcessStageControl.context.client.isRTL) {
                    fieldSectionItemContainerStyle.marginLeft = Containers.ProcessStageControl.context.theming.measures.measure025;
                }
                else {
                    fieldSectionItemContainerStyle.marginRight = Containers.ProcessStageControl.context.theming.measures.measure025;
                }
                if (!stepIdsAndProperties || stepIdsAndProperties.length === 0) {
                    return null;
                }
                if (Containers.ProcessControlManager.Instance.isStageLocked(stageId) ||
                    !Containers.ProcessControlManager.Instance.isStageForCurrentEntity(stageId)) {
                    return ProcessRenderingUtils.renderFieldSectionLabels(stageId, stepIdsAndProperties);
                }
                stepIdsAndProperties.forEach(function (stepIdProperty, index) {
                    var stepIdKeys = Object.keys(stepIdProperty);
                    var properties = stepIdProperty[stepIdKeys[0]];
                    if (stepIdKeys.length > 2 &&
                        stepIdProperty[stepIdKeys[1]] &&
                        stepIdProperty[stepIdKeys[1]].toLowerCase() === actionStepType) {
                        flyoutFieldSectionItems.push(new Containers.ActionContainer().render(properties.controlstates.label, stepIdKeys[1], index, stepIdKeys[2], stepIdKeys[0]));
                    }
                    else if (stepIdKeys.length > 2 &&
                        stepIdProperty[stepIdKeys[1]] &&
                        stepIdProperty[stepIdKeys[1]].toLowerCase() === flowStepType) {
                        flyoutFieldSectionItems.push(new Containers.FlowContainer().render(properties.controlstates.label, stepIdKeys[1], index, stepIdKeys[2], stepIdKeys[0]));
                    }
                    else {
                        flyoutFieldSectionItems.push(Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                            key: "fieldSectionItemContainer_" + stepIdKeys[0],
                            id: "fieldSectionItemContainer_" + stepIdKeys[0],
                            style: fieldSectionItemContainerStyle,
                        }, [
                            Containers.ProcessStageControl.context.factory.createComponent("MscrmControls.Containers.FieldSectionItem", "fieldSectionItem_" + index + "_" + stepIdKeys[0], properties),
                        ]));
                    }
                });
                return flyoutFieldSectionItems;
            };
            ProcessRenderingUtils.renderFieldSectionLabels = function (stageId, stepIdsAndProperties) {
                var fieldSectionLabels = [];
                stepIdsAndProperties.forEach(function (stepIdProperty, index) {
                    var stepIdKeys = Object.keys(stepIdProperty);
                    var labelName = stepIdProperty[stepIdKeys[0]].controlstates.label;
                    fieldSectionLabels.push(Containers.ProcessStageControl.context.factory.createElement("CONTAINER", {
                        key: "fieldSectionItemLabel_" + stepIdKeys[0],
                        id: "fieldSectionItemLabel_" + stepIdKeys[0],
                        style: ProcessRenderingUtils._getStyle(),
                        role: "group",
                        accessibilityLabel: labelName,
                    }, [
                        Containers.ProcessStageControl.context.factory.createElement("LABEL", {
                            key: labelName,
                            id: labelName,
                            style: {
                                margin: "10px",
                            },
                        }, labelName),
                    ]));
                });
                return fieldSectionLabels;
            };
            ProcessRenderingUtils.isNewRecord = function (contextInfo) {
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(contextInfo)) {
                    var entityId = Guid.tryParse(contextInfo.entityId);
                    return Guid.equals(entityId, Guid.EMPTY);
                }
                return true;
            };
            ProcessRenderingUtils._getStyle = function () {
                return {
                    borderBottomColor: Containers.StyleHelper.getShade(Shades.Grey3),
                    borderBottomWidth: "1px",
                    borderBottomStyle: "solid",
                    paddingBottom: "0.25em",
                    paddingTop: "0.25em",
                    borderTopStyle: "solid",
                    borderRightStyle: "solid",
                    borderLeftStyle: "solid",
                    alignItems: "baseline",
                    width: "100%",
                };
            };
            return ProcessRenderingUtils;
        }());
        Containers.ProcessRenderingUtils = ProcessRenderingUtils;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var ProcessStageFocusHandler = (function () {
            function ProcessStageFocusHandler() {
            }
            ProcessStageFocusHandler._setFocus = function (stageId, isLockedStage) {
                if (isLockedStage === void 0) { isLockedStage = false; }
                if (!Containers.ProcessControlManager.Instance.contextManager.hasChanged(Containers.ControlMode.stage)) {
                    return;
                }
                if (ProcessStageFocusHandler._setFocusTimer !== null) {
                    window.clearInterval(ProcessStageFocusHandler._setFocusTimer);
                    ProcessStageFocusHandler._setFocusTimer = null;
                }
                ProcessStageFocusHandler._setFocusTimer = window.setInterval(function () {
                    var containerId = null;
                    if (Containers.ProcessControlManager.Instance.getDisplayState() === Containers.DisplayState.floating) {
                        containerId = Containers.StyleHelper.headerStageFlyoutContainer + "_" + stageId.guid;
                    }
                    else {
                        containerId = Containers.StyleHelper.stageDockContainer;
                    }
                    var uniqueId = Containers.ProcessStageControl.context.accessibility.getUniqueId(containerId);
                    var container = document.getElementById(uniqueId);
                    if (container) {
                        var tabbableElements = container.querySelectorAll("[tabindex='0']");
                        if (tabbableElements.length > 0) {
                            window.clearInterval(ProcessStageFocusHandler._setFocusTimer);
                            ProcessStageFocusHandler._setFocusTimer = null;
                            tabbableElements[0].focus();
                            if (Containers.AccessibilityHelper.addDockedNotification && !isLockedStage) {
                                Containers.AccessibilityHelper.addDockedNotification = false;
                                window.setTimeout(function () {
                                    Containers.ProcessControlManager.Instance.setNarratorNotification(Containers.ResourceStrings.getResourceString(Containers.ResourceStrings.StageFlyoutDocked));
                                }, 500);
                            }
                        }
                    }
                }, 200);
            };
            ProcessStageFocusHandler._setFocusTimer = null;
            return ProcessStageFocusHandler;
        }());
        Containers.ProcessStageFocusHandler = ProcessStageFocusHandler;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
