/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderControl = (function () {
            function QueryBuilderControl() {
            }
            QueryBuilderControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.initializeQueryTree(context);
                this.queryBuilderCommandBar = new QueryBuilder.QueryBuilderCommandBar(this.queryTree.Context, this.queryTree);
                this.queryBuilderCommandBarComponent = this.queryBuilderCommandBar.Commands;
                this.registerPageShortcuts();
            };
            QueryBuilderControl.prototype.initializeQueryTree = function (context) {
                var _this = this;
                this.queryTree = new QueryBuilder.QueryBuilderQueryTree(context, QueryBuilder.Constants.UsageContext.AdvancedFind, context.parameters.OutputCallback.raw);
                var inputConverter = new QueryBuilder.InputConverterRegistry().getConverter(this.queryTree.UsageContext);
                var self = this;
                inputConverter.convert(this.queryTree).then(function () {
                    var telemetryEventHandler = new QueryBuilder.TelemetryEventHandlerRegistry().getHandler(self.queryTree.UsageContext);
                    if (telemetryEventHandler) {
                        self.queryTree.registerObserver(telemetryEventHandler);
                    }
                    _this.initialized = true;
                    self.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.Initialized, Properties: {} });
                }, function (error) {
                    self.queryTree.onError(error);
                });
            };
            QueryBuilderControl.prototype.updateView = function (context) {
                this.queryTree.Context = context;
                if (!this.initialized) {
                    return this.getQueryBuilderProgressBar();
                }
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    key: "QueryBuilder",
                    id: "queryBuilder",
                    style: QueryBuilder.QueryBuilderStyle.commandBarContainerStyle(this.queryTree.Context.theming),
                }, [
                    this.getAriaLiveRegion(),
                    this.renderCommandBar(),
                    this.queryTree.renderQueryBuilderFilters(),
                    this.queryTree.renderConfirmationDialog(),
                ]);
            };
            QueryBuilderControl.setPostRenderFocusElementId = function (elementId) {
                QueryBuilderControl.postRenderFocusElementId = elementId;
            };
            QueryBuilderControl.getPostRenderFocusElementId = function () {
                return QueryBuilderControl.postRenderFocusElementId;
            };
            QueryBuilderControl.rerenderControl = function (context, postRenderFocusableElementId) {
                if (postRenderFocusableElementId) {
                    QueryBuilderControl.setPostRenderFocusElementId(postRenderFocusableElementId);
                }
                context.utils.requestRender(function () {
                    QueryBuilderControl.getPostRenderFocusElementId() &&
                        context.accessibility.focusElementById(QueryBuilderControl.getPostRenderFocusElementId());
                    QueryBuilderControl.setPostRenderFocusElementId("");
                });
            };
            QueryBuilderControl.prototype.renderCommandBar = function () {
                this.queryBuilderCommandBar.updateCommandBar();
                this.queryBuilderCommandBarComponent = this.queryBuilderCommandBar.Commands;
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    key: "CommandBar",
                    id: "commandBar",
                    style: QueryBuilder.QueryBuilderStyle.commandBarNavStyle(this.queryTree.Context.theming),
                }, [this.queryBuilderCommandBarComponent]);
            };
            QueryBuilderControl.prototype.getAriaLiveRegion = function () {
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.ariaLiveLabelId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.ariaLiveLabelId(),
                    style: {
                        position: "absolute",
                        clip: "rect(1px, 1px, 1px, 1px)",
                    },
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                }, "");
            };
            QueryBuilderControl.prototype.renderTextOutput = function () {
                var label = this.queryTree.Context.factory.createElement("LABEL", {
                    id: "label" + "_" + QueryBuilder.Utils.newGuid(),
                    key: "label" + "_" + QueryBuilder.Utils.newGuid(),
                }, [this.queryTree.getConverterOutput()]);
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    key: "OutputText",
                    id: "OutputText",
                    style: QueryBuilder.QueryBuilderStyle.commandBarTextConatinerStyle(this.queryTree.Context.theming),
                }, [label]);
            };
            QueryBuilderControl.prototype.getGuidFromDivId = function (divId, delimiter) {
                var splitId = divId.split(delimiter);
                return splitId[1].substring(0, 36);
            };
            QueryBuilderControl.prototype.getQueryBuilderProgressBar = function () {
                var progressIndicator = this.queryTree.Context.factory.createElement("PROGRESSINDICATOR", {
                    key: "QueryBuilderProgressIndicator",
                    id: "QueryBuilderProgressIndicator",
                    style: {
                        width: "40px",
                        height: "40px",
                        display: "table",
                        margin: "0 auto",
                    },
                    progressType: "ring",
                    testhooks: { id: "categorized-search-progress-indicator" },
                    active: true,
                }, []);
                var progressIndicatorContainer = this.queryTree.Context.factory.createElement("CONTAINER", {
                    id: "QueryBuilderProgressIndicatorContainer",
                    key: "QueryBuilderProgressIndicatorContainer",
                    style: {
                        position: "relative",
                        display: "flex",
                        margin: "10 auto",
                        flex: "1",
                        "flex-direction": "row",
                    },
                }, [progressIndicator]);
                return progressIndicatorContainer;
            };
            QueryBuilderControl.prototype.getOutputs = function () {
                return null;
            };
            QueryBuilderControl.prototype.destroy = function () {
                this.queryTree.onDestroy({ EventType: QueryBuilder.Constants.QueryTreeEventType.Destroy, Properties: {} });
            };
            QueryBuilderControl.prototype.registerPageShortcuts = function () {
                var _this = this;
                var groupAndKeyCombination = [18, 16, 65];
                var groupOrKeyCombination = [18, 16, 79];
                var groupUngroupKeyCombination = [18, 16, 85];
                var clearFiltersKeyCombination = [18, 16, 76];
                var runQueryKeyCombination = [18, 16, 81];
                var deleteFiltersCombination = [46];
                this.queryTree.Context.accessibility.registerShortcut(groupAndKeyCombination, function () {
                    var newAndNodeId = _this.queryTree.groupAND(Object.keys(_this.queryTree.getSelectedNodes()));
                    QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix() + newAndNodeId);
                    _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.GroupAND, Properties: {} });
                }, true, "queryBuilderCommandBar", "group And selected filters");
                this.queryTree.Context.accessibility.registerShortcut(groupOrKeyCombination, function () {
                    var newOrNodeId = _this.queryTree.groupOR(Object.keys(_this.queryTree.getSelectedNodes()));
                    QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix() + newOrNodeId);
                    _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.GroupOR, Properties: {} });
                }, true, "queryBuilderCommandBar", "group OR selected filters");
                this.queryTree.Context.accessibility.registerShortcut(groupUngroupKeyCombination, function () {
                    var nodes = Object.keys(_this.queryTree.getSelectedNodes());
                    if (nodes.length > 1) {
                        for (var i = 0; i < nodes.length; i++) {
                            delete _this.queryTree.getSelectedNodes()[nodes[i]];
                        }
                    }
                    else {
                        _this.queryTree.unGroup(nodes[0]);
                        _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.UnGroup, Properties: {} });
                    }
                }, true, "queryBuilderCommandBar", "Ungroup selected filters");
                this.queryTree.Context.accessibility.registerShortcut(clearFiltersKeyCombination, function () {
                    _this.queryTree.ConfirmationDialog.ShowConfirmationDialog(QueryBuilder.Utils.getResourceString(_this.queryTree.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_TITLE_CLEAR), QueryBuilder.Utils.getResourceString(_this.queryTree.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_MESSAGE_RESET), function () {
                        _this.queryTree.clearTree();
                        _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.Reset, Properties: {} });
                    });
                }, true, "queryBuilderCommandBar", "Clear all filters");
                this.queryTree.Context.accessibility.registerShortcut(deleteFiltersCombination, function () {
                    _this.queryTree.delete(Object.keys(_this.queryTree.getSelectedNodes()));
                    QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId());
                    _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.Delete, Properties: {} });
                }, true, "queryBuilderCommandBar", "delete selected filters");
                this.queryTree.Context.accessibility.registerShortcut(runQueryKeyCombination, function () {
                    _this.queryTree.runQuery();
                    QueryBuilderControl.setPostRenderFocusElementId("GlobalRunQueryButton");
                    _this.queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.RunQuery, Properties: {} });
                }, true, "queryBuilderCommandBar", "Run configured query");
            };
            return QueryBuilderControl;
        }());
        QueryBuilder.QueryBuilderControl = QueryBuilderControl;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var LanguageDataProvider = (function () {
            function LanguageDataProvider() {
            }
            LanguageDataProvider.prototype.getProvisionedLanguageList = function (context) {
                var languageTemplate = "Language_{0}";
                var localeLanguageTemplate = "Locale_DisplayName_{0}";
                var languageList = new Array();
                return new Promise(function (resolve, reject) {
                    if (QueryBuilder.MetadataStore.Instance.containsProvisionedLanguageList()) {
                        resolve(QueryBuilder.MetadataStore.Instance.getProvisionedLanguageList());
                    }
                    else {
                        new QueryBuilder.ODataHelper(context).retrieveOrganizationProvisionedLanguages().then(function (response) {
                            if (response && response.RetrieveProvisionedLanguages) {
                                for (var _i = 0, _a = response.RetrieveProvisionedLanguages; _i < _a.length; _i++) {
                                    var languageCode = _a[_i];
                                    var label = QueryBuilder.Utils.getResourceString(context, MscrmCommon.ControlUtils.String.Format(languageTemplate, [languageCode.toString()]));
                                    if (label.match(languageTemplate)) {
                                        label = QueryBuilder.Utils.getResourceString(context, MscrmCommon.ControlUtils.String.Format(localeLanguageTemplate, [languageCode.toString()]));
                                    }
                                    languageList.push(new QueryBuilder.Option(label, languageCode, null));
                                }
                                QueryBuilder.MetadataStore.Instance.addProvisionedLanguageList(languageList);
                                resolve(QueryBuilder.MetadataStore.Instance.getProvisionedLanguageList());
                            }
                        }, function (error) {
                            reject(error);
                        });
                    }
                });
            };
            return LanguageDataProvider;
        }());
        QueryBuilder.LanguageDataProvider = LanguageDataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            var LinkedEntityControlChangeHandler = (function () {
                function LinkedEntityControlChangeHandler(addLinkedEntityButton) {
                    this.addLinkedEntityButton = addLinkedEntityButton;
                }
                LinkedEntityControlChangeHandler.prototype.onChange = function (controlDefinition) {
                    var valueParts = QueryBuilder.Utils.getControlDefinitionValue(controlDefinition).split(",");
                    var relationshipType = (parseInt(QueryBuilder.Constants.LinkedEntityRelationshipType[valueParts[0]]));
                    var fromEntityLogicalName = valueParts[1];
                    var fromAttributeLogicalName = valueParts[2];
                    var toEntityLogicalName = valueParts[3];
                    var toAttributeLogicalName = valueParts[4];
                    var intersectEntity = "", intersectPrimaryAttribute = "", intersectRelatedAttribute = "";
                    if (relationshipType == QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany) {
                        intersectEntity = valueParts[5];
                        intersectPrimaryAttribute = valueParts[6];
                        intersectRelatedAttribute = valueParts[7];
                    }
                    this.addLinkedEntityButton.handleRelatedEntitySelection(relationshipType, fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, intersectEntity, intersectPrimaryAttribute, intersectRelatedAttribute);
                };
                return LinkedEntityControlChangeHandler;
            }());
            ConditionModel.LinkedEntityControlChangeHandler = LinkedEntityControlChangeHandler;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            var ConditionControlChangeHandler = (function () {
                function ConditionControlChangeHandler(parentCondition) {
                    this.parentCondition = parentCondition;
                }
                ConditionControlChangeHandler.prototype.getContext = function () {
                    return this.parentCondition.getContext();
                };
                ConditionControlChangeHandler.prototype.onChange = function (controlDefinition) {
                    var componentIndex = this.parentCondition.ControlDefinitions.indexOf(controlDefinition);
                    if (componentIndex === -1) {
                        console.error("Control definition not found!");
                    }
                    this.parentCondition.ControlDefinitions = this.parentCondition.ControlDefinitions.slice(0, componentIndex + 1);
                    var controlDefinitionProvider = new QueryBuilder.ControlDefinitionProviderRegistry().getProvider(this.parentCondition.getUsageContext());
                    var self = this;
                    controlDefinitionProvider
                        .getNextControlDefinitions(this.getContext(), this.parentCondition.ControlDefinitions, this.parentCondition.ParentConditionNode)
                        .then(function (newControlDefinitions) {
                        self.parentCondition.pushComponents(newControlDefinitions);
                        self.parentCondition
                            .getQueryTree()
                            .onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.UpdateCondition, Properties: {} });
                    }, function (error) {
                        self.parentCondition.getQueryTree().onError(error);
                    });
                };
                return ConditionControlChangeHandler;
            }());
            ConditionModel.ConditionControlChangeHandler = ConditionControlChangeHandler;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var QueryBuilderStyle = (function () {
            function QueryBuilderStyle() {
            }
            QueryBuilderStyle.commandBarNavStyle = function (theme) {
                return {
                    width: "auto",
                    flexDirection: "column",
                    background: theme.colors.grays.gray05,
                    paddingRight: theme.measures.measure075,
                    paddingLeft: theme.measures.measure075,
                    fontFamily: theme.fontfamilies.regular,
                    marginBottom: theme.measures.measure075,
                    height: theme.measures.measure225,
                    minHeight: theme.measures.measure225,
                };
            };
            QueryBuilderStyle.commandBarContainerStyle = function (theme) {
                return {
                    width: "100%",
                    flexDirection: "column",
                    position: "relative",
                };
            };
            QueryBuilderStyle.commandBarButtonStyle = function (theme, enable) {
                return {
                    fontSize: theme.fontsizes.font085,
                    background: "transparent",
                    width: "auto",
                    color: "#FFFFFF",
                    border: "0",
                    padding: theme.measures.measure050,
                    lineHeight: "18px",
                    ":hover": {
                        background: "transparent",
                    },
                    flexDirection: "row",
                    opacity: enable ? "1" : "0.50",
                    fontFamily: theme.fontfamilies.regular,
                };
            };
            QueryBuilderStyle.commandBarResetButtonStyle = function (theme, isRTL) {
                return {
                    fontSize: theme.fontsizes.font085,
                    background: "transparent",
                    width: "auto",
                    color: "#FFFFFF",
                    border: "0",
                    padding: theme.measures.measure050,
                    lineHeight: "18px",
                    marginLeft: isRTL ? "0" : undefined,
                    marginRight: isRTL ? undefined : "0",
                    ":hover": {
                        background: "transparent",
                    },
                    flexDirection: "row",
                    fontFamily: theme.fontfamilies.regular,
                };
            };
            QueryBuilderStyle.commandBarAdvancedButtonStyle = function (theme, isRTL) {
                return {
                    fontSize: theme.fontsizes.font085,
                    background: "transparent",
                    width: "auto",
                    color: "#FFFFFF",
                    border: "0",
                    padding: theme.measures.measure050,
                    lineHeight: "18px",
                    marginLeft: isRTL ? "0" : "auto",
                    marginRight: isRTL ? "auto" : "0",
                    ":hover": {
                        background: "transparent",
                    },
                    flexDirection: "row",
                    fontFamily: theme.fontfamilies.regular,
                };
            };
            QueryBuilderStyle.commandBarIconStyle = function (theme, enable) {
                return {
                    paddingRight: theme.measures.measure025,
                    paddingLeft: theme.measures.measure025,
                    fontSize: theme.fontsizes.font085,
                    borderWidth: "0px",
                    opacity: enable ? "1" : "0.50",
                    fontFamily: theme.fontfamilies.regular,
                };
            };
            QueryBuilderStyle.commandBarLabelConatinerStyle = function (theme) {
                return {
                    paddingRight: theme.measures.measure025,
                    paddingLeft: theme.measures.measure025,
                    cursor: "pointer",
                };
            };
            QueryBuilderStyle.QueryBuilderConditionStyle = function (theme) {
                return {
                    width: "auto",
                    display: "flex",
                    flexDirection: "row",
                };
            };
            QueryBuilderStyle.QueryBuilderGetEntityIconStyle = function (theme) {
                return {
                    fontSize: theme.fontsizes.font085,
                    color: theme.colors.grays.gray05,
                    paddingLeft: theme.measures.measure050,
                    paddingRight: theme.measures.measure050,
                    alignSelf: "center",
                };
            };
            QueryBuilderStyle.QueryBuilderGetEntitylabeltStyle = function (theme) {
                return {
                    fontSize: theme.fontsizes.font085,
                    fontFamily: theme.fontfamilies.regular,
                    color: theme.colors.grays.gray05,
                };
            };
            QueryBuilderStyle.QueryBuilderFilterStyle = function (theme) {
                return {
                    width: "auto",
                    display: "flex",
                    flexDirection: "column",
                    padding: "0 0.50rem",
                    height: "calc(100% - 3.5rem)",
                };
            };
            QueryBuilderStyle.QueryBuilderFilterSectionStyle = function (theme) {
                return {
                    overflowY: "auto",
                    display: "inline-block",
                };
            };
            QueryBuilderStyle.QueryBuilderGetContextStyle = function (theme, isRTL) {
                return {
                    width: "auto",
                    display: "flex",
                    flexDirection: "row",
                    paddingTop: theme.measures.measure050,
                    paddingBottom: theme.measures.measure050,
                    marginRight: isRTL ? undefined : theme.measures.measure025,
                    marginLeft: isRTL ? theme.measures.measure025 : undefined,
                    backgroundColor: "rgba(234,6,0,0.1)",
                };
            };
            QueryBuilderStyle.QueryBuilderGetEntityContainerStyle = function (theme) {
                return {
                    width: "100%",
                    display: "flex",
                    flexDirection: "row",
                    paddingBottom: theme.measures.measure050,
                    backgroundColor: "transparent",
                };
            };
            QueryBuilderStyle.QueryBuilderSelectBoxStyle = function (theme) {
                return {
                    display: "flex",
                    flexDirection: "row",
                    width: "fit-content",
                    height: "auto",
                    fontFamily: theme.fontfamilies.regular,
                    color: theme.colors.grays.gray05,
                };
            };
            QueryBuilderStyle.QueryBuilderRelatedSelectboxStyle = function (theme) {
                return {
                    borderWidth: "1px",
                    borderStyle: "solid",
                    borderColor: theme.colors.grays.gray04,
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                };
            };
            QueryBuilderStyle.QueryBuilderRelatedEntitySelectboxStyle = function (theme) {
                return {
                    border: "none",
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                };
            };
            QueryBuilderStyle.CommandBarButtonConatinerStyle = function (theme) {
                return {
                    width: "auto",
                    flexDirection: "row",
                };
            };
            QueryBuilderStyle.RelatedEntityConatinerStyle = function (theme, isRTL) {
                return {
                    flexDirection: "column",
                    paddingLeft: isRTL ? undefined : theme.measures.measure200,
                    paddingRight: isRTL ? theme.measures.measure200 : undefined,
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: " solid",
                    borderColor: theme.colors.grays.gray02,
                };
            };
            QueryBuilderStyle.LinkedEntityHeaderConatinerStyle = function (theme) {
                return {
                    display: "flex",
                    flexDirection: "row",
                    height: "100%",
                    background: theme.colors.grays.gray01,
                    marginBottom: theme.measures.measure050,
                    alignItems: "center",
                };
            };
            QueryBuilderStyle.QueryBuilderDropDownLinkButtonStyle = function (theme, isRTL) {
                return {
                    marginLeft: isRTL ? "0" : "auto",
                    marginRight: isRTL ? "auto" : "0",
                    background: theme.colors.grays.gray01,
                    color: theme.colors.grays.gray06,
                    lineHeight: theme.measures.measure225,
                    border: "0",
                    ":hover": {
                        background: theme.colors.grays.gray03,
                    },
                };
            };
            QueryBuilderStyle.RelatedEntityDisplayTextLabelStyle = function (theme) {
                return {
                    paddingLeft: theme.measures.measure050,
                    paddingRight: theme.measures.measure050,
                    color: theme.colors.grays.gray06,
                    fontSize: theme.fontsizes.font085,
                    overflow: "hidden",
                    width: "auto",
                    maxWidth: "20rem",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                };
            };
            QueryBuilderStyle.EmptyFilterSectionSimpleModeStyle = function (theme) {
                return {
                    paddingLeft: theme.measures.measure050,
                    paddingRight: theme.measures.measure050,
                    color: theme.colors.grays.gray06,
                    fontSize: theme.fontsizes.font085,
                    overflow: "hidden",
                    width: "auto",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                };
            };
            QueryBuilderStyle.RelatedEntityDisplayIconLabelStyle = function (theme, isRTL) {
                return {
                    paddingLeft: theme.measures.measure050,
                    paddingRight: theme.measures.measure050,
                    fontFamily: theme.fontfamilies.regular,
                    color: theme.colors.grays.gray06,
                    fontSize: theme.fontsizes.font085,
                    marginLeft: isRTL ? undefined : "auto",
                    marginRight: isRTL ? "auto" : undefined,
                };
            };
            QueryBuilderStyle.ConditionNodeConatinerStyle = function (theme) {
                return {
                    display: "flex",
                    flexDirection: "row",
                    width: "auto",
                };
            };
            QueryBuilderStyle.ConditionNodeWrapConatinerStyle = function (theme, nodeHasError, isRTL) {
                return {
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: "solid",
                    borderColor: nodeHasError ? theme.colors.basecolor.red["red3"] : theme.colors.grays.gray04,
                    display: "flex",
                    flexDirection: "column",
                    marginBottom: theme.measures.measure050,
                    width: "auto",
                };
            };
            QueryBuilderStyle.ConditionErrorConatinerStyle = function (theme) {
                return {
                    width: "auto",
                    display: "flex",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.ConditionErrorLabelStyle = function (theme) {
                return {
                    fontFamily: theme.fontfamilies.semibold,
                    fontSize: theme.fontsizes.font085,
                    color: theme.colors.basecolor.red["red4"],
                    paddingLeft: theme.measures.measure025,
                    paddingRight: theme.measures.measure025,
                    alignSelf: "center",
                };
            };
            QueryBuilderStyle.ConditionErrorIconStyle = function (theme) {
                return {
                    fontSize: theme.fontsizes.font085,
                    color: theme.colors.basecolor.red["red4"],
                    paddingLeft: theme.measures.measure025,
                    paddingRight: theme.measures.measure025,
                    alignSelf: "center",
                };
            };
            QueryBuilderStyle.commandBarTextConatinerStyle = function (theme) {
                return {
                    display: "flex",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.GroupNodeListStyle = function (theme, isRootNode, isMarginBottomNotRequired) {
                return {
                    flexDirection: "row",
                    marginBottom: isMarginBottomNotRequired ? undefined : theme.measures.measure050,
                };
            };
            QueryBuilderStyle.GroupAndViewConatinerStyle = function (theme, isRTL) {
                return {
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: " solid",
                    borderColor: theme.colors.grays.gray04,
                    display: "flex",
                    flexDirection: "column",
                    position: "relative",
                    width: theme.measures.measure225,
                    textAlign: "center",
                };
            };
            QueryBuilderStyle.GroupOrViewConatinerStyle = function (theme, isRTL) {
                return {
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: " dashed",
                    borderColor: theme.colors.grays.gray04,
                    display: "flex",
                    flexDirection: "column",
                    position: "relative",
                    width: theme.measures.measure225,
                    textAlign: "center",
                };
            };
            QueryBuilderStyle.ChildViewConatinerStyle = function (theme) {
                return {
                    display: "flex",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.QueryBuilderTypeAheadTextBoxStyle = function (theme) {
                return {
                    border: "none",
                    padding: theme.measures.measure025,
                    height: "auto",
                    color: theme.colors.grays.gray05,
                    fontFamily: theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                };
            };
            QueryBuilderStyle.QueryBuilderTypeAheadContainerStyle = function (width) {
                return {
                    width: width ? width : "auto",
                    background: "#ffffff",
                    border: "1px solid #b3b3b3",
                };
            };
            QueryBuilderStyle.QueryBuilderValueTextBoxStyle = function (theme) {
                return {
                    padding: theme.measures.measure025,
                    height: "auto",
                    color: theme.colors.grays.gray05,
                    fontFamily: theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                    border: "none",
                    width: "100%",
                };
            };
            QueryBuilderStyle.QueryBuilderValueReadOnlyStyle = function (theme, isRTL) {
                return {
                    paddingLeft: theme.measures.measure025,
                    paddingRight: theme.measures.measure025,
                    fontSize: theme.fontsizes.font085,
                    fontFamily: theme.fontfamilies.regular,
                    color: theme.colors.grays.gray05,
                    width: "auto",
                    textAlign: isRTL ? "right" : "left",
                    lineHeight: "275%",
                };
            };
            QueryBuilderStyle.QueryBuilderValueFiscalYearAndPeriodStyle = function (theme) {
                return {
                    height: "auto",
                    width: "100%",
                    color: theme.colors.grays.gray05,
                    fontFamily: theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                    border: "none",
                };
            };
            QueryBuilderStyle.QueryBuilderTextBoxIconStyle = function (theme) {
                return {
                    background: theme.colors.basecolor.white,
                    height: "100%",
                    width: "auto",
                    padding: theme.measures.measure025,
                    border: "none",
                    color: theme.colors.grays.gray05,
                    fontFamily: theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                    lineHeight: theme.measures.measure200,
                    ":hover": {
                        background: theme.colors.grays.gray01,
                    },
                };
            };
            QueryBuilderStyle.QueryBuilderCheckboxStyle = function (theme) {
                return {
                    cursor: "pointer",
                    marginLeft: theme.measures.measure050,
                    marginRight: theme.measures.measure050,
                    marginTop: theme.measures.measure075,
                    marginBottom: theme.measures.measure075,
                    height: "12px",
                    width: "12px",
                };
            };
            QueryBuilderStyle.QueryBuilderCommandBarCheckboxStyle = function (theme) {
                return {
                    cursor: "pointer",
                    marginLeft: theme.measures.measure050,
                    marginRight: theme.measures.measure050,
                    height: "12px",
                    width: "12px",
                };
            };
            QueryBuilderStyle.QueryBuilderLinkButtonStyle = function (theme) {
                return {
                    background: "none",
                    border: "none",
                    padding: "0",
                    cursor: "pointer",
                    color: theme.colors.basecolor.blue["blue3"],
                    textDecoration: "none",
                    lineHeight: theme.measures.measure200,
                    fontSize: theme.fontsizes.font085,
                    fontFamily: theme.fontfamilies.regular,
                    ":hover": {
                        background: "none",
                        color: theme.colors.basecolor.blue["blue3"],
                    },
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                };
            };
            QueryBuilderStyle.QueryBuilderLabelIconStyle = function (theme) {
                return {
                    color: theme.colors.basecolor.blue["blue3"],
                    fontSize: theme.fontsizes.font100,
                    paddingRight: theme.measures.measure050,
                    paddingLeft: theme.measures.measure050,
                };
            };
            QueryBuilderStyle.QueryBuilderLogicalLabelStyle = function (theme) {
                return {
                    color: theme.colors.grays.gray05,
                    fontSize: theme.fontsizes.font085,
                    fontFamily: theme.fontfamilies.regular,
                    width: "100%",
                    textAlign: "center",
                };
            };
            QueryBuilderStyle.QueryBuilderRelatedLinkButtonStyle = function (theme) {
                return {
                    background: "none",
                    border: "none",
                    padding: "0",
                    cursor: "pointer",
                    color: "#3472b9",
                    textDecoration: "none",
                    lineHeight: theme.measures.measure200,
                    fontSize: theme.fontsizes.font085,
                    fontFamily: theme.fontfamilies.regular,
                    paddingRight: theme.measures.measure025,
                    paddingLeft: theme.measures.measure025,
                    ":hover": {
                        background: "none",
                        color: "#3b79b7",
                    },
                };
            };
            QueryBuilderStyle.QueryBuilderFilterLinkContainerStyle = function (theme) {
                return {
                    margin: "0",
                    width: "auto",
                    display: "flex",
                    flexDirection: "row",
                };
            };
            QueryBuilderStyle.QueryBuilderRelatedLinkContainerStyle = function (theme) {
                return {
                    margin: "0",
                    width: "auto",
                    flexDirection: "row",
                };
            };
            QueryBuilderStyle.QueryBuilderAddFilterAndRelatedEntityButtons = function (theme, isRTL) {
                return {
                    display: "flex",
                    flexDirection: "row",
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: " solid",
                    borderColor: theme.colors.grays.gray02,
                };
            };
            QueryBuilderStyle.ControlDefinitionContainerStyle = function (theme, error, isValueControl) {
                return {
                    width: "auto",
                    display: "flex",
                    flexDirection: "row",
                    height: isValueControl ? "auto" : "35px",
                    border: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode && !isValueControl
                        ? "none"
                        : error
                            ? "1px solid #ea0600"
                            : "1px solid #b3b3b3",
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                    color: theme.colors.grays.gray05,
                    fontFamily: theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                    minWidth: isValueControl ? "14.5rem" : undefined,
                    overflow: !isValueControl ? "hidden" : undefined,
                };
            };
            QueryBuilderStyle.SimpleModeContainerStyle = function (theme, name) {
                return {
                    width: "auto",
                    maxwidth: "20rem",
                    flexDirection: "row",
                    height: "35px",
                    lineHeight: "35px",
                    border: "none",
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                    color: theme.colors.grays.gray05,
                    fontFamily: name === QueryBuilder.Constants.ConditionFieldName.LHSAttribute ? theme.fontfamilies.semibold : theme.fontfamilies.regular,
                    fontSize: theme.fontsizes.font085,
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                };
            };
            QueryBuilderStyle.HiddenLabelStyle = function (theme) {
                return {
                    width: "0px",
                    height: "0px",
                    position: "absolute",
                    left: "-1000px",
                    top: "-1000px",
                };
            };
            QueryBuilderStyle.DialogFlyoutOkButtonStyle = function (theme) {
                return {
                    display: "block",
                    width: theme.measures.measure600,
                    height: theme.measures.measure250,
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                    background: theme.colors.basecolor.blue["blue3"],
                    color: theme.colors.basecolor.white,
                    textAlign: "center",
                    borderWidth: "1px",
                    borderStyle: "solid",
                    borderColor: theme.colors.basecolor.blue["blue3"],
                    ":hover": {
                        background: theme.colors.basecolor.blue["blue4"],
                        color: theme.colors.basecolor.white,
                    },
                };
            };
            QueryBuilderStyle.DialogFlyoutCancelButtonStyle = function (theme) {
                return {
                    display: "block",
                    width: theme.measures.measure600,
                    height: theme.measures.measure250,
                    marginLeft: theme.measures.measure025,
                    marginRight: theme.measures.measure025,
                    background: theme.colors.basecolor.white,
                    color: theme.colors.basecolor.blue["blue3"],
                    textAlign: "center",
                    borderWidth: "1px",
                    borderStyle: "solid",
                    borderColor: theme.colors.basecolor.blue["blue3"],
                    ":hover": {
                        borderColor: theme.colors.basecolor.blue["blue4"],
                    },
                };
            };
            QueryBuilderStyle.ConfirmationDialogContainerStyle = function (theme) {
                return {
                    width: "100%",
                    justifyContent: "center",
                    alignItems: "center",
                };
            };
            QueryBuilderStyle.ConfirmationDialogButtonContainerStyle = function (theme) {
                return {
                    marginTop: theme.measures.measure300,
                    flexDirection: "row",
                    alignSelf: "flex-end",
                    justifyContent: "flex-end",
                    flex: "0 0 auto",
                    width: "100%",
                };
            };
            QueryBuilderStyle.ConfirmationDialogTitleLabelStyle = function (theme) {
                return {
                    fontFamily: theme.fontfamilies.semilight,
                    color: theme.colors.grays.gray07,
                    fontSize: theme.fontsizes.font125,
                };
            };
            QueryBuilderStyle.ConfirmationDialogMessageLabelStyle = function (theme, isRTL) {
                return {
                    fontFamily: theme.fontfamilies.regular,
                    color: theme.colors.grays.gray07,
                    fontSize: theme.fontsizes.font100,
                    marginTop: theme.measures.measure125,
                    marginLeft: isRTL ? undefined : "2.75rem",
                    marginRight: isRTL ? "2.75rem" : undefined,
                };
            };
            QueryBuilderStyle.ConfirmationTitleIconContainerStyle = function (theme) {
                return {
                    width: "100%",
                    alignItems: "center",
                };
            };
            QueryBuilderStyle.DialogContainerContentStyle = function (theme) {
                return {
                    width: "100%",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.ConfirmationDialogWarningIconStyle = function (theme) {
                return {
                    color: theme.colors.basecolor.yellow["yellow3"],
                    fontSize: theme.fontsizes.font125,
                    marginLeft: theme.measures.measure075,
                    marginRight: theme.measures.measure075,
                };
            };
            QueryBuilderStyle.ConfirmationDialogCloseIconStyle = function (theme) {
                return {
                    color: theme.colors.grays.gray07,
                    fontSize: theme.fontsizes.font125,
                };
            };
            QueryBuilderStyle.DialogContainerHeaderStyle = function (theme) {
                return {
                    width: "100%",
                };
            };
            QueryBuilderStyle.getDialogContainerContent = function (theme) {
                return {
                    width: "100%",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.ConfirmationDialogCloseButtonStyle = function (theme) {
                return {
                    width: "auto",
                    border: "0",
                    background: "none",
                    color: theme.colors.grays.gray07,
                    fontSize: theme.fontsizes.font125,
                };
            };
            QueryBuilderStyle.DialogOverlayContainerStyle = function (theme) {
                return {
                    position: "fixed",
                    width: "100%",
                    height: "100%",
                    top: "0px",
                    left: "0px",
                    backgroundColor: "rgba(0,0,0,0.6)",
                    zIndex: "1",
                };
            };
            QueryBuilderStyle.QueryBuilderFlyoutLabelStyle = function (theme) {
                return {
                    fontFamily: theme.fontfamilies.regular,
                    marginRight: theme.measures.measure025,
                    marginLeft: theme.measures.measure025,
                };
            };
            QueryBuilderStyle.QueryBuilderFlyoutListItemLabelStyle = function (theme, isRTL) {
                return {
                    fontFamily: theme.fontfamilies.regular,
                    fontWeight: "bold",
                    paddingLeft: theme.measures.measure100,
                    paddingRight: theme.measures.measure100,
                };
            };
            QueryBuilderStyle.QueryBuilderFlyoutListItemStyle = function (theme) {
                return {
                    fontSize: theme.fontsizes.font085,
                    color: theme.colors.grays.gray07,
                    fontFamily: theme.fontfamilies.regular,
                    paddingTop: theme.measures.measure050,
                    paddingBottom: theme.measures.measure050,
                    display: "flex",
                    ":hover": {
                        backgroundColor: theme.colors.grays.gray01,
                    },
                    ":focus": {
                        backgroundColor: theme.colors.grays.gray03,
                    },
                };
            };
            QueryBuilderStyle.QueryBuilderFlyoutRemoveListItemStyle = function (theme) {
                return {
                    fontSize: theme.fontsizes.font100,
                    color: theme.colors.grays.gray07,
                    fontFamily: theme.fontfamilies.regular,
                    paddingTop: theme.measures.measure050,
                    paddingBottom: theme.measures.measure050,
                    paddingLeft: theme.measures.measure100,
                    paddingRight: theme.measures.measure100,
                    borderTopWidth: "1px",
                    borderTopStyle: "solid",
                    borderTopColor: theme.colors.grays.gray03,
                    display: "flex",
                    ":hover": {
                        backgroundColor: theme.colors.grays.gray01,
                    },
                    ":focus": {
                        backgroundColor: theme.colors.grays.gray03,
                    },
                };
            };
            QueryBuilderStyle.QueryBuilderFlyoutListStyle = function (theme) {
                return {
                    listStyle: "none",
                    display: "inline-block",
                    maxHeight: "322px",
                };
            };
            QueryBuilderStyle.QueryBuilderEntityHeaderStyle = function (theme) {
                return {
                    border: theme.borders.border02,
                    background: theme.colors.grays.gray03,
                    display: "flex",
                    flexDirection: "row",
                    width: "auto",
                    height: theme.measures.measure175,
                    marginRight: theme.measures.measure025,
                    marginLeft: theme.measures.measure025,
                    alignItems: "center",
                };
            };
            QueryBuilderStyle.QueryBuilderEntityHeaderSelectStyle = function (theme) {
                return {
                    borderWidth: "1px",
                    borderStyle: "solid",
                    borderColor: theme.colors.grays.gray04,
                    display: "flex",
                    flexDirection: "row",
                    height: theme.measures.measure175,
                    marginRight: theme.measures.measure025,
                    marginLeft: theme.measures.measure025,
                    width: "auto",
                    alignItems: "center",
                };
            };
            QueryBuilderStyle.QueryBuilderEntityIconButtonStyle = function (theme) {
                return {
                    background: "transparent",
                    width: "auto",
                    paddingLeft: theme.measures.measure050,
                    paddingRight: theme.measures.measure050,
                    color: theme.colors.grays.gray06,
                    fontSize: theme.fontsizes.font085,
                    border: "0",
                    ":hover": {
                        background: "transparent",
                    },
                    flexDirection: "row",
                };
            };
            QueryBuilderStyle.ConditionListContainerStyle = function (theme, isRTL) {
                return {
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                };
            };
            QueryBuilderStyle.AddButtonsContainerStyle = function (theme, isRTL) {
                return {
                    display: "flex",
                    flexDirection: "row",
                    borderLeftWidth: isRTL ? undefined : "2px",
                    borderRightWidth: isRTL ? "2px" : undefined,
                    borderStyle: "solid",
                    borderColor: theme.colors.grays.gray02,
                };
            };
            QueryBuilderStyle.GroupNodeChildListItemStyle = function (theme) {
                return {
                    listStyleType: "none",
                    display: "flex",
                    flexDirection: "column",
                };
            };
            QueryBuilderStyle.QueryBuilderDropIconContainerStyle = function (theme) {
                return {
                    width: theme.measures.measure100,
                    display: "flex",
                    marginRight: theme.measures.measure025,
                    marginLeft: theme.measures.measure025,
                };
            };
            QueryBuilderStyle.QueryBuilderDropDownIcon = function (theme) {
                return {
                    marginRight: theme.measures.measure025,
                    marginLeft: theme.measures.measure025,
                    display: "flex",
                    fontSize: theme.fontsizes.font085,
                };
            };
            return QueryBuilderStyle;
        }());
        QueryBuilder.QueryBuilderStyle = QueryBuilderStyle;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ComponentIdPrefixesAndSuffixes = (function () {
            function ComponentIdPrefixesAndSuffixes() {
            }
            ComponentIdPrefixesAndSuffixes.getCommandBarId = function () {
                return "GlobalCommandBar";
            };
            ComponentIdPrefixesAndSuffixes.getRunQueryButtonId = function () {
                return "GlobalRunQueryButton";
            };
            ComponentIdPrefixesAndSuffixes.getAndButtonId = function () {
                return "GlobalAndButton";
            };
            ComponentIdPrefixesAndSuffixes.getOrButtonId = function () {
                return "GlobalOrButton";
            };
            ComponentIdPrefixesAndSuffixes.getDeleteButtonId = function () {
                return "GlobalDeleteButton";
            };
            ComponentIdPrefixesAndSuffixes.getUngroupButtonId = function () {
                return "GlobalUngroupButton";
            };
            ComponentIdPrefixesAndSuffixes.getClearButtonId = function () {
                return "GlobalClearButton";
            };
            ComponentIdPrefixesAndSuffixes.getCommandBarIconPrefix = function () {
                return "commandBarIcon-";
            };
            ComponentIdPrefixesAndSuffixes.getCommandBarButtonLabelPrefix = function () {
                return "commandBarButtonLabel-";
            };
            ComponentIdPrefixesAndSuffixes.getConditionIdPrefix = function () {
                return "conditionNode_";
            };
            ComponentIdPrefixesAndSuffixes.getConditionErrorsPrefix = function () {
                return "conditionErrors_";
            };
            ComponentIdPrefixesAndSuffixes.getConditionNodeAndErrorsContainerPrefix = function () {
                return "conditionNodeAndErrorsContainer_";
            };
            ComponentIdPrefixesAndSuffixes.getConditionChildPrefix = function () {
                return "conditionElement_";
            };
            ComponentIdPrefixesAndSuffixes.getTypeAheadControlPrefix = function () {
                return QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadControlPrefix();
            };
            ComponentIdPrefixesAndSuffixes.getTypeAheadTextBoxPrefix = function () {
                return QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix();
            };
            ComponentIdPrefixesAndSuffixes.getConditionNodeCheckboxPrefix = function () {
                return "checkbox-condition-";
            };
            ComponentIdPrefixesAndSuffixes.getRelatedEntitySectionElipsisButtonPrefix = function () {
                return "related-entity-elipsis-button-";
            };
            ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListPrefix = function () {
                return "related-enitity-elipsis-flyout-list-";
            };
            ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemRemovePrefix = function () {
                return "related-enitity-elipsis-flyout-listitem-remove-";
            };
            ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemNotContainsDataPrefix = function () {
                return "related-enitity-elipsis-flyout-listitem-does-not-contain-data-";
            };
            ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemContainsDataPrefix = function () {
                return "related-enitity-elipsis-flyout-listitem-contains-data-";
            };
            ComponentIdPrefixesAndSuffixes.getShowHideInSimpleModeId = function () {
                return "ShowHideInSimpleMode";
            };
            ComponentIdPrefixesAndSuffixes.getcommandBarModeId = function () {
                return "commandBarMode";
            };
            ComponentIdPrefixesAndSuffixes.getsimpleAdvLabelId = function () {
                return "simpleAdvLabelId";
            };
            ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId = function () {
                return "simpleAdvancedCheckId";
            };
            ComponentIdPrefixesAndSuffixes.gethiddenConditionId = function () {
                return "hiddenConditionId";
            };
            ComponentIdPrefixesAndSuffixes.clearConfirmationDialogOkayButtonId = function () {
                return "confirm-dialog-OK-button";
            };
            ComponentIdPrefixesAndSuffixes.clearConfirmationDialogCancelButtonId = function () {
                return "confirm-dialog-Cancel-button";
            };
            ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix = function () {
                return "checkBoxForGroup_";
            };
            ComponentIdPrefixesAndSuffixes.getSimpleModeErrorId = function () {
                return "SimpleModeError";
            };
            ComponentIdPrefixesAndSuffixes.getQueryBuilderControlPrefix = function () {
                return "MscrmControls.QueryBuilder.QueryBuilderControl-";
            };
            ComponentIdPrefixesAndSuffixes.getAddRelatedEntityButtonPrefix = function () {
                return "add-related-entity-";
            };
            ComponentIdPrefixesAndSuffixes.getHiddenLabelPrefix = function () {
                return "hiddenAccessibilityLabel_";
            };
            ComponentIdPrefixesAndSuffixes.ariaLiveLabelId = function () {
                return "ariaLiveQB";
            };
            return ComponentIdPrefixesAndSuffixes;
        }());
        QueryBuilder.ComponentIdPrefixesAndSuffixes = ComponentIdPrefixesAndSuffixes;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var QueryBuilderConstants;
        (function (QueryBuilderConstants) {
            "use strict";
            QueryBuilderConstants.CONTAINER_TYPE = "Container Type";
            QueryBuilderConstants.PRIMARY_KEY = "PrimaryKey";
        })(QueryBuilderConstants = QueryBuilder.QueryBuilderConstants || (QueryBuilder.QueryBuilderConstants = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var CrmDataProvider = (function () {
            function CrmDataProvider() {
            }
            CrmDataProvider.prototype.getData = function (context, data) {
                var self = this;
                var records = new QueryBuilder.Dictionary();
                return new Promise(function (resolve, reject) {
                    new QueryBuilder.EntityMetadataProvider()
                        .getEntitiesMetadata(data.keys(), QueryBuilder.AdvancedFindConstants.ENTITY_METADATA_ATTRIBUTES, "", context)
                        .then(function (response) {
                        var promises = [];
                        for (var _i = 0, _a = data.keys(); _i < _a.length; _i++) {
                            var entityLogicalName = _a[_i];
                            promises.push(self.fetchRecords(context, response.get(entityLogicalName), data.get(entityLogicalName).toList(), records));
                        }
                        Promise.all(promises).then(function () {
                            resolve(records);
                        }, function (error) {
                            reject(error);
                        });
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            CrmDataProvider.prototype.fetchRecords = function (context, entityMetadata, recordIds, records) {
                return new Promise(function (resolve, reject) {
                    new QueryBuilder.ODataHelper(context)
                        .retrieveEntityData(entityMetadata.logicalCollectionName, [entityMetadata.primaryNameAttribute], entityMetadata.primaryIdAttribute, recordIds)
                        .then(function (response) {
                        if (response && response.value && response.value.length) {
                            for (var i = 0; i < response.value.length; i++) {
                                var recordId = response.value[i][entityMetadata.primaryIdAttribute].toLowerCase();
                                records.put(recordId, new QueryBuilder.CrmRecord(response.value[i][entityMetadata.primaryNameAttribute], entityMetadata.logicalName));
                            }
                        }
                        resolve();
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            return CrmDataProvider;
        }());
        QueryBuilder.CrmDataProvider = CrmDataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var ViewMetadataProvider = (function () {
            function ViewMetadataProvider() {
            }
            ViewMetadataProvider.prototype.getDefaultLookupViewIdForEntity = function (entityLogicalName, context) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    self
                        .getEntitiesViewMetadata([entityLogicalName], ["returnedtypecode", "savedqueryid", "isdefault", "querytype"], [QueryBuilder.Constants.ViewType.Lookup], "isdefault eq true", context)
                        .then(function (entityViewMetadataMap) {
                        resolve(entityViewMetadataMap[entityLogicalName].defaultLookupViewId);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            ViewMetadataProvider.prototype.getEntitiesViewMetadata = function (entityList, columns, supportedViewTypes, additionalFilterClause, context) {
                var self = this;
                var entityViewMap = {};
                var uncachedEntityList = entityList.filter(function (entity) { return !QueryBuilder.MetadataStore.Instance.containsEntityViewMetadata(entity); });
                return new Promise(function (resolve, reject) {
                    if (uncachedEntityList.length == 0) {
                        for (var _i = 0, entityList_1 = entityList; _i < entityList_1.length; _i++) {
                            var entity = entityList_1[_i];
                            entityViewMap[entity] = QueryBuilder.MetadataStore.Instance.getEntityViewMetadata(entity);
                        }
                        resolve(entityViewMap);
                    }
                    else {
                        new QueryBuilder.ODataHelper(context)
                            .retrieveViewsForEntities(uncachedEntityList, columns, supportedViewTypes, additionalFilterClause)
                            .then(function (response) {
                            for (var _i = 0, _a = response.value; _i < _a.length; _i++) {
                                var view = _a[_i];
                                var entityViewMetadata = self.parseEntityViewMetadataResponse(view);
                                QueryBuilder.MetadataStore.Instance.addEntityViewMetadata(view.returnedtypecode, entityViewMetadata);
                            }
                            for (var _b = 0, entityList_2 = entityList; _b < entityList_2.length; _b++) {
                                var entity = entityList_2[_b];
                                entityViewMap[entity] = QueryBuilder.MetadataStore.Instance.getEntityViewMetadata(entity);
                            }
                            resolve(entityViewMap);
                        }, function (error) {
                            reject(error);
                        });
                    }
                });
            };
            ViewMetadataProvider.prototype.parseEntityViewMetadataResponse = function (metadataResponse) {
                var entityViewMetadata = new QueryBuilder.EntityViewMetadata(Guid.EMPTY.toString());
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataResponse.querytype) &&
                    !MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataResponse.isdefault) &&
                    metadataResponse.querytype === QueryBuilder.Constants.ViewType.Lookup &&
                    metadataResponse.isdefault) {
                    entityViewMetadata.defaultLookupViewId = metadataResponse.savedqueryid;
                }
                return entityViewMetadata;
            };
            return ViewMetadataProvider;
        }());
        QueryBuilder.ViewMetadataProvider = ViewMetadataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SampleInputConverter = (function () {
            function SampleInputConverter() {
            }
            SampleInputConverter.prototype.convert = function (queryTree) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    var results = {};
                    new QueryBuilder.SampleInitialDataProvider().getAllData(results).then(function () {
                        self._populateTree(queryTree, results);
                        resolve();
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            SampleInputConverter.prototype._populateTree = function (queryTree, results) {
                var input = queryTree.Context.parameters
                    ? queryTree.Context.parameters.Input
                        ? queryTree.Context.parameters.Input.raw
                        : undefined
                    : undefined;
                if (input) {
                    var stack = new Array();
                    for (var i = 0; i < input.length; i++) {
                        switch (input.charAt(i)) {
                            case " ":
                                break;
                            case "(":
                            case "&":
                            case "|":
                                stack.push(input.charAt(i));
                                break;
                            case ")":
                                var stackTop = "";
                                var inBraces = new Array();
                                while (stackTop != "(") {
                                    stackTop = stack.pop();
                                    inBraces.push(stackTop);
                                }
                                inBraces.pop();
                                if (inBraces.length == 1) {
                                    stack.push(inBraces[0]);
                                }
                                else {
                                    var nodeType = inBraces[1] == "&" ? QueryBuilder.Constants.QueryTreeNodeType.AND : QueryBuilder.Constants.QueryTreeNodeType.OR;
                                    var logicalGroupNode = queryTree.createLogicalGroupNode(nodeType);
                                    inBraces.reverse();
                                    for (var j = 0; j < inBraces.length; j = j + 2) {
                                        logicalGroupNode.addChild(inBraces[j]);
                                    }
                                    stack.push(logicalGroupNode);
                                }
                                break;
                            default:
                                var lhs = "";
                                var operator = "";
                                var rhs = "";
                                while (input.charAt(i) != " ") {
                                    lhs += input.charAt(i);
                                    i++;
                                }
                                i++;
                                while (input.charAt(i) != " ") {
                                    operator += input.charAt(i);
                                    i++;
                                }
                                i++;
                                while (input.charAt(i) != ")") {
                                    rhs += input.charAt(i);
                                    i++;
                                }
                                i--;
                                stack.push(this.getConditionNode(queryTree, results, lhs, operator, rhs));
                                break;
                        }
                    }
                    queryTree.Root = stack[0];
                }
                else {
                    queryTree.Root = queryTree.createLogicalGroupNode(QueryBuilder.Constants.QueryTreeNodeType.AND);
                }
            };
            SampleInputConverter.prototype.getConditionNode = function (queryTree, results, lhs, operator, rhs) {
                var conditionNode = queryTree.createConditionNode();
                var lhsComboBoxOptions = results["sample-field"] ? results["sample-field"] : [];
                var lhsControl = QueryBuilder.Utils.createComboBoxDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.SampleField, false, lhsComboBoxOptions, lhs, conditionNode.Condition);
                var operatorComboBoxOptions = results["operator"] ? results["operator"] : [];
                var operatorControl = QueryBuilder.Utils.createComboBoxDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.Operator, false, operatorComboBoxOptions, operator, conditionNode.Condition);
                var valueControl = null;
                switch (lhs) {
                    case "tb":
                        valueControl = QueryBuilder.Utils.createTextBoxDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, rhs, conditionNode.Condition);
                        break;
                    case "dt":
                        valueControl = QueryBuilder.Utils.createDateTimeDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, rhs, conditionNode.Condition);
                        break;
                    case "cb":
                        var valueComboBoxOptions = results["value-combo-box"]
                            ? results["value-combo-box"]
                            : [];
                        valueControl = QueryBuilder.Utils.createComboBoxDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, valueComboBoxOptions, rhs, conditionNode.Condition);
                        break;
                    case "opst":
                        var valueOptionSetOptions = results["value-option-set"]
                            ? results["value-option-set"]
                            : [];
                        valueControl = QueryBuilder.Utils.createOptionSetDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, valueOptionSetOptions, parseInt(rhs), conditionNode.Condition);
                        break;
                    case "tas":
                        var valueTypeAheadSelectOptions = results["value-type-ahead-select"]
                            ? results["value-type-ahead-select"]
                            : [];
                        valueControl = QueryBuilder.Utils.createTypeAheadSelectDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, "", false, rhs, conditionNode.Condition, valueTypeAheadSelectOptions, "", "Value", null);
                        break;
                    case "mspl":
                        var valueMultiSelectPicklistOptions = results["value-multi-select-picklist"]
                            ? results["value-multi-select-picklist"]
                            : [];
                        var values = rhs
                            ? rhs.split(",").map(function (item) {
                                return parseInt(item);
                            })
                            : [];
                        valueControl = QueryBuilder.Utils.createMultiSelectPicklistDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, valueMultiSelectPicklistOptions, values, conditionNode.Condition);
                        break;
                    case "slp":
                        valueControl = QueryBuilder.Utils.createSimpleLookupDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, ["account"], null, conditionNode.Condition);
                        break;
                    case "pllp":
                        valueControl = QueryBuilder.Utils.createPartyListLookupDefinition(queryTree.Context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, ["account"], null, conditionNode.Condition);
                        break;
                    default:
                        break;
                }
                conditionNode.Condition.ControlDefinitions = [lhsControl, operatorControl, valueControl];
                return conditionNode;
            };
            return SampleInputConverter;
        }());
        QueryBuilder.SampleInputConverter = SampleInputConverter;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            var SampleControlDefinitionProvider = (function () {
                function SampleControlDefinitionProvider() {
                }
                SampleControlDefinitionProvider.prototype.getInitialControlDefinitions = function (context, conditionNode) {
                    var self = this;
                    return new Promise(function (resolve, reject) {
                        new QueryBuilder.SampleFieldDataProvider().getComboBoxData().then(function (options) {
                            var controlDefinitions = [
                                QueryBuilder.Utils.createComboBoxDefinition(context, QueryBuilder.Constants.ConditionFieldName.SampleField, false, options, null, conditionNode.Condition),
                            ];
                            resolve(controlDefinitions);
                        }, function (error) {
                            reject(error);
                        });
                    });
                };
                SampleControlDefinitionProvider.prototype.getNextControlDefinitions = function (context, controlDefinitions, conditionNode) {
                    var self = this;
                    return new Promise(function (resolve, reject) {
                        var controlName = controlDefinitions[controlDefinitions.length - 1].name;
                        switch (controlName) {
                            case QueryBuilder.Constants.ConditionFieldName.SampleField:
                                new QueryBuilder.SampleOperatorDataProvider().getComboBoxData().then(function (options) {
                                    var controlDefinitions = [
                                        QueryBuilder.Utils.createComboBoxDefinition(context, QueryBuilder.Constants.ConditionFieldName.Operator, false, options, null, conditionNode.Condition),
                                    ];
                                    resolve(controlDefinitions);
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case QueryBuilder.Constants.ConditionFieldName.Operator:
                                self
                                    .getRHSValueControlDefinition(context, controlDefinitions[0].value.value, conditionNode)
                                    .then(function (controlDefinition) {
                                    resolve([controlDefinition]);
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                resolve([]);
                                break;
                            default:
                                reject("Unexpected Control Name: " + controlName);
                                break;
                        }
                    });
                };
                SampleControlDefinitionProvider.prototype.getLinkedEntityControlDefinition = function (context, rootNodeContainer) {
                    return new Promise(function (resolve, reject) {
                        resolve(null);
                    });
                };
                SampleControlDefinitionProvider.prototype.getRHSValueControlDefinition = function (context, sampleFieldValue, conditionNode) {
                    return new Promise(function (resolve, reject) {
                        switch (sampleFieldValue) {
                            case "tb":
                                resolve(QueryBuilder.Utils.createTextBoxDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, null, conditionNode.Condition));
                                break;
                            case "dt":
                                resolve(QueryBuilder.Utils.createDateTimeDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, null, conditionNode.Condition));
                                break;
                            case "cb":
                                new QueryBuilder.SampleValueComboBoxDataProvider().getComboBoxData().then(function (comboBoxOptions) {
                                    resolve(QueryBuilder.Utils.createComboBoxDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, comboBoxOptions, null, conditionNode.Condition));
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case "opst":
                                new QueryBuilder.SampleValueOptionSetDataProvider().getOptionSetData().then(function (optionSetOptions) {
                                    resolve(QueryBuilder.Utils.createOptionSetDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, optionSetOptions, null, conditionNode.Condition));
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case "tas":
                                new QueryBuilder.SampleValueTypeAheadSelectDataProvider().getTypeAheadSelectData().then(function (typeAheadSelectOptions) {
                                    resolve(QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, "Value", false, null, conditionNode.Condition, typeAheadSelectOptions, "", "Value", null));
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case "mspl":
                                new QueryBuilder.SampleValueMultiSelectPicklistDataProvider().getMultiSelectPicklistata().then(function (multiSelectPicklistOptions) {
                                    resolve(QueryBuilder.Utils.createMultiSelectPicklistDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, multiSelectPicklistOptions, null, conditionNode.Condition));
                                }, function (error) {
                                    reject(error);
                                });
                                break;
                            case "slp":
                                resolve(QueryBuilder.Utils.createSimpleLookupDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, ["account"], null, conditionNode.Condition));
                                break;
                            case "pllp":
                                resolve(QueryBuilder.Utils.createPartyListLookupDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, ["account"], null, conditionNode.Condition));
                                break;
                            default:
                                reject("Unexpected Field Type: " + sampleFieldValue);
                                break;
                        }
                    });
                };
                return SampleControlDefinitionProvider;
            }());
            ConditionModel.SampleControlDefinitionProvider = SampleControlDefinitionProvider;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SampleInitialDataProvider = (function () {
            function SampleInitialDataProvider() {
            }
            SampleInitialDataProvider.prototype.getAllData = function (results) {
                return new Promise(function (resolve, reject) {
                    var promises = [];
                    promises.push(new SampleFieldDataProvider().getComboBoxData());
                    promises.push(new SampleOperatorDataProvider().getComboBoxData());
                    promises.push(new SampleValueComboBoxDataProvider().getComboBoxData());
                    promises.push(new SampleValueOptionSetDataProvider().getOptionSetData());
                    promises.push(new SampleValueTypeAheadSelectDataProvider().getTypeAheadSelectData());
                    promises.push(new SampleValueMultiSelectPicklistDataProvider().getMultiSelectPicklistata());
                    Promise.all(promises).then(function (responses) {
                        results["sample-field"] = responses[0];
                        results["operator"] = responses[1];
                        results["value-combo-box"] = responses[2];
                        results["value-option-set"] = responses[3];
                        results["value-type-ahead-select"] = responses[4];
                        results["value-multi-select-picklist"] = responses[5];
                        resolve();
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            return SampleInitialDataProvider;
        }());
        QueryBuilder.SampleInitialDataProvider = SampleInitialDataProvider;
        var SampleFieldDataProvider = (function () {
            function SampleFieldDataProvider() {
            }
            SampleFieldDataProvider.prototype.getComboBoxData = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve([
                        { Value: "", Label: "" },
                        { Value: "tb", Label: "Text Box" },
                        { Value: "dt", Label: "Date Time" },
                        { Value: "cb", Label: "Combo Box" },
                        { Value: "mspl", Label: "Multi-Select Picklist" },
                        { Value: "opst", Label: "Option Set" },
                        { Value: "tas", Label: "Type-Ahead Select" },
                        { Value: "slp", Label: "Lookup" },
                        { Value: "pllp", Label: "PartyListLookup" },
                    ]);
                });
            };
            return SampleFieldDataProvider;
        }());
        QueryBuilder.SampleFieldDataProvider = SampleFieldDataProvider;
        var SampleOperatorDataProvider = (function () {
            function SampleOperatorDataProvider() {
            }
            SampleOperatorDataProvider.prototype.getComboBoxData = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve([
                        { Value: "", Label: "" },
                        { Value: "eq", Label: "Equals" },
                        { Value: "neq", Label: "Not Equals" },
                        { Value: "lt", Label: "Less Than" },
                        { Value: "gt", Label: "Greater Than" },
                    ]);
                });
            };
            return SampleOperatorDataProvider;
        }());
        QueryBuilder.SampleOperatorDataProvider = SampleOperatorDataProvider;
        var SampleValueComboBoxDataProvider = (function () {
            function SampleValueComboBoxDataProvider() {
            }
            SampleValueComboBoxDataProvider.prototype.getComboBoxData = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve([
                        { Value: "", Label: "" },
                        { Value: "I", Label: "I" },
                        { Value: "II", Label: "II" },
                        { Value: "III", Label: "III" },
                    ]);
                });
            };
            return SampleValueComboBoxDataProvider;
        }());
        QueryBuilder.SampleValueComboBoxDataProvider = SampleValueComboBoxDataProvider;
        var SampleValueOptionSetDataProvider = (function () {
            function SampleValueOptionSetDataProvider() {
            }
            SampleValueOptionSetDataProvider.prototype.getOptionSetData = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve([
                        { Value: 0, Label: "Red" },
                        { Value: 1, Label: "Blue" },
                        { Value: 2, Label: "Green" },
                        { Value: 3, Label: "Yellow" },
                    ]);
                });
            };
            return SampleValueOptionSetDataProvider;
        }());
        QueryBuilder.SampleValueOptionSetDataProvider = SampleValueOptionSetDataProvider;
        var SampleValueTypeAheadSelectDataProvider = (function () {
            function SampleValueTypeAheadSelectDataProvider() {
            }
            SampleValueTypeAheadSelectDataProvider.prototype.getTypeAheadSelectData = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve({
                        isSectioningEnabled: true,
                        sections: [
                            { sectionName: "First", sectionElements: [{ Value: "1", Label: "One" }, { Value: "2", Label: "Two" }] },
                            { sectionName: "Second", sectionElements: [{ Value: "3", Label: "Three" }, { Value: "4", Label: "Four" }] },
                        ],
                    });
                });
            };
            return SampleValueTypeAheadSelectDataProvider;
        }());
        QueryBuilder.SampleValueTypeAheadSelectDataProvider = SampleValueTypeAheadSelectDataProvider;
        var SampleValueMultiSelectPicklistDataProvider = (function () {
            function SampleValueMultiSelectPicklistDataProvider() {
            }
            SampleValueMultiSelectPicklistDataProvider.prototype.getMultiSelectPicklistata = function () {
                var self = this;
                return new Promise(function (resolve, reject) {
                    resolve([
                        { Value: 0, Label: "i" },
                        { Value: 1, Label: "ii" },
                        { Value: 2, Label: "iii" },
                        { Value: 3, Label: "iv" },
                    ]);
                });
            };
            return SampleValueMultiSelectPicklistDataProvider;
        }());
        QueryBuilder.SampleValueMultiSelectPicklistDataProvider = SampleValueMultiSelectPicklistDataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SpecialConditionOperatorProvider = (function () {
            function SpecialConditionOperatorProvider() {
            }
            SpecialConditionOperatorProvider.prototype.getSpecialConditionOperators = function (context, operatorData, attributeLogicalName, entityAttributeMetadata, useTypeAhead) {
                var _this = this;
                if (useTypeAhead === void 0) { useTypeAhead = true; }
                var self = this;
                var operatorsToAppend = [];
                var currentOperators = useTypeAhead
                    ? operatorData.sections[0].sectionElements
                    : operatorData;
                var selectedAttribute = entityAttributeMetadata.attributes[attributeLogicalName];
                return new Promise(function (resolve, reject) {
                    switch (selectedAttribute.attributeType.Name) {
                        case QueryBuilder.EntityAttributeType.LookUp:
                            if (selectedAttribute.targets.length <= 0) {
                                resolve(operatorsToAppend);
                            }
                            operatorsToAppend.push.apply(operatorsToAppend, _this.getEntityRelatedOperators(selectedAttribute.targets, currentOperators));
                            if (!(selectedAttribute.targets.length == 1)) {
                                resolve(operatorsToAppend);
                            }
                            new QueryBuilder.AttributeMetadataProvider().getAttributeMetadata(context, selectedAttribute.targets[0]).then(function (entityMetadata) {
                                if (QueryBuilder.Utils.isHierarchyEnabledForEntity(entityMetadata)) {
                                    operatorsToAppend.push.apply(operatorsToAppend, [QueryBuilder.ConditionOperator.under, QueryBuilder.ConditionOperator.not_under]);
                                }
                                resolve(operatorsToAppend);
                            }, function (error) {
                                reject(error);
                            });
                            break;
                        case QueryBuilder.EntityAttributeType.UniqueIdentifier:
                            if (selectedAttribute.attributeBaseType == QueryBuilder.QueryBuilderConstants.PRIMARY_KEY &&
                                QueryBuilder.Utils.isHierarchyEnabledForEntity(entityAttributeMetadata)) {
                                operatorsToAppend.push.apply(operatorsToAppend, [QueryBuilder.ConditionOperator.under, QueryBuilder.ConditionOperator.not_under]);
                            }
                            operatorsToAppend.push.apply(operatorsToAppend, _this.getEntityRelatedOperators([entityAttributeMetadata.logicalName], currentOperators));
                            resolve(operatorsToAppend);
                            break;
                        default:
                            resolve(operatorsToAppend);
                    }
                });
            };
            SpecialConditionOperatorProvider.prototype.getEntityRelatedOperators = function (entities, currentOperators) {
                var operatorsToAppend = [];
                if (entities.indexOf("systemuser") > -1 &&
                    currentOperators.filter(function (operatorData) {
                        return (operatorData.Value === QueryBuilder.ConditionOperator.eq_userid || operatorData.Value === QueryBuilder.ConditionOperator.ne_userid);
                    }).length === 0) {
                    operatorsToAppend.push.apply(operatorsToAppend, [QueryBuilder.ConditionOperator.eq_userid, QueryBuilder.ConditionOperator.ne_userid]);
                }
                if (entities.indexOf("businessunit") > -1 &&
                    currentOperators.filter(function (operatorData) {
                        return (operatorData.Value === QueryBuilder.ConditionOperator.eq_businessid ||
                            operatorData.Value === QueryBuilder.ConditionOperator.ne_businessid);
                    }).length === 0) {
                    operatorsToAppend.push.apply(operatorsToAppend, [QueryBuilder.ConditionOperator.eq_businessid, QueryBuilder.ConditionOperator.ne_businessid]);
                }
                return operatorsToAppend;
            };
            return SpecialConditionOperatorProvider;
        }());
        QueryBuilder.SpecialConditionOperatorProvider = SpecialConditionOperatorProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var CrmRecord = (function () {
            function CrmRecord(name, entityLogicalName) {
                this.name = name;
                this.entityLogicalName = entityLogicalName;
            }
            return CrmRecord;
        }());
        QueryBuilder.CrmRecord = CrmRecord;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var BaseControlDefinition = (function () {
                function BaseControlDefinition(context, name, label, isHidden, parentCondition) {
                    this._context = context;
                    this._name = name;
                    this._label = label;
                    this._controlId = QueryBuilder.Utils.newGuid();
                    this._isHidden = isHidden;
                    this._errors = [];
                    this._controlChangeHandler = new ConditionModel.ConditionControlChangeHandler(parentCondition);
                }
                Object.defineProperty(BaseControlDefinition.prototype, "context", {
                    get: function () {
                        return this._context;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "name", {
                    get: function () {
                        return this._name;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "label", {
                    get: function () {
                        return this._label;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "controlId", {
                    get: function () {
                        return this._controlId;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "type", {
                    get: function () {
                        return this._type;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "isHidden", {
                    get: function () {
                        return this._isHidden;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "errors", {
                    get: function () {
                        return this._errors;
                    },
                    set: function (errors) {
                        this._errors = errors;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BaseControlDefinition.prototype, "controlChangeHandler", {
                    get: function () {
                        return this._controlChangeHandler;
                    },
                    set: function (controlChangeHandler) {
                        this._controlChangeHandler = controlChangeHandler;
                    },
                    enumerable: true,
                    configurable: true
                });
                BaseControlDefinition.prototype.getView = function () {
                    return null;
                };
                BaseControlDefinition.prototype.getForElementId = function () {
                    return null;
                };
                BaseControlDefinition.prototype.executeOnChange = function () {
                    this.controlChangeHandler.onChange(this);
                };
                return BaseControlDefinition;
            }());
            ConditionModel.BaseControlDefinition = BaseControlDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var FiscalYearAndPeriodDefinition = (function (_super) {
                __extends(FiscalYearAndPeriodDefinition, _super);
                function FiscalYearAndPeriodDefinition(context, name, label, isHidden, data, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.FiscalYearAndPeriod;
                    _this._data = data;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(FiscalYearAndPeriodDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalYearAndPeriodDefinition.prototype, "data", {
                    get: function () {
                        return this._data;
                    },
                    set: function (data) {
                        this._data = data;
                    },
                    enumerable: true,
                    configurable: true
                });
                FiscalYearAndPeriodDefinition.prototype.getFiscalYearProps = function () {
                    var _this = this;
                    return {
                        controlstates: {
                            hasFocus: this.context.mode.hasFocus,
                            isControlDisabled: false,
                        },
                        descriptor: {
                            Id: "fiscalYear_" + this.controlId,
                            Label: "MscrmFiscalYearControl",
                            Name: "FiscalYearControl",
                            ShowLabel: false,
                            Visible: true,
                            Disabled: false,
                        },
                        configuration: {
                            CustomControlId: "MscrmControls.FieldControls.OptionSet",
                            Name: "FiscalYearControl",
                            Version: "1.0.0",
                            Parameters: {
                                value: {
                                    Usage: 3,
                                    Static: false,
                                    Value: this.value != null ? this.value.yearValue : null,
                                    Type: "OptionSet",
                                    Attributes: {
                                        LogicalName: "FiscalYearControl" + this.controlId,
                                        Options: this.data.years,
                                        OptionSet: this.data.years,
                                    },
                                    Callback: function (change) { return _this.onYearChangeHandler(change); },
                                },
                            },
                        },
                    };
                };
                FiscalYearAndPeriodDefinition.prototype.getFiscalPeriodProps = function () {
                    var _this = this;
                    return {
                        controlstates: {
                            hasFocus: this.context.mode.hasFocus,
                            isControlDisabled: false,
                        },
                        descriptor: {
                            Id: "fiscalPeriod_" + this.controlId,
                            Label: "MscrmFiscalPeriodControl",
                            Name: "FiscalPeriodControl",
                            ShowLabel: false,
                            Visible: true,
                            Disabled: false,
                        },
                        configuration: {
                            CustomControlId: "MscrmControls.FieldControls.OptionSet",
                            Name: "FiscalPeriodControl",
                            Version: "1.0.0",
                            Parameters: {
                                value: {
                                    Usage: 3,
                                    Static: false,
                                    Value: this.value != null ? this.value.periodValue : null,
                                    Type: "OptionSet",
                                    Attributes: {
                                        LogicalName: "FiscalPeriodControl" + this.controlId,
                                        Options: this.data.periods,
                                        OptionSet: this.data.periods,
                                    },
                                    Callback: function (change) { return _this.onQuarterChangeHandler(change); },
                                },
                            },
                        },
                    };
                };
                FiscalYearAndPeriodDefinition.prototype.onQuarterChangeHandler = function (selectedValue) {
                    this.value = Object.assign({}, this.value, {
                        periodValue: selectedValue,
                    });
                    this.executeOnChange();
                };
                FiscalYearAndPeriodDefinition.prototype.onYearChangeHandler = function (selectedValue) {
                    this.value = Object.assign({}, this.value, {
                        yearValue: selectedValue,
                    });
                    this.executeOnChange();
                };
                FiscalYearAndPeriodDefinition.prototype.getForElementId = function () {
                    return this.getPeriodId() + QueryBuilder.FocusableElementPrefixSuffix.getOptionSetSuffix();
                };
                FiscalYearAndPeriodDefinition.prototype.getPeriodId = function () {
                    return "fiscalPeriod_" + this.controlId;
                };
                FiscalYearAndPeriodDefinition.prototype.getYeadId = function () {
                    return "fiscalYear_" + this.controlId;
                };
                FiscalYearAndPeriodDefinition.prototype.getView = function () {
                    return this.context.factory.createElement("CONTAINER", {
                        id: "fiscalYearAndPeriodContainerId" + this.controlId,
                        key: "fiscalYearAndPeriodContainerId" + this.controlId,
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderValueFiscalYearAndPeriodStyle(this.context.theming),
                    }, [
                        this.context.factory.createComponent("MscrmControls.FieldControls.OptionSet", this.getPeriodId(), this.getFiscalPeriodProps()),
                        this.context.factory.createComponent("MscrmControls.FieldControls.OptionSet", this.getYeadId(), this.getFiscalYearProps()),
                    ]);
                };
                return FiscalYearAndPeriodDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.FiscalYearAndPeriodDefinition = FiscalYearAndPeriodDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var TypeAheadSelectDefinition = (function (_super) {
                __extends(TypeAheadSelectDefinition, _super);
                function TypeAheadSelectDefinition(context, name, label, isHidden, value, parentCondition, data, control, controlLabel, controlWidth, controlChangeHandler) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.TypeAheadSelect;
                    _this._value = value;
                    _this._data = data;
                    _this._control = control;
                    _this._controlWidth = controlWidth;
                    _this._controlLabel = controlLabel;
                    _this.controlChangeHandler = controlChangeHandler;
                    _this.initialize();
                    return _this;
                }
                TypeAheadSelectDefinition.prototype.initialize = function () {
                    if (!this.control) {
                        var foundValue = void 0;
                        var typeAheadState = {};
                        if (this.value && this.value.value) {
                            for (var _i = 0, _a = this.data.sections; _i < _a.length; _i++) {
                                var section = _a[_i];
                                for (var _b = 0, _c = section.sectionElements; _b < _c.length; _b++) {
                                    var sectionElem = _c[_b];
                                    if (sectionElem.Value == this.value.value) {
                                        foundValue = sectionElem;
                                        break;
                                    }
                                }
                                if (foundValue) {
                                    typeAheadState = {
                                        selectedValue: {
                                            Value: foundValue.Value,
                                            Label: foundValue.Label,
                                        },
                                    };
                                    break;
                                }
                            }
                        }
                        this._control = new QueryBuilder.TypeAheadSelect(this.context, this.getTypeAheadProps(), typeAheadState);
                    }
                };
                Object.defineProperty(TypeAheadSelectDefinition.prototype, "control", {
                    get: function () {
                        return this._control;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TypeAheadSelectDefinition.prototype, "data", {
                    get: function () {
                        return this._data;
                    },
                    set: function (data) {
                        this._data = data;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TypeAheadSelectDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                TypeAheadSelectDefinition.prototype.getProps = function () {
                    return null;
                };
                TypeAheadSelectDefinition.prototype.getView = function () {
                    if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode) {
                        return this.context.factory.createElement("CONTAINER", this.getReadOnlyProps(), [this.getDisplayValue()]);
                    }
                    return this.control.getView();
                };
                Object.defineProperty(TypeAheadSelectDefinition.prototype, "controlWidth", {
                    get: function () {
                        return this._controlWidth;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TypeAheadSelectDefinition.prototype, "controlLabel", {
                    get: function () {
                        return this._controlLabel;
                    },
                    enumerable: true,
                    configurable: true
                });
                TypeAheadSelectDefinition.prototype.getTypeAheadProps = function () {
                    var _this = this;
                    var options = this.data ? this.data.sections : [];
                    var idKey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadControlPrefix() + this.controlId;
                    var props = {
                        id: idKey,
                        key: idKey,
                        onChange: function (change) { return _this.onChangeHandler(change); },
                        options: options,
                        hidden: this.isHidden,
                        controlLabel: this.controlLabel,
                        name: QueryBuilder.Constants.ConditionFieldName[this.name],
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderTypeAheadContainerStyle(this.controlWidth),
                    };
                    return props;
                };
                TypeAheadSelectDefinition.prototype.onChangeHandler = function (controlState) {
                    var selectedValue = controlState.selectedValue;
                    this.value = { value: selectedValue ? selectedValue.Value : null };
                    this.executeOnChange();
                };
                TypeAheadSelectDefinition.prototype.getReadOnlyProps = function () {
                    return {
                        id: "readOnly_" + this.controlId,
                        key: "readOnly_" + this.controlId,
                        tabIndex: -1,
                        accessibilityLabel: this.getDisplayValue(),
                        style: this.isHidden
                            ? { display: "none" }
                            : QueryBuilder.QueryBuilderStyle.QueryBuilderValueReadOnlyStyle(this.context.theming, this.context.client.isRTL),
                    };
                };
                TypeAheadSelectDefinition.prototype.getDisplayValue = function () {
                    if (this.value && this.value.value) {
                        var foundValue = void 0;
                        for (var _i = 0, _a = this.data.sections; _i < _a.length; _i++) {
                            var section = _a[_i];
                            for (var _b = 0, _c = section.sectionElements; _b < _c.length; _b++) {
                                var sectionElem = _c[_b];
                                if (sectionElem.Value == this.value.value) {
                                    foundValue = sectionElem;
                                    break;
                                }
                            }
                            if (foundValue) {
                                return foundValue.Label;
                            }
                        }
                    }
                };
                return TypeAheadSelectDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.TypeAheadSelectDefinition = TypeAheadSelectDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var SimpleLookupDefinition = (function (_super) {
                __extends(SimpleLookupDefinition, _super);
                function SimpleLookupDefinition(context, name, label, isHidden, targets, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.SimpleLookup;
                    _this._targets = targets;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(SimpleLookupDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SimpleLookupDefinition.prototype, "accessibilityLabel", {
                    get: function () {
                        return this.accessibilityLabel;
                    },
                    set: function (value) {
                        this._accessibilityLabel = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SimpleLookupDefinition.prototype, "targets", {
                    get: function () {
                        return this._targets;
                    },
                    set: function (targets) {
                        this._targets = targets;
                    },
                    enumerable: true,
                    configurable: true
                });
                SimpleLookupDefinition.prototype.getProps = function () {
                    var _this = this;
                    var targets = this.targets;
                    var viewId = null;
                    var attributes = {
                        DisplayName: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? this._accessibilityLabel : "",
                        IsSecured: false,
                        Format: "none",
                        ImeMode: -1,
                        RequiredLevel: 0,
                        Type: "lookup",
                        Targets: targets,
                    };
                    return {
                        id: this.controlId,
                        key: this.controlId,
                        parameters: {
                            value: {
                                Attributes: attributes,
                                Callback: function (value) { return _this.onChangeHandler(value); },
                                Usage: 3,
                                Static: false,
                                Type: "Lookup.MultiEntity",
                                Value: this.value ? this.value : null,
                                Primary: true,
                                Name: "value",
                                ViewId: viewId,
                                AllowFilterOff: false,
                                DisableQuickFind: false,
                                EnableViewPicker: true,
                            },
                            valueDataSet: {
                                ViewId: viewId,
                                EnableViewPicker: true,
                                Name: "valueDataSet",
                            },
                        },
                    };
                };
                SimpleLookupDefinition.prototype.onChangeHandler = function (value) {
                    this.value = value[0];
                    this.executeOnChange();
                };
                SimpleLookupDefinition.prototype.getView = function () {
                    return this.context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", "SimpleLookup_" + this.controlId, this.getProps());
                };
                return SimpleLookupDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.SimpleLookupDefinition = SimpleLookupDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var PartyListLookupDefinition = (function (_super) {
                __extends(PartyListLookupDefinition, _super);
                function PartyListLookupDefinition(context, name, label, isHidden, targets, values, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.PartyListLookup;
                    _this._targets = targets;
                    _this._values = values;
                    return _this;
                }
                Object.defineProperty(PartyListLookupDefinition.prototype, "values", {
                    get: function () {
                        return this._values;
                    },
                    set: function (values) {
                        this._values = values;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PartyListLookupDefinition.prototype, "accessibilityLabel", {
                    get: function () {
                        return this.accessibilityLabel;
                    },
                    set: function (value) {
                        this._accessibilityLabel = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PartyListLookupDefinition.prototype, "targets", {
                    get: function () {
                        return this._targets;
                    },
                    set: function (targets) {
                        this._targets = targets;
                    },
                    enumerable: true,
                    configurable: true
                });
                PartyListLookupDefinition.prototype.getProps = function () {
                    var _this = this;
                    var targets = this.targets;
                    var viewId = null;
                    var attributes = {
                        DisplayName: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? this._accessibilityLabel : "",
                        IsSecured: false,
                        Format: "none",
                        ImeMode: -1,
                        RequiredLevel: 0,
                        Type: "lookup",
                        Targets: targets,
                    };
                    return {
                        id: this.controlId,
                        key: this.controlId,
                        parameters: {
                            value: {
                                Attributes: attributes,
                                Callback: function (values) { return _this.onChangeHandler(values); },
                                Usage: 3,
                                Static: false,
                                Type: "Lookup.PartyList",
                                Value: this.values ? this.values : null,
                                Primary: true,
                                Name: "value",
                                ViewId: viewId,
                                AllowFilterOff: false,
                                DisableQuickFind: false,
                                EnableViewPicker: true,
                            },
                            valueDataSet: {
                                ViewId: viewId,
                                EnableViewPicker: true,
                                Name: "valueDataSet",
                            },
                        },
                    };
                };
                PartyListLookupDefinition.prototype.onChangeHandler = function (values) {
                    this.values = values;
                    this.executeOnChange();
                };
                PartyListLookupDefinition.prototype.getView = function () {
                    return this.context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", "PartyListLookup_" + this.controlId, this.getProps());
                };
                return PartyListLookupDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.PartyListLookupDefinition = PartyListLookupDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var OptionSetDefinition = (function (_super) {
                __extends(OptionSetDefinition, _super);
                function OptionSetDefinition(context, name, label, isHidden, data, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.OptionSet;
                    _this._data = data;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(OptionSetDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(OptionSetDefinition.prototype, "data", {
                    get: function () {
                        return this._data;
                    },
                    set: function (data) {
                        this._data = data;
                    },
                    enumerable: true,
                    configurable: true
                });
                OptionSetDefinition.prototype.getProps = function () {
                    var _this = this;
                    return {
                        controlstates: {
                            hasFocus: this.context.mode.hasFocus,
                            isControlDisabled: false,
                        },
                        descriptor: {
                            Id: "optionSet_" + this.controlId,
                            Label: "MscrmOptionSetControl",
                            Name: "OptionSetControl",
                            ShowLabel: false,
                            Visible: true,
                            Disabled: false,
                        },
                        configuration: {
                            CustomControlId: "MscrmControls.FieldControls.OptionSet",
                            Name: "OptionSetControl",
                            Version: "1.0.0",
                            Parameters: {
                                value: {
                                    Usage: 3,
                                    Static: false,
                                    Value: this.value != null ? this.value.value : null,
                                    Type: "OptionSet",
                                    Attributes: {
                                        LogicalName: "OptionSet" + this.controlId,
                                        DefaultValue: this.value.value,
                                        Options: this.data,
                                        OptionSet: this.data,
                                    },
                                    Callback: function (change) { return _this.onChangeHandler(change); },
                                },
                            },
                        },
                    };
                };
                OptionSetDefinition.prototype.onChangeHandler = function (changedValue) {
                    this.value = { value: changedValue };
                    this.executeOnChange();
                };
                OptionSetDefinition.prototype.getForElementId = function () {
                    return this.getId() + QueryBuilder.FocusableElementPrefixSuffix.getOptionSetSuffix();
                };
                OptionSetDefinition.prototype.getId = function () {
                    return this.getProps().descriptor.Id;
                };
                OptionSetDefinition.prototype.getView = function () {
                    return this.context.factory.createComponent("MscrmControls.FieldControls.OptionSet", this.getId(), this.getProps());
                };
                return OptionSetDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.OptionSetDefinition = OptionSetDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var MultiSelectPicklistDefinition = (function (_super) {
                __extends(MultiSelectPicklistDefinition, _super);
                function MultiSelectPicklistDefinition(context, name, label, isHidden, data, values, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.MultiSelectPicklist;
                    _this._data = data;
                    _this._values = values;
                    return _this;
                }
                Object.defineProperty(MultiSelectPicklistDefinition.prototype, "values", {
                    get: function () {
                        return this._values;
                    },
                    set: function (values) {
                        this._values = values;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(MultiSelectPicklistDefinition.prototype, "accessibilityLabel", {
                    get: function () {
                        return this.accessibilityLabel;
                    },
                    set: function (value) {
                        this._accessibilityLabel = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(MultiSelectPicklistDefinition.prototype, "data", {
                    get: function () {
                        return this._data;
                    },
                    set: function (data) {
                        this._data = data;
                    },
                    enumerable: true,
                    configurable: true
                });
                MultiSelectPicklistDefinition.prototype.getProps = function () {
                    var _this = this;
                    return {
                        controlstates: {
                            hasFocus: this.context.mode.hasFocus,
                            isControlDisabled: false,
                        },
                        descriptor: {
                            Id: "MultiSelectPicklist" + this.controlId,
                            Label: "TMultiSelectPicklistControl",
                            Name: "MultiSelectPicklistControl",
                            ShowLabel: false,
                            Visible: true,
                            Disabled: false,
                        },
                        configuration: {
                            CustomControlId: "MscrmControls.MultiSelectPicklist.MultiSelectPicklistControl",
                            Name: "MutliSelectPicklistControl",
                            Version: "1.0.0",
                            Parameters: {
                                value: {
                                    Usage: 3,
                                    Static: false,
                                    Value: this.values != null ? this.getMultiselectValues(this.values) : [],
                                    Type: "MultiSelectOptionSet",
                                    Attributes: {
                                        DisplayName: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? this._accessibilityLabel : "",
                                        LogicalName: this.getId(),
                                        DefaultValue: this.getMultiselectValues(this.values),
                                        Options: this.data,
                                        OptionSet: this.data,
                                    },
                                    Callback: function (change) { return _this.onChangeHandler(change); },
                                },
                            },
                        },
                    };
                };
                MultiSelectPicklistDefinition.prototype.getMultiselectValues = function (controlValues) {
                    var values = [];
                    for (var _i = 0, controlValues_1 = controlValues; _i < controlValues_1.length; _i++) {
                        var item = controlValues_1[_i];
                        values.push(item.value);
                    }
                    return values;
                };
                MultiSelectPicklistDefinition.prototype.onChangeHandler = function (changedValue) {
                    this.values = [];
                    for (var _i = 0, changedValue_1 = changedValue; _i < changedValue_1.length; _i++) {
                        var item = changedValue_1[_i];
                        this.values.push({ value: item });
                    }
                    this.executeOnChange();
                };
                MultiSelectPicklistDefinition.prototype.getForElementId = function () {
                    return this.getId() + QueryBuilder.FocusableElementPrefixSuffix.getMultiSelectSuffix();
                };
                MultiSelectPicklistDefinition.prototype.getId = function () {
                    return "MultiSelectPicklist_" + this.controlId;
                };
                MultiSelectPicklistDefinition.prototype.getView = function () {
                    return this.context.factory.createComponent("MscrmControls.FieldControls.OptionSet", this.getId(), this.getProps());
                };
                return MultiSelectPicklistDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.MultiSelectPicklistDefinition = MultiSelectPicklistDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var DateTimeDefinition = (function (_super) {
                __extends(DateTimeDefinition, _super);
                function DateTimeDefinition(context, name, label, isHidden, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.DateTime;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(DateTimeDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                DateTimeDefinition.prototype.getProps = function () {
                    var _this = this;
                    return {
                        parameters: {
                            value: {
                                Usage: 3,
                                Static: true,
                                Value: this.value != null ? this.reverseCompensateTimeZoneForInputBehavior(this.value.value) : null,
                                Callback: function (change) { return _this.onChangeHandler(change); },
                                Type: "DateAndTime.DateOnly",
                                Attributes: {
                                    Format: "dateonly",
                                    Type: "datetime",
                                    Behavior: 2,
                                },
                            },
                            deviceSizeMode: {
                                Usage: 1,
                                Static: true,
                                Value: 0,
                                Type: "Enum",
                                Primary: false,
                            },
                        },
                    };
                };
                DateTimeDefinition.prototype.reverseCompensateTimeZoneForInputBehavior = function (date) {
                    var MILLISECONDS_IN_MINUTE = 60000;
                    if (!date) {
                        return date;
                    }
                    var currentTimeZoneOffsetMillisec = date.getTimezoneOffset() * MILLISECONDS_IN_MINUTE;
                    return new Date(date.getTime() - currentTimeZoneOffsetMillisec);
                };
                DateTimeDefinition.prototype.onChangeHandler = function (changedValue) {
                    this.value = { value: changedValue };
                    this.executeOnChange();
                };
                DateTimeDefinition.prototype.getForElementId = function () {
                    return (QueryBuilder.FocusableElementPrefixSuffix.getControlNamePrefix() +
                        "-" +
                        QueryBuilder.FocusableElementPrefixSuffix.getControlNamePrefix() +
                        "." +
                        this.getId() +
                        QueryBuilder.FocusableElementPrefixSuffix.getDateTimeSuffix());
                };
                DateTimeDefinition.prototype.getId = function () {
                    return "DateTimeControl_" + this.controlId;
                };
                DateTimeDefinition.prototype.getView = function () {
                    return this.context.factory.createComponent("MscrmControls.FieldControls.DateTimeControl", this.getId(), this.getProps());
                };
                return DateTimeDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.DateTimeDefinition = DateTimeDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var ComboBoxDefinition = (function (_super) {
                __extends(ComboBoxDefinition, _super);
                function ComboBoxDefinition(context, name, label, isHidden, data, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.ComboBox;
                    _this._data = data;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(ComboBoxDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    set: function (value) {
                        this._value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ComboBoxDefinition.prototype, "data", {
                    get: function () {
                        return this._data;
                    },
                    set: function (data) {
                        this.data = data;
                    },
                    enumerable: true,
                    configurable: true
                });
                ComboBoxDefinition.prototype.getProps = function () {
                    var _this = this;
                    var options = this.convertToOptions(this.data);
                    var style = {
                        width: "180px",
                        height: "30px",
                        margin: "10px",
                    };
                    if (this.isHidden) {
                        Object.assign(style, {}, { display: "none" });
                    }
                    return {
                        key: "ControlKey_" + this.controlId,
                        id: "ControlID_" + this.controlId,
                        options: options,
                        onChange: function (change) { return _this.onChangeHandler(change); },
                        style: style,
                        textStyle: {
                            fontWeight: "bold",
                        },
                        value: this.value != null ? this.value.value : "",
                    };
                };
                ComboBoxDefinition.prototype.convertToOptions = function (data) {
                    var options = new Array();
                    for (var i = 0; i < data.length; i++) {
                        options.push({ value: data[i].Value, text: data[i].Label });
                    }
                    return options;
                };
                ComboBoxDefinition.prototype.onChangeHandler = function (changedValue) {
                    this.value = { value: changedValue };
                    this.executeOnChange();
                };
                ComboBoxDefinition.prototype.getView = function () {
                    return this.context.factory.createElement("COMBOBOX", this.getProps(), {});
                };
                return ComboBoxDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.ComboBoxDefinition = ComboBoxDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            "use strict";
            var TextBoxDefinition = (function (_super) {
                __extends(TextBoxDefinition, _super);
                function TextBoxDefinition(context, name, label, isHidden, attributeType, isRangeBased, minValue, maxValue, precision, value, parentCondition) {
                    var _this = _super.call(this, context, name, label, isHidden, parentCondition) || this;
                    _this._type = ConditionModel.ControlTypes.TextBox;
                    _this._value = value;
                    return _this;
                }
                Object.defineProperty(TextBoxDefinition.prototype, "value", {
                    get: function () {
                        return this._value;
                    },
                    enumerable: true,
                    configurable: true
                });
                TextBoxDefinition.prototype.getForElementId = function () {
                    return QueryBuilder.FocusableElementPrefixSuffix.getControlNamePrefix() + "-" + this.getId();
                };
                TextBoxDefinition.prototype.getId = function () {
                    return "textBox_" + this.controlId;
                };
                TextBoxDefinition.prototype.getProps = function () {
                    var _this = this;
                    return {
                        id: this.getId(),
                        key: this.getId(),
                        placeholder: "Enter the value",
                        value: this._value != null ? this._value.value : "",
                        onChange: function (change) { return _this.onChangeHandler(change); },
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderValueTextBoxStyle(this.context.theming),
                        disabled: false,
                        accessibilityRequired: true,
                    };
                };
                TextBoxDefinition.prototype.onChangeHandler = function (changedValue) {
                    this._value.value = changedValue.target.value;
                    this.executeOnChange();
                };
                TextBoxDefinition.prototype.getView = function () {
                    return this.context.factory.createElement("TEXTINPUT", this.getProps(), {});
                };
                return TextBoxDefinition;
            }(ConditionModel.BaseControlDefinition));
            ConditionModel.TextBoxDefinition = TextBoxDefinition;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderConfirmationDialog = (function () {
            function QueryBuilderConfirmationDialog(context) {
                this.context = context;
                this.title = "";
                this.message = "";
                this.isDialogVisible = false;
            }
            QueryBuilderConfirmationDialog.prototype.ShowConfirmationDialog = function (title, message, yesCallback) {
                this.title = title;
                this.message = message;
                this.yesCallback = yesCallback;
                this.isDialogVisible = true;
                QueryBuilder.QueryBuilderControl.rerenderControl(this.context, QueryBuilder.ComponentIdPrefixesAndSuffixes.clearConfirmationDialogOkayButtonId());
            };
            QueryBuilderConfirmationDialog.prototype.hideDialog = function () {
                this.isDialogVisible = false;
                this.context.utils.requestRender();
            };
            QueryBuilderConfirmationDialog.prototype.getView = function () {
                if (!this.isDialogVisible)
                    return null;
                var self = this;
                var flyoutDivStyle = {
                    border: " 1px solid #b3b3b3",
                    backgroundColor: "#FFFFFF",
                    height: "auto",
                    width: "30rem",
                    padding: this.context.theming.measures.measure150,
                    flexDirection: "column",
                    zIndex: "2",
                };
                var flyout = this.context.factory.createElement("FLYOUT", {
                    id: "confirmDialog_",
                    key: "confirmDialog_",
                    flyoutStyle: flyoutDivStyle,
                    flyoutDirection: this.context.client.isRTL ? 0 : 1,
                    relativeToElementId: "queryBuilder",
                    positionType: "absolute",
                    role: "dialog",
                    position: this.context.client.isRTL ? { top: "40%", right: "35%" } : { top: "40%", left: "35%" },
                    onOutsideClick: function (e) { },
                }, [this.getDialogContainerContent(), this.getButtons()]);
                var dialogContainer = this.context.factory.createElement("CONTAINER", {
                    id: "dialogContainerkey",
                    key: "dialogContainerkey",
                }, [this.getDialogOverlayContainer(), flyout]);
                return dialogContainer;
            };
            QueryBuilderConfirmationDialog.prototype.getDialogOverlayContainer = function () {
                return this.context.factory.createElement("CONTAINER", {
                    id: "dialogoverlaykey",
                    key: "dialogoverlaykey",
                    style: QueryBuilder.QueryBuilderStyle.DialogOverlayContainerStyle(this.context.theming),
                });
            };
            QueryBuilderConfirmationDialog.prototype.getDialogWarningIcon = function () {
                return this.context.factory.createElement("MICROSOFTICON", {
                    id: "warningiconkey",
                    key: "warningiconkey",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogWarningIconStyle(this.context.theming),
                    type: 232,
                });
            };
            QueryBuilderConfirmationDialog.prototype.getDialogCancelIcon = function () {
                return this.context.factory.createElement("MICROSOFTICON", {
                    id: "canceliconkey",
                    key: "canceliconkey",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogCloseIconStyle(this.context.theming),
                    type: 9,
                });
            };
            QueryBuilderConfirmationDialog.prototype.getDialogCancelButton = function () {
                var self = this;
                return this.context.factory.createElement("BUTTON", {
                    id: "CancelBtn",
                    key: "CancelBtn",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogCloseButtonStyle(this.context.theming),
                    onClick: function (e) {
                        self.hideDialog();
                    },
                }, [this.getDialogCancelIcon()]);
            };
            QueryBuilderConfirmationDialog.prototype.getTitleLabel = function () {
                return this.context.factory.createElement("LABEL", {
                    id: "_title",
                    key: "_title",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogTitleLabelStyle(this.context.theming),
                }, this.title);
            };
            QueryBuilderConfirmationDialog.prototype.getMessageLabel = function () {
                return this.context.factory.createElement("LABEL", {
                    id: "_message",
                    key: "_message",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogMessageLabelStyle(this.context.theming, this.context.client.isRTL),
                }, this.message);
            };
            QueryBuilderConfirmationDialog.prototype.getDialogTitleIconContainer = function () {
                return this.context.factory.createElement("CONTAINER", {
                    id: "dialogTitleIcon",
                    key: "dialogTitleIcon",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationTitleIconContainerStyle(this.context.theming),
                }, [this.getDialogWarningIcon(), this.getTitleLabel()]);
            };
            QueryBuilderConfirmationDialog.prototype.getDialogContainerContent = function () {
                return this.context.factory.createElement("CONTAINER", {
                    id: "dialogContent",
                    key: "dialogContent",
                    style: QueryBuilder.QueryBuilderStyle.DialogContainerContentStyle(this.context.theming),
                }, [this.getDialogContainerHeader(), this.getMessageLabel()]);
            };
            QueryBuilderConfirmationDialog.prototype.getDialogContainerHeader = function () {
                return this.context.factory.createElement("CONTAINER", {
                    id: "dialogHeader",
                    key: "dialogHeader",
                    style: QueryBuilder.QueryBuilderStyle.DialogContainerHeaderStyle(this.context.theming),
                }, [this.getDialogTitleIconContainer(), this.getDialogCancelButton()]);
            };
            QueryBuilderConfirmationDialog.prototype.getButtons = function () {
                var _this = this;
                var self = this;
                var yesBtn = this.context.factory.createElement("BUTTON", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.clearConfirmationDialogOkayButtonId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.clearConfirmationDialogOkayButtonId(),
                    style: QueryBuilder.QueryBuilderStyle.DialogFlyoutOkButtonStyle(this.context.theming),
                    onClick: function () {
                        self.isDialogVisible = false;
                        self.yesCallback();
                    },
                }, [QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_OK)]);
                var noBtn = self.context.factory.createElement("BUTTON", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.clearConfirmationDialogCancelButtonId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.clearConfirmationDialogCancelButtonId(),
                    style: QueryBuilder.QueryBuilderStyle.DialogFlyoutCancelButtonStyle(this.context.theming),
                    onClick: function () {
                        self.hideDialog();
                    },
                    onKeyDown: function (keyEvent) {
                        if (keyEvent.keyCode == 9)
                            _this.context.accessibility.focusElementById("CancelBtn");
                    },
                }, [QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_CANCEL)]);
                return this.context.factory.createElement("CONTAINER", {
                    id: "btnContainer",
                    key: "btnContainer",
                    style: QueryBuilder.QueryBuilderStyle.ConfirmationDialogButtonContainerStyle(this.context.theming),
                }, [yesBtn, noBtn]);
            };
            return QueryBuilderConfirmationDialog;
        }());
        QueryBuilder.QueryBuilderConfirmationDialog = QueryBuilderConfirmationDialog;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AttributeMetadata = (function () {
            function AttributeMetadata() {
            }
            AttributeMetadata.prototype.populate = function (metadataObject) {
                this.attributeType =
                    !MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataObject.AttributeTypeName) &&
                        !MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataObject.AttributeTypeName.Value)
                        ? new EntityAttributeType(metadataObject.AttributeTypeName.Value)
                        : new EntityAttributeType(metadataObject.AttributeType);
                this.attributeFormatType = !MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataObject.AttributeFormatType)
                    ? new EntityAttributeTypeFormat(metadataObject.AttributeFormatType)
                    : new EntityAttributeTypeFormat(metadataObject.Format);
                this.attributeBaseType = metadataObject.AttributeBaseType;
                this.requiredLevel = new EntityAttributeRequiredLevel(metadataObject.AttributeRequiredLevelId);
                this.displayName = metadataObject.DisplayName;
                this.logicalName = metadataObject.LogicalName;
                this.isValidForAdvancedFind = metadataObject.IsValidForAdvancedFind;
                this.optionSet = metadataObject.OptionSet;
                this.yomiOf = metadataObject.YomiOf;
                this.targets = metadataObject.Targets;
                this.isRangeBased = metadataObject.IsRangeBased;
            };
            AttributeMetadata.prototype.AddRangeInformation = function (minValue, maxValue, precision) {
                this.minValue = minValue;
                this.maxValue = maxValue;
                this.precision = precision;
            };
            return AttributeMetadata;
        }());
        QueryBuilder.AttributeMetadata = AttributeMetadata;
        var EntityAttributeType = (function () {
            function EntityAttributeType(name) {
                this.name = name;
            }
            Object.defineProperty(EntityAttributeType.prototype, "Name", {
                get: function () {
                    return this.name;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "TwoOptions", {
                get: function () {
                    return "BooleanType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "Customer", {
                get: function () {
                    return "Customer";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "CustomerType", {
                get: function () {
                    return "CustomerType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "DateTime", {
                get: function () {
                    return "DateTimeType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "DecimalNumber", {
                get: function () {
                    return "DecimalType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "FloatingPointNumber", {
                get: function () {
                    return "DoubleType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "WholeNumber", {
                get: function () {
                    return "IntegerType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "LookUp", {
                get: function () {
                    return "LookupType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "MultipleLineofText", {
                get: function () {
                    return "MemoType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "Currency", {
                get: function () {
                    return "MoneyType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "Owner", {
                get: function () {
                    return "Owner";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "OwnerType", {
                get: function () {
                    return "OwnerType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "PartyList", {
                get: function () {
                    return "PartyList";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "PartyListType", {
                get: function () {
                    return "PartyListType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "OptionSet", {
                get: function () {
                    return "PicklistType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "State", {
                get: function () {
                    return "StateType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "Status", {
                get: function () {
                    return "StatusType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "SingleLineofText", {
                get: function () {
                    return "StringType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "UniqueIdentifier", {
                get: function () {
                    return "UniqueidentifierType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "CalendarRulesType", {
                get: function () {
                    return "CalendarRulesType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "VirtualType", {
                get: function () {
                    return "VirtualType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "BigInt", {
                get: function () {
                    return "BigIntType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "ManagedPropertyType", {
                get: function () {
                    return "ManagedPropertyType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "EntityNameType", {
                get: function () {
                    return "EntityNameType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "Image", {
                get: function () {
                    return "ImageType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "MultiSelectOptionSet", {
                get: function () {
                    return "MultiSelectPicklistType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeType, "PrimaryNameAttributeType", {
                get: function () {
                    return "String";
                },
                enumerable: true,
                configurable: true
            });
            return EntityAttributeType;
        }());
        QueryBuilder.EntityAttributeType = EntityAttributeType;
        var OptionSetProperties = (function () {
            function OptionSetProperties() {
            }
            OptionSetProperties.prototype.getOptions = function () {
                if (this.options && this.options.length)
                    return this.options;
                else
                    return [this.trueOption, this.falseOption];
            };
            return OptionSetProperties;
        }());
        QueryBuilder.OptionSetProperties = OptionSetProperties;
        var OptionSetType = (function () {
            function OptionSetType(name) {
                this.name = name;
            }
            Object.defineProperty(OptionSetType, "PickList", {
                get: function () {
                    return "Picklist";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OptionSetType, "Boolean", {
                get: function () {
                    return "Boolean";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OptionSetType, "State", {
                get: function () {
                    return "State";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OptionSetType, "Status", {
                get: function () {
                    return "Status";
                },
                enumerable: true,
                configurable: true
            });
            return OptionSetType;
        }());
        QueryBuilder.OptionSetType = OptionSetType;
        var Option = (function () {
            function Option(label, value, state) {
                this.Label = label;
                this.Value = value;
                this.State = state;
            }
            return Option;
        }());
        QueryBuilder.Option = Option;
        var EntityAttributeRequiredLevel = (function () {
            function EntityAttributeRequiredLevel(name) {
                this.name = name;
            }
            Object.defineProperty(EntityAttributeRequiredLevel, "None", {
                get: function () {
                    return "None";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeRequiredLevel, "SystemRequired", {
                get: function () {
                    return "SystemRequired";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeRequiredLevel, "ApplicationRequired", {
                get: function () {
                    return "ApplicationRequired";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeRequiredLevel, "Recommended", {
                get: function () {
                    return "Recommended";
                },
                enumerable: true,
                configurable: true
            });
            return EntityAttributeRequiredLevel;
        }());
        QueryBuilder.EntityAttributeRequiredLevel = EntityAttributeRequiredLevel;
        var EntityAttributeTypeFormat = (function () {
            function EntityAttributeTypeFormat(name) {
                this.name = name;
                if (!name) {
                    this.name = EntityAttributeTypeFormat.None;
                }
            }
            Object.defineProperty(EntityAttributeTypeFormat, "Email", {
                get: function () {
                    return "Email";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Text", {
                get: function () {
                    return "Text";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "TextArea", {
                get: function () {
                    return "TextArea";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Url", {
                get: function () {
                    return "Url";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "TickerSymbol", {
                get: function () {
                    return "TickerSymbol";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "PhoneticGuide", {
                get: function () {
                    return "PhoneticGuide";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "VersionNumber", {
                get: function () {
                    return "VersionNumber";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Phone", {
                get: function () {
                    return "Phone";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "None", {
                get: function () {
                    return "None";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Duration", {
                get: function () {
                    return "Duration";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "TimeZone", {
                get: function () {
                    return "TimeZone";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Language", {
                get: function () {
                    return "Language";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Locale", {
                get: function () {
                    return "Locale";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "DateOnly", {
                get: function () {
                    return "DateOnly";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "DateAndTime", {
                get: function () {
                    return "DateAndTime";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Picklist", {
                get: function () {
                    return "Picklist";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "State", {
                get: function () {
                    return "State";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Status", {
                get: function () {
                    return "Status";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Boolean", {
                get: function () {
                    return "Boolean";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EntityAttributeTypeFormat, "Regarding", {
                get: function () {
                    return "Regarding";
                },
                enumerable: true,
                configurable: true
            });
            return EntityAttributeTypeFormat;
        }());
        QueryBuilder.EntityAttributeTypeFormat = EntityAttributeTypeFormat;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var RelationshipMetadataBase = (function () {
            function RelationshipMetadataBase(metadataObject) {
                this.referencingAttribute = metadataObject.ReferencingAttribute;
                this.referencedAttribute = metadataObject.ReferencedAttribute;
                this.isValidForAdvancedFind = metadataObject.IsValidForAdvancedFind;
                this.hasReadPrivilege = metadataObject.HasReadPrivilege;
            }
            return RelationshipMetadataBase;
        }());
        QueryBuilder.RelationshipMetadataBase = RelationshipMetadataBase;
        var OneToManyRelationEntityMetadata = (function (_super) {
            __extends(OneToManyRelationEntityMetadata, _super);
            function OneToManyRelationEntityMetadata(metadataObject) {
                var _this = _super.call(this, metadataObject) || this;
                _this.referencingEntity = metadataObject.RelationshipEntity;
                _this.isHierarchical = metadataObject.IsHierarchical;
                return _this;
            }
            return OneToManyRelationEntityMetadata;
        }(RelationshipMetadataBase));
        QueryBuilder.OneToManyRelationEntityMetadata = OneToManyRelationEntityMetadata;
        var ManyToOneRelationEntityMetadata = (function (_super) {
            __extends(ManyToOneRelationEntityMetadata, _super);
            function ManyToOneRelationEntityMetadata(metadataObject) {
                var _this = _super.call(this, metadataObject) || this;
                _this.referencedEntity = metadataObject.RelationshipEntity;
                _this.isHierarchical = metadataObject.IsHierarchical;
                return _this;
            }
            return ManyToOneRelationEntityMetadata;
        }(RelationshipMetadataBase));
        QueryBuilder.ManyToOneRelationEntityMetadata = ManyToOneRelationEntityMetadata;
        var ManyToManyRelationEntityMetadata = (function (_super) {
            __extends(ManyToManyRelationEntityMetadata, _super);
            function ManyToManyRelationEntityMetadata(metadataObject) {
                var _this = _super.call(this, metadataObject) || this;
                _this.referencingEntity = metadataObject.RelationshipEntity;
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataObject.ManyToManyRelationshipMetadata)) {
                    _this.intersectEntity = metadataObject.ManyToManyRelationshipMetadata.IntersectEntity;
                    _this.fromEntityAttribute = metadataObject.ManyToManyRelationshipMetadata.FromEntityAttribute;
                    _this.toEntityAttribute = metadataObject.ManyToManyRelationshipMetadata.ToEntityAttribute;
                    _this.intersectPrimaryAttribute = metadataObject.ManyToManyRelationshipMetadata.IntersectPrimaryAttribute;
                    _this.intersectRelatedAttribute = metadataObject.ManyToManyRelationshipMetadata.IntersectRelatedAttribute;
                }
                return _this;
            }
            return ManyToManyRelationEntityMetadata;
        }(RelationshipMetadataBase));
        QueryBuilder.ManyToManyRelationEntityMetadata = ManyToManyRelationEntityMetadata;
        var RelationshipType = (function () {
            function RelationshipType() {
            }
            Object.defineProperty(RelationshipType, "ManyToOneRelationship", {
                get: function () {
                    return "ManyToOneRelationship";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(RelationshipType, "OneToManyRelationship", {
                get: function () {
                    return "OneToManyRelationship";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(RelationshipType, "ManyToManyRelationship", {
                get: function () {
                    return "ManyToManyRelationship";
                },
                enumerable: true,
                configurable: true
            });
            return RelationshipType;
        }());
        QueryBuilder.RelationshipType = RelationshipType;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            var AdvancedFindControlDefinitionProvider = (function () {
                function AdvancedFindControlDefinitionProvider() {
                }
                AdvancedFindControlDefinitionProvider.prototype.getInitialControlDefinitions = function (context, conditionNode) {
                    var entityLogicalName = QueryBuilder.AdvancedFindUtils.getEntityLogicalName(conditionNode.getNodeContainer());
                    var self = this;
                    return new Promise(function (resolve, reject) {
                        new QueryBuilder.AttributeMetadataProvider().getAttributeTypeAheadSelectData(context, entityLogicalName).then(function (typeAheadSelectInput) {
                            var controlDefinitions = [
                                self.getAttributeControlDefinition(context, conditionNode.Condition, typeAheadSelectInput),
                            ];
                            resolve(controlDefinitions);
                        }, function (error) {
                            reject(error);
                        });
                    });
                };
                AdvancedFindControlDefinitionProvider.prototype.getNextControlDefinitions = function (context, controlDefinitions, conditionNode) {
                    var _this = this;
                    var controlName = controlDefinitions[controlDefinitions.length - 1].name;
                    var entityLogicalName = QueryBuilder.AdvancedFindUtils.getEntityLogicalName(conditionNode.getNodeContainer());
                    var attributeLogicalName;
                    var operator;
                    var self = this;
                    switch (controlName) {
                        case QueryBuilder.Constants.ConditionFieldName.LHSAttribute:
                            attributeLogicalName = controlDefinitions[controlDefinitions.length - 1].value.value;
                            if (!attributeLogicalName) {
                                return new Promise(function (resolve, reject) {
                                    resolve([]);
                                });
                            }
                            return new Promise(function (resolve, reject) {
                                new QueryBuilder.AttributeMetadataProvider().getAttributeMetadata(context, entityLogicalName).then(function (entityMetadata) {
                                    var newControlDefinitions = [
                                        self.getOperatorControlDefinition(context, conditionNode.Condition, new QueryBuilder.OperatorMetadataProvider().getTypeAheadSelectData(context, entityMetadata.attributes[attributeLogicalName].attributeType.Name, entityMetadata.attributes[attributeLogicalName].attributeFormatType.name)),
                                    ];
                                    new QueryBuilder.SpecialConditionOperatorProvider()
                                        .getSpecialConditionOperators(context, newControlDefinitions[0].data, attributeLogicalName, entityMetadata, true)
                                        .then(function (operators) {
                                        var currentOperators = newControlDefinitions[0]
                                            .data.sections[0].sectionElements;
                                        QueryBuilder.AdvancedFindUtils.appendOperators(context, currentOperators, operators);
                                        resolve(newControlDefinitions);
                                    });
                                }, function (error) {
                                    reject(error);
                                });
                            });
                        case QueryBuilder.Constants.ConditionFieldName.Operator:
                            attributeLogicalName = controlDefinitions[controlDefinitions.length - 2].value.value;
                            operator = controlDefinitions[controlDefinitions.length - 1]
                                .value.value;
                            if (!operator) {
                                return new Promise(function (resolve, reject) {
                                    resolve([]);
                                });
                            }
                            return new Promise(function (resolve, reject) {
                                new QueryBuilder.AttributeMetadataProvider().getAttributeMetadata(context, entityLogicalName).then(function (entityAndAttrMetadata) {
                                    if (_this.handleHierarchyOperators(attributeLogicalName, operator, entityAndAttrMetadata)) {
                                        _this.hierarchyOperatorsHandler(context, conditionNode, entityLogicalName, attributeLogicalName, operator, entityAndAttrMetadata);
                                        return new Promise(function (resolve, reject) {
                                            resolve([]);
                                        });
                                    }
                                    var newControlDefinitions = [];
                                    var attributeType = entityAndAttrMetadata.attributes[attributeLogicalName].attributeType;
                                    var attributeFormatType = entityAndAttrMetadata.attributes[attributeLogicalName].attributeFormatType;
                                    var newControlDefinition = QueryBuilder.AdvancedFindUtils.GetValueControlByAttributeAndOperator(context, conditionNode, attributeType.Name, attributeFormatType.name, operator);
                                    if (!newControlDefinition) {
                                        resolve(newControlDefinitions);
                                    }
                                    if (attributeFormatType.name == QueryBuilder.EntityAttributeTypeFormat.Language &&
                                        (newControlDefinition.type == ConditionModel.ControlTypes.OptionSet ||
                                            newControlDefinition.type == ConditionModel.ControlTypes.MultiSelectPicklist)) {
                                        new QueryBuilder.LanguageDataProvider().getProvisionedLanguageList(context).then(function (data) {
                                            if (newControlDefinition.type == ConditionModel.ControlTypes.OptionSet) {
                                                newControlDefinition.data = data;
                                            }
                                            else if (newControlDefinition.type == ConditionModel.ControlTypes.MultiSelectPicklist) {
                                                newControlDefinition.data = data;
                                            }
                                            newControlDefinitions.push(newControlDefinition);
                                            resolve(newControlDefinitions);
                                        });
                                    }
                                    else {
                                        switch (newControlDefinition.type) {
                                            case ConditionModel.ControlTypes.OptionSet:
                                                if (operator === QueryBuilder.ConditionOperator.in_fiscal_period) {
                                                    newControlDefinition.data = QueryBuilder.AdvancedFindUtils.GetPeriodList(context);
                                                }
                                                else if (operator === QueryBuilder.ConditionOperator.in_fiscal_year) {
                                                    newControlDefinition.data = QueryBuilder.AdvancedFindUtils.GetFiscalYearsList(context);
                                                }
                                                else {
                                                    newControlDefinition.data = entityAndAttrMetadata
                                                        .attributes[attributeLogicalName].optionsetProperties
                                                        ? entityAndAttrMetadata.attributes[attributeLogicalName].optionsetProperties.getOptions()
                                                        : [];
                                                }
                                                break;
                                            case ConditionModel.ControlTypes.FiscalYearAndPeriod:
                                                newControlDefinition.data = QueryBuilder.AdvancedFindUtils.GetFiscalYearAndPeriod(context);
                                                break;
                                            case ConditionModel.ControlTypes.MultiSelectPicklist:
                                                newControlDefinition.data = entityAndAttrMetadata
                                                    .attributes[attributeLogicalName].optionsetProperties
                                                    ? entityAndAttrMetadata.attributes[attributeLogicalName].optionsetProperties.getOptions()
                                                    : [];
                                                break;
                                            case ConditionModel.ControlTypes.SimpleLookup:
                                                var targets = entityAndAttrMetadata.attributes[attributeLogicalName].targets;
                                                newControlDefinition.targets =
                                                    targets.length > 0 ? targets : [entityLogicalName];
                                                break;
                                            case ConditionModel.ControlTypes.PartyListLookup:
                                                var targetEntities = entityAndAttrMetadata.attributes[attributeLogicalName].targets;
                                                newControlDefinition.targets =
                                                    targetEntities.length > 0 ? targetEntities : [entityLogicalName];
                                                break;
                                            default:
                                                break;
                                        }
                                        newControlDefinitions.push(newControlDefinition);
                                        resolve(newControlDefinitions);
                                    }
                                }, function (error) {
                                    reject(error);
                                });
                            });
                        case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                            return new Promise(function (resolve, reject) {
                                resolve([]);
                            });
                        default:
                            throw new Error("Invalid Control Name: " + controlName);
                    }
                };
                AdvancedFindControlDefinitionProvider.prototype.getLinkedEntityControlDefinition = function (context, rootNodeContainer, addLinkedEnityButton) {
                    var entityLogicalName = QueryBuilder.AdvancedFindUtils.getEntityLogicalName(rootNodeContainer);
                    var self = this;
                    return new Promise(function (resolve, reject) {
                        new QueryBuilder.AttributeMetadataProvider().getRelatedEntityTypeAheadSelectData(context, entityLogicalName).then(function (typeAheadSelectInput) {
                            var controlDefinition = self.getRelatedEntityControlDefinition(context, addLinkedEnityButton, typeAheadSelectInput);
                            resolve(controlDefinition);
                        }, function (error) {
                            reject(error);
                        });
                    });
                };
                AdvancedFindControlDefinitionProvider.prototype.getAttributeControlDefinition = function (context, parentCondition, data) {
                    return QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.LHSAttribute, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_ATTRIBUTE), false, null, parentCondition, data, "12.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_FIELDS_SECTION_NAME), new ConditionModel.ConditionControlChangeHandler(parentCondition));
                };
                AdvancedFindControlDefinitionProvider.prototype.getOperatorControlDefinition = function (context, parentCondition, data) {
                    return QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.Operator, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_OPERATOR), false, null, parentCondition, data, "8.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_OPERATORS_SECTION_NAME), new ConditionModel.ConditionControlChangeHandler(parentCondition));
                };
                AdvancedFindControlDefinitionProvider.prototype.getRelatedEntityControlDefinition = function (context, addLinkedEntityButton, data) {
                    return QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.RelatedEntity, "Related Entities", false, null, null, data, "12.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_RELATED_ENTITIES_SECTION_NAME), new ConditionModel.LinkedEntityControlChangeHandler(addLinkedEntityButton));
                };
                AdvancedFindControlDefinitionProvider.prototype.handleHierarchyOperators = function (attributeName, operator, entityAndAttrMetadata) {
                    var operators = [QueryBuilder.ConditionOperator.under, QueryBuilder.ConditionOperator.not_under];
                    var attributeType = entityAndAttrMetadata.attributes[attributeName].attributeType.Name;
                    if (attributeType == QueryBuilder.EntityAttributeType.LookUp && operators.filter(function (op) { return op == operator; })[0]) {
                        return true;
                    }
                    return false;
                };
                AdvancedFindControlDefinitionProvider.prototype.hierarchyOperatorsHandler = function (context, conditionNode, entityLogicalName, attributeLogicalName, operator, entityAndAttrMetadata) {
                    var toEntityLogicalName = entityLogicalName;
                    var toAttributeLogicalName = attributeLogicalName;
                    var relationship = entityAndAttrMetadata.manyToOneRelationships.filter(function (x) { return x.referencingAttribute == toAttributeLogicalName; })[0];
                    var fromEntityLogicalName = relationship.referencedEntity;
                    var fromAttributeLogicalName = relationship.referencedAttribute;
                    var attributeMetadataProvider = new QueryBuilder.AttributeMetadataProvider();
                    var relationshipType = attributeMetadataProvider.getRelationshipType(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName);
                    attributeMetadataProvider
                        .getAttributeMetadata(context, fromEntityLogicalName)
                        .then(function (fromEntityAndAttrMetadata) {
                        new QueryBuilder.AdvancedFindInitialMetadataLoader()
                            .getDisplayNamesForLinkedEntity(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, context)
                            .then(function (result) {
                            var fromEntityDisplayName = result[fromEntityLogicalName];
                            var toEntityDisplayName = result[toEntityLogicalName];
                            var fromAttributeDisplayName = result[fromAttributeLogicalName];
                            var toAttributeDisplayName = result[toAttributeLogicalName];
                            var linkedEntityData = {
                                RelationshipType: relationshipType,
                                FromEntityLogicalName: fromEntityLogicalName,
                                FromEntityDisplayName: fromEntityDisplayName,
                                FromAttributeLogicalName: fromAttributeLogicalName,
                                FromAttributeDisplayName: fromAttributeDisplayName,
                                ToEntityLogicalName: toEntityLogicalName,
                                ToEntityDisplayName: toEntityDisplayName,
                                ToAttributeLogicalName: toAttributeLogicalName,
                                ToAttributeDisplayName: toAttributeDisplayName,
                                IsVisible: true,
                                LinkType: QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER,
                                IsIntersect: false,
                                NoDisplayName: false,
                            };
                            var nodeContainer = conditionNode.getNodeContainer();
                            var linkedEntityNodeId;
                            var queryTree = conditionNode.ContainerTree;
                            if (nodeContainer.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] ==
                                QueryBuilder.Constants.RootNodeContainerType.QueryTree) {
                                linkedEntityNodeId = queryTree.addLinkedEntityNode(null, linkedEntityData);
                            }
                            else if (nodeContainer.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] ==
                                QueryBuilder.Constants.RootNodeContainerType.LinkedEntity) {
                                linkedEntityNodeId = queryTree.addLinkedEntityNode(nodeContainer.Id, linkedEntityData);
                            }
                            var linkedEntity = queryTree.getNode(linkedEntityNodeId);
                            var condition = queryTree.createConditionNode();
                            QueryBuilder.AdvancedFindUtils.createTypeAheadSelectDefinitions(context, condition, fromEntityAndAttrMetadata, fromEntityLogicalName, fromAttributeLogicalName, operator).then(function (controlDefinitions) {
                                var valueControl = QueryBuilder.Utils.createSimpleLookupDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], null, condition.Condition);
                                var targets = fromEntityAndAttrMetadata.attributes[fromAttributeLogicalName].targets;
                                valueControl.targets =
                                    targets && targets.length > 0 ? targets : [fromEntityLogicalName];
                                controlDefinitions.push(valueControl);
                                condition.Condition.ControlDefinitions = controlDefinitions;
                                linkedEntity.Root.addChild(condition);
                                queryTree.delete([conditionNode.Id]);
                                queryTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.AddLinkedEntity, Properties: {} });
                            });
                        });
                    });
                };
                return AdvancedFindControlDefinitionProvider;
            }());
            ConditionModel.AdvancedFindControlDefinitionProvider = AdvancedFindControlDefinitionProvider;
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var ConditionModel;
        (function (ConditionModel) {
            var ControlTypes;
            (function (ControlTypes) {
                ControlTypes[ControlTypes["TextBox"] = 0] = "TextBox";
                ControlTypes[ControlTypes["ComboBox"] = 1] = "ComboBox";
                ControlTypes[ControlTypes["DateTime"] = 2] = "DateTime";
                ControlTypes[ControlTypes["MultiSelectPicklist"] = 3] = "MultiSelectPicklist";
                ControlTypes[ControlTypes["OptionSet"] = 4] = "OptionSet";
                ControlTypes[ControlTypes["TypeAheadSelect"] = 5] = "TypeAheadSelect";
                ControlTypes[ControlTypes["SimpleLookup"] = 6] = "SimpleLookup";
                ControlTypes[ControlTypes["PartyListLookup"] = 7] = "PartyListLookup";
                ControlTypes[ControlTypes["FiscalYearAndPeriod"] = 8] = "FiscalYearAndPeriod";
            })(ControlTypes = ConditionModel.ControlTypes || (ConditionModel.ControlTypes = {}));
        })(ConditionModel = QueryBuilder.ConditionModel || (QueryBuilder.ConditionModel = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var Constants;
        (function (Constants) {
            "use strict";
            var UsageContext;
            (function (UsageContext) {
                UsageContext[UsageContext["AdvancedFind"] = 0] = "AdvancedFind";
                UsageContext[UsageContext["Sample"] = 1] = "Sample";
            })(UsageContext = Constants.UsageContext || (Constants.UsageContext = {}));
            var ConditionFieldName;
            (function (ConditionFieldName) {
                ConditionFieldName[ConditionFieldName["LHSEntity"] = 0] = "LHSEntity";
                ConditionFieldName[ConditionFieldName["LHSAttribute"] = 1] = "LHSAttribute";
                ConditionFieldName[ConditionFieldName["Operator"] = 2] = "Operator";
                ConditionFieldName[ConditionFieldName["RHSValueType"] = 3] = "RHSValueType";
                ConditionFieldName[ConditionFieldName["RHSEntity"] = 4] = "RHSEntity";
                ConditionFieldName[ConditionFieldName["RHSAttribute"] = 5] = "RHSAttribute";
                ConditionFieldName[ConditionFieldName["RHSValue"] = 6] = "RHSValue";
                ConditionFieldName[ConditionFieldName["RelatedEntity"] = 7] = "RelatedEntity";
                ConditionFieldName[ConditionFieldName["SampleField"] = 8] = "SampleField";
            })(ConditionFieldName = Constants.ConditionFieldName || (Constants.ConditionFieldName = {}));
            var QueryTreeNodeType;
            (function (QueryTreeNodeType) {
                QueryTreeNodeType[QueryTreeNodeType["AND"] = 0] = "AND";
                QueryTreeNodeType[QueryTreeNodeType["OR"] = 1] = "OR";
                QueryTreeNodeType[QueryTreeNodeType["Condition"] = 2] = "Condition";
                QueryTreeNodeType[QueryTreeNodeType["LinkedEntity"] = 3] = "LinkedEntity";
            })(QueryTreeNodeType = Constants.QueryTreeNodeType || (Constants.QueryTreeNodeType = {}));
            var QueryTreeEventType;
            (function (QueryTreeEventType) {
                QueryTreeEventType[QueryTreeEventType["Initialized"] = 0] = "Initialized";
                QueryTreeEventType[QueryTreeEventType["RunQuery"] = 1] = "RunQuery";
                QueryTreeEventType[QueryTreeEventType["GroupAND"] = 2] = "GroupAND";
                QueryTreeEventType[QueryTreeEventType["GroupOR"] = 3] = "GroupOR";
                QueryTreeEventType[QueryTreeEventType["UnGroup"] = 4] = "UnGroup";
                QueryTreeEventType[QueryTreeEventType["Delete"] = 5] = "Delete";
                QueryTreeEventType[QueryTreeEventType["AddLinkedEntity"] = 6] = "AddLinkedEntity";
                QueryTreeEventType[QueryTreeEventType["RemoveLinkedEntity"] = 7] = "RemoveLinkedEntity";
                QueryTreeEventType[QueryTreeEventType["AddCondition"] = 8] = "AddCondition";
                QueryTreeEventType[QueryTreeEventType["UpdateCondition"] = 9] = "UpdateCondition";
                QueryTreeEventType[QueryTreeEventType["Reset"] = 10] = "Reset";
                QueryTreeEventType[QueryTreeEventType["Destroy"] = 11] = "Destroy";
                QueryTreeEventType[QueryTreeEventType["ClearLinkedEntity"] = 12] = "ClearLinkedEntity";
                QueryTreeEventType[QueryTreeEventType["LinkedEntityContainsData"] = 13] = "LinkedEntityContainsData";
                QueryTreeEventType[QueryTreeEventType["ShowInSimpleMode"] = 14] = "ShowInSimpleMode";
            })(QueryTreeEventType = Constants.QueryTreeEventType || (Constants.QueryTreeEventType = {}));
            var QueryBuilderCommandBarType;
            (function (QueryBuilderCommandBarType) {
                QueryBuilderCommandBarType[QueryBuilderCommandBarType["Global"] = 0] = "Global";
                QueryBuilderCommandBarType[QueryBuilderCommandBarType["LinkedEntity"] = 1] = "LinkedEntity";
            })(QueryBuilderCommandBarType = Constants.QueryBuilderCommandBarType || (Constants.QueryBuilderCommandBarType = {}));
            var QueryBuilderCommandBarButtonType;
            (function (QueryBuilderCommandBarButtonType) {
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["RunQuery"] = 0] = "RunQuery";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["AND"] = 1] = "AND";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["OR"] = 2] = "OR";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["Delete"] = 3] = "Delete";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["Ungroup"] = 4] = "Ungroup";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["Clear"] = 5] = "Clear";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["SimpleDetailed"] = 6] = "SimpleDetailed";
                QueryBuilderCommandBarButtonType[QueryBuilderCommandBarButtonType["ShowHideInSimpleMode"] = 7] = "ShowHideInSimpleMode";
            })(QueryBuilderCommandBarButtonType = Constants.QueryBuilderCommandBarButtonType || (Constants.QueryBuilderCommandBarButtonType = {}));
            var ValidationErrorKey;
            (function (ValidationErrorKey) {
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_LHS_ENTITY"] = 0] = "INCOMPLETE_LHS_ENTITY";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_LHS_ATTRIBUTE"] = 1] = "INCOMPLETE_LHS_ATTRIBUTE";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_OPERATOR"] = 2] = "INCOMPLETE_OPERATOR";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_RHS_VALUE_TYPE"] = 3] = "INCOMPLETE_RHS_VALUE_TYPE";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_RHS_ENTITY"] = 4] = "INCOMPLETE_RHS_ENTITY";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_RHS_ATTRIBUTE"] = 5] = "INCOMPLETE_RHS_ATTRIBUTE";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_VALUE"] = 6] = "INCOMPLETE_VALUE";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_CONDITION"] = 7] = "INCOMPLETE_CONDITION";
                ValidationErrorKey[ValidationErrorKey["INVALID_VALUE"] = 8] = "INVALID_VALUE";
                ValidationErrorKey[ValidationErrorKey["INVALID_RANGE"] = 9] = "INVALID_RANGE";
                ValidationErrorKey[ValidationErrorKey["INVALID_PRECISION"] = 10] = "INVALID_PRECISION";
                ValidationErrorKey[ValidationErrorKey["INCOMPLETE_SAMPLE_FIELD"] = 11] = "INCOMPLETE_SAMPLE_FIELD";
                ValidationErrorKey[ValidationErrorKey["TOO_LONG_VALUE"] = 12] = "TOO_LONG_VALUE";
            })(ValidationErrorKey = Constants.ValidationErrorKey || (Constants.ValidationErrorKey = {}));
            var ValidationLevel;
            (function (ValidationLevel) {
                ValidationLevel[ValidationLevel["ERROR"] = 0] = "ERROR";
            })(ValidationLevel = Constants.ValidationLevel || (Constants.ValidationLevel = {}));
            var AddNodeButtonType;
            (function (AddNodeButtonType) {
                AddNodeButtonType[AddNodeButtonType["AddFilter"] = 0] = "AddFilter";
                AddNodeButtonType[AddNodeButtonType["AddRelated"] = 1] = "AddRelated";
            })(AddNodeButtonType = Constants.AddNodeButtonType || (Constants.AddNodeButtonType = {}));
            var QueryTreeOptionNotifyOutputChangeOn;
            (function (QueryTreeOptionNotifyOutputChangeOn) {
                QueryTreeOptionNotifyOutputChangeOn[QueryTreeOptionNotifyOutputChangeOn["OutputChange"] = 0] = "OutputChange";
                QueryTreeOptionNotifyOutputChangeOn[QueryTreeOptionNotifyOutputChangeOn["ValidOutputChange"] = 1] = "ValidOutputChange";
                QueryTreeOptionNotifyOutputChangeOn[QueryTreeOptionNotifyOutputChangeOn["RunButtonClick"] = 2] = "RunButtonClick";
            })(QueryTreeOptionNotifyOutputChangeOn = Constants.QueryTreeOptionNotifyOutputChangeOn || (Constants.QueryTreeOptionNotifyOutputChangeOn = {}));
            var ViewType;
            (function (ViewType) {
                ViewType[ViewType["Public"] = 0] = "Public";
                ViewType[ViewType["AdvancedFind"] = 1] = "AdvancedFind";
                ViewType[ViewType["Associated"] = 2] = "Associated";
                ViewType[ViewType["QuickFind"] = 4] = "QuickFind";
                ViewType[ViewType["Lookup"] = 64] = "Lookup";
            })(ViewType = Constants.ViewType || (Constants.ViewType = {}));
            var LinkedEntityRelationshipType;
            (function (LinkedEntityRelationshipType) {
                LinkedEntityRelationshipType[LinkedEntityRelationshipType["OneToMany"] = 0] = "OneToMany";
                LinkedEntityRelationshipType[LinkedEntityRelationshipType["ManyToOne"] = 1] = "ManyToOne";
                LinkedEntityRelationshipType[LinkedEntityRelationshipType["ManyToMany"] = 2] = "ManyToMany";
            })(LinkedEntityRelationshipType = Constants.LinkedEntityRelationshipType || (Constants.LinkedEntityRelationshipType = {}));
            var ShowQueryTreeRoot;
            (function (ShowQueryTreeRoot) {
                ShowQueryTreeRoot[ShowQueryTreeRoot["Always"] = 0] = "Always";
                ShowQueryTreeRoot[ShowQueryTreeRoot["Never"] = 1] = "Never";
                ShowQueryTreeRoot[ShowQueryTreeRoot["OnlyIfOR"] = 2] = "OnlyIfOR";
            })(ShowQueryTreeRoot = Constants.ShowQueryTreeRoot || (Constants.ShowQueryTreeRoot = {}));
            var RootNodeContainerType;
            (function (RootNodeContainerType) {
                RootNodeContainerType[RootNodeContainerType["QueryTree"] = 0] = "QueryTree";
                RootNodeContainerType[RootNodeContainerType["LinkedEntity"] = 1] = "LinkedEntity";
            })(RootNodeContainerType = Constants.RootNodeContainerType || (Constants.RootNodeContainerType = {}));
            var Mode;
            (function (Mode) {
                Mode[Mode["Simple"] = 1] = "Simple";
                Mode[Mode["Advanced"] = 2] = "Advanced";
            })(Mode = Constants.Mode || (Constants.Mode = {}));
            var FiscalPeriodType;
            (function (FiscalPeriodType) {
                FiscalPeriodType[FiscalPeriodType["Annually"] = 2000] = "Annually";
                FiscalPeriodType[FiscalPeriodType["Semiannually"] = 2001] = "Semiannually";
                FiscalPeriodType[FiscalPeriodType["Quarterly"] = 2002] = "Quarterly";
                FiscalPeriodType[FiscalPeriodType["Monthly"] = 2003] = "Monthly";
                FiscalPeriodType[FiscalPeriodType["FourWeekPeriod"] = 2004] = "FourWeekPeriod";
            })(FiscalPeriodType = Constants.FiscalPeriodType || (Constants.FiscalPeriodType = {}));
            var FiscalPeriodFormat;
            (function (FiscalPeriodFormat) {
                FiscalPeriodFormat[FiscalPeriodFormat["Quarter_Format"] = 1] = "Quarter_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["Q_Format"] = 2] = "Q_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["P_Format"] = 3] = "P_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["Month_Format"] = 4] = "Month_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["M_Format"] = 5] = "M_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["Semester_Format"] = 6] = "Semester_Format";
                FiscalPeriodFormat[FiscalPeriodFormat["MonthName_Format"] = 7] = "MonthName_Format";
            })(FiscalPeriodFormat = Constants.FiscalPeriodFormat || (Constants.FiscalPeriodFormat = {}));
        })(Constants = QueryBuilder.Constants || (QueryBuilder.Constants = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var LocalizedStrings;
        (function (LocalizedStrings) {
            "use strict";
            LocalizedStrings.LS_QUERYBUILDER_AND_STRING = "QueryBuilder.QueryTree.Node.And";
            LocalizedStrings.LS_QUERYBUILDER_OR_STRING = "QueryBuilder.QueryTree.Node.Or";
            LocalizedStrings.LS_QUERYBUILDER_ADD_CONDITION = "QueryBuilder.QueryTree.AddCondition";
            LocalizedStrings.LS_QUERYBUILDER_ADD_RELATED = "QueryBuilder.QueryTree.AddRelatedEntity";
            LocalizedStrings.INCOMPLETE_LHS_ENTITY = "QueryBuilder.QueryTree.Error.IncompleteLHSEntity";
            LocalizedStrings.INCOMPLETE_LHS_ATTRIBUTE = "QueryBuilder.QueryTree.Error.IncompleteLHSAttribute";
            LocalizedStrings.INCOMPLETE_OPERATOR = "QueryBuilder.QueryTree.Error.IncompleteOperator";
            LocalizedStrings.INCOMPLETE_RHS_VALUE_TYPE = "QueryBuilder.QueryTree.Error.IncompleteRHSValueType";
            LocalizedStrings.INCOMPLETE_RHS_ENTITY = "QueryBuilder.QueryTree.Error.IncompleteRHSEntity";
            LocalizedStrings.INCOMPLETE_RHS_ATTRIBUTE = "QueryBuilder.QueryTree.Error.IncompleteRHSAttribute";
            LocalizedStrings.INCOMPLETE_VALUE = "QueryBuilder.QueryTree.Error.IncompleteValue";
            LocalizedStrings.INCOMPLETE_CONDITION = "QueryBuilder.QueryTree.Error.IncompleteCondition";
            LocalizedStrings.INVALID_VALUE = "QueryBuilder.QueryTree.Error.InvalidValue";
            LocalizedStrings.INVALID_RANGE = "QueryBuilder.QueryTree.Error.InvalidRange";
            LocalizedStrings.INVALID_PRECISION = "QueryBuilder.QueryTree.Error.InvalidPrecision";
            LocalizedStrings.FiscalSettings_PeriodFormat_Annual_Format = "FiscalSettings_PeriodFormat_Annual_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_P_Format = "FiscalSettings_PeriodFormat_P_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_Period_Format = "FiscalSettings_PeriodFormat_Period_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_Q_Format = "FiscalSettings_PeriodFormat_Q_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_Quarter_Format = "FiscalSettings_PeriodFormat_Quarter_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_M_Format = "FiscalSettings_PeriodFormat_M_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_Month_Format = "FiscalSettings_PeriodFormat_Month_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_S_Format = "FiscalSettings_PeriodFormat_S_Format";
            LocalizedStrings.FiscalSettings_PeriodFormat_Semester_Format = "FiscalSettings_PeriodFormat_Semester_Format";
            LocalizedStrings.FISCAL_YEAR_FORMAT = "FiscalYear_Format_String_NoSpace";
            LocalizedStrings.FiscalMonthPrefix = "FiscalMonth_";
            LocalizedStrings.ATTR_DROPDOWN_FIELDS_SECTION_NAME = "ATTR_DROPDOWN_FIELDS_SECTION_NAME";
            LocalizedStrings.ATTR_DROPDOWN_OPERATORS_SECTION_NAME = "ATTR_DROPDOWN_OPERATORS_SECTION_NAME";
            LocalizedStrings.ATTR_DROPDOWN_RELATED_ENTITIES_SECTION_NAME = "ATTR_DROPDOWN_RELATED_ENTITIES_SECTION_NAME";
            LocalizedStrings.COMMANDBAR_RUN_QUERY = "COMMANDBAR_RUN_QUERY";
            LocalizedStrings.COMMANDBAR_AND = "COMMANDBAR_AND";
            LocalizedStrings.COMMANDBAR_OR = "COMMANDBAR_OR";
            LocalizedStrings.COMMANDBAR_UNGROUP = "COMMANDBAR_UNGROUP";
            LocalizedStrings.COMMANDBAR_DELETE = "COMMANDBAR_DELETE";
            LocalizedStrings.COMMANDBAR_CLEAR = "COMMANDBAR_CLEAR";
            LocalizedStrings.COMMANDBAR_MODE = "COMMANDBAR_MODE";
            LocalizedStrings.COMMANDBAR_SHOW_SIMPLE = "ShowInSimpleMode";
            LocalizedStrings.COMMANDBAR_HIDE_SIMPLE = "HideInSimpleMode";
            LocalizedStrings.COMMANDBAR_AND_TITLE_VERBAL_STRING = "COMMANDBAR_AND_TITLE_VERBAL_STRING";
            LocalizedStrings.COMMANDBAR_OR_TITLE_VERBAL_STRING = "COMMANDBAR_OR_TITLE_VERBAL_STRING";
            LocalizedStrings.COMMANDBAR_UNGROUP_TITLE_VERBAL_STRING = "COMMANDBAR_UNGROUP_TITLE_VERBAL_STRING";
            LocalizedStrings.COMMANDBAR_CLEAR_TITLE_VERBAL_STRING = "COMMANDBAR_CLEAR_TITLE_VERBAL_STRING";
            LocalizedStrings.COMMANDBAR_RUN_QUERY_TITLE_VERBAL_STRING = "COMMANDBAR_RUN_QUERY_TITLE_VERBAL_STRING";
            LocalizedStrings.COMMANDBAR_DELETE_TITLE_VERBAL_STRING = "COMMANDBAR_DELETE_TITLE_VERBAL_STRING";
            LocalizedStrings.LS_QUERYBUILDER_ADD_FILTER = "LS_QUERYBUILDER_ADD_FILTER";
            LocalizedStrings.LS_QUERYBUILDER_ADD_RELATED_ENTITY = "LS_QUERYBUILDER_ADD_RELATED_ENTITY";
            LocalizedStrings.LS_QUERYBUILDER_CONDITION = "QueryBuilder.VerbalStrings.Condition";
            LocalizedStrings.LINKED_ENTITY_REMOVE = "LINKED_ENTITY_REMOVE";
            LocalizedStrings.LINKED_ENTITY_CONTAINS_DATA = "LINKED_ENTITY_CONTAINS_DATA";
            LocalizedStrings.LINKED_ENTITY_DOESNOT_CONTAIN_DATA = "LINKED_ENTITY_DOESNOT_CONTAIN_DATA";
            LocalizedStrings.LINKED_ENTITY_DOESNOT_CONTAIN_DATA_VIEW = "LINKED_ENTITY_DOESNOT_CONTAIN_DATA_VIEW";
            LocalizedStrings.CONFIRMATION_DIALOG_OK = "CONFIRMATION_DIALOG_OK";
            LocalizedStrings.CONFIRMATION_DIALOG_CANCEL = "CONFIRMATION_DIALOG_CANCEL";
            LocalizedStrings.CONFIRMATION_DIALOG_TITLE_CLEAR = "CONFIRMATION_DIALOG_TITLE_CLEAR";
            LocalizedStrings.CONFIRMATION_DIALOG_TITLE_DELETE = "CONFIRMATION_DIALOG_TITLE_DELETE";
            LocalizedStrings.CONFIRMATION_MESSAGE_RESET = "CONFIRMATION_MESSAGE_RESET";
            LocalizedStrings.CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY = "CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY";
            LocalizedStrings.CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY_FILTERS = "CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY_FILTERS";
            LocalizedStrings.CONDITION_HIDDEN = "CONDITION_HIDDEN";
            LocalizedStrings.LS_ATTRIBUTE = "QueryBuilder.TypeAhead.Attribute";
            LocalizedStrings.LS_OPERATOR = "QueryBuilder.TypeAhead.Operator";
            LocalizedStrings.SHOW_ERROR_IF_NO_CONDITION = "EmptyFilterSectionSimpleMode";
            LocalizedStrings.SwitchToSimpleMode = "SwitchToSimpleMode";
            LocalizedStrings.SwitchToAdvancedMode = "SwitchToAdvancedMode";
            LocalizedStrings.EntityReadAccessError = "EntityReadAccessError";
        })(LocalizedStrings = QueryBuilder.LocalizedStrings || (QueryBuilder.LocalizedStrings = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var AdvancedFindConstants;
        (function (AdvancedFindConstants) {
            "use strict";
            AdvancedFindConstants.ADVANCED_FIND_AND = "and";
            AdvancedFindConstants.ADVANCED_FIND_OR = "or";
            AdvancedFindConstants.NODE_NAME_FILTER = "filter";
            AdvancedFindConstants.NODE_NAME_CONDITION = "condition";
            AdvancedFindConstants.NODE_NAME_LINK_ENTITY = "link-entity";
            AdvancedFindConstants.NODE_NAME_VALUE = "value";
            AdvancedFindConstants.ATTRIBUTE_NAME_TYPE = "type";
            AdvancedFindConstants.ATTRIBUTE_NAME_ATTRIBUTE = "attribute";
            AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR = "operator";
            AdvancedFindConstants.ATTRIBUTE_NAME_VALUE = "value";
            AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE = "uitype";
            AdvancedFindConstants.ATTRIBUTE_NAME_UINAME = "uiname";
            AdvancedFindConstants.ATTRIBUTE_NAME_UIHIDDEN = "uihidden";
            AdvancedFindConstants.FETCH_ATTRIBUTES = "fetchAttributes";
            AdvancedFindConstants.ENTITY_ATTRIBUTES = "entityAttributes";
            AdvancedFindConstants.ENTITY_CHILD_NODES = "entityChildNodes";
            AdvancedFindConstants.ENTITY_ATTRIBUTE_NAME = "name";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_ALIAS = "alias";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_LINK_TYPE = "link-type";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_INTERSECT = "intersect";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_TO = "to";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_FROM = "from";
            AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_VISIBLE = "visible";
            AdvancedFindConstants.LINK_TYPE_INNER = "inner";
            AdvancedFindConstants.LINK_TYPE_OUTER = "outer";
            AdvancedFindConstants.ENTITYNAME = "entityname";
            AdvancedFindConstants.ENTITY_METADATA_ATTRIBUTES = [
                "DisplayName",
                "LogicalName",
                "LogicalCollectionName",
                "PrimaryIdAttribute",
                "PrimaryNameAttribute",
                "DisplayCollectionName",
            ];
        })(AdvancedFindConstants = QueryBuilder.AdvancedFindConstants || (QueryBuilder.AdvancedFindConstants = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AttributeMetadataProvider = (function () {
            function AttributeMetadataProvider() {
            }
            AttributeMetadataProvider.prototype.getAttributeTypeAheadSelectData = function (context, entityLogicalName) {
                var _this = this;
                var self = this;
                return new Promise(function (resolve, reject) {
                    _this.getAttributeMetadata(context, entityLogicalName).then(function (entityAndAttributesMetadata) {
                        resolve(self.populateAttributeListForTypeAheadSelect(context, entityAndAttributesMetadata, entityLogicalName, true, false));
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AttributeMetadataProvider.prototype.getRelatedEntityTypeAheadSelectData = function (context, entityLogicalName) {
                var _this = this;
                var self = this;
                return new Promise(function (resolve, reject) {
                    _this.getAttributeMetadata(context, entityLogicalName).then(function (entityAndAttributesMetadata) {
                        resolve(self.populateAttributeListForTypeAheadSelect(context, entityAndAttributesMetadata, entityLogicalName, false, true));
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AttributeMetadataProvider.prototype.getAttributeType = function (entityLogicalName, attributeName, context) {
                var _this = this;
                var self = this;
                return new Promise(function (resolve, reject) {
                    _this.getAttributeMetadata(context, entityLogicalName).then(function (entityMetadata) {
                        resolve(entityMetadata.attributes[attributeName].attributeType);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AttributeMetadataProvider.prototype.getRelationshipType = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) {
                var relationshipType = QueryBuilder.MetadataStore.Instance.getRelationshipData(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName).relationshipType;
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(relationshipType)) {
                    throw new Error(MscrmCommon.ControlUtils.String.Format("No relationship exists between fromEntity: {0}, fromAttribute: {1}, toEntity: {2}, toAttribute: {3}", fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName));
                }
                return relationshipType;
            };
            AttributeMetadataProvider.prototype.hasReadPrivilegeForRelationship = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) {
                return QueryBuilder.MetadataStore.Instance.getRelationshipData(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName).hasReadPrivilege;
            };
            AttributeMetadataProvider.prototype.getAttribute = function (entityLogicalName, attributeName, context) {
                var _this = this;
                var self = this;
                return new Promise(function (resolve, reject) {
                    _this.getAttributeMetadata(context, entityLogicalName).then(function (entityMetadata) {
                        resolve(entityMetadata.attributes[attributeName]);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AttributeMetadataProvider.prototype.getAttributeDisplayName = function (entityLogicalName, attributeLogicalName, context) {
                var _this = this;
                return new Promise(function (resolve, reject) {
                    _this.getAttributeMetadata(context, entityLogicalName).then(function (entityMetadata) {
                        resolve(entityMetadata.attributes[attributeLogicalName].displayName);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AttributeMetadataProvider.prototype.getAttributeMetadata = function (context, entityLogicalName) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    if (QueryBuilder.MetadataStore.Instance.containsEntityAndAttributesMetadata(entityLogicalName)) {
                        resolve(QueryBuilder.MetadataStore.Instance.getEntityAndAttributesMetadataByName(entityLogicalName));
                    }
                    else {
                        new QueryBuilder.ODataHelper(context).retrieveAttributesAndRelatedEntitiesMetadataByEntityName(entityLogicalName).then(function (response) {
                            var entityAndAttrMetadata = self.parseEntityAndAttributeMetadataResponse(entityLogicalName, response.EntityRelationsWithDependantEntityMetadata, context);
                            QueryBuilder.MetadataStore.Instance.addEntityAndAttributesMetadata(entityLogicalName, entityAndAttrMetadata);
                            resolve(QueryBuilder.MetadataStore.Instance.getEntityAndAttributesMetadataByName(entityLogicalName));
                        }, function (error) {
                            reject(error);
                        });
                    }
                });
            };
            AttributeMetadataProvider.prototype.getAttributeMetadataForEntities = function (context, entityLogicalNames) {
                var self = this;
                var entityAttributeMap = {};
                var uncachedEntityList = entityLogicalNames.filter(function (entity) { return !QueryBuilder.MetadataStore.Instance.containsEntityAndAttributesMetadata(entity); });
                return new Promise(function (resolve, reject) {
                    if (uncachedEntityList.length == 0) {
                        for (var _i = 0, entityLogicalNames_1 = entityLogicalNames; _i < entityLogicalNames_1.length; _i++) {
                            var entity = entityLogicalNames_1[_i];
                            entityAttributeMap[entity] = QueryBuilder.MetadataStore.Instance.getEntityAndAttributesMetadataByName(entity);
                        }
                        resolve(entityAttributeMap);
                    }
                    else {
                        new QueryBuilder.ODataHelper(context).retrieveAttributesAndRelatedEntitiesMetadataByEntityNames(uncachedEntityList).then(function (response) {
                            for (var i = 0; i < response.EntitiesRelationsWithDependantEntityMetadata.length; i++) {
                                var metadata = response.EntitiesRelationsWithDependantEntityMetadata[i];
                                var entityLogicalName = uncachedEntityList[i];
                                var entityAttributeMetadata = self.parseEntityAndAttributeMetadataResponse(entityLogicalName, metadata, context);
                                QueryBuilder.MetadataStore.Instance.addEntityAndAttributesMetadata(entityLogicalName, entityAttributeMetadata);
                            }
                            for (var _i = 0, entityLogicalNames_2 = entityLogicalNames; _i < entityLogicalNames_2.length; _i++) {
                                var entity = entityLogicalNames_2[_i];
                                entityAttributeMap[entity] = QueryBuilder.MetadataStore.Instance.getEntityAndAttributesMetadataByName(entity);
                            }
                            resolve(entityAttributeMap);
                        }, function (error) {
                            reject(error);
                        });
                    }
                });
            };
            AttributeMetadataProvider.prototype.parseEntityAndAttributeMetadataResponse = function (entityLogicalName, metadataResponse, context) {
                var downloadedMetadata = metadataResponse;
                var entityMetadata = new QueryBuilder.EntityMetadataAndAttributes(entityLogicalName);
                for (var _i = 0, _a = downloadedMetadata.AttributesMetadata.DependentAttributes; _i < _a.length; _i++) {
                    var attr = _a[_i];
                    var attributeMetadata = new QueryBuilder.AttributeMetadata();
                    attributeMetadata.populate(attr);
                    entityMetadata.addAttribute(attributeMetadata);
                    attributeMetadata.optionsetProperties = this.processDependentOptionSetMetadata(attributeMetadata.optionSet);
                    if (attributeMetadata.isRangeBased) {
                        attributeMetadata.AddRangeInformation(attr.MinValue, attr.MaxValue, attr.Precision);
                    }
                }
                for (var _b = 0, _c = downloadedMetadata.EntityRelationshipCollection.DependentRelationships; _b < _c.length; _b++) {
                    var relationship = _c[_b];
                    switch (relationship.EntityRelationshipType) {
                        case QueryBuilder.RelationshipType.ManyToOneRelationship:
                            entityMetadata.addManyToOneRelationship(new QueryBuilder.ManyToOneRelationEntityMetadata(relationship));
                            break;
                        case QueryBuilder.RelationshipType.OneToManyRelationship:
                            entityMetadata.addOneToManyRelationship(new QueryBuilder.OneToManyRelationEntityMetadata(relationship));
                            break;
                        case QueryBuilder.RelationshipType.ManyToManyRelationship:
                            entityMetadata.addManyToManyRelationship(new QueryBuilder.ManyToManyRelationEntityMetadata(relationship));
                            break;
                    }
                }
                for (var _d = 0, _e = downloadedMetadata.DependantEntitiesCollection.DependantEntities; _d < _e.length; _d++) {
                    var relatedEntity = _e[_d];
                    var relatedEntityMetadata = new QueryBuilder.RelatedEntityMetadataAndAttributes(relatedEntity.LogicalName);
                    relatedEntityMetadata.displayName = relatedEntity.DisplayName;
                    for (var _f = 0, _g = relatedEntity.Attributes.DependentAttributes; _f < _g.length; _f++) {
                        var attr = _g[_f];
                        var attributeMetadata = new QueryBuilder.AttributeMetadata();
                        attributeMetadata.populate(attr);
                        relatedEntityMetadata.addAttribute(attributeMetadata);
                    }
                    entityMetadata.relatedEntities[relatedEntity.LogicalName] = relatedEntityMetadata;
                }
                return entityMetadata;
            };
            AttributeMetadataProvider.prototype.processDependentOptionSetMetadata = function (dependentOptionSetMetadata) {
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(dependentOptionSetMetadata)) {
                    return null;
                }
                var optionSetProperties = new QueryBuilder.OptionSetProperties();
                var optionSetType = dependentOptionSetMetadata.Type;
                optionSetProperties.optionSetType = new QueryBuilder.OptionSetType(optionSetType);
                if (optionSetType === QueryBuilder.OptionSetType.Boolean) {
                    optionSetProperties.trueOption = new QueryBuilder.Option(dependentOptionSetMetadata.TrueOption.Label, dependentOptionSetMetadata.TrueOption.Value, dependentOptionSetMetadata.TrueOption.State);
                    optionSetProperties.falseOption = new QueryBuilder.Option(dependentOptionSetMetadata.FalseOption.Label, dependentOptionSetMetadata.FalseOption.Value, dependentOptionSetMetadata.FalseOption.State);
                }
                else {
                    optionSetProperties.options = new Array();
                    for (var _i = 0, _a = dependentOptionSetMetadata.Options.OptionList; _i < _a.length; _i++) {
                        var option = _a[_i];
                        optionSetProperties.options.push(new QueryBuilder.Option(option.Label, option.Value, option.State));
                    }
                }
                return optionSetProperties;
            };
            AttributeMetadataProvider.prototype.populateAttributeListForTypeAheadSelect = function (context, entityMetadata, entityLogicalName, addAttributes, addRelatedEntities) {
                var sections = [];
                if (addAttributes) {
                    sections.push(this.populateFieldsTypeAheadSelectSection(context, entityMetadata));
                }
                if (addRelatedEntities) {
                    sections.push(this.populateRelatedEntitiesTypeAheadSelectSection(context, entityMetadata, entityLogicalName));
                }
                return { isSectioningEnabled: true, sections: sections };
            };
            AttributeMetadataProvider.prototype.populateFieldsTypeAheadSelectSection = function (context, entityMetadata) {
                return {
                    sectionName: "--" + QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_FIELDS_SECTION_NAME) + "--",
                    sectionElements: this.populateFieldsSelectOptions(entityMetadata),
                };
            };
            AttributeMetadataProvider.prototype.populateRelatedEntitiesTypeAheadSelectSection = function (context, entityMetadata, entityLogicalName) {
                return {
                    sectionName: "--" + QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_RELATED_ENTITIES_SECTION_NAME) + "--",
                    sectionElements: this.populateRelatedEntitiesSelectOptions(context, entityMetadata, entityLogicalName),
                };
            };
            AttributeMetadataProvider.prototype.populateFieldsSelectOptions = function (entityMetadata) {
                var fieldSelectOptions = new Array();
                for (var attr in entityMetadata.attributes) {
                    var attributeMetadata = entityMetadata.attributes[attr];
                    if (attributeMetadata.isValidForAdvancedFind === true &&
                        MscrmCommon.ControlUtils.String.isNullOrEmpty(attributeMetadata.yomiOf)) {
                        fieldSelectOptions.push(QueryBuilder.Utils.getSectionElement(attributeMetadata.displayName, attributeMetadata.logicalName));
                    }
                }
                QueryBuilder.Utils.sortSelectOptions(fieldSelectOptions);
                return fieldSelectOptions;
            };
            AttributeMetadataProvider.prototype.populateRelatedEntitiesSelectOptions = function (context, entityMetadata, entityLogicalName) {
                var relatedEntitiesSelectOptions = new Array();
                var displayName, logicalName;
                var relatedEntityMetadata;
                for (var _i = 0, _a = entityMetadata.oneToManyRelationships; _i < _a.length; _i++) {
                    var oneToManyRelationship = _a[_i];
                    if (oneToManyRelationship.isValidForAdvancedFind && oneToManyRelationship.hasReadPrivilege) {
                        relatedEntityMetadata = entityMetadata.relatedEntities[oneToManyRelationship.referencingEntity];
                        displayName = QueryBuilder.Utils.getRelatedEntityAttributeDisplayName(relatedEntityMetadata.displayName, relatedEntityMetadata.getAttributeByLogicalName(oneToManyRelationship.referencingAttribute)
                            ? relatedEntityMetadata.getAttributeByLogicalName(oneToManyRelationship.referencingAttribute).displayName
                            : oneToManyRelationship.referencingAttribute);
                        logicalName = QueryBuilder.Utils.getRelatedEntityAttributeLogicalName(QueryBuilder.Constants.LinkedEntityRelationshipType[QueryBuilder.Constants.LinkedEntityRelationshipType.OneToMany], oneToManyRelationship.referencingEntity, oneToManyRelationship.referencingAttribute, entityLogicalName, oneToManyRelationship.referencedAttribute);
                        relatedEntitiesSelectOptions.push(QueryBuilder.Utils.getSectionElement(displayName, logicalName));
                    }
                }
                for (var _b = 0, _c = entityMetadata.manyToOneRelationships; _b < _c.length; _b++) {
                    var manyToOneRelationship = _c[_b];
                    if (manyToOneRelationship.isValidForAdvancedFind && manyToOneRelationship.hasReadPrivilege) {
                        relatedEntityMetadata = entityMetadata.relatedEntities[manyToOneRelationship.referencedEntity];
                        if (entityMetadata.getAttributeByLogicalName(manyToOneRelationship.referencingAttribute) &&
                            !MscrmCommon.ControlUtils.Object.isNullOrUndefined(entityMetadata.getAttributeByLogicalName(manyToOneRelationship.referencingAttribute).displayName)) {
                            displayName = QueryBuilder.Utils.getRelatedEntityAttributeDisplayName(entityMetadata.getAttributeByLogicalName(manyToOneRelationship.referencingAttribute).displayName, relatedEntityMetadata.displayName);
                            logicalName = QueryBuilder.Utils.getRelatedEntityAttributeLogicalName(QueryBuilder.Constants.LinkedEntityRelationshipType[QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToOne], manyToOneRelationship.referencedEntity, manyToOneRelationship.referencedAttribute, entityLogicalName, manyToOneRelationship.referencingAttribute);
                            relatedEntitiesSelectOptions.push(QueryBuilder.Utils.getSectionElement(displayName, logicalName));
                        }
                    }
                }
                for (var _d = 0, _e = entityMetadata.manyToManyRelationships; _d < _e.length; _d++) {
                    var manyToManyRelationship = _e[_d];
                    if (manyToManyRelationship.isValidForAdvancedFind && manyToManyRelationship.hasReadPrivilege) {
                        relatedEntityMetadata = entityMetadata.relatedEntities[manyToManyRelationship.referencingEntity];
                        displayName = QueryBuilder.Utils.getRelatedEntityAttributeDisplayName(relatedEntityMetadata.displayName, relatedEntityMetadata.attributes[manyToManyRelationship.referencingAttribute]
                            ? relatedEntityMetadata.attributes[manyToManyRelationship.referencingAttribute].displayName
                            : manyToManyRelationship.referencingAttribute);
                        logicalName = [
                            QueryBuilder.Constants.LinkedEntityRelationshipType[QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany],
                            manyToManyRelationship.referencingEntity,
                            manyToManyRelationship.referencingAttribute,
                            entityLogicalName,
                            manyToManyRelationship.referencedAttribute,
                            manyToManyRelationship.intersectEntity,
                            manyToManyRelationship.intersectPrimaryAttribute,
                            manyToManyRelationship.intersectRelatedAttribute,
                        ].join();
                        relatedEntitiesSelectOptions.push(QueryBuilder.Utils.getSectionElement(displayName, logicalName));
                    }
                }
                QueryBuilder.Utils.sortSelectOptions(relatedEntitiesSelectOptions);
                return relatedEntitiesSelectOptions;
            };
            return AttributeMetadataProvider;
        }());
        QueryBuilder.AttributeMetadataProvider = AttributeMetadataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var MetadataStore = (function () {
            function MetadataStore() {
                this._entityMetadataMap = new QueryBuilder.Dictionary();
                this._entityViewMetadataMap = {};
                this._entityMetadataAndAttributesMap = {};
                this._relationshipMap = {};
                this._provisionedLanguageList = [];
            }
            Object.defineProperty(MetadataStore, "Instance", {
                get: function () {
                    if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(this._instance)) {
                        this._instance = new MetadataStore();
                    }
                    return this._instance;
                },
                enumerable: true,
                configurable: true
            });
            MetadataStore.prototype.addEntityMetadata = function (entityLogicalname, entityMetadata) {
                this._entityMetadataMap.put(entityLogicalname, QueryBuilder.Utils.deepFreeze(entityMetadata));
            };
            MetadataStore.prototype.getEntityMetadata = function (entityLogicalname) {
                return this._entityMetadataMap.get(entityLogicalname);
            };
            MetadataStore.prototype.containsEntityMetadata = function (entityLogicalname) {
                return !MscrmCommon.ControlUtils.Object.isNullOrUndefined(this._entityMetadataMap.get(entityLogicalname));
            };
            MetadataStore.prototype.addEntityViewMetadata = function (entityLogicalname, entityViewMetadata) {
                this._entityViewMetadataMap[entityLogicalname] = QueryBuilder.Utils.deepFreeze(entityViewMetadata);
            };
            MetadataStore.prototype.getEntityViewMetadata = function (entityLogicalname) {
                return this._entityViewMetadataMap[entityLogicalname];
            };
            MetadataStore.prototype.containsEntityViewMetadata = function (entityLogicalname) {
                return !MscrmCommon.ControlUtils.Object.isNullOrUndefined(this._entityViewMetadataMap[entityLogicalname]);
            };
            MetadataStore.prototype.addEntityAndAttributesMetadata = function (entityLogicalname, entityMetadataAndAttributes) {
                this._entityMetadataAndAttributesMap[entityLogicalname] = (QueryBuilder.Utils.deepFreeze(entityMetadataAndAttributes));
                this.populateRelationshipTypes(entityMetadataAndAttributes);
            };
            MetadataStore.prototype.getEntityAndAttributesMetadataByName = function (entityLogicalname) {
                return this._entityMetadataAndAttributesMap[entityLogicalname];
            };
            MetadataStore.prototype.getAttributeMetadataByName = function (entityLogicalname, attributeLogicalName) {
                return this._entityMetadataAndAttributesMap[entityLogicalname].attributes[attributeLogicalName];
            };
            MetadataStore.prototype.containsEntityAndAttributesMetadata = function (entityLogicalname) {
                return !MscrmCommon.ControlUtils.Object.isNullOrUndefined(this._entityMetadataAndAttributesMap[entityLogicalname]);
            };
            MetadataStore.prototype.addRelationshipData = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, relationshipType, hasReadPrivilege) {
                var key = QueryBuilder.Utils.getRelationshipTypeMapKey(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName);
                this._relationshipMap[key] = {
                    relationshipType: relationshipType,
                    hasReadPrivilege: hasReadPrivilege,
                };
            };
            MetadataStore.prototype.getRelationshipData = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) {
                var key = QueryBuilder.Utils.getRelationshipTypeMapKey(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName);
                return this._relationshipMap[key];
            };
            MetadataStore.prototype.populateRelationshipTypes = function (entityAndAttributeMetadata) {
                for (var _i = 0, _a = entityAndAttributeMetadata.oneToManyRelationships; _i < _a.length; _i++) {
                    var oneToManyRelationship = _a[_i];
                    this.addRelationshipData(oneToManyRelationship.referencingEntity, oneToManyRelationship.referencingAttribute, entityAndAttributeMetadata.logicalName, oneToManyRelationship.referencedAttribute, QueryBuilder.Constants.LinkedEntityRelationshipType.OneToMany, oneToManyRelationship.hasReadPrivilege);
                }
                for (var _b = 0, _c = entityAndAttributeMetadata.manyToOneRelationships; _b < _c.length; _b++) {
                    var manyToOneRelationship = _c[_b];
                    this.addRelationshipData(manyToOneRelationship.referencedEntity, manyToOneRelationship.referencedAttribute, entityAndAttributeMetadata.logicalName, manyToOneRelationship.referencingAttribute, QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToOne, manyToOneRelationship.hasReadPrivilege);
                }
                for (var _d = 0, _e = entityAndAttributeMetadata.manyToManyRelationships; _d < _e.length; _d++) {
                    var manyToManyRelationship = _e[_d];
                    this.addRelationshipData(manyToManyRelationship.intersectEntity, manyToManyRelationship.intersectPrimaryAttribute, entityAndAttributeMetadata.logicalName, manyToManyRelationship.fromEntityAttribute, QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany, manyToManyRelationship.hasReadPrivilege);
                    this.addRelationshipData(manyToManyRelationship.referencingEntity, manyToManyRelationship.toEntityAttribute, manyToManyRelationship.intersectEntity, manyToManyRelationship.intersectRelatedAttribute, QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany, manyToManyRelationship.hasReadPrivilege);
                }
            };
            MetadataStore.prototype.addProvisionedLanguageList = function (languageList) {
                (_a = this._provisionedLanguageList).push.apply(_a, languageList);
                Object.freeze(this._provisionedLanguageList);
                var _a;
            };
            MetadataStore.prototype.getProvisionedLanguageList = function () {
                return this._provisionedLanguageList;
            };
            MetadataStore.prototype.containsProvisionedLanguageList = function () {
                return this._provisionedLanguageList.length > 0 ? true : false;
            };
            return MetadataStore;
        }());
        QueryBuilder.MetadataStore = MetadataStore;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var EntityMetadataProvider = (function () {
            function EntityMetadataProvider() {
            }
            EntityMetadataProvider.prototype.getEntitiesMetadata = function (entityList, columns, additionalFilterClause, context) {
                var self = this;
                var entityMetadataMap = new QueryBuilder.Dictionary();
                var uncachedEntityList = entityList.filter(function (entity) { return !QueryBuilder.MetadataStore.Instance.containsEntityMetadata(entity); });
                return new Promise(function (resolve, reject) {
                    if (uncachedEntityList.length == 0) {
                        for (var _i = 0, entityList_3 = entityList; _i < entityList_3.length; _i++) {
                            var entity = entityList_3[_i];
                            entityMetadataMap.put(entity, QueryBuilder.MetadataStore.Instance.getEntityMetadata(entity));
                        }
                        resolve(entityMetadataMap);
                    }
                    else {
                        new QueryBuilder.ODataHelper(context).retrieveEntitiesMetadata(uncachedEntityList, columns, additionalFilterClause).then(function (response) {
                            for (var _i = 0, _a = response.value; _i < _a.length; _i++) {
                                var entity = _a[_i];
                                var entityMetadata = self.parseEntityMetadataResponse(entity);
                                QueryBuilder.MetadataStore.Instance.addEntityMetadata(entityMetadata.logicalName, entityMetadata);
                            }
                            for (var _b = 0, entityList_4 = entityList; _b < entityList_4.length; _b++) {
                                var entity = entityList_4[_b];
                                entityMetadataMap.put(entity, QueryBuilder.MetadataStore.Instance.getEntityMetadata(entity));
                            }
                            resolve(entityMetadataMap);
                        }, function (error) {
                            reject(error);
                        });
                    }
                });
            };
            EntityMetadataProvider.prototype.getEntityDisplayName = function (entityLogicalName, context) {
                var _this = this;
                return new Promise(function (resolve, reject) {
                    _this.getEntitiesMetadata([entityLogicalName], QueryBuilder.AdvancedFindConstants.ENTITY_METADATA_ATTRIBUTES, "", context).then(function (entityMetadataMap) {
                        resolve(entityMetadataMap.get(entityLogicalName).displayName);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            EntityMetadataProvider.prototype.getEntitiesDisplayCollectionNames = function (entityList, context) {
                var _this = this;
                var displayCollectionNamesMap = new QueryBuilder.Dictionary();
                return new Promise(function (resolve, reject) {
                    _this.getEntitiesMetadata(entityList, QueryBuilder.AdvancedFindConstants.ENTITY_METADATA_ATTRIBUTES, "", context).then(function (entityMetadataMap) {
                        for (var _i = 0, entityList_5 = entityList; _i < entityList_5.length; _i++) {
                            var entity = entityList_5[_i];
                            displayCollectionNamesMap.put(entity, entityMetadataMap.get(entity).displayCollectionName);
                        }
                        resolve(displayCollectionNamesMap);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            EntityMetadataProvider.prototype.parseEntityMetadataResponse = function (metadataResponse) {
                var entityMetadata = new QueryBuilder.EntityMetadata();
                entityMetadata.logicalName = metadataResponse.LogicalName;
                entityMetadata.displayName = MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataResponse.DisplayName.UserLocalizedLabel)
                    ? ""
                    : metadataResponse.DisplayName.UserLocalizedLabel.Label;
                entityMetadata.logicalCollectionName = metadataResponse.LogicalCollectionName;
                entityMetadata.primaryIdAttribute = metadataResponse.PrimaryIdAttribute;
                entityMetadata.primaryNameAttribute = metadataResponse.PrimaryNameAttribute;
                entityMetadata.displayCollectionName = MscrmCommon.ControlUtils.Object.isNullOrUndefined(metadataResponse.DisplayCollectionName.UserLocalizedLabel)
                    ? ""
                    : metadataResponse.DisplayCollectionName.UserLocalizedLabel.Label;
                return entityMetadata;
            };
            EntityMetadataProvider.prototype.getTypeAheadSelectData = function (columns, additionalFilterClause, context) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    new QueryBuilder.ODataHelper(context).retrieveEntitiesMetadata([], columns, additionalFilterClause).then(function (response) {
                        var entityDataProviderResult = self.populateEntityListForTypeAheadSelect(response);
                        resolve(entityDataProviderResult);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            EntityMetadataProvider.prototype.populateEntityListForTypeAheadSelect = function (entityListResponse) {
                var entityLogicalName, entityDisplayName;
                var sectionElements = new Array();
                for (var _i = 0, _a = entityListResponse.value; _i < _a.length; _i++) {
                    var entity = _a[_i];
                    entityLogicalName = entity.LogicalName;
                    entityDisplayName = entity.DisplayName.UserLocalizedLabel.Label;
                    sectionElements.push(QueryBuilder.Utils.getSectionElement(entityDisplayName, entityLogicalName));
                }
                QueryBuilder.Utils.sortSelectOptions(sectionElements);
                var section = {
                    sectionName: "",
                    sectionElements: sectionElements,
                };
                var sections = [];
                sections.push(section);
                return {
                    isSectioningEnabled: false,
                    sections: sections,
                };
            };
            return EntityMetadataProvider;
        }());
        QueryBuilder.EntityMetadataProvider = EntityMetadataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var Storage = (function () {
            function Storage() {
            }
            return Storage;
        }());
        QueryBuilder.Storage = Storage;
        var ConditionOperator = (function () {
            function ConditionOperator() {
            }
            Object.defineProperty(ConditionOperator, "eq", {
                get: function () {
                    return "eq";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "neq", {
                get: function () {
                    return "neq";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "ne", {
                get: function () {
                    return "ne";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "gt", {
                get: function () {
                    return "gt";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "lt", {
                get: function () {
                    return "lt";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "ge", {
                get: function () {
                    return "ge";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "le", {
                get: function () {
                    return "le";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "like", {
                get: function () {
                    return "like";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_like", {
                get: function () {
                    return "not-like";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in", {
                get: function () {
                    return "in";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_in", {
                get: function () {
                    return "not-in";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "between", {
                get: function () {
                    return "between";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_between", {
                get: function () {
                    return "not-between";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "null", {
                get: function () {
                    return "null";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_null", {
                get: function () {
                    return "not-null";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "yesterday", {
                get: function () {
                    return "yesterday";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "today", {
                get: function () {
                    return "today";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "tomorrow", {
                get: function () {
                    return "tomorrow";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_seven_days", {
                get: function () {
                    return "last-seven-days";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_seven_days", {
                get: function () {
                    return "next-seven-days";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_week", {
                get: function () {
                    return "last-week";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "this_week", {
                get: function () {
                    return "this-week";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_week", {
                get: function () {
                    return "next-week";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_month", {
                get: function () {
                    return "last-month";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "this_month", {
                get: function () {
                    return "this-month";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_month", {
                get: function () {
                    return "next-month";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "on", {
                get: function () {
                    return "on";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "on_or_before", {
                get: function () {
                    return "on-or-before";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "on_or_after", {
                get: function () {
                    return "on-or-after";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_year", {
                get: function () {
                    return "last-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "this_year", {
                get: function () {
                    return "this-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_year", {
                get: function () {
                    return "next-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_hours", {
                get: function () {
                    return "last-x-hours";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_hours", {
                get: function () {
                    return "next-x-hours";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_days", {
                get: function () {
                    return "last-x-days";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_days", {
                get: function () {
                    return "next-x-days";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_weeks", {
                get: function () {
                    return "last-x-weeks";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_weeks", {
                get: function () {
                    return "next-x-weeks";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_months", {
                get: function () {
                    return "last-x-months";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_months", {
                get: function () {
                    return "next-x-months";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_years", {
                get: function () {
                    return "last-x-years";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_years", {
                get: function () {
                    return "next-x-years";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_months", {
                get: function () {
                    return "olderthan-x-months";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_years", {
                get: function () {
                    return "olderthan-x-years";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_weeks", {
                get: function () {
                    return "olderthan-x-weeks";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_days", {
                get: function () {
                    return "olderthan-x-days";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_hours", {
                get: function () {
                    return "olderthan-x-hours";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "olderthan_x_minutes", {
                get: function () {
                    return "olderthan-x-minutes";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_userid", {
                get: function () {
                    return "eq-userid";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "ne_userid", {
                get: function () {
                    return "ne-userid";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_userteams", {
                get: function () {
                    return "eq-userteams";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_useroruserteams", {
                get: function () {
                    return "eq-useroruserteams";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_useroruserhierarchy", {
                get: function () {
                    return "eq-useroruserhierarchy";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_useroruserhierarchyandteams", {
                get: function () {
                    return "eq-useroruserhierarchyandteams";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_businessid", {
                get: function () {
                    return "eq-businessid";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "ne_businessid", {
                get: function () {
                    return "ne-businessid";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_userlanguage", {
                get: function () {
                    return "eq-userlanguage";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "this_fiscal_year", {
                get: function () {
                    return "this-fiscal-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "this_fiscal_period", {
                get: function () {
                    return "this-fiscal-period";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_fiscal_year", {
                get: function () {
                    return "next-fiscal-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_fiscal_period", {
                get: function () {
                    return "next-fiscal-period";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_fiscal_year", {
                get: function () {
                    return "last-fiscal-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_fiscal_period", {
                get: function () {
                    return "last-fiscal-period";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_fiscal_years", {
                get: function () {
                    return "last-x-fiscal-years";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "last_x_fiscal_periods", {
                get: function () {
                    return "last-x-fiscal-periods";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_fiscal_years", {
                get: function () {
                    return "next-x-fiscal-years";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "next_x_fiscal_periods", {
                get: function () {
                    return "next-x-fiscal-periods";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in_fiscal_year", {
                get: function () {
                    return "in-fiscal-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in_fiscal_period", {
                get: function () {
                    return "in-fiscal-period";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in_fiscal_period_and_year", {
                get: function () {
                    return "in-fiscal-period-and-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in_or_before_fiscal_period_and_year", {
                get: function () {
                    return "in-or-before-fiscal-period-and-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "in_or_after_fiscal_period_and_year", {
                get: function () {
                    return "in-or-after-fiscal-period-and-year";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "begins_with", {
                get: function () {
                    return "begins-with";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_begin_with", {
                get: function () {
                    return "not-begin-with";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "ends_with", {
                get: function () {
                    return "ends-with";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_end_with", {
                get: function () {
                    return "not-end-with";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "under", {
                get: function () {
                    return "under";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_or_under", {
                get: function () {
                    return "eq-or-under";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_under", {
                get: function () {
                    return "not-under";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "above", {
                get: function () {
                    return "above";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "eq_or_above", {
                get: function () {
                    return "eq-or-above";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "any_time", {
                get: function () {
                    return "any-time";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "contain_values", {
                get: function () {
                    return "contain-values";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ConditionOperator, "not_contain_values", {
                get: function () {
                    return "not-contain-values";
                },
                enumerable: true,
                configurable: true
            });
            return ConditionOperator;
        }());
        QueryBuilder.ConditionOperator = ConditionOperator;
        var DisplayNameOperatorMapping = (function () {
            function DisplayNameOperatorMapping() {
            }
            DisplayNameOperatorMapping.getDisplayName = function (context, operator) {
                var localizationPrefix = "QueryBuilder.ConditionOperator.";
                var displayName = "";
                switch (operator) {
                    case ConditionOperator.eq:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq");
                        break;
                    case ConditionOperator.neq:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "neq");
                        break;
                    case ConditionOperator.ne:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "ne");
                        break;
                    case ConditionOperator.gt:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "gt");
                        break;
                    case ConditionOperator.lt:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "lt");
                        break;
                    case ConditionOperator.ge:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "ge");
                        break;
                    case ConditionOperator.le:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "le");
                        break;
                    case ConditionOperator.like:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "like");
                        break;
                    case ConditionOperator.not_like:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_like");
                        break;
                    case ConditionOperator.in:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in$");
                        break;
                    case ConditionOperator.not_in:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_in");
                        break;
                    case ConditionOperator.between:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "between");
                        break;
                    case ConditionOperator.not_between:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_between");
                        break;
                    case ConditionOperator.null:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "null$");
                        break;
                    case ConditionOperator.not_null:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_null");
                        break;
                    case ConditionOperator.yesterday:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "yesterday");
                        break;
                    case ConditionOperator.today:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "today");
                        break;
                    case ConditionOperator.tomorrow:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "tomorrow");
                        break;
                    case ConditionOperator.last_seven_days:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_seven_days");
                        break;
                    case ConditionOperator.next_seven_days:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_seven_days");
                        break;
                    case ConditionOperator.last_week:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_week");
                        break;
                    case ConditionOperator.this_week:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "this_week");
                        break;
                    case ConditionOperator.next_week:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_week");
                        break;
                    case ConditionOperator.last_month:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_month");
                        break;
                    case ConditionOperator.this_month:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "this_month");
                        break;
                    case ConditionOperator.next_month:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_month");
                        break;
                    case ConditionOperator.on:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "on");
                        break;
                    case ConditionOperator.on_or_before:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "on_or_before");
                        break;
                    case ConditionOperator.on_or_after:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "on_or_after");
                        break;
                    case ConditionOperator.last_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_year");
                        break;
                    case ConditionOperator.this_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "this_year");
                        break;
                    case ConditionOperator.next_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_year");
                        break;
                    case ConditionOperator.last_x_hours:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_hours");
                        break;
                    case ConditionOperator.next_x_hours:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_hours");
                        break;
                    case ConditionOperator.last_x_days:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_days");
                        break;
                    case ConditionOperator.next_x_days:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_days");
                        break;
                    case ConditionOperator.last_x_weeks:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_weeks");
                        break;
                    case ConditionOperator.next_x_weeks:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_weeks");
                        break;
                    case ConditionOperator.last_x_months:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_months");
                        break;
                    case ConditionOperator.next_x_months:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_months");
                        break;
                    case ConditionOperator.last_x_years:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_years");
                        break;
                    case ConditionOperator.next_x_years:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_years");
                        break;
                    case ConditionOperator.olderthan_x_months:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_months");
                        break;
                    case ConditionOperator.olderthan_x_years:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_years");
                        break;
                    case ConditionOperator.olderthan_x_weeks:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_weeks");
                        break;
                    case ConditionOperator.olderthan_x_days:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_days");
                        break;
                    case ConditionOperator.olderthan_x_hours:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_hours");
                        break;
                    case ConditionOperator.olderthan_x_minutes:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "olderthan_x_minutes");
                        break;
                    case ConditionOperator.eq_userid:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_userid");
                        break;
                    case ConditionOperator.ne_userid:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "ne_userid");
                        break;
                    case ConditionOperator.eq_userteams:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_userteams");
                        break;
                    case ConditionOperator.eq_useroruserteams:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_useroruserteams");
                        break;
                    case ConditionOperator.eq_useroruserhierarchy:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_useroruserhierarchy");
                        break;
                    case ConditionOperator.eq_useroruserhierarchyandteams:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_useroruserhierarchyandteams");
                        break;
                    case ConditionOperator.eq_businessid:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_businessid");
                        break;
                    case ConditionOperator.ne_businessid:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "ne_businessid");
                        break;
                    case ConditionOperator.eq_userlanguage:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_userlanguage");
                        break;
                    case ConditionOperator.this_fiscal_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "this_fiscal_year");
                        break;
                    case ConditionOperator.this_fiscal_period:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "this_fiscal_period");
                        break;
                    case ConditionOperator.next_fiscal_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_fiscal_year");
                        break;
                    case ConditionOperator.next_fiscal_period:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_fiscal_period");
                        break;
                    case ConditionOperator.last_fiscal_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_fiscal_year");
                        break;
                    case ConditionOperator.last_fiscal_period:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_fiscal_period");
                        break;
                    case ConditionOperator.last_x_fiscal_years:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_fiscal_years");
                        break;
                    case ConditionOperator.last_x_fiscal_periods:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "last_x_fiscal_periods");
                        break;
                    case ConditionOperator.next_x_fiscal_years:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_fiscal_years");
                        break;
                    case ConditionOperator.next_x_fiscal_periods:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "next_x_fiscal_periods");
                        break;
                    case ConditionOperator.in_fiscal_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in_fiscal_year");
                        break;
                    case ConditionOperator.in_fiscal_period:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in_fiscal_period");
                        break;
                    case ConditionOperator.in_fiscal_period_and_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in_fiscal_period_and_year");
                        break;
                    case ConditionOperator.in_or_before_fiscal_period_and_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in_or_before_fiscal_period_and_year");
                        break;
                    case ConditionOperator.in_or_after_fiscal_period_and_year:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "in_or_after_fiscal_period_and_year");
                        break;
                    case ConditionOperator.begins_with:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "begins_with");
                        break;
                    case ConditionOperator.not_begin_with:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_begin_with");
                        break;
                    case ConditionOperator.ends_with:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "ends_with");
                        break;
                    case ConditionOperator.not_end_with:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_end_with");
                        break;
                    case ConditionOperator.under:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "under");
                        break;
                    case ConditionOperator.eq_or_under:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_or_under");
                        break;
                    case ConditionOperator.not_under:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_under");
                        break;
                    case ConditionOperator.above:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "above");
                        break;
                    case ConditionOperator.eq_or_above:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "eq_or_above");
                        break;
                    case ConditionOperator.any_time:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "any_time");
                        break;
                    case ConditionOperator.contain_values:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "contain_values");
                        break;
                    case ConditionOperator.not_contain_values:
                        displayName = QueryBuilder.Utils.getResourceString(context, localizationPrefix + "not_contain_values");
                        break;
                }
                return displayName;
            };
            return DisplayNameOperatorMapping;
        }());
        QueryBuilder.DisplayNameOperatorMapping = DisplayNameOperatorMapping;
        var DateTimeOperatorMapping = (function () {
            function DateTimeOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.on);
                this.operatorList.push(ConditionOperator.on_or_after);
                this.operatorList.push(ConditionOperator.on_or_before);
                this.operatorList.push(ConditionOperator.yesterday);
                this.operatorList.push(ConditionOperator.today);
                this.operatorList.push(ConditionOperator.tomorrow);
                this.operatorList.push(ConditionOperator.next_seven_days);
                this.operatorList.push(ConditionOperator.last_seven_days);
                this.operatorList.push(ConditionOperator.next_week);
                this.operatorList.push(ConditionOperator.last_week);
                this.operatorList.push(ConditionOperator.this_week);
                this.operatorList.push(ConditionOperator.next_month);
                this.operatorList.push(ConditionOperator.last_month);
                this.operatorList.push(ConditionOperator.this_month);
                this.operatorList.push(ConditionOperator.next_year);
                this.operatorList.push(ConditionOperator.last_year);
                this.operatorList.push(ConditionOperator.this_year);
                this.operatorList.push(ConditionOperator.last_x_hours);
                this.operatorList.push(ConditionOperator.next_x_hours);
                this.operatorList.push(ConditionOperator.last_x_days);
                this.operatorList.push(ConditionOperator.next_x_days);
                this.operatorList.push(ConditionOperator.last_x_weeks);
                this.operatorList.push(ConditionOperator.next_x_weeks);
                this.operatorList.push(ConditionOperator.last_x_months);
                this.operatorList.push(ConditionOperator.next_x_months);
                this.operatorList.push(ConditionOperator.last_x_years);
                this.operatorList.push(ConditionOperator.next_x_years);
                this.operatorList.push(ConditionOperator.olderthan_x_minutes);
                this.operatorList.push(ConditionOperator.olderthan_x_hours);
                this.operatorList.push(ConditionOperator.olderthan_x_days);
                this.operatorList.push(ConditionOperator.olderthan_x_weeks);
                this.operatorList.push(ConditionOperator.olderthan_x_months);
                this.operatorList.push(ConditionOperator.olderthan_x_years);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.in_fiscal_year);
                this.operatorList.push(ConditionOperator.in_fiscal_period);
                this.operatorList.push(ConditionOperator.in_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.in_or_before_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.in_or_after_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.last_fiscal_year);
                this.operatorList.push(ConditionOperator.this_fiscal_year);
                this.operatorList.push(ConditionOperator.next_fiscal_year);
                this.operatorList.push(ConditionOperator.last_x_fiscal_years);
                this.operatorList.push(ConditionOperator.next_x_fiscal_years);
                this.operatorList.push(ConditionOperator.last_fiscal_period);
                this.operatorList.push(ConditionOperator.this_fiscal_period);
                this.operatorList.push(ConditionOperator.next_fiscal_period);
                this.operatorList.push(ConditionOperator.last_x_fiscal_periods);
                this.operatorList.push(ConditionOperator.next_x_fiscal_periods);
                this.operatorList.push(ConditionOperator.any_time);
            }
            Object.defineProperty(DateTimeOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new DateTimeOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DateTimeOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return DateTimeOperatorMapping;
        }());
        QueryBuilder.DateTimeOperatorMapping = DateTimeOperatorMapping;
        var MultiSelectOperatorMapping = (function () {
            function MultiSelectOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
                this.operatorList.push(ConditionOperator.contain_values);
                this.operatorList.push(ConditionOperator.not_contain_values);
            }
            Object.defineProperty(MultiSelectOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new MultiSelectOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MultiSelectOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return MultiSelectOperatorMapping;
        }());
        QueryBuilder.MultiSelectOperatorMapping = MultiSelectOperatorMapping;
        var StatusOperatorMapping = (function () {
            function StatusOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.ne);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.like);
                this.operatorList.push(ConditionOperator.not_like);
                this.operatorList.push(ConditionOperator.begins_with);
                this.operatorList.push(ConditionOperator.not_begin_with);
                this.operatorList.push(ConditionOperator.ends_with);
                this.operatorList.push(ConditionOperator.not_end_with);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
            }
            Object.defineProperty(StatusOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new StatusOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(StatusOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return StatusOperatorMapping;
        }());
        QueryBuilder.StatusOperatorMapping = StatusOperatorMapping;
        var DoubleOperatorMapping = (function () {
            function DoubleOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.gt);
                this.operatorList.push(ConditionOperator.ge);
                this.operatorList.push(ConditionOperator.lt);
                this.operatorList.push(ConditionOperator.le);
            }
            Object.defineProperty(DoubleOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new DoubleOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DoubleOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return DoubleOperatorMapping;
        }());
        QueryBuilder.DoubleOperatorMapping = DoubleOperatorMapping;
        var LanguageOperatorMapping = (function () {
            function LanguageOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
                this.operatorList.push(ConditionOperator.eq_userlanguage);
            }
            Object.defineProperty(LanguageOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new LanguageOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(LanguageOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return LanguageOperatorMapping;
        }());
        QueryBuilder.LanguageOperatorMapping = LanguageOperatorMapping;
        var OwnerOperatorMapping = (function () {
            function OwnerOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq_userid);
                this.operatorList.push(ConditionOperator.ne_userid);
                this.operatorList.push(ConditionOperator.eq_userteams);
                this.operatorList.push(ConditionOperator.eq_useroruserteams);
                this.operatorList.push(ConditionOperator.eq_useroruserhierarchy);
                this.operatorList.push(ConditionOperator.eq_useroruserhierarchyandteams);
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.like);
                this.operatorList.push(ConditionOperator.not_like);
                this.operatorList.push(ConditionOperator.begins_with);
                this.operatorList.push(ConditionOperator.not_begin_with);
                this.operatorList.push(ConditionOperator.ends_with);
                this.operatorList.push(ConditionOperator.not_end_with);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
            }
            Object.defineProperty(OwnerOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new OwnerOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OwnerOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return OwnerOperatorMapping;
        }());
        QueryBuilder.OwnerOperatorMapping = OwnerOperatorMapping;
        var MemoOperatorMapping = (function () {
            function MemoOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.like);
                this.operatorList.push(ConditionOperator.not_like);
                this.operatorList.push(ConditionOperator.begins_with);
                this.operatorList.push(ConditionOperator.not_begin_with);
                this.operatorList.push(ConditionOperator.ends_with);
                this.operatorList.push(ConditionOperator.not_end_with);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
            }
            Object.defineProperty(MemoOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new MemoOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MemoOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return MemoOperatorMapping;
        }());
        QueryBuilder.MemoOperatorMapping = MemoOperatorMapping;
        var UniqueIdentiferOperatorMapping = (function () {
            function UniqueIdentiferOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
            }
            Object.defineProperty(UniqueIdentiferOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new UniqueIdentiferOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(UniqueIdentiferOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return UniqueIdentiferOperatorMapping;
        }());
        QueryBuilder.UniqueIdentiferOperatorMapping = UniqueIdentiferOperatorMapping;
        var StringOperatorMapping = (function () {
            function StringOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.like);
                this.operatorList.push(ConditionOperator.not_like);
                this.operatorList.push(ConditionOperator.begins_with);
                this.operatorList.push(ConditionOperator.not_begin_with);
                this.operatorList.push(ConditionOperator.ends_with);
                this.operatorList.push(ConditionOperator.not_end_with);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
            }
            Object.defineProperty(StringOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new StringOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(StringOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return StringOperatorMapping;
        }());
        QueryBuilder.StringOperatorMapping = StringOperatorMapping;
        var DefaultOperatorMapping = (function () {
            function DefaultOperatorMapping() {
                this.operatorList = [];
                this.operatorList.push(ConditionOperator.eq);
                this.operatorList.push(ConditionOperator.neq);
                this.operatorList.push(ConditionOperator.gt);
                this.operatorList.push(ConditionOperator.ge);
                this.operatorList.push(ConditionOperator.lt);
                this.operatorList.push(ConditionOperator.le);
                this.operatorList.push(ConditionOperator.on);
                this.operatorList.push(ConditionOperator.on_or_after);
                this.operatorList.push(ConditionOperator.on_or_before);
                this.operatorList.push(ConditionOperator.yesterday);
                this.operatorList.push(ConditionOperator.today);
                this.operatorList.push(ConditionOperator.tomorrow);
                this.operatorList.push(ConditionOperator.next_seven_days);
                this.operatorList.push(ConditionOperator.last_seven_days);
                this.operatorList.push(ConditionOperator.next_week);
                this.operatorList.push(ConditionOperator.last_week);
                this.operatorList.push(ConditionOperator.this_week);
                this.operatorList.push(ConditionOperator.next_month);
                this.operatorList.push(ConditionOperator.last_month);
                this.operatorList.push(ConditionOperator.this_month);
                this.operatorList.push(ConditionOperator.next_year);
                this.operatorList.push(ConditionOperator.last_year);
                this.operatorList.push(ConditionOperator.this_year);
                this.operatorList.push(ConditionOperator.last_x_hours);
                this.operatorList.push(ConditionOperator.next_x_hours);
                this.operatorList.push(ConditionOperator.last_x_days);
                this.operatorList.push(ConditionOperator.next_x_days);
                this.operatorList.push(ConditionOperator.last_x_weeks);
                this.operatorList.push(ConditionOperator.next_x_weeks);
                this.operatorList.push(ConditionOperator.last_x_months);
                this.operatorList.push(ConditionOperator.next_x_months);
                this.operatorList.push(ConditionOperator.last_x_years);
                this.operatorList.push(ConditionOperator.next_x_years);
                this.operatorList.push(ConditionOperator.olderthan_x_minutes);
                this.operatorList.push(ConditionOperator.olderthan_x_hours);
                this.operatorList.push(ConditionOperator.olderthan_x_days);
                this.operatorList.push(ConditionOperator.olderthan_x_weeks);
                this.operatorList.push(ConditionOperator.olderthan_x_months);
                this.operatorList.push(ConditionOperator.olderthan_x_years);
                this.operatorList.push(ConditionOperator.null);
                this.operatorList.push(ConditionOperator.not_null);
                this.operatorList.push(ConditionOperator.in);
                this.operatorList.push(ConditionOperator.not_in);
                this.operatorList.push(ConditionOperator.in_fiscal_year);
                this.operatorList.push(ConditionOperator.in_fiscal_period);
                this.operatorList.push(ConditionOperator.in_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.in_or_before_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.in_or_after_fiscal_period_and_year);
                this.operatorList.push(ConditionOperator.last_fiscal_year);
                this.operatorList.push(ConditionOperator.this_fiscal_year);
                this.operatorList.push(ConditionOperator.next_fiscal_year);
                this.operatorList.push(ConditionOperator.last_x_fiscal_years);
                this.operatorList.push(ConditionOperator.next_x_fiscal_years);
                this.operatorList.push(ConditionOperator.last_fiscal_period);
                this.operatorList.push(ConditionOperator.this_fiscal_period);
                this.operatorList.push(ConditionOperator.next_fiscal_period);
                this.operatorList.push(ConditionOperator.last_x_fiscal_periods);
                this.operatorList.push(ConditionOperator.next_x_fiscal_periods);
                this.operatorList.push(ConditionOperator.like);
                this.operatorList.push(ConditionOperator.not_like);
                this.operatorList.push(ConditionOperator.begins_with);
                this.operatorList.push(ConditionOperator.not_begin_with);
                this.operatorList.push(ConditionOperator.ends_with);
                this.operatorList.push(ConditionOperator.not_end_with);
                this.operatorList.push(ConditionOperator.under);
                this.operatorList.push(ConditionOperator.eq_or_under);
                this.operatorList.push(ConditionOperator.not_under);
                this.operatorList.push(ConditionOperator.above);
                this.operatorList.push(ConditionOperator.eq_or_above);
                this.operatorList.push(ConditionOperator.any_time);
            }
            Object.defineProperty(DefaultOperatorMapping, "Instance", {
                get: function () {
                    if (this.instance == null) {
                        this.instance = new DefaultOperatorMapping();
                    }
                    return this.instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DefaultOperatorMapping.prototype, "ConditionOperatorList", {
                get: function () {
                    return this.operatorList;
                },
                enumerable: true,
                configurable: true
            });
            return DefaultOperatorMapping;
        }());
        QueryBuilder.DefaultOperatorMapping = DefaultOperatorMapping;
        var OperatorMetadataProvider = (function () {
            function OperatorMetadataProvider() {
            }
            OperatorMetadataProvider.GetOperatorMapping = function (attributeType, attributeFormatType) {
                switch (attributeType) {
                    case QueryBuilder.EntityAttributeType.DateTime:
                        return DateTimeOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.MultiSelectOptionSet:
                        return MultiSelectOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.State:
                    case QueryBuilder.EntityAttributeType.Status:
                    case QueryBuilder.EntityAttributeType.LookUp:
                    case QueryBuilder.EntityAttributeType.OptionSet:
                    case QueryBuilder.EntityAttributeType.EntityNameType:
                    case QueryBuilder.EntityAttributeType.TwoOptions:
                    case QueryBuilder.EntityAttributeType.CustomerType:
                        return StatusOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.WholeNumber:
                        if (attributeFormatType == QueryBuilder.EntityAttributeTypeFormat.Language) {
                            return LanguageOperatorMapping.Instance.ConditionOperatorList;
                        }
                        else {
                            return DoubleOperatorMapping.Instance.ConditionOperatorList;
                        }
                    case QueryBuilder.EntityAttributeType.DecimalNumber:
                    case QueryBuilder.EntityAttributeType.FloatingPointNumber:
                    case QueryBuilder.EntityAttributeType.BigInt:
                    case QueryBuilder.EntityAttributeType.Currency:
                        return DoubleOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.OwnerType:
                        return OwnerOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.MultipleLineofText:
                        return MemoOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.UniqueIdentifier:
                        return UniqueIdentiferOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.SingleLineofText:
                        return StringOperatorMapping.Instance.ConditionOperatorList;
                    case QueryBuilder.EntityAttributeType.PartyListType:
                    case QueryBuilder.EntityAttributeType.CalendarRulesType:
                    case QueryBuilder.EntityAttributeType.VirtualType:
                    case QueryBuilder.EntityAttributeType.ManagedPropertyType:
                    case QueryBuilder.EntityAttributeType.Image:
                    default:
                        return DefaultOperatorMapping.Instance.ConditionOperatorList;
                }
            };
            OperatorMetadataProvider.prototype.getTypeAheadSelectData = function (context, attributeType, attributeFormatType) {
                return {
                    isSectioningEnabled: true,
                    sections: [
                        {
                            sectionName: "--" + QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.ATTR_DROPDOWN_OPERATORS_SECTION_NAME) + "--",
                            sectionElements: this.getSelectOptions(context, attributeType, attributeFormatType),
                        },
                    ],
                };
            };
            OperatorMetadataProvider.prototype.getSelectOptions = function (context, attributeType, attributeFormatType) {
                var operators = QueryBuilder.OperatorMetadataProvider.GetOperatorMapping(attributeType, attributeFormatType);
                var operatorSelectOptions = new Array();
                for (var i = 0; i < operators.length; i++) {
                    operatorSelectOptions.push({
                        Value: operators[i].toString(),
                        Label: QueryBuilder.DisplayNameOperatorMapping.getDisplayName(context, operators[i]),
                    });
                }
                return operatorSelectOptions;
            };
            return OperatorMetadataProvider;
        }());
        QueryBuilder.OperatorMetadataProvider = OperatorMetadataProvider;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindInputConverter = (function () {
            function AdvancedFindInputConverter() {
            }
            AdvancedFindInputConverter.prototype.convert = function (queryTree) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    queryTree.Root = queryTree.createLogicalGroupNode(QueryBuilder.Constants.QueryTreeNodeType.AND);
                    var inputFetchXML = queryTree.Context.parameters
                        ? queryTree.Context.parameters.Input
                            ? queryTree.Context.parameters.Input.raw
                            : undefined
                        : undefined;
                    if (inputFetchXML) {
                        var xmlParser = new DOMParser();
                        var fetchXMLDocument_1 = xmlParser.parseFromString(inputFetchXML, "text/xml");
                        var fetchElement = fetchXMLDocument_1.childNodes[0];
                        if (!(fetchElement.nodeName === "fetch"))
                            reject("Invalid FetchXML. <fetch /> not found.");
                        var entityElement = self.getNodeByName(fetchElement, "entity");
                        if (!entityElement)
                            reject("Invalid FetchXML. <entity /> not found.");
                        var entities = self._collateEntities(fetchXMLDocument_1);
                        new QueryBuilder.AdvancedFindInitialMetadataLoader()
                            .loadInitialEntitiesMetadata(queryTree.Context, entities.toList())
                            .then(function (initialMetadata) {
                            self._populateTree(queryTree, fetchXMLDocument_1, initialMetadata);
                            var data = self._collateLookupData(queryTree, initialMetadata);
                            if (data.count() > 0) {
                                new QueryBuilder.CrmDataProvider().getData(queryTree.Context, data).then(function (records) {
                                    self._populateLookupDataForTree(queryTree, records);
                                    resolve();
                                }, function (error) {
                                    reject(error);
                                });
                            }
                            else {
                                resolve();
                            }
                        }, function (error) {
                            reject(error);
                        });
                    }
                    else {
                        var primaryEntity = queryTree.Context.parameters.PrimaryEntity
                            ? queryTree.Context.parameters.PrimaryEntity.raw
                            : undefined;
                        queryTree.Properties["entityAttributes"] = { name: primaryEntity };
                        resolve();
                    }
                });
            };
            AdvancedFindInputConverter.prototype._hasSingleRoot = function (entityElement) {
                var rootCount = 0;
                for (var indx = 0; indx < entityElement.childNodes.length; indx++) {
                    var childElement = entityElement.childNodes[indx];
                    if (childElement.nodeName == QueryBuilder.AdvancedFindConstants.NODE_NAME_FILTER &&
                        !this.isDoesNotContainDataFilter(childElement)) {
                        rootCount++;
                        if (rootCount > 1)
                            return false;
                    }
                }
                return true;
            };
            AdvancedFindInputConverter.prototype._collateEntities = function (fetchXMLDocument) {
                var entities = new QueryBuilder.Set();
                this.addEntityNameToSet(this.getNodeByName(fetchXMLDocument.childNodes[0], "entity"), entities);
                return entities;
            };
            AdvancedFindInputConverter.prototype.addEntityNameToSet = function (entityElement, entities) {
                var entityName = this.getAttributeValue(entityElement, "name");
                if (entityName)
                    entities.put(entityName);
                var linkedEntityNodes = this.getAllChildNodesByName(entityElement, QueryBuilder.AdvancedFindConstants.NODE_NAME_LINK_ENTITY);
                for (var _i = 0, linkedEntityNodes_1 = linkedEntityNodes; _i < linkedEntityNodes_1.length; _i++) {
                    var linkedEntityNode = linkedEntityNodes_1[_i];
                    this.addEntityNameToSet(linkedEntityNode, entities);
                }
            };
            AdvancedFindInputConverter.prototype._populateTree = function (queryTree, fetchXMLDocument, initialMetadata) {
                var fetchElement = fetchXMLDocument.childNodes[0];
                queryTree.Properties[QueryBuilder.AdvancedFindConstants.FETCH_ATTRIBUTES] = QueryBuilder.AdvancedFindUtils.getAttributesOfElement(fetchElement);
                var entityElement = this.getNodeByName(fetchElement, "entity");
                this.addEntityElementToTree(queryTree, queryTree, entityElement, initialMetadata);
            };
            AdvancedFindInputConverter.prototype.addEntityElementToTree = function (queryTree, currentTree, entityElement, initialMetadata) {
                var isRootNodeAddedToEntityChildren = false;
                var hasSingleRoot = this._hasSingleRoot(entityElement);
                var toEntityLogicalName = this.getAttributeValue(entityElement, QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTE_NAME);
                currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES] = Object.assign({}, currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES], QueryBuilder.AdvancedFindUtils.getAttributesOfElement(entityElement));
                currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES] = [];
                for (var indx = 0; indx < entityElement.childNodes.length; indx++) {
                    var childElement = entityElement.childNodes[indx];
                    switch (childElement.nodeName) {
                        case QueryBuilder.AdvancedFindConstants.NODE_NAME_FILTER:
                            if (this.isDoesNotContainDataFilter(childElement)) {
                                var conditionEntityName = this.getAttributeValue(childElement.childNodes[0], QueryBuilder.AdvancedFindConstants.ENTITYNAME);
                                var associatedLinkedEntityID = this.findLinkedEntityIdByAliasInTree(conditionEntityName, queryTree);
                                var associatedLinkedEntity = queryTree.getNodeById(associatedLinkedEntityID);
                                associatedLinkedEntity.ContainsData = false;
                                break;
                            }
                            if (!hasSingleRoot) {
                                var filterType = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE);
                                switch (filterType) {
                                    case QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_AND:
                                        var filterANDNode = this.appendFilterNode(currentTree.Root, childElement, queryTree, QueryBuilder.Constants.QueryTreeNodeType.AND);
                                        this.addFilterToNode(childElement, filterANDNode, queryTree, entityElement, initialMetadata);
                                        break;
                                    case QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_OR:
                                        var filterORNode = this.appendFilterNode(currentTree.Root, childElement, queryTree, QueryBuilder.Constants.QueryTreeNodeType.OR);
                                        this.addFilterToNode(childElement, filterORNode, queryTree, entityElement, initialMetadata);
                                        break;
                                    default:
                                        throw new Error("Invalid FetchXML. Unknown Attribute: " + filterType);
                                }
                            }
                            else {
                                var filterType = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE);
                                if (filterType == QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_OR) {
                                    currentTree.Root.NodeType = QueryBuilder.Constants.QueryTreeNodeType.OR;
                                }
                                currentTree.Root.Properties = QueryBuilder.AdvancedFindUtils.getAttributesOfElement(childElement, QueryBuilder.AdvancedFindInputConverterConstants.FilterIgnoredAttributes);
                                this.addFilterToNode(childElement, currentTree.Root, queryTree, entityElement, initialMetadata);
                            }
                            if (!isRootNodeAddedToEntityChildren) {
                                currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES].push(QueryBuilder.AdvancedFindUtils.createEntityChild(currentTree.Root));
                                isRootNodeAddedToEntityChildren = true;
                            }
                            break;
                        case QueryBuilder.AdvancedFindConstants.NODE_NAME_LINK_ENTITY:
                            var intersect = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_INTERSECT);
                            var isIntersect = intersect && intersect === "true" ? true : false;
                            var fromEntityLogicalName = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTE_NAME);
                            var fromAttributeLogicalName = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_FROM);
                            var toAttributeLogicalName = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_TO);
                            var fromEntityDisplayName = initialMetadata.entityMetadataMap.get(fromEntityLogicalName)
                                .displayName;
                            var fromAttributeDisplayName = initialMetadata.entityMetadataAndAttributesMap[fromEntityLogicalName].getAttributeByLogicalName(fromAttributeLogicalName).displayName;
                            var toEntityDisplayName = initialMetadata.entityMetadataMap.get(toEntityLogicalName).displayName;
                            var toAttributeDisplayName = initialMetadata.entityMetadataAndAttributesMap[toEntityLogicalName].getAttributeByLogicalName(toAttributeLogicalName).displayName;
                            var visible = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_VISIBLE);
                            var isVisible = visible && visible === "false" ? false : true;
                            var linkType = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_LINK_TYPE);
                            var attributeMetadataProvider = new QueryBuilder.AttributeMetadataProvider();
                            if (attributeMetadataProvider.hasReadPrivilegeForRelationship(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) === false) {
                                throw new Error(QueryBuilder.Utils.getResourceString(queryTree.Context, QueryBuilder.LocalizedStrings.EntityReadAccessError));
                            }
                            var relationshipType = void 0;
                            var noDisplayName = false;
                            try {
                                relationshipType = attributeMetadataProvider.getRelationshipType(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName);
                            }
                            catch (ex) {
                                noDisplayName = true;
                            }
                            var linkedEntityData = {
                                RelationshipType: relationshipType,
                                FromEntityLogicalName: fromEntityLogicalName,
                                FromEntityDisplayName: fromEntityDisplayName,
                                FromAttributeLogicalName: fromAttributeLogicalName,
                                FromAttributeDisplayName: fromAttributeDisplayName,
                                ToEntityLogicalName: toEntityLogicalName,
                                ToEntityDisplayName: toEntityDisplayName,
                                ToAttributeLogicalName: toAttributeLogicalName,
                                ToAttributeDisplayName: toAttributeDisplayName,
                                IsVisible: isVisible,
                                LinkType: linkType ? linkType : QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER,
                                IsIntersect: isIntersect,
                                NoDisplayName: noDisplayName,
                            };
                            var linkedEntityTree = queryTree.createLinkedEntityNode(linkedEntityData);
                            currentTree.addLinkedEntity(linkedEntityTree);
                            linkedEntityTree.Root = queryTree.createLogicalGroupNode(QueryBuilder.Constants.QueryTreeNodeType.AND);
                            this.addEntityElementToTree(queryTree, linkedEntityTree, childElement, initialMetadata);
                            currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES].push(QueryBuilder.AdvancedFindUtils.createEntityChild(linkedEntityTree));
                            break;
                        default:
                            currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES].push(QueryBuilder.AdvancedFindUtils.createEntityChild(childElement));
                            break;
                    }
                }
            };
            AdvancedFindInputConverter.prototype.addFilterToNode = function (filterElement, parentNode, queryTree, entityElement, initialMetadata) {
                var conditionElements = filterElement.childNodes;
                for (var childIndex = 0; childIndex < conditionElements.length; childIndex++) {
                    var childElement = conditionElements[childIndex];
                    var childElementName = childElement.nodeName;
                    switch (childElementName) {
                        case QueryBuilder.AdvancedFindConstants.NODE_NAME_CONDITION:
                            var conditionNode = this.getConditionNode(childElement, queryTree, this.getAttributeValue(entityElement, "name"), initialMetadata);
                            parentNode.addChild(conditionNode);
                            conditionNode.Properties = QueryBuilder.AdvancedFindUtils.getAttributesOfElement(childElement, QueryBuilder.AdvancedFindInputConverterConstants.ConditionIgnoredAttributes);
                            break;
                        case QueryBuilder.AdvancedFindConstants.NODE_NAME_FILTER:
                            var filterType = this.getAttributeValue(childElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE);
                            switch (filterType) {
                                case QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_AND:
                                    var filterANDNode = this.appendFilterNode(parentNode, childElement, queryTree, QueryBuilder.Constants.QueryTreeNodeType.AND);
                                    this.addFilterToNode(childElement, filterANDNode, queryTree, entityElement, initialMetadata);
                                    break;
                                case QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_OR:
                                    var filterORNode = this.appendFilterNode(parentNode, childElement, queryTree, QueryBuilder.Constants.QueryTreeNodeType.OR);
                                    this.addFilterToNode(childElement, filterORNode, queryTree, entityElement, initialMetadata);
                                    break;
                                default:
                                    throw new Error("Invalid FetchXML. Unknown Attribute: " + filterType);
                            }
                            break;
                        default:
                            throw new Error("Invalid FetchXML. Unknown Tag: " + childElementName);
                    }
                }
            };
            AdvancedFindInputConverter.prototype.getNodeByName = function (entityElement, elementName) {
                return this.getAllChildNodesByName(entityElement, elementName)[0];
            };
            AdvancedFindInputConverter.prototype.getAllChildNodesByName = function (entityElement, elementName) {
                var nodes = [];
                for (var i = 0; i < entityElement.childNodes.length; i++) {
                    if (entityElement.childNodes[i].nodeName === elementName)
                        nodes.push(entityElement.childNodes[i]);
                }
                return nodes;
            };
            AdvancedFindInputConverter.prototype.getConditionNode = function (conditionElement, queryTree, entityLogicalName, initialMetadata) {
                var conditionNode = queryTree.createConditionNode();
                var entityMetadata = initialMetadata.entityMetadataAndAttributesMap[entityLogicalName];
                var attributeName = this.getAttributeValue(conditionElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_ATTRIBUTE);
                var operator = this.getAttributeValue(conditionElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR);
                var uihidden = this.getAttributeValue(conditionElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UIHIDDEN);
                conditionNode.Condition.IsVisibleInSimpleMode = uihidden && uihidden === "1" ? false : true;
                var controlName = entityMetadata
                    ? QueryBuilder.AdvancedFindUtils.GetValueControlNameByAttributeAndOperator(entityMetadata.attributes[attributeName].attributeType.Name, entityMetadata.attributes[attributeName].attributeFormatType.name, operator)
                    : QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType;
                var value = null;
                switch (controlName) {
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType:
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.DateTimeType:
                        value = this.getAttributeValue(conditionElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE);
                        break;
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.OptionSetType:
                        value = parseInt(this.getAttributeValue(conditionElement, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE));
                        break;
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.MultiSelectType:
                        value = this.getMultiSelectPicklistValue(conditionElement);
                        break;
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.LookupType:
                        value = this.getLookupValueFromElement(conditionElement);
                        break;
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.PartyListType:
                        value = this.getPartyListValue(conditionElement);
                        break;
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.FiscalYearAndPeriodType:
                        value = this.getFiscalYearAndPeriodValue(conditionElement);
                        break;
                }
                conditionNode.Condition.ControlDefinitions = this.createControlDefinitions(queryTree.Context, conditionNode, entityLogicalName, attributeName, operator, value, controlName, initialMetadata);
                return conditionNode;
            };
            AdvancedFindInputConverter.prototype.appendSpecialConditionOperators = function (context, operatorData, initialMetadata, entityLogicalName, attributeLogicalName, useTypeAhead) {
                if (useTypeAhead === void 0) { useTypeAhead = true; }
                var operatorsToAppend = [];
                var currentOperators = useTypeAhead
                    ? operatorData.sections[0].sectionElements
                    : operatorData;
                var selectedAttribute = initialMetadata.entityMetadataAndAttributesMap[entityLogicalName].attributes[attributeLogicalName];
                switch (selectedAttribute.attributeType.Name) {
                    case QueryBuilder.EntityAttributeType.LookUp:
                        if (selectedAttribute.targets.length > 0) {
                            operatorsToAppend.push.apply(operatorsToAppend, new QueryBuilder.SpecialConditionOperatorProvider().getEntityRelatedOperators(selectedAttribute.targets, currentOperators));
                            if (selectedAttribute.targets.length === 1) {
                                if (QueryBuilder.Utils.isHierarchyEnabledForEntity(initialMetadata.entityMetadataAndAttributesMap[selectedAttribute.targets[0]])) {
                                    operatorsToAppend.push.apply(operatorsToAppend, [QueryBuilder.ConditionOperator.under, QueryBuilder.ConditionOperator.not_under]);
                                }
                            }
                        }
                        break;
                    case QueryBuilder.EntityAttributeType.UniqueIdentifier:
                        if (selectedAttribute.attributeBaseType == QueryBuilder.QueryBuilderConstants.PRIMARY_KEY &&
                            QueryBuilder.Utils.isHierarchyEnabledForEntity(initialMetadata.entityMetadataAndAttributesMap[entityLogicalName])) {
                            operatorsToAppend = [QueryBuilder.ConditionOperator.under, QueryBuilder.ConditionOperator.not_under];
                        }
                        operatorsToAppend.push.apply(operatorsToAppend, new QueryBuilder.SpecialConditionOperatorProvider().getEntityRelatedOperators([entityLogicalName], currentOperators));
                        break;
                }
                QueryBuilder.AdvancedFindUtils.appendOperators(context, currentOperators, operatorsToAppend);
            };
            AdvancedFindInputConverter.prototype.createTypeAheadSelectDefinitions = function (context, conditionNode, initialMetadata, entity, attribute, operator) {
                var entityMetadata = initialMetadata.entityMetadataAndAttributesMap[entity];
                var attributesData = entityMetadata
                    ? new QueryBuilder.AttributeMetadataProvider().populateAttributeListForTypeAheadSelect(context, entityMetadata, entity, true, false)
                    : { isSectioningEnabled: true, sections: [] };
                var operatorData = entityMetadata
                    ? new QueryBuilder.OperatorMetadataProvider().getTypeAheadSelectData(context, entityMetadata.attributes[attribute].attributeType.Name, entityMetadata.attributes[attribute].attributeFormatType.name)
                    : { isSectioningEnabled: true, sections: [] };
                if (entityMetadata) {
                    this.appendSpecialConditionOperators(context, operatorData, initialMetadata, entity, attribute, true);
                }
                var controlDefinitions = [
                    QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.LHSAttribute, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_ATTRIBUTE), false, attribute, null, attributesData, "12.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_ATTRIBUTE), new QueryBuilder.ConditionModel.ConditionControlChangeHandler(conditionNode.Condition)),
                    QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.Operator, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_OPERATOR), false, operator, null, operatorData, "8.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_OPERATOR), new QueryBuilder.ConditionModel.ConditionControlChangeHandler(conditionNode.Condition)),
                ];
                return controlDefinitions;
            };
            AdvancedFindInputConverter.prototype.createControlDefinitions = function (context, conditionNode, entity, attribute, operator, value, controlName, initialMetadata) {
                var entityMetadata = initialMetadata.entityMetadataAndAttributesMap[entity];
                var controlDefinitions = this.createTypeAheadSelectDefinitions(context, conditionNode, initialMetadata, entity, attribute, operator);
                var valueControl = QueryBuilder.AdvancedFindUtils.GetValueControlByControlName(context, conditionNode, controlName, value, operator);
                if (valueControl) {
                    switch (valueControl.type) {
                        case QueryBuilder.ConditionModel.ControlTypes.TextBox:
                            if (valueControl.value.value) {
                                if (operator === QueryBuilder.ConditionOperator.begins_with ||
                                    operator === QueryBuilder.ConditionOperator.ends_with ||
                                    operator === QueryBuilder.ConditionOperator.like ||
                                    operator === QueryBuilder.ConditionOperator.not_begin_with ||
                                    operator === QueryBuilder.ConditionOperator.not_end_with ||
                                    operator === QueryBuilder.ConditionOperator.not_like) {
                                    valueControl.value.value = this.removeWildcard(valueControl.value.value);
                                }
                            }
                            break;
                        case QueryBuilder.ConditionModel.ControlTypes.OptionSet:
                            if (entityMetadata.attributes[attribute].attributeFormatType &&
                                entityMetadata.attributes[attribute].attributeFormatType.name == QueryBuilder.EntityAttributeTypeFormat.Language) {
                                valueControl.data = initialMetadata.provisionedLanguageList;
                            }
                            else {
                                if (operator === QueryBuilder.ConditionOperator.in_fiscal_period) {
                                    valueControl.data = QueryBuilder.AdvancedFindUtils.GetPeriodList(context);
                                }
                                else if (operator === QueryBuilder.ConditionOperator.in_fiscal_year) {
                                    valueControl.data = QueryBuilder.AdvancedFindUtils.GetFiscalYearsList(context);
                                }
                                else {
                                    valueControl.data = entityMetadata.attributes[attribute]
                                        .optionsetProperties
                                        ? entityMetadata.attributes[attribute].optionsetProperties.getOptions()
                                        : [];
                                }
                            }
                            break;
                        case QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod:
                            valueControl.data = QueryBuilder.AdvancedFindUtils.GetFiscalYearAndPeriod(context);
                            break;
                        case QueryBuilder.ConditionModel.ControlTypes.MultiSelectPicklist:
                            if (entityMetadata.attributes[attribute].attributeFormatType &&
                                entityMetadata.attributes[attribute].attributeFormatType.name == QueryBuilder.EntityAttributeTypeFormat.Language) {
                                valueControl.data =
                                    initialMetadata.provisionedLanguageList;
                            }
                            else {
                                valueControl.data = entityMetadata.attributes[attribute]
                                    .optionsetProperties
                                    ? entityMetadata.attributes[attribute].optionsetProperties.getOptions()
                                    : [];
                            }
                            break;
                        case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                            var targets = entityMetadata.attributes[attribute].targets;
                            valueControl.targets =
                                targets && targets.length > 0 ? targets : [entity];
                            break;
                        case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                            var targetEntities = entityMetadata.attributes[attribute].targets;
                            valueControl.targets =
                                targetEntities && targetEntities.length > 0 ? targetEntities : [entity];
                            break;
                        default:
                            break;
                    }
                    controlDefinitions.push(valueControl);
                }
                return controlDefinitions;
            };
            AdvancedFindInputConverter.prototype.removeWildcard = function (stringValue) {
                if (stringValue[0] === "%")
                    stringValue = stringValue.slice(1, stringValue.length);
                if (stringValue[stringValue.length - 1] === "%")
                    stringValue = stringValue.slice(0, stringValue.length - 1);
                return stringValue;
            };
            AdvancedFindInputConverter.prototype.getAttributeValue = function (element, name) {
                var attribute = element.attributes.getNamedItem(name);
                return attribute ? attribute.value : undefined;
            };
            AdvancedFindInputConverter.prototype.getLookupValueFromElement = function (element) {
                var value = this.getAttributeValue(element, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE);
                return {
                    id: value.replace(/\{|\}/gi, ""),
                    Name: this.getAttributeValue(element, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UINAME),
                    LogicalName: this.getAttributeValue(element, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE),
                };
            };
            AdvancedFindInputConverter.prototype.getMultiSelectPicklistValue = function (element) {
                var picklistValues = [];
                for (var indx = 0; indx < element.childNodes.length; indx++) {
                    if (element.childNodes[indx].nodeName === QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE)
                        picklistValues.push(parseInt(element.childNodes[indx].textContent));
                }
                return picklistValues.length ? picklistValues : null;
            };
            AdvancedFindInputConverter.prototype.getFiscalYearAndPeriodValue = function (element) {
                var fiscalValue = {};
                if (element.childNodes.length != 2) {
                    console.error("Invalid FiscalAndPeriod value");
                }
                else {
                    fiscalValue.periodValue = parseInt(element.childNodes[0].textContent.replace("0", ""));
                    fiscalValue.yearValue = parseInt(element.childNodes[1].textContent);
                }
                return fiscalValue;
            };
            AdvancedFindInputConverter.prototype.getPartyListValue = function (element) {
                var lookupValues = [];
                for (var indx = 0; indx < element.childNodes.length; indx++) {
                    var child = element.childNodes[indx];
                    if (child.nodeName === QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE) {
                        var value = child.textContent;
                        var lookupValue = {
                            id: value ? value.replace(/\{|\}/gi, "") : null,
                            Name: this.getAttributeValue(child, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UINAME),
                            LogicalName: this.getAttributeValue(child, QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE),
                        };
                        lookupValues.push(lookupValue);
                    }
                }
                return lookupValues.length ? lookupValues : null;
            };
            AdvancedFindInputConverter.prototype.appendFilterNode = function (parentNode, currentElement, queryTree, filterType) {
                var filterNode = queryTree.createLogicalGroupNode(filterType);
                parentNode.addChild(filterNode);
                filterNode.Properties = QueryBuilder.AdvancedFindUtils.getAttributesOfElement(currentElement, QueryBuilder.AdvancedFindInputConverterConstants.FilterIgnoredAttributes);
                return filterNode;
            };
            AdvancedFindInputConverter.prototype._collateLookupData = function (queryTree, initialMetadata) {
                var data = new QueryBuilder.Dictionary();
                this._collateLookupDataForTree(queryTree, initialMetadata, data);
                return data;
            };
            AdvancedFindInputConverter.prototype._collateLookupDataForTree = function (currentTree, initialMetadata, data) {
                this._collateLookupDataForNode(currentTree.Root, initialMetadata, data);
                if (currentTree.LinkedEntities.length) {
                    for (var i = 0; i < currentTree.LinkedEntities.length; i++) {
                        this._collateLookupDataForTree(currentTree.LinkedEntities[i], initialMetadata, data);
                    }
                }
            };
            AdvancedFindInputConverter.prototype._collateLookupDataForNode = function (currentNode, initialMetadata, data) {
                if (currentNode && currentNode.Children.length) {
                    for (var i = 0; i < currentNode.Children.length; i++) {
                        switch (currentNode.Children[i].NodeType) {
                            case QueryBuilder.Constants.QueryTreeNodeType.AND:
                            case QueryBuilder.Constants.QueryTreeNodeType.OR:
                                this._collateLookupDataForNode(currentNode.Children[i], initialMetadata, data);
                                break;
                            case QueryBuilder.Constants.QueryTreeNodeType.Condition:
                                var rootNodeContainer = currentNode.Children[i].getNodeContainer();
                                var entityLogicalName = rootNodeContainer.Properties["entityAttributes"]["name"];
                                this._collateLookupDataForConditionNode(currentNode.Children[i], entityLogicalName, initialMetadata, data);
                                break;
                            default:
                                break;
                        }
                    }
                }
            };
            AdvancedFindInputConverter.prototype._collateLookupDataForConditionNode = function (conditionNode, entityLogicalName, initialMetadata, data) {
                var attributeLogicalName;
                if (conditionNode.Condition &&
                    conditionNode.Condition.ControlDefinitions &&
                    conditionNode.Condition.ControlDefinitions.length) {
                    for (var i = 0; i < conditionNode.Condition.ControlDefinitions.length; i++) {
                        switch (conditionNode.Condition.ControlDefinitions[i].name) {
                            case QueryBuilder.Constants.ConditionFieldName.LHSAttribute:
                                var typeAheadSelect = conditionNode.Condition
                                    .ControlDefinitions[i];
                                attributeLogicalName = typeAheadSelect.value.value;
                                break;
                            case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                switch (conditionNode.Condition.ControlDefinitions[i].type) {
                                    case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                                        var simpleLookup = conditionNode.Condition
                                            .ControlDefinitions[i];
                                        this._addToMap(data, entityLogicalName, attributeLogicalName, simpleLookup.value, initialMetadata);
                                        break;
                                    case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                                        var partyListLookup = conditionNode.Condition
                                            .ControlDefinitions[i];
                                        if (partyListLookup.values && partyListLookup.values.length) {
                                            for (var j = 0; j < partyListLookup.values.length; j++) {
                                                this._addToMap(data, entityLogicalName, attributeLogicalName, partyListLookup.values[j], initialMetadata);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            };
            AdvancedFindInputConverter.prototype._addToMap = function (data, entityLogicalName, attributeLogicalName, value, initialMetadata) {
                if (value && value.id) {
                    var attributeMetadata = initialMetadata.entityMetadataAndAttributesMap[entityLogicalName].attributes[attributeLogicalName];
                    switch (attributeMetadata.attributeType.Name) {
                        case QueryBuilder.EntityAttributeType.UniqueIdentifier:
                            this._populateMap(data, [entityLogicalName], value.id);
                            break;
                        case QueryBuilder.EntityAttributeType.LookUp:
                        case QueryBuilder.EntityAttributeType.CustomerType:
                        case QueryBuilder.EntityAttributeType.OwnerType:
                            this._populateMap(data, attributeMetadata.targets, value.id);
                            break;
                        default:
                            break;
                    }
                }
            };
            AdvancedFindInputConverter.prototype._populateMap = function (map, entities, value) {
                for (var _i = 0, entities_1 = entities; _i < entities_1.length; _i++) {
                    var entity = entities_1[_i];
                    if (!map.contains(entity)) {
                        map.put(entity, new QueryBuilder.Set());
                    }
                    map.get(entity).put(value);
                }
            };
            AdvancedFindInputConverter.prototype._populateLookupDataForTree = function (currentTree, records) {
                this._populateLookupDataForNode(currentTree.Root, records);
                if (currentTree.LinkedEntities.length) {
                    for (var i = 0; i < currentTree.LinkedEntities.length; i++) {
                        this._populateLookupDataForTree(currentTree.LinkedEntities[i], records);
                    }
                }
            };
            AdvancedFindInputConverter.prototype._populateLookupDataForNode = function (currentNode, records) {
                if (currentNode && currentNode.Children.length) {
                    for (var i = 0; i < currentNode.Children.length; i++) {
                        switch (currentNode.Children[i].NodeType) {
                            case QueryBuilder.Constants.QueryTreeNodeType.AND:
                            case QueryBuilder.Constants.QueryTreeNodeType.OR:
                                this._populateLookupDataForNode(currentNode.Children[i], records);
                                break;
                            case QueryBuilder.Constants.QueryTreeNodeType.Condition:
                                this._populateLookupDataForConditionNode(currentNode.Children[i], records);
                                break;
                            default:
                                break;
                        }
                    }
                }
            };
            AdvancedFindInputConverter.prototype._populateLookupDataForConditionNode = function (conditionNode, records) {
                if (conditionNode.Condition &&
                    conditionNode.Condition.ControlDefinitions &&
                    conditionNode.Condition.ControlDefinitions.length) {
                    for (var i = 0; i < conditionNode.Condition.ControlDefinitions.length; i++) {
                        switch (conditionNode.Condition.ControlDefinitions[i].name) {
                            case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                switch (conditionNode.Condition.ControlDefinitions[i].type) {
                                    case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                                        var simpleLookup = conditionNode.Condition
                                            .ControlDefinitions[i];
                                        this._populateLookupValue(simpleLookup.value, records);
                                        break;
                                    case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                                        var partyListLookup = conditionNode.Condition
                                            .ControlDefinitions[i];
                                        if (partyListLookup.values && partyListLookup.values.length) {
                                            for (var j = 0; j < partyListLookup.values.length; j++) {
                                                this._populateLookupValue(partyListLookup.values[j], records);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            };
            AdvancedFindInputConverter.prototype._populateLookupValue = function (lookupValue, records) {
                if (lookupValue.id) {
                    var recordId = lookupValue.id.toLowerCase();
                    if (records.contains(recordId)) {
                        lookupValue.Name = records.get(recordId).name;
                        lookupValue.LogicalName = records.get(recordId).entityLogicalName;
                    }
                }
            };
            AdvancedFindInputConverter.prototype.findLinkedEntityIdByAliasInTree = function (alias, queryTree) {
                var linkedEntityQueue = [];
                this.addChildLinkedEntitiesToQueue(queryTree, linkedEntityQueue);
                for (var _i = 0, linkedEntityQueue_1 = linkedEntityQueue; _i < linkedEntityQueue_1.length; _i++) {
                    var linkedEntity = linkedEntityQueue_1[_i];
                    if (linkedEntity.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES][QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_ALIAS] === alias) {
                        return linkedEntity.Id;
                    }
                    else {
                        this.addChildLinkedEntitiesToQueue(linkedEntity, linkedEntityQueue);
                    }
                }
                return null;
            };
            AdvancedFindInputConverter.prototype.addChildLinkedEntitiesToQueue = function (parent, linkedEntityQueue) {
                for (var i = 0; i < parent.LinkedEntities.length; i++) {
                    linkedEntityQueue.push(parent.LinkedEntities[i]);
                }
            };
            AdvancedFindInputConverter.prototype.isDoesNotContainDataFilter = function (filterElement) {
                return (filterElement.childNodes &&
                    filterElement.childNodes.length === 1 &&
                    this.getAttributeValue(filterElement.childNodes[0], QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR) === "null" &&
                    !MscrmCommon.ControlUtils.Object.isNullOrUndefined(this.getAttributeValue(filterElement.childNodes[0], QueryBuilder.AdvancedFindConstants.ENTITYNAME)));
            };
            return AdvancedFindInputConverter;
        }());
        QueryBuilder.AdvancedFindInputConverter = AdvancedFindInputConverter;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindInputConverterConstants = (function () {
            function AdvancedFindInputConverterConstants() {
            }
            AdvancedFindInputConverterConstants.ConditionIgnoredAttributes = [
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_ATTRIBUTE,
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR,
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE,
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE,
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UINAME,
                QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UIHIDDEN,
            ];
            AdvancedFindInputConverterConstants.FilterIgnoredAttributes = [QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE];
            return AdvancedFindInputConverterConstants;
        }());
        QueryBuilder.AdvancedFindInputConverterConstants = AdvancedFindInputConverterConstants;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var EntityMetadata = (function () {
            function EntityMetadata() {
            }
            return EntityMetadata;
        }());
        QueryBuilder.EntityMetadata = EntityMetadata;
        var EntityMetadataAndAttributes = (function () {
            function EntityMetadataAndAttributes(entityLogicalName) {
                this.logicalName = entityLogicalName;
                this.attributes = {};
                this.oneToManyRelationships = [];
                this.manyToOneRelationships = [];
                this.manyToManyRelationships = [];
                this.relatedEntities = {};
            }
            EntityMetadataAndAttributes.prototype.addAttribute = function (attributeMetadata) {
                this.attributes[attributeMetadata.logicalName] = attributeMetadata;
            };
            EntityMetadataAndAttributes.prototype.addOneToManyRelationship = function (oneToManyRelationship) {
                if (!this.containsOneToManyRelationship(oneToManyRelationship)) {
                    this.oneToManyRelationships.push(oneToManyRelationship);
                }
            };
            EntityMetadataAndAttributes.prototype.addManyToOneRelationship = function (manyToOneRelationship) {
                if (!this.containsManyToOneRelationship(manyToOneRelationship)) {
                    this.manyToOneRelationships.push(manyToOneRelationship);
                }
            };
            EntityMetadataAndAttributes.prototype.addManyToManyRelationship = function (manyToManyRelationshiop) {
                if (!this.containsManyToManyRelationship(manyToManyRelationshiop)) {
                    this.manyToManyRelationships.push(manyToManyRelationshiop);
                }
            };
            EntityMetadataAndAttributes.prototype.containsManyToOneRelationship = function (value) {
                return (this.manyToOneRelationships.filter(function (relation) {
                    return (relation.referencedEntity === value.referencedEntity &&
                        relation.referencedAttribute === value.referencedAttribute &&
                        relation.referencingAttribute === value.referencingAttribute);
                }).length > 0);
            };
            EntityMetadataAndAttributes.prototype.containsOneToManyRelationship = function (value) {
                return (this.oneToManyRelationships.filter(function (relation) {
                    return (relation.referencingEntity === value.referencingEntity &&
                        relation.referencingAttribute === value.referencingAttribute &&
                        relation.referencedAttribute === value.referencedAttribute);
                }).length > 0);
            };
            EntityMetadataAndAttributes.prototype.containsManyToManyRelationship = function (value) {
                return (this.manyToManyRelationships.filter(function (relation) {
                    return (relation.referencingEntity === value.referencingEntity &&
                        relation.referencingAttribute === value.referencingAttribute &&
                        relation.referencedAttribute === value.referencedAttribute &&
                        relation.intersectEntity === value.intersectEntity &&
                        relation.intersectPrimaryAttribute === value.intersectPrimaryAttribute &&
                        relation.intersectRelatedAttribute === value.intersectRelatedAttribute &&
                        relation.fromEntityAttribute === value.fromEntityAttribute &&
                        relation.toEntityAttribute === value.toEntityAttribute);
                }).length > 0);
            };
            EntityMetadataAndAttributes.prototype.getAttributeByLogicalName = function (attributeLogicalName) {
                return this.attributes[attributeLogicalName];
            };
            return EntityMetadataAndAttributes;
        }());
        QueryBuilder.EntityMetadataAndAttributes = EntityMetadataAndAttributes;
        var RelatedEntityMetadataAndAttributes = (function () {
            function RelatedEntityMetadataAndAttributes(entityLogicalName) {
                this.logicalName = entityLogicalName;
                this.attributes = {};
            }
            RelatedEntityMetadataAndAttributes.prototype.addAttribute = function (attributeMetadata) {
                this.attributes[attributeMetadata.logicalName] = attributeMetadata;
            };
            RelatedEntityMetadataAndAttributes.prototype.getAttributeByLogicalName = function (attributeLogicalName) {
                return this.attributes[attributeLogicalName];
            };
            return RelatedEntityMetadataAndAttributes;
        }());
        QueryBuilder.RelatedEntityMetadataAndAttributes = RelatedEntityMetadataAndAttributes;
        var EntityViewMetadata = (function () {
            function EntityViewMetadata(defaultLookupViewId) {
                this.defaultLookupViewId = defaultLookupViewId;
            }
            return EntityViewMetadata;
        }());
        QueryBuilder.EntityViewMetadata = EntityViewMetadata;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderCommandBar = (function () {
            function QueryBuilderCommandBar(context, associatedTree) {
                var _this = this;
                this.context = context;
                this.associatedTree = associatedTree;
                this.onClickAction = function (type) {
                    switch (type) {
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.RunQuery:
                            _this.associatedTree.runQuery();
                            QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getRunQueryButtonId());
                            _this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.RunQuery, Properties: {} });
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.AND:
                            var newAndNodeId = _this.associatedTree.groupAND(Object.keys(_this.associatedTree.getSelectedNodes()));
                            QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix() + newAndNodeId);
                            _this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.GroupAND, Properties: {} });
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.OR:
                            var newOrNodeId = _this.associatedTree.groupOR(Object.keys(_this.associatedTree.getSelectedNodes()));
                            QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix() + newOrNodeId);
                            _this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.GroupOR, Properties: {} });
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Delete:
                            _this.associatedTree.delete(Object.keys(_this.associatedTree.getSelectedNodes()));
                            QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId());
                            _this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.Delete, Properties: {} });
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Ungroup:
                            var nodes = Object.keys(_this.associatedTree.getSelectedNodes());
                            if (nodes.length > 1) {
                                for (var i = 0; i < nodes.length; i++) {
                                    delete _this.associatedTree.getSelectedNodes()[nodes[i]];
                                }
                            }
                            else {
                                _this.associatedTree.unGroup(nodes[0]);
                                _this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.UnGroup, Properties: {} });
                            }
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Clear:
                            _this.associatedTree.ConfirmationDialog.ShowConfirmationDialog(QueryBuilder.Utils.getResourceString(_this.context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_TITLE_CLEAR), QueryBuilder.Utils.getResourceString(_this.context, QueryBuilder.LocalizedStrings.CONFIRMATION_MESSAGE_RESET), _this.clearTree.bind(_this));
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.SimpleDetailed:
                            _this.associatedTree.renderSimple(_this.associatedTree.Root);
                            break;
                        case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.ShowHideInSimpleMode:
                            var selectedNodes = Object.keys(_this.associatedTree.getSelectedNodes());
                            if (selectedNodes.length == 1) {
                                var selectedNode = _this.associatedTree.getNode(selectedNodes[0]);
                                _this.associatedTree.showOrHideinSimpleMode(selectedNode);
                            }
                            _this.associatedTree.onChange({
                                EventType: QueryBuilder.Constants.QueryTreeEventType.ShowInSimpleMode,
                                Properties: {},
                            });
                            break;
                    }
                };
                this.updateCommandBar();
            }
            Object.defineProperty(QueryBuilderCommandBar.prototype, "Commands", {
                get: function () {
                    return this.commands;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderCommandBar.prototype.updateCommandBar = function () {
                var showRunButton = this.associatedTree.Options.NotifyOutputChangeOn ==
                    QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.RunButtonClick;
                this.commands = this.context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarId(),
                    name: "GlobalCommandBar",
                    style: QueryBuilder.QueryBuilderStyle.CommandBarButtonConatinerStyle(this.context.theming),
                }, [
                    showRunButton ? this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.RunQuery) : null,
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.AND),
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.OR),
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Ungroup),
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Delete),
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.ShowHideInSimpleMode),
                    this.getModeButton(),
                    this.getButton(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Clear),
                ]);
            };
            QueryBuilderCommandBar.prototype.clearTree = function () {
                this.associatedTree.clearTree();
                this.associatedTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.Reset, Properties: {} });
            };
            QueryBuilderCommandBar.prototype.getModeButton = function () {
                var _this = this;
                var idkey = "SimpleDetailedButton";
                var commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_MODE);
                var accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_MODE);
                var accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_MODE);
                var attachmentIconType = 32;
                var enable = true;
                var style = QueryBuilder.QueryBuilderStyle.commandBarAdvancedButtonStyle(this.context.theming, this.context.client.isRTL);
                var checkBox = this.context.factory.createElement("BOOLEAN", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId(),
                    value: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? false : true,
                    accessibilityLabel: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode
                        ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToAdvancedMode)
                        : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToSimpleMode),
                    title: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode
                        ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToAdvancedMode)
                        : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToSimpleMode),
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderCommandBarCheckboxStyle(this.context.theming),
                    onValueChange: function () {
                        _this.onClickAction(QueryBuilder.Constants.QueryBuilderCommandBarButtonType.SimpleDetailed);
                    },
                }, []);
                var label = this.context.factory.createElement("LABEL", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvLabelId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvLabelId(),
                    tabIndex: -1,
                    accessibilityLabel: QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_MODE),
                    forElementId: QueryBuilder.ComponentIdPrefixesAndSuffixes.getQueryBuilderControlPrefix() +
                        QueryBuilder.ComponentIdPrefixesAndSuffixes.getsimpleAdvancedCheckId(),
                    style: QueryBuilder.QueryBuilderStyle.commandBarLabelConatinerStyle(this.context.theming),
                }, [QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_MODE)]);
                return this.context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getcommandBarModeId(),
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getcommandBarModeId(),
                    accessibilityLabel: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode
                        ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToAdvancedMode)
                        : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToSimpleMode),
                    title: QueryBuilder.QueryBuilderQueryTree.IsSimpleMode
                        ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToAdvancedMode)
                        : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SwitchToSimpleMode),
                    tabIndex: -1,
                    style: style,
                }, [checkBox, label]);
            };
            QueryBuilderCommandBar.prototype.getButton = function (type) {
                var _this = this;
                var idkey = "";
                var self = this;
                var commandString = "";
                var accessibilityLabel = "";
                var accessibilityTitle = "";
                var attachmentIconType = 0;
                var style = {};
                var nodeIds = Object.keys(this.associatedTree.getSelectedNodes());
                var enable = false;
                var singleSelection = false;
                var multipleSelection = false;
                if (nodeIds) {
                    if (nodeIds.length == 1) {
                        singleSelection = true;
                    }
                    else if (nodeIds.length > 1) {
                        multipleSelection = true;
                    }
                }
                switch (type) {
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.RunQuery:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getRunQueryButtonId();
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_RUN_QUERY);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_RUN_QUERY_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_RUN_QUERY);
                        attachmentIconType = 319;
                        if (!this.associatedTree.HasErrors) {
                            enable = true;
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.AND:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getAndButtonId();
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_AND);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_AND_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_AND);
                        attachmentIconType = 320;
                        if (singleSelection) {
                            var node = this.associatedTree.getNode(nodeIds[0]);
                            if (node && node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                                enable = true;
                            }
                        }
                        else if (multipleSelection && this.associatedTree.canBeGrouped(nodeIds)) {
                            enable = true;
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.OR:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getOrButtonId();
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_OR);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_OR_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_OR);
                        attachmentIconType = 321;
                        if (singleSelection) {
                            var node = this.associatedTree.getNode(nodeIds[0]);
                            if (node && node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND) {
                                enable = true;
                            }
                        }
                        else if (multipleSelection && this.associatedTree.canBeGrouped(nodeIds)) {
                            enable = true;
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Delete:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getDeleteButtonId();
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_DELETE);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_DELETE_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_DELETE);
                        attachmentIconType = 6;
                        if (singleSelection) {
                            var node = this.associatedTree.getNode(nodeIds[0]);
                            if (node && node.Parent) {
                                enable = true;
                            }
                        }
                        if (multipleSelection) {
                            enable = true;
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Ungroup:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getUngroupButtonId();
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_UNGROUP);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_UNGROUP_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_UNGROUP);
                        attachmentIconType = 322;
                        if (singleSelection) {
                            var node = this.associatedTree.getNode(nodeIds[0]);
                            if (node &&
                                (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND || node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR)) {
                                if (node.Parent) {
                                    enable = true;
                                }
                            }
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.Clear:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getClearButtonId();
                        enable = true;
                        style = QueryBuilder.QueryBuilderStyle.commandBarResetButtonStyle(this.context.theming, this.context.client.isRTL);
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_CLEAR);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_CLEAR_TITLE_VERBAL_STRING);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_CLEAR);
                        attachmentIconType = 32;
                        break;
                    case QueryBuilder.Constants.QueryBuilderCommandBarButtonType.ShowHideInSimpleMode:
                        idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getShowHideInSimpleModeId();
                        attachmentIconType = 323;
                        commandString = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE);
                        accessibilityLabel = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE);
                        accessibilityTitle = QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE);
                        if (singleSelection) {
                            var node = this.associatedTree.getNode(nodeIds[0]);
                            if (node && node.NodeType === QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                                enable = true;
                                attachmentIconType = this.associatedTree.isVisibleInSimpleMode(node) ? 323 : 324;
                                commandString = this.associatedTree.isVisibleInSimpleMode(node)
                                    ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE)
                                    : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_SHOW_SIMPLE);
                                accessibilityLabel = this.associatedTree.isVisibleInSimpleMode(node)
                                    ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE)
                                    : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_SHOW_SIMPLE);
                                accessibilityTitle = this.associatedTree.isVisibleInSimpleMode(node)
                                    ? QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_HIDE_SIMPLE)
                                    : QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.COMMANDBAR_SHOW_SIMPLE);
                            }
                        }
                        style = QueryBuilder.QueryBuilderStyle.commandBarButtonStyle(this.context.theming, enable);
                        break;
                }
                var attachmentIcon = this.context.factory.createElement("MICROSOFTICON", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarIconPrefix() + idkey,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarIconPrefix() + idkey,
                    style: QueryBuilder.QueryBuilderStyle.commandBarIconStyle(this.context.theming, enable),
                    type: attachmentIconType,
                });
                var buttonLabel = this.context.factory.createElement("LABEL", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarButtonLabelPrefix() + idkey,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getCommandBarButtonLabelPrefix() + idkey,
                    forElementId: this.context.accessibility.getUniqueId(idkey),
                    style: QueryBuilder.QueryBuilderStyle.commandBarLabelConatinerStyle(this.context.theming),
                }, commandString);
                return this.context.factory.createElement("BUTTON", {
                    id: idkey,
                    key: idkey,
                    name: "CommandBarButton",
                    style: style,
                    accessibilityLabel: accessibilityLabel,
                    tabIndex: 0,
                    hidden: false,
                    disabled: !enable,
                    onClick: function () {
                        _this.onClickAction(type);
                    },
                    title: accessibilityTitle,
                }, [attachmentIcon, buttonLabel]);
            };
            return QueryBuilderCommandBar;
        }());
        QueryBuilder.QueryBuilderCommandBar = QueryBuilderCommandBar;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderTelemetryEvent = (function () {
            function QueryBuilderTelemetryEvent(eventName, eventParameters) {
                this.eventName = eventName;
                this.eventParameters = eventParameters;
            }
            Object.defineProperty(QueryBuilderTelemetryEvent.prototype, "EventName", {
                get: function () {
                    return this.eventName;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderTelemetryEvent.prototype, "EventParameters", {
                get: function () {
                    return this.eventParameters;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderTelemetryEvent.prototype.addEventParameter = function (eventParameter) {
                this.eventParameters.push(eventParameter);
            };
            return QueryBuilderTelemetryEvent;
        }());
        QueryBuilder.QueryBuilderTelemetryEvent = QueryBuilderTelemetryEvent;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderAddLinkedEntityButton = (function () {
            function QueryBuilderAddLinkedEntityButton(queryTree, usageContext, parentId, rootNodeContainer, addRelatedEntityHandler, isHidden) {
                this.queryTree = queryTree;
                this.usageContext = usageContext;
                this.parentId = parentId;
                this.rootNodeContainer = rootNodeContainer;
                this.addRelatedEntityHandler = addRelatedEntityHandler;
                this.isHidden = isHidden;
                this.buttonType = QueryBuilder.Constants.AddNodeButtonType.AddRelated;
            }
            QueryBuilderAddLinkedEntityButton.prototype.isRelatedEntityControlVisible = function () {
                return this.showRelatedEntityControl;
            };
            QueryBuilderAddLinkedEntityButton.prototype.hideRelatedEntityControl = function () {
                this.showRelatedEntityControl = false;
            };
            QueryBuilderAddLinkedEntityButton.prototype.getButton = function (disabled) {
                var self = this;
                var buttonText = QueryBuilder.Utils.getResourceString(this.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_RELATED);
                var idKey = this.parentId ? this.parentId : "treeRoot" + "Related";
                var addRelatedEntityIcon = this.queryTree.Context.factory.createElement("MICROSOFTICON", {
                    id: "iconkey",
                    key: "iconkey",
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderLabelIconStyle(this.queryTree.Context.theming),
                    type: 187,
                });
                return this.queryTree.Context.factory.createElement("BUTTON", {
                    id: idKey,
                    key: idKey,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderRelatedLinkButtonStyle(this.queryTree.Context.theming),
                    accessibilityLabel: QueryBuilder.Utils.getResourceString(self.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_RELATED_ENTITY),
                    tabIndex: 0,
                    hidden: this.isHidden,
                    onClick: function (e) {
                        self.showRelatedEntityTypeAheadSelect(self);
                        e.preventDefault();
                        e.stopPropagation();
                    },
                    title: QueryBuilder.Utils.getResourceString(self.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_RELATED_ENTITY),
                }, [addRelatedEntityIcon, buttonText]);
            };
            QueryBuilderAddLinkedEntityButton.prototype.showRelatedEntityTypeAheadSelect = function (self) {
                var _this = this;
                self.showRelatedEntityControl = true;
                if (self.controlDefinition) {
                    QueryBuilder.QueryBuilderControl.rerenderControl(this.queryTree.Context, this.getOnClickNextFocusableId());
                }
                else {
                    var controlDefinitionProvider = new QueryBuilder.ControlDefinitionProviderRegistry().getProvider(this.usageContext);
                    controlDefinitionProvider
                        .getLinkedEntityControlDefinition(this.queryTree.Context, this.rootNodeContainer, this)
                        .then(function (controlDefinition) {
                        self.controlDefinition = controlDefinition;
                    }, function (error) {
                        self.queryTree.onError(error);
                    })
                        .then(function () {
                        QueryBuilder.QueryBuilderControl.rerenderControl(_this.queryTree.Context, _this.getOnClickNextFocusableId());
                    });
                }
            };
            QueryBuilderAddLinkedEntityButton.prototype.handleRelatedEntitySelection = function (relationshipType, fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, intersectEntity, intersectPrimaryAttribute, intersectRelatedAttribute) {
                var _this = this;
                this.showRelatedEntityControl = false;
                this.controlDefinition.control.setState({
                    selectedValue: null,
                    filter: "",
                });
                var self = this;
                new QueryBuilder.AdvancedFindInitialMetadataLoader()
                    .getDisplayNamesForLinkedEntity(fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, this.queryTree.Context)
                    .then(function (result) {
                    var fromEntityDisplayName = result[fromEntityLogicalName];
                    var toEntityDisplayName = result[toEntityLogicalName];
                    var fromAttributeDisplayName = result[fromAttributeLogicalName];
                    var toAttributeDisplayName = result[toAttributeLogicalName];
                    var linkedEntityData;
                    if (relationshipType != QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany) {
                        linkedEntityData = {
                            RelationshipType: relationshipType,
                            FromEntityLogicalName: fromEntityLogicalName,
                            FromEntityDisplayName: fromEntityDisplayName,
                            FromAttributeLogicalName: fromAttributeLogicalName,
                            FromAttributeDisplayName: fromAttributeDisplayName,
                            ToEntityLogicalName: toEntityLogicalName,
                            ToEntityDisplayName: toEntityDisplayName,
                            ToAttributeLogicalName: toAttributeLogicalName,
                            ToAttributeDisplayName: toAttributeDisplayName,
                            IsVisible: true,
                            LinkType: QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER,
                            IsIntersect: false,
                            NoDisplayName: false,
                        };
                        self.addRelatedEntityHandler(_this.parentId, linkedEntityData);
                    }
                    else {
                        linkedEntityData = {
                            RelationshipType: relationshipType,
                            FromEntityLogicalName: intersectEntity,
                            FromEntityDisplayName: "",
                            FromAttributeLogicalName: intersectPrimaryAttribute,
                            FromAttributeDisplayName: "",
                            ToEntityLogicalName: toEntityLogicalName,
                            ToEntityDisplayName: toEntityDisplayName,
                            ToAttributeLogicalName: toAttributeLogicalName,
                            ToAttributeDisplayName: toAttributeDisplayName,
                            IsVisible: false,
                            LinkType: QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER,
                            IsIntersect: true,
                            NoDisplayName: false,
                        };
                        var manyToManyLinkedEntityData = {
                            RelationshipType: relationshipType,
                            FromEntityLogicalName: fromEntityLogicalName,
                            FromEntityDisplayName: fromEntityDisplayName,
                            FromAttributeLogicalName: fromAttributeLogicalName,
                            FromAttributeDisplayName: fromAttributeDisplayName,
                            ToEntityLogicalName: intersectEntity,
                            ToEntityDisplayName: "",
                            ToAttributeLogicalName: intersectRelatedAttribute,
                            ToAttributeDisplayName: "",
                            IsVisible: true,
                            LinkType: QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER,
                            IsIntersect: false,
                            NoDisplayName: false,
                        };
                        self.addRelatedEntityHandler(_this.parentId, linkedEntityData, manyToManyLinkedEntityData);
                    }
                });
            };
            QueryBuilderAddLinkedEntityButton.prototype.getView = function () {
                var button = this.getButton(this.showRelatedEntityControl);
                var relatedEntityControl = null;
                if (this.showRelatedEntityControl) {
                    relatedEntityControl = this.controlDefinition.getView();
                }
                var relatedEntitySelectBox = this.queryTree.Context.factory.createElement("CONTAINER", {
                    style: this.showRelatedEntityControl
                        ? QueryBuilder.QueryBuilderStyle.QueryBuilderRelatedSelectboxStyle(this.queryTree.Context.theming)
                        : QueryBuilder.QueryBuilderStyle.QueryBuilderRelatedEntitySelectboxStyle(this.queryTree.Context.theming),
                }, [relatedEntityControl]);
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getAddRelatedEntityButtonPrefix() + this.parentId,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getAddRelatedEntityButtonPrefix() + this.parentId,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderRelatedLinkContainerStyle(this.queryTree.Context.theming),
                }, [button, relatedEntitySelectBox]);
            };
            QueryBuilderAddLinkedEntityButton.prototype.getOnClickNextFocusableId = function () {
                return (QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadTextBoxPrefix() +
                    QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadControlPrefix() +
                    (this.controlDefinition ? this.controlDefinition.controlId : ""));
            };
            return QueryBuilderAddLinkedEntityButton;
        }());
        QueryBuilder.QueryBuilderAddLinkedEntityButton = QueryBuilderAddLinkedEntityButton;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderQueryNode = (function () {
            function QueryBuilderQueryNode(context, id, tree) {
                var _this = this;
                this.context = context;
                this.id = id;
                this.checkBoxOnChangeListener = function (change) {
                    _this.IsSelected = change;
                    if (change)
                        _this.ContainerTree.setSelectedNodes(_this.Id, _this);
                    else
                        delete _this.ContainerTree.getSelectedNodes()[_this.Id];
                    _this.context.utils.requestRender();
                };
                this.properties = {};
                this.parent = null;
                this.isSelected = false;
                this.containerTree = tree;
                this.errors = [];
            }
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Parent", {
                get: function () {
                    return this.parent;
                },
                set: function (value) {
                    this.parent = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Properties", {
                get: function () {
                    return this.properties;
                },
                set: function (properties) {
                    this.properties = properties;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Id", {
                get: function () {
                    return this.id;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "NodeType", {
                get: function () {
                    return this.nodeType;
                },
                set: function (nodeType) {
                    this.nodeType = nodeType;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Context", {
                get: function () {
                    return this.context;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "ContainerTree", {
                get: function () {
                    return this.containerTree;
                },
                set: function (tree) {
                    this.containerTree = tree;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "IsSelected", {
                get: function () {
                    return this.isSelected;
                },
                set: function (selected) {
                    this.isSelected = selected;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Depth", {
                get: function () {
                    return this.depth;
                },
                set: function (value) {
                    this.depth = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryNode.prototype, "Errors", {
                get: function () {
                    return this.errors;
                },
                set: function (value) {
                    this.errors = value;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderQueryNode.prototype.getNodeContainer = function () {
                var _this = this;
                var rootNode = this.getRootNode(this.Parent);
                if (rootNode) {
                    if (this.ContainerTree.Root.Id == rootNode.Id) {
                        this.ContainerTree.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] =
                            QueryBuilder.Constants.RootNodeContainerType.QueryTree;
                        return this.ContainerTree;
                    }
                    else {
                        return this.getContainerLinkedEntity(rootNode, this.ContainerTree.LinkedEntities);
                    }
                }
                else {
                    if (this.ContainerTree.Root.Id == this.Id ||
                        this.containerTree.LinkedEntities.filter(function (x) { return x.id == _this.id; })[0]) {
                        this.ContainerTree.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] =
                            QueryBuilder.Constants.RootNodeContainerType.QueryTree;
                        return this.ContainerTree;
                    }
                    else {
                        return this.getContainerLinkedEntity(this, this.ContainerTree.LinkedEntities);
                    }
                }
            };
            QueryBuilderQueryNode.prototype.getContainerLinkedEntity = function (rootNode, linkedEntities) {
                for (var _i = 0, linkedEntities_1 = linkedEntities; _i < linkedEntities_1.length; _i++) {
                    var linkedEntity = linkedEntities_1[_i];
                    if (linkedEntity.Root.Id == rootNode.Id || linkedEntity.Id == rootNode.id) {
                        linkedEntity.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] = QueryBuilder.Constants.RootNodeContainerType.LinkedEntity;
                        return linkedEntity;
                    }
                    else {
                        var containerNode = this.getContainerLinkedEntity(rootNode, linkedEntity.LinkedEntities);
                        if (containerNode) {
                            containerNode.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] =
                                QueryBuilder.Constants.RootNodeContainerType.LinkedEntity;
                            return containerNode;
                        }
                    }
                }
            };
            QueryBuilderQueryNode.prototype.getRootNode = function (node) {
                if (node) {
                    if (node.Parent) {
                        return this.getRootNode(node.Parent);
                    }
                    else {
                        return node;
                    }
                }
            };
            QueryBuilderQueryNode.prototype.getView = function (addRelatedEnityButton) {
                return null;
            };
            QueryBuilderQueryNode.prototype.getConditions = function (components) { };
            QueryBuilderQueryNode.prototype.getCheckbox = function (checkboxIdKey) {
                var self = this;
                var chkBox = this.Context.factory.createElement("BOOLEAN", {
                    id: checkboxIdKey,
                    key: checkboxIdKey,
                    value: this.ContainerTree.getSelectedNodes()[this.Id] ? true : false,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderCheckboxStyle(this.Context.theming),
                    onValueChange: self.checkBoxOnChangeListener,
                }, []);
                return this.Context.factory.createElement("CONTAINER", {
                    id: checkboxIdKey + "_Container",
                    key: checkboxIdKey + "_Container",
                    style: {
                        flex: "0 1 auto",
                    },
                }, chkBox);
            };
            return QueryBuilderQueryNode;
        }());
        QueryBuilder.QueryBuilderQueryNode = QueryBuilderQueryNode;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderQueryTree = (function () {
            function QueryBuilderQueryTree(context, usageContext, notifyOutputChanged) {
                var _this = this;
                this.addSectionHandler = function (parentId) {
                    var nodeId = _this.addConditionNode(parentId);
                    _this.getNode(nodeId).initialize();
                    return nodeId;
                };
                this.addRelatedEntityHandler = function (parentId, linkedEntityData, manyToManyLinkedEntityData) {
                    var linkedEntities;
                    if (!parentId) {
                        linkedEntities = _this.linkedEntities;
                    }
                    else {
                        linkedEntities = _this.idToNodeMap[parentId].LinkedEntities;
                    }
                    var nodeId = _this.getLinkedEntity(linkedEntities, linkedEntityData.FromEntityLogicalName, linkedEntityData.FromAttributeLogicalName);
                    if (!nodeId) {
                        nodeId = _this.addLinkedEntityNode(parentId, linkedEntityData);
                        QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntitySectionElipsisButtonPrefix() + nodeId);
                    }
                    else {
                        _this.getNode(nodeId).LinkedEntityData.IsVisible = true;
                    }
                    if (manyToManyLinkedEntityData) {
                        _this.addRelatedEntityHandler(nodeId, manyToManyLinkedEntityData);
                    }
                    _this.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.AddLinkedEntity, Properties: {} });
                };
                this.runQuery = function () {
                    _this.outputChanged();
                };
                this.context = context;
                this.usageContext = usageContext;
                this.notifyOutputChanged = notifyOutputChanged;
                this.options = new QueryBuilder.QueryBuilderQueryTreeOption(this.context, this.usageContext);
                this.properties = {};
                this.root = null;
                this.linkedEntities = [];
                this.idToNodeMap = {};
                this.selectedNodes = {};
                this.observers = [];
                this.errors = [];
                this.hasErrors = false;
                QueryBuilderQueryTree.Mode =
                    context && context.parameters && context.parameters.Mode
                        ? context.parameters.Mode.raw
                        : QueryBuilder.Constants.Mode.Advanced;
                QueryBuilderQueryTree.FiscalPeriodType =
                    context && context.orgSettings && context.orgSettings.fiscalPeriodType
                        ? context.orgSettings.fiscalPeriodType
                        : QueryBuilder.Constants.FiscalPeriodType.Quarterly;
                QueryBuilderQueryTree.FiscalPeriodFormat =
                    context && context.orgSettings && context.orgSettings.fiscalPeriodFormat
                        ? context.orgSettings.fiscalPeriodFormat
                        : QueryBuilder.Constants.FiscalPeriodFormat.P_Format;
                this.confirmationDialog = new QueryBuilder.QueryBuilderConfirmationDialog(this.context);
                if (this.options.LinkedEntityEnabled) {
                    this.addRelatedEntityButton = new QueryBuilder.QueryBuilderAddLinkedEntityButton(this, this.usageContext, null, this, this.addRelatedEntityHandler);
                }
            }
            QueryBuilderQueryTree.prototype.renderConfirmationDialog = function () {
                return this.confirmationDialog.getView();
            };
            QueryBuilderQueryTree.prototype.createLogicalGroupNode = function (nodeType) {
                var node = new QueryBuilder.QueryBuilderLogicalGroupNode(this.Context, QueryBuilder.Utils.newGuid(), this, nodeType);
                this.idToNodeMap[node.Id] = node;
                return node;
            };
            QueryBuilderQueryTree.prototype.createConditionNode = function () {
                var nodeId = QueryBuilder.Utils.newGuid();
                var node = new QueryBuilder.QueryBuilderConditionNode(this.Context, nodeId, this);
                this.idToNodeMap[node.Id] = node;
                return node;
            };
            QueryBuilderQueryTree.prototype.createLinkedEntityNode = function (linkedEntityData) {
                var linkedEntityNode = new QueryBuilder.QueryBuilderLinkedEntityNode(this.context, QueryBuilder.Utils.newGuid(), this, linkedEntityData);
                this.idToNodeMap[linkedEntityNode.Id] = linkedEntityNode;
                return linkedEntityNode;
            };
            Object.defineProperty(QueryBuilderQueryTree.prototype, "Context", {
                get: function () {
                    return this.context;
                },
                set: function (context) {
                    this.context = context;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree, "Mode", {
                get: function () {
                    return this.mode;
                },
                set: function (value) {
                    this.mode = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree, "FiscalPeriodType", {
                get: function () {
                    return this.fiscalPeriodType;
                },
                set: function (value) {
                    this.fiscalPeriodType = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree, "FiscalPeriodFormat", {
                get: function () {
                    return this.fiscalPeriodFormat;
                },
                set: function (value) {
                    this.fiscalPeriodFormat = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "ShowErrorIfNoConditionsInSimpleMode", {
                get: function () {
                    return this.showErrorIfNoConditionsInSimpleMode;
                },
                set: function (value) {
                    this.showErrorIfNoConditionsInSimpleMode = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "UsageContext", {
                get: function () {
                    return this.usageContext;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "Options", {
                get: function () {
                    return this.options;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "Root", {
                get: function () {
                    return this.root;
                },
                set: function (node) {
                    this.root = node;
                    this.root.Depth = 0;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "LinkedEntities", {
                get: function () {
                    return this.linkedEntities;
                },
                set: function (value) {
                    this.linkedEntities = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "Errors", {
                get: function () {
                    return this.errors;
                },
                set: function (value) {
                    this.errors = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "HasErrors", {
                get: function () {
                    return this.hasErrors;
                },
                set: function (value) {
                    this.hasErrors = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree.prototype, "ConfirmationDialog", {
                get: function () {
                    return this.confirmationDialog;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderQueryTree.prototype.getSelectedNodes = function () {
                return this.selectedNodes;
            };
            QueryBuilderQueryTree.prototype.setSelectedNodes = function (id, node) {
                this.selectedNodes[id] = node;
            };
            QueryBuilderQueryTree.prototype.getNode = function (id) {
                return this.idToNodeMap[id];
            };
            QueryBuilderQueryTree.prototype.nodeExists = function (id) {
                if (!id)
                    return false;
                if (this.idToNodeMap[id])
                    return true;
                return false;
            };
            QueryBuilderQueryTree.prototype.getNodeById = function (id) {
                if (!id)
                    return null;
                if (this.idToNodeMap[id])
                    return this.idToNodeMap[id];
                return null;
            };
            Object.defineProperty(QueryBuilderQueryTree.prototype, "Properties", {
                get: function () {
                    return this.properties;
                },
                set: function (properties) {
                    this.properties = properties;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTree, "IsSimpleMode", {
                get: function () {
                    if (this.Mode === QueryBuilder.Constants.Mode.Simple) {
                        return true;
                    }
                    return false;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderQueryTree.prototype.onChange = function (event) {
                new QueryBuilder.QueryTreeValidationService().validate(this, this.usageContext);
                this.notifyAll(event);
                switch (this.options.NotifyOutputChangeOn) {
                    case QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.OutputChange:
                        this.outputChanged();
                        break;
                    case QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.ValidOutputChange:
                        if (!this.hasErrors) {
                            this.outputChanged();
                        }
                        break;
                    default:
                        break;
                }
                QueryBuilder.QueryBuilderControl.rerenderControl(this.Context);
            };
            QueryBuilderQueryTree.prototype.outputChanged = function () {
                if (this.notifyOutputChanged) {
                    this.notifyOutputChanged(this.getConverterOutput());
                }
            };
            QueryBuilderQueryTree.prototype.getConverterOutput = function () {
                var outputConverter = new QueryBuilder.OutputConverterRegistry().getConverter(this.UsageContext);
                return outputConverter.convert(this);
            };
            QueryBuilderQueryTree.prototype.onDestroy = function (event) {
                this.notifyAll(event);
            };
            QueryBuilderQueryTree.prototype.updateIdToNodeMap = function (id, node) {
                this.idToNodeMap[id] = node;
            };
            QueryBuilderQueryTree.prototype.addConditionNode = function (parentId) {
                var parentNode = this.idToNodeMap[parentId];
                var childNode = new QueryBuilder.QueryBuilderConditionNode(this.context, QueryBuilder.Utils.newGuid(), this);
                parentNode.addChild(childNode);
                this.idToNodeMap[childNode.Id] = childNode;
                return childNode.Id;
            };
            QueryBuilderQueryTree.prototype.addLinkedEntityNode = function (parentId, linkedEntityData) {
                var childNode = this.createLinkedEntityNode(linkedEntityData);
                if (parentId == undefined || parentId == null || parentId == "") {
                    this.addLinkedEntity(childNode);
                }
                else {
                    var parentNode = this.idToNodeMap[parentId];
                    if (parentNode.NodeType == QueryBuilder.Constants.QueryTreeNodeType.LinkedEntity) {
                        childNode.Parent = parentNode;
                        childNode.Depth = parentNode.Depth + 1;
                        parentNode.LinkedEntities.push(childNode);
                    }
                    else {
                        return;
                    }
                }
                childNode.Root = this.createLogicalGroupNode(QueryBuilder.Constants.QueryTreeNodeType.AND);
                childNode.Root.Depth = childNode.Depth + 1;
                return childNode.Id;
            };
            QueryBuilderQueryTree.prototype.addLinkedEntity = function (childLinkedEntity, index) {
                childLinkedEntity.Parent = null;
                childLinkedEntity.Depth = 0;
                if (index == undefined) {
                    this.LinkedEntities.push(childLinkedEntity);
                }
                else {
                    this.LinkedEntities.splice(index, 0, childLinkedEntity);
                }
            };
            QueryBuilderQueryTree.prototype.getLinkedEntity = function (linkedEntities, fromEntityLogicalName, fromAttributeLogicalName) {
                for (var i = 0; i < linkedEntities.length; i++) {
                    if (linkedEntities[i].LinkedEntityData.FromEntityLogicalName == fromEntityLogicalName &&
                        linkedEntities[i].LinkedEntityData.FromAttributeLogicalName == fromAttributeLogicalName) {
                        return linkedEntities[i].Id;
                    }
                }
                return undefined;
            };
            QueryBuilderQueryTree.prototype.groupAND = function (ids) {
                return this.group(ids, QueryBuilder.Constants.QueryTreeNodeType.AND);
            };
            QueryBuilderQueryTree.prototype.groupOR = function (ids) {
                return this.group(ids, QueryBuilder.Constants.QueryTreeNodeType.OR);
            };
            QueryBuilderQueryTree.prototype.group = function (ids, groupType, collapse) {
                if (collapse === void 0) { collapse = false; }
                if (ids == undefined || ids.length == 0) {
                    this.clearSelectedNodes();
                    return;
                }
                if (ids.length == 1) {
                    var node_1 = this.getNode(ids[0]);
                    if (node_1) {
                        if (node_1.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND && groupType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                            node_1.NodeType = QueryBuilder.Constants.QueryTreeNodeType.OR;
                        }
                        else if (node_1.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR && groupType == QueryBuilder.Constants.QueryTreeNodeType.AND) {
                            node_1.NodeType = QueryBuilder.Constants.QueryTreeNodeType.AND;
                        }
                    }
                    this.clearSelectedNodes();
                    return;
                }
                if (!this.canBeGrouped(ids)) {
                    this.clearSelectedNodes();
                    return;
                }
                var parent = this.getNode(ids[0]).Parent;
                var node = this.createLogicalGroupNode(groupType);
                var orderedIds = [];
                var _loop_1 = function (child) {
                    if (ids.filter(function (x) { return x == child.Id; })[0]) {
                        orderedIds.push(child.Id);
                    }
                };
                for (var _i = 0, _a = parent.Children; _i < _a.length; _i++) {
                    var child = _a[_i];
                    _loop_1(child);
                }
                var position = parent.Children.indexOf(parent.Children.filter(function (x) { return x.Id == orderedIds[0]; })[0]);
                parent.Children.splice(position, 0, node);
                node.Parent = parent;
                node.Depth = parent.Depth + 1;
                var _loop_2 = function (id) {
                    var childIndex = parent.Children.indexOf(parent.Children.filter(function (x) { return x.Id == id; })[0]);
                    parent.Children.splice(childIndex, 1);
                    node.addChild(this_1.idToNodeMap[id]);
                    if (collapse) {
                        this_1.unGroup(id);
                    }
                };
                var this_1 = this;
                for (var _b = 0, orderedIds_1 = orderedIds; _b < orderedIds_1.length; _b++) {
                    var id = orderedIds_1[_b];
                    _loop_2(id);
                }
                this.updateSubtreeDepth(node);
                this.idToNodeMap[node.Id] = node;
                this.clearSelectedNodes();
                return node.Id;
            };
            QueryBuilderQueryTree.prototype.canBeGrouped = function (ids) {
                var parent = this.getNode(ids[0]).Parent;
                if (!parent)
                    return false;
                for (var i = 1; i < ids.length; i++) {
                    var node = this.getNode(ids[i]);
                    if (!node || !node.Parent)
                        return false;
                    if (parent.Id != node.Parent.Id) {
                        return false;
                    }
                }
                return true;
            };
            QueryBuilderQueryTree.prototype.updateSubtreeDepth = function (node) {
                if (node == null || node == undefined) {
                    return;
                }
                if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.LinkedEntity) {
                    node.Root.Depth = node.Depth + 1;
                    this.updateSubtreeDepth(node.Root);
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        linkedEntity.Depth = node.Depth + 1;
                        this.updateSubtreeDepth(linkedEntity);
                    }
                }
                else {
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND || node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        for (var _b = 0, _c = node.Children; _b < _c.length; _b++) {
                            var child = _c[_b];
                            child.Depth = node.Depth + 1;
                            this.updateSubtreeDepth(child);
                        }
                    }
                }
            };
            QueryBuilderQueryTree.prototype.unGroup = function (id) {
                var node = this.getNode(id);
                if (!(node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND) && !(node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR)) {
                    this.clearSelectedNodes();
                    return;
                }
                var parent = node.Parent;
                if (parent) {
                    var children = node.Children;
                    var position = parent.Children.indexOf(parent.Children.filter(function (x) { return x.Id == id; })[0]);
                    parent.Children[position] = children[0];
                    children[0].Parent = parent;
                    children[0].Depth = parent.Depth + 1;
                    this.updateSubtreeDepth(children[0]);
                    for (var i = 1; i < children.length; i++) {
                        parent.addChild(children[i], ++position);
                        this.updateSubtreeDepth(children[i]);
                    }
                    delete this.idToNodeMap[node.Id];
                }
                this.clearSelectedNodes();
            };
            QueryBuilderQueryTree.prototype.delete = function (ids) {
                var _this = this;
                if (ids.length == 0) {
                    return;
                }
                ids.sort(function (id1, id2) {
                    return _this.getNode(id1).Depth > _this.getNode(id2).Depth ? 1 : -1;
                });
                for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                    var id = ids_1[_i];
                    var node = this.getNode(id);
                    if (node) {
                        if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.LinkedEntity) {
                            this.deleteLinkedEntityNode(node);
                        }
                        else {
                            this.deleteNode(node);
                        }
                    }
                }
                this.clearSelectedNodes();
            };
            QueryBuilderQueryTree.prototype.clearSelectedNodes = function () {
                this.selectedNodes = {};
            };
            QueryBuilderQueryTree.prototype.deleteLinkedEntityNode = function (node) {
                var parent = node.Parent;
                if (parent != null || parent != undefined) {
                    var childIndex = parent.LinkedEntities.indexOf(node);
                    parent.LinkedEntities.splice(childIndex, 1);
                }
                else {
                    var childIndex = this.LinkedEntities.indexOf(node);
                    this.LinkedEntities.splice(childIndex, 1);
                }
                if (node.Root) {
                    this.deleteSubtree(node.Root);
                }
                if (node.LinkedEntities) {
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.deleteLinkedEntityNode(linkedEntity);
                    }
                }
                delete this.idToNodeMap[node.Id];
            };
            QueryBuilderQueryTree.prototype.deleteNode = function (node) {
                if (node) {
                    var parent_1 = node.Parent;
                    if (parent_1) {
                        var childIndex = parent_1.Children.indexOf(node);
                        parent_1.Children.splice(childIndex, 1);
                        if (node.NodeType === QueryBuilder.Constants.QueryTreeNodeType.OR || node.NodeType === QueryBuilder.Constants.QueryTreeNodeType.AND) {
                            this.deleteSubtree(node);
                        }
                        else {
                            delete this.idToNodeMap[node.Id];
                        }
                        if (parent_1 != null && parent_1.Children.length == 0 && parent_1.Parent != null) {
                            this.deleteNode(parent_1);
                        }
                        if (parent_1 != null && parent_1.Children.length == 1) {
                            if (parent_1.Parent != null) {
                                var child = parent_1.Children[0];
                                var position = parent_1.Parent.Children.indexOf(parent_1);
                                parent_1.Parent.Children[position] = child;
                                child.Parent = parent_1.Parent;
                                delete this.idToNodeMap[parent_1.Id];
                            }
                        }
                    }
                }
            };
            QueryBuilderQueryTree.prototype.deleteSubtree = function (node) {
                if (node) {
                    if (node.NodeType === QueryBuilder.Constants.QueryTreeNodeType.OR || node.NodeType === QueryBuilder.Constants.QueryTreeNodeType.AND) {
                        for (var _i = 0, _a = node.Children; _i < _a.length; _i++) {
                            var child = _a[_i];
                            this.deleteSubtree(child);
                        }
                    }
                    delete this.idToNodeMap[node.Id];
                }
            };
            QueryBuilderQueryTree.prototype.collapseGroupAND = function (ids) {
                return this.group(ids, QueryBuilder.Constants.QueryTreeNodeType.AND, true);
            };
            QueryBuilderQueryTree.prototype.collapseGroupOR = function (ids) {
                return this.group(ids, QueryBuilder.Constants.QueryTreeNodeType.OR, true);
            };
            QueryBuilderQueryTree.prototype.clearTree = function () {
                for (var _i = 0, _a = this.Root.Children; _i < _a.length; _i++) {
                    var child = _a[_i];
                    this.deleteSubtree(child);
                }
                this.Root.Children = [];
                for (var _b = 0, _c = this.LinkedEntities; _b < _c.length; _b++) {
                    var child = _c[_b];
                    this.deleteLinkedEntityNode(child);
                }
                this.LinkedEntities = [];
                if (this.options.LinkedEntityEnabled && this.addRelatedEntityButton.isRelatedEntityControlVisible()) {
                    this.addRelatedEntityButton.hideRelatedEntityControl();
                }
                if (this.Root.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR &&
                    this.Options.ShowRootNode == QueryBuilder.Constants.ShowQueryTreeRoot.OnlyIfOR) {
                    this.Root.NodeType = QueryBuilder.Constants.QueryTreeNodeType.AND;
                }
                this.clearSelectedNodes();
            };
            QueryBuilderQueryTree.prototype.clearLinkedEntity = function (id) {
                var node = this.getNode(id);
                if (node) {
                    for (var _i = 0, _a = node.Root.Children; _i < _a.length; _i++) {
                        var child = _a[_i];
                        this.deleteSubtree(child);
                    }
                    node.Root.Children = [];
                    for (var _b = 0, _c = node.LinkedEntities; _b < _c.length; _b++) {
                        var child = _c[_b];
                        this.deleteLinkedEntityNode(child);
                    }
                    node.LinkedEntities = [];
                    if (node.AddRelatedEntityButton.isRelatedEntityControlVisible()) {
                        node.AddRelatedEntityButton.hideRelatedEntityControl();
                    }
                }
            };
            QueryBuilderQueryTree.prototype.registerObserver = function (observer) {
                this.observers.push(observer);
            };
            QueryBuilderQueryTree.prototype.notifyAll = function (event) {
                var queryTree = this;
                this.observers.forEach(function (observer) {
                    try {
                        observer.handleQueryTreeEvent(queryTree, event);
                    }
                    catch (error) {
                    }
                });
            };
            QueryBuilderQueryTree.prototype.onError = function (error) {
                this.notifyError(error);
            };
            QueryBuilderQueryTree.prototype.notifyError = function (error) {
                var telemetryEventHandler = new QueryBuilder.TelemetryEventHandlerRegistry().getHandler(this.usageContext);
                if (telemetryEventHandler) {
                    try {
                        telemetryEventHandler.handleErrorEvent(this, error);
                    }
                    catch (error) {
                    }
                }
            };
            QueryBuilderQueryTree.prototype.showOrHideinSimpleMode = function (selectedNode) {
                selectedNode.Condition.IsVisibleInSimpleMode = !selectedNode.Condition.IsVisibleInSimpleMode;
                this.clearSelectedNodes();
            };
            QueryBuilderQueryTree.prototype.isVisibleInSimpleMode = function (selectedNode) {
                return selectedNode.Condition.IsVisibleInSimpleMode;
            };
            QueryBuilderQueryTree.prototype.renderQueryBuilderFilters = function () {
                return this.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFilterStyle(this.Context.theming),
                }, [this.renderQueryBuilderFiltersSection()]);
            };
            QueryBuilderQueryTree.prototype.renderQueryBuilderFiltersSection = function () {
                this.ShowErrorIfNoConditionsInSimpleMode = true;
                return this.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFilterSectionStyle(this.Context.theming),
                }, this.renderQueryTree().concat(this.renderLinkedEntities(), this.renderErrorInSimpleMode()));
            };
            QueryBuilderQueryTree.prototype.renderQueryTree = function () {
                var outputView = new Array();
                if (QueryBuilderQueryTree.IsSimpleMode) {
                    outputView.push(this.Root.getSimpleView());
                }
                else {
                    outputView.push(this.Root.getView(this.options.LinkedEntityEnabled ? this.addRelatedEntityButton : null));
                }
                return outputView;
            };
            QueryBuilderQueryTree.prototype.renderLinkedEntities = function () {
                var outputView = new Array();
                for (var _i = 0, _a = this.linkedEntities; _i < _a.length; _i++) {
                    var linkedNode = _a[_i];
                    if (QueryBuilderQueryTree.IsSimpleMode) {
                        linkedNode.computeRenderableHearedInSimpleMode();
                    }
                    outputView.push(linkedNode.getView());
                }
                return outputView;
            };
            QueryBuilderQueryTree.prototype.renderErrorInSimpleMode = function () {
                var outputView = new Array();
                if (QueryBuilderQueryTree.IsSimpleMode && this.ShowErrorIfNoConditionsInSimpleMode) {
                    var label = this.Context.factory.createElement("CONTAINER", {
                        id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getSimpleModeErrorId(),
                        key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getSimpleModeErrorId(),
                        tabIndex: 0,
                        role: "presentation",
                        accessibilityLabel: QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SHOW_ERROR_IF_NO_CONDITION),
                        style: QueryBuilder.QueryBuilderStyle.EmptyFilterSectionSimpleModeStyle(this.Context.theming),
                    }, [QueryBuilder.Utils.getResourceString(this.context, QueryBuilder.LocalizedStrings.SHOW_ERROR_IF_NO_CONDITION)]);
                    outputView.push(label);
                    return outputView;
                }
                return null;
            };
            QueryBuilderQueryTree.prototype.renderSimple = function (root) {
                if (QueryBuilderQueryTree.IsSimpleMode) {
                    QueryBuilderQueryTree.Mode = QueryBuilder.Constants.Mode.Advanced;
                }
                else {
                    QueryBuilderQueryTree.Mode = QueryBuilder.Constants.Mode.Simple;
                }
                this.clearSelectedNodes();
                this.context.utils.requestRender();
            };
            return QueryBuilderQueryTree;
        }());
        QueryBuilder.QueryBuilderQueryTree = QueryBuilderQueryTree;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderAddConditionButton = (function () {
            function QueryBuilderAddConditionButton(queryTree, parentId, addSectionHandler, isHidden) {
                this.queryTree = queryTree;
                this.parentId = parentId;
                this.addSectionHandler = addSectionHandler;
                this.isHidden = isHidden;
                this.buttonType = QueryBuilder.Constants.AddNodeButtonType.AddFilter;
            }
            QueryBuilderAddConditionButton.prototype.getButton = function () {
                var self = this;
                var buttonText = QueryBuilder.Utils.getResourceString(self.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_CONDITION);
                var idKey = self.parentId + "Filter";
                var iconKey = self.parentId + "relatedEntityConditionIcon";
                var addFilterIcon = this.queryTree.Context.factory.createElement("MICROSOFTICON", {
                    id: iconKey,
                    key: iconKey,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderLabelIconStyle(this.queryTree.Context.theming),
                    type: 187,
                });
                return this.queryTree.Context.factory.createElement("BUTTON", {
                    id: idKey,
                    key: idKey,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderLinkButtonStyle(self.queryTree.Context.theming),
                    accessibilityLabel: QueryBuilder.Utils.getResourceString(self.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_FILTER),
                    tabIndex: 0,
                    hidden: self.isHidden,
                    onClick: function (e) {
                        var nodeId = self.addSectionHandler(self.parentId);
                        e.preventDefault();
                        e.stopPropagation();
                    },
                    title: QueryBuilder.Utils.getResourceString(self.queryTree.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_ADD_FILTER),
                }, [addFilterIcon, buttonText]);
            };
            QueryBuilderAddConditionButton.prototype.getView = function () {
                return this.queryTree.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFilterLinkContainerStyle(this.queryTree.Context.theming),
                }, this.getButton());
            };
            return QueryBuilderAddConditionButton;
        }());
        QueryBuilder.QueryBuilderAddConditionButton = QueryBuilderAddConditionButton;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderLogicalGroupNode = (function (_super) {
            __extends(QueryBuilderLogicalGroupNode, _super);
            function QueryBuilderLogicalGroupNode(context, id, tree, nodeType) {
                var _this = _super.call(this, context, id, tree) || this;
                _this.NodeType = nodeType;
                _this.children = [];
                _this.addConditionButton = new QueryBuilder.QueryBuilderAddConditionButton(tree, _this.Id, _this.ContainerTree.addSectionHandler);
                return _this;
            }
            Object.defineProperty(QueryBuilderLogicalGroupNode.prototype, "Children", {
                get: function () {
                    return this.children;
                },
                set: function (value) {
                    this.children = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLogicalGroupNode.prototype, "Parent", {
                get: function () {
                    return this.parent;
                },
                set: function (value) {
                    this.parent = value;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderLogicalGroupNode.prototype.addChild = function (child, index) {
                child.Parent = this;
                child.Depth = this.Depth + 1;
                if (index == undefined) {
                    this.children.push(child);
                }
                else {
                    this.children.splice(index, 0, child);
                }
            };
            QueryBuilderLogicalGroupNode.prototype.getSimpleView = function () {
                var components = new Array();
                this.getConditions(components);
                var childView = new Array();
                for (var _i = 0, components_1 = components; _i < components_1.length; _i++) {
                    var child = components_1[_i];
                    if (child.Condition.IsVisibleInSimpleMode &&
                        !QueryBuilder.AdvancedFindUtils.hasErrorInAttrAndOperator(child.Condition.ControlDefinitions)) {
                        var childListItem = this.Context.factory.createElement("LISTITEM", {
                            id: "conditionItem_" + child.Id,
                            key: "conditionItem_" + child.Id,
                            role: "listitem",
                            tabIndex: -1,
                            style: QueryBuilder.QueryBuilderStyle.GroupNodeChildListItemStyle(this.Context.theming),
                        }, child.getView());
                        childView.push(childListItem);
                    }
                }
                if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode && childView.length > 0) {
                    this.ContainerTree.ShowErrorIfNoConditionsInSimpleMode = false;
                }
                if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode && childView.length == 0) {
                    return null;
                }
                return this.Context.factory.createElement("LIST", {
                    id: "allConditions_" + this.Id,
                    key: "allConditions_" + this.Id,
                    tabIndex: -1,
                    role: "list",
                    style: { flexDirection: "column" },
                }, childView);
            };
            QueryBuilderLogicalGroupNode.prototype.getConditions = function (components) {
                for (var _i = 0, _a = this.Children; _i < _a.length; _i++) {
                    var child = _a[_i];
                    if (child.NodeType === QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                        components.push(child);
                    }
                    else {
                        child.getConditions(components);
                    }
                }
            };
            QueryBuilderLogicalGroupNode.prototype.getView = function (addRelatedEnityButton) {
                var rootView;
                switch (this.ContainerTree.Options.ShowRootNode) {
                    case QueryBuilder.Constants.ShowQueryTreeRoot.Always:
                        rootView = this.getLogicalGroupView();
                        break;
                    case QueryBuilder.Constants.ShowQueryTreeRoot.Never:
                        rootView = null;
                        break;
                    case QueryBuilder.Constants.ShowQueryTreeRoot.OnlyIfOR:
                        if (this.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                            rootView = this.getLogicalGroupView();
                        }
                        else {
                            rootView = null;
                        }
                        break;
                    default:
                        rootView = null;
                        break;
                }
                var logicalGroupView = this.Parent ? this.getLogicalGroupView() : rootView;
                var childView = new Array();
                for (var _i = 0, _a = this.Children; _i < _a.length; _i++) {
                    var child = _a[_i];
                    var childListItem = this.Context.factory.createElement("LISTITEM", {
                        id: "groupChild_" + child.Id,
                        key: "groupChild_" + child.Id,
                        role: "treeitem",
                        tabIndex: 0,
                        accessibilityLabel: "User Configured Filter",
                        style: QueryBuilder.QueryBuilderStyle.GroupNodeChildListItemStyle(this.Context.theming),
                    }, child.getView());
                    childView.push(childListItem);
                }
                if (this.ContainerTree) {
                    childView.push(this.ContainerTree.Context.factory.createElement("LISTITEM", {
                        id: "addButtons_" + this.Id,
                        key: "addButtons_" + this.Id,
                        role: "treeitem",
                        tabIndex: 0,
                        style: QueryBuilder.QueryBuilderStyle.AddButtonsContainerStyle(this.Context.theming, this.Context.client.isRTL),
                    }, [this.addConditionButton.getView(), addRelatedEnityButton ? addRelatedEnityButton.getView() : null]));
                }
                var childViewContainer = this.ContainerTree.Context.factory.createElement("CONTAINER", {
                    id: "allConditionsContainer_" + this.Id,
                    key: "allConditionsContainer_" + this.Id,
                    role: "presentation",
                    style: QueryBuilder.QueryBuilderStyle.ConditionListContainerStyle(this.Context.theming, this.Context.client.isRTL),
                }, childView);
                return this.Context.factory.createElement("LIST", {
                    id: "groupNode_" + this.Id,
                    key: "groupNode_" + this.Id,
                    role: !this.Parent ? "tree" : "group",
                    style: QueryBuilder.QueryBuilderStyle.GroupNodeListStyle(this.Context.theming, !this.Parent, this.isMarginBottomNotRequired()),
                }, [logicalGroupView, childViewContainer]);
            };
            QueryBuilderLogicalGroupNode.prototype.isMarginBottomNotRequired = function () {
                var container = this.getNodeContainer();
                return (!this.Parent &&
                    container.Properties[QueryBuilder.QueryBuilderConstants.CONTAINER_TYPE] === QueryBuilder.Constants.RootNodeContainerType.LinkedEntity &&
                    (!container.LinkedEntities ||
                        !container.LinkedEntities.length));
            };
            QueryBuilderLogicalGroupNode.prototype.getLogicalGroupView = function () {
                var checkboxIdKey = this.getFirstFocusableElementId();
                return this.Context.factory.createElement("CONTAINER", {
                    id: "groupView_" + this.Id,
                    key: "groupView_" + this.Id,
                    role: "presentation",
                    style: this.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND
                        ? QueryBuilder.QueryBuilderStyle.GroupAndViewConatinerStyle(this.Context.theming, this.Context.client.isRTL)
                        : QueryBuilder.QueryBuilderStyle.GroupOrViewConatinerStyle(this.Context.theming, this.Context.client.isRTL),
                }, [this.getCheckbox(checkboxIdKey), this.getQueryBuilderLogicalLabel(checkboxIdKey)]);
            };
            QueryBuilderLogicalGroupNode.prototype.getQueryBuilderLogicalLabel = function (checkboxIdKey) {
                var logicalGroupName;
                if (this.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND) {
                    logicalGroupName = QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_AND_STRING);
                }
                else if (this.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                    logicalGroupName = QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_OR_STRING);
                }
                return this.Context.factory.createElement("LABEL", {
                    id: "groupLabel_" + logicalGroupName + "_" + this.Id,
                    key: "groupLabel_" + logicalGroupName + "_" + this.Id,
                    forElementId: QueryBuilder.ComponentIdPrefixesAndSuffixes.getQueryBuilderControlPrefix() + checkboxIdKey,
                    accessibilityLabel: logicalGroupName,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderLogicalLabelStyle(this.Context.theming),
                }, [logicalGroupName]);
            };
            QueryBuilderLogicalGroupNode.prototype.getFirstFocusableElementId = function () {
                return QueryBuilder.ComponentIdPrefixesAndSuffixes.groupNodeCheckboxPrefix() + this.Id;
            };
            return QueryBuilderLogicalGroupNode;
        }(QueryBuilder.QueryBuilderQueryNode));
        QueryBuilder.QueryBuilderLogicalGroupNode = QueryBuilderLogicalGroupNode;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderConditionNode = (function (_super) {
            __extends(QueryBuilderConditionNode, _super);
            function QueryBuilderConditionNode(context, id, tree, condition) {
                var _this = _super.call(this, context, id, tree) || this;
                _this.NodeType = QueryBuilder.Constants.QueryTreeNodeType.Condition;
                _this._condition = condition ? condition : new QueryBuilder.Condition(_this, null, id);
                return _this;
            }
            Object.defineProperty(QueryBuilderConditionNode.prototype, "Condition", {
                get: function () {
                    return this._condition;
                },
                set: function (condition) {
                    this._condition = condition;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderConditionNode.prototype, "Parent", {
                get: function () {
                    return this.parent;
                },
                set: function (value) {
                    this.parent = value;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderConditionNode.prototype.initialize = function () {
                this._condition.initialize();
            };
            QueryBuilderConditionNode.prototype.getView = function () {
                var nodeHasError = this.Errors.length > 0;
                var checkboxIdKey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionNodeCheckboxPrefix() + this.Id;
                var checkBox = QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? null : this.getCheckbox(checkboxIdKey);
                var conditionNode = this.Context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionIdPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionIdPrefix() + this.Id,
                    style: QueryBuilder.QueryBuilderStyle.ConditionNodeConatinerStyle(this.Context.theming),
                }, [checkBox, this.Condition.getView()]);
                var conditionErrors = this.Context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionErrorsPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionErrorsPrefix() + this.Id,
                    style: QueryBuilder.QueryBuilderStyle.ConditionErrorConatinerStyle(this.Context.theming),
                }, this.Condition.getConditionErrorView());
                return this.Context.factory.createElement("CONTAINER", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionNodeAndErrorsContainerPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionNodeAndErrorsContainerPrefix() + this.Id,
                    style: QueryBuilder.QueryBuilderStyle.ConditionNodeWrapConatinerStyle(this.Context.theming, nodeHasError, this.Context.client.isRTL),
                }, [
                    conditionNode,
                    conditionErrors,
                    QueryBuilder.QueryBuilderQueryTree.IsSimpleMode ? null : this.getHiddenLabelForConditionCheckbox(checkboxIdKey),
                ]);
            };
            QueryBuilderConditionNode.prototype.getHiddenLabelForConditionCheckbox = function (checkboxIdKey) {
                return this.Context.factory.createElement("LABEL", {
                    id: "label-for-" + checkboxIdKey,
                    key: "label-for-" + checkboxIdKey,
                    style: {
                        position: "absolute",
                        left: "-1000px",
                        right: "-1000px",
                        height: "0px",
                        width: "0px",
                    },
                    forElementId: QueryBuilder.ComponentIdPrefixesAndSuffixes.getQueryBuilderControlPrefix() + checkboxIdKey,
                    accessibilityLabel: QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_CONDITION),
                }, [QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LS_QUERYBUILDER_CONDITION)]);
            };
            return QueryBuilderConditionNode;
        }(QueryBuilder.QueryBuilderQueryNode));
        QueryBuilder.QueryBuilderConditionNode = QueryBuilderConditionNode;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderLinkedEntityNode = (function (_super) {
            __extends(QueryBuilderLinkedEntityNode, _super);
            function QueryBuilderLinkedEntityNode(context, id, tree, linkedEntityData) {
                var _this = _super.call(this, context, id, tree) || this;
                _this.isFlyoutVisible = false;
                _this.containsData = true;
                _this.showHeaderInSimpleMode = false;
                _this.NodeType = QueryBuilder.Constants.QueryTreeNodeType.LinkedEntity;
                _this.linkedEntityData = linkedEntityData;
                _this.linkedEntities = [];
                if (linkedEntityData) {
                    _this.properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES] = {
                        name: linkedEntityData.FromEntityLogicalName,
                        from: linkedEntityData.FromAttributeLogicalName,
                        to: linkedEntityData.ToAttributeLogicalName,
                        alias: "" + linkedEntityData.ToEntityLogicalName + linkedEntityData.ToAttributeLogicalName + linkedEntityData.FromEntityLogicalName + linkedEntityData.FromAttributeLogicalName,
                        "link-type": linkedEntityData.LinkType,
                    };
                    if (linkedEntityData.IsIntersect) {
                        _this.properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES][QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_INTERSECT] = true;
                        _this.properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES][QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_VISIBLE] = false;
                    }
                }
                _this.addRelatedEntityButton = new QueryBuilder.QueryBuilderAddLinkedEntityButton(_this.ContainerTree, _this.ContainerTree.UsageContext, _this.Id, _this, _this.ContainerTree.addRelatedEntityHandler);
                return _this;
            }
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "Parent", {
                get: function () {
                    return this.parent;
                },
                set: function (value) {
                    this.parent = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "LinkedEntityData", {
                get: function () {
                    return this.linkedEntityData;
                },
                set: function (linkedEntityData) {
                    this.linkedEntityData = linkedEntityData;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "ContainsData", {
                get: function () {
                    return this.containsData;
                },
                set: function (value) {
                    this.containsData = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "Root", {
                get: function () {
                    return this.root;
                },
                set: function (value) {
                    this.root = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "LinkedEntities", {
                get: function () {
                    return this.linkedEntities;
                },
                set: function (value) {
                    this.linkedEntities = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderLinkedEntityNode.prototype, "AddRelatedEntityButton", {
                get: function () {
                    return this.addRelatedEntityButton;
                },
                enumerable: true,
                configurable: true
            });
            QueryBuilderLinkedEntityNode.prototype.addLinkedEntity = function (childLinkedEntity, index) {
                childLinkedEntity.Parent = this;
                childLinkedEntity.Depth = this.Depth + 1;
                if (index == undefined) {
                    this.LinkedEntities.push(childLinkedEntity);
                }
                else {
                    this.LinkedEntities.splice(index, 0, childLinkedEntity);
                }
            };
            QueryBuilderLinkedEntityNode.prototype.getView = function () {
                if (!this.linkedEntityData.IsVisible && !this.linkedEntityData.IsIntersect) {
                    return null;
                }
                var linkedEntityNode = this.linkedEntityData.IsIntersect
                    ? this.linkedEntities[0]
                    : this;
                var linkedEntityHeader = linkedEntityNode.getLinkedEntityHeader();
                var linkedEntityView = linkedEntityNode.getLinkedEntitiesView();
                if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode && !this.showHeaderInSimpleMode) {
                    return null;
                }
                return this.Context.factory.createElement("CONTAINER", {
                    id: "relatedView_" + linkedEntityNode.Id,
                    key: "relatedView_" + linkedEntityNode.Id,
                    style: QueryBuilder.QueryBuilderStyle.RelatedEntityConatinerStyle(linkedEntityNode.Context.theming, linkedEntityNode.Context.client.isRTL),
                }, [linkedEntityHeader].concat(linkedEntityView));
            };
            QueryBuilderLinkedEntityNode.prototype.getLinkedEntitiesView = function () {
                var outputView = new Array();
                if (this.containsData) {
                    var rootView = QueryBuilder.QueryBuilderQueryTree.IsSimpleMode
                        ? this.Root.getSimpleView()
                        : this.Root.getView(this.addRelatedEntityButton);
                    outputView.push(rootView);
                    for (var _i = 0, _a = this.linkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        outputView.push(linkedEntity.getView());
                    }
                }
                else {
                    var icon = this.Context.factory.createElement("MICROSOFTICON", {
                        id: "MYICON" + "_" + QueryBuilder.Utils.newGuid(),
                        key: "MYICON" + "_" + QueryBuilder.Utils.newGuid(),
                        type: 181,
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderGetEntityIconStyle(this.Context.theming),
                    });
                    var label = this.Context.factory.createElement("LABEL", {
                        id: "label" + "_" + this.Id,
                        key: "label" + "_" + this.Id,
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderGetEntitylabeltStyle(this.Context.theming),
                    }, [QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LINKED_ENTITY_DOESNOT_CONTAIN_DATA_VIEW)]);
                    var doesNotContainDataView = this.Context.factory.createElement("CONTAINER", {
                        id: "doesNotContainDataSection_" + this.Id,
                        key: "doesNotContainDataSection_" + this.Id,
                        style: QueryBuilder.QueryBuilderStyle.QueryBuilderGetEntityContainerStyle(this.Context.theming),
                    }, [icon, label]);
                    outputView.push(doesNotContainDataView);
                }
                return outputView;
            };
            QueryBuilderLinkedEntityNode.prototype.computeRenderableHearedInSimpleMode = function () {
                this.showHeaderInSimpleMode = false;
                var components = new Array();
                this.Root.getConditions(components);
                for (var _i = 0, components_2 = components; _i < components_2.length; _i++) {
                    var child = components_2[_i];
                    if (child.Condition.IsVisibleInSimpleMode &&
                        !QueryBuilder.AdvancedFindUtils.hasErrorInAttrAndOperator(child.Condition.ControlDefinitions)) {
                        this.showHeaderInSimpleMode = true;
                    }
                }
                for (var _a = 0, _b = this.LinkedEntities; _a < _b.length; _a++) {
                    var linkedEntity = _b[_a];
                    var showChild = linkedEntity.computeRenderableHearedInSimpleMode();
                    if (!this.showHeaderInSimpleMode) {
                        this.showHeaderInSimpleMode = showChild;
                    }
                }
                return this.showHeaderInSimpleMode;
            };
            QueryBuilderLinkedEntityNode.prototype.getFirstFocusableElementId = function () {
                return "linkedEntityHeader_" + this.Id;
            };
            QueryBuilderLinkedEntityNode.prototype.getLinkedEntityHeader = function () {
                return this.Context.factory.createElement("CONTAINER", {
                    id: this.getFirstFocusableElementId(),
                    key: this.getFirstFocusableElementId(),
                    style: QueryBuilder.QueryBuilderStyle.LinkedEntityHeaderConatinerStyle(this.Context.theming),
                }, [
                    !this.containsData ? this.getDoesNotContainContainer() : null,
                    this.getDisplayTextContainer(),
                    this.getDropDownLinkButton(),
                ]);
            };
            QueryBuilderLinkedEntityNode.prototype.getDoesNotContainContainer = function () {
                var self = this;
                var label = this.Context.factory.createElement("LABEL", {
                    id: "label" + "_" + self.Id,
                    key: "label" + "_" + self.Id,
                    style: QueryBuilder.QueryBuilderStyle.RelatedEntityDisplayTextLabelStyle(this.Context.theming),
                }, [QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.LINKED_ENTITY_DOESNOT_CONTAIN_DATA)]);
                var icon = this.Context.factory.createElement("MICROSOFTICON", {
                    id: "MYICON" + "_" + self.Id,
                    key: "MYICON" + "_" + self.Id,
                    type: 9,
                });
                var cancelButton = this.Context.factory.createElement("BUTTON", {
                    id: "cancelButton_" + self.Id,
                    key: "cancelButton_" + self.Id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderEntityIconButtonStyle(this.Context.theming),
                    tabIndex: 0,
                    hidden: false,
                    onClick: function () {
                        self.onCancelButtonClickHandler();
                    },
                    title: "Cancel Does Not Contain Data",
                }, [icon]);
                return this.Context.factory.createElement("CONTAINER", {
                    id: "doesNotContainHeader_" + self.Id,
                    key: "doesNotContainHeader_" + self.Id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderEntityHeaderStyle(this.Context.theming),
                }, [label, cancelButton]);
            };
            QueryBuilderLinkedEntityNode.prototype.getDisplayText = function () {
                if (this.linkedEntityData.NoDisplayName)
                    return " ";
                switch (this.linkedEntityData.RelationshipType) {
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.OneToMany:
                        return this.linkedEntityData.FromEntityDisplayName && this.linkedEntityData.FromAttributeDisplayName
                            ? this.linkedEntityData.FromEntityDisplayName + " (" + this.linkedEntityData.FromAttributeDisplayName + ")"
                            : this.linkedEntityData.FromEntityLogicalName + " (" + this.linkedEntityData.FromAttributeLogicalName + ")";
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToOne:
                        return this.linkedEntityData.ToAttributeDisplayName && this.linkedEntityData.FromEntityDisplayName
                            ? this.linkedEntityData.ToAttributeDisplayName + " (" + this.linkedEntityData.FromEntityDisplayName + ")"
                            : this.linkedEntityData.ToAttributeLogicalName + " (" + this.linkedEntityData.FromEntityLogicalName + ")";
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany:
                        return this.linkedEntityData.FromEntityDisplayName && this.linkedEntityData.FromAttributeDisplayName
                            ? this.linkedEntityData.FromEntityDisplayName + " (" + this.linkedEntityData.FromAttributeDisplayName + ")"
                            : this.linkedEntityData.FromEntityLogicalName + " (" + this.linkedEntityData.FromAttributeLogicalName + ")";
                    default:
                        throw new Error("Unknown Relationship Type: " + this.linkedEntityData.RelationshipType);
                }
            };
            QueryBuilderLinkedEntityNode.prototype.getDisplayTextContainer = function () {
                var displayText = this.getDisplayText();
                var label = this.Context.factory.createElement("LABEL", {
                    id: "linkedEntityLabel_" + this.Id,
                    key: "linkedEntityLabel_" + this.Id,
                    style: QueryBuilder.QueryBuilderStyle.RelatedEntityDisplayTextLabelStyle(this.Context.theming),
                }, [displayText]);
                var icon = this.Context.factory.createElement("MICROSOFTICON", {
                    id: "MYICON" + "_" + this.Id,
                    key: "MYICON" + "_" + this.Id,
                    type: 72,
                    style: QueryBuilder.QueryBuilderStyle.RelatedEntityDisplayIconLabelStyle(this.Context.theming, this.Context.client.isRTL),
                });
                return this.Context.factory.createElement("CONTAINER", {
                    id: "displayTextHeader_" + this.Id,
                    key: "displayTextHeader_" + this.Id,
                    tabIndex: 0,
                    accessibilityLabel: displayText,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderEntityHeaderSelectStyle(this.Context.theming),
                }, [label, icon]);
            };
            QueryBuilderLinkedEntityNode.prototype.getDropDownLinkButton = function () {
                var _this = this;
                var self = this;
                var idkey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntitySectionElipsisButtonPrefix() + this.Id;
                var iconKey = "addrelatedLinkDropIcon" + this.Id;
                var addrelatedLinkDropIcon = this.ContainerTree.Context.factory.createElement("MICROSOFTICON", {
                    id: iconKey,
                    key: iconKey,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderLabelIconStyle(this.ContainerTree.Context.theming),
                    type: 12,
                });
                return this.ContainerTree.Context.factory.createElement("BUTTON", {
                    id: idkey,
                    key: idkey,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropDownLinkButtonStyle(this.ContainerTree.Context.theming, this.ContainerTree.Context.client.isRTL),
                    accessibilityLabel: "DropDown Button",
                    onClick: function (e) {
                        _this.toggleFlyoutVisibility();
                        e.preventDefault();
                        e.stopPropagation();
                    },
                    onKeyDown: function (event) {
                        if (event.keyCode === 40) {
                            self.Context.accessibility.focusElementById(QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemContainsDataPrefix() + self.Id);
                        }
                    },
                    tabIndex: 0,
                    hidden: false,
                    title: "DropDown Button",
                }, [addrelatedLinkDropIcon, this.isFlyoutVisible ? this.getHeaderFlyout(idkey) : null]);
            };
            QueryBuilderLinkedEntityNode.prototype.getHeaderFlyout = function (forId) {
                var self = this;
                var flyoutDivStyle = {
                    border: " 1px solid #e2e2e2",
                    backgroundColor: "#FFFFFF",
                };
                var flyout = this.Context.factory.createElement("FLYOUT", {
                    id: "headerFlyout_" + forId,
                    key: "headerFlyout_" + forId,
                    relativeToElementId: forId,
                    positionType: "relative",
                    onOutsideClick: function (e) {
                        self.toggleFlyoutVisibility();
                        e.stopPropagation();
                    },
                    flyoutStyle: flyoutDivStyle,
                    flyoutDirection: 7,
                }, this.getListOfButtons());
                return flyout;
            };
            QueryBuilderLinkedEntityNode.prototype.getListOfButtons = function () {
                var _this = this;
                var list = this.Context.factory.createElement("LIST", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListPrefix() + this.Id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListStyle(this.Context.theming),
                    onKeyDown: function (event) {
                        return event.keyCode === 27
                            ? _this.toggleFlyoutVisibility()
                            : event.keyCode === 9
                                ? event.preventDefault()
                                : QueryBuilder.ListAccessibility.keyboardNavigation(event);
                    },
                }, [this.containsDataButton(), this.doesNotContainDataButton(), this.removeButton()]);
                return list;
            };
            QueryBuilderLinkedEntityNode.prototype.removeButton = function () {
                var self = this;
                if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode) {
                    return null;
                }
                var label = this.Context.factory.createElement("LABEL", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutLabelStyle(this.Context.theming),
                }, [QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.LINKED_ENTITY_REMOVE)]);
                var iconContainer = this.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropIconContainerStyle(this.Context.theming),
                }, []);
                return this.Context.factory.createElement("LISTITEM", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemRemovePrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemRemovePrefix() + this.Id,
                    tabIndex: 0,
                    style: Object.assign({}, QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListItemStyle(this.Context.theming), {
                        borderTopWidth: "1px",
                        borderTopStyle: "solid",
                        borderTopColor: this.Context.theming.colors.grays.gray03,
                    }),
                    onClick: function () {
                        self.ContainerTree.ConfirmationDialog.ShowConfirmationDialog(QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_TITLE_DELETE), QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY), self.onDeleteClickHandler.bind(self));
                    },
                }, [iconContainer, label]);
            };
            QueryBuilderLinkedEntityNode.prototype.containsDataButton = function () {
                var self = this;
                var label = this.Context.factory.createElement("LABEL", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutLabelStyle(this.Context.theming),
                }, [QueryBuilder.Utils.getResourceString(this.Context, QueryBuilder.LocalizedStrings.LINKED_ENTITY_CONTAINS_DATA)]);
                var icon = this.Context.factory.createElement("MICROSOFTICON", {
                    id: "MYICON" + "_" + this.Id,
                    key: "MYICON" + "_" + this.Id,
                    type: 25,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropDownIcon(this.Context.theming),
                });
                var iconContainer = this.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropIconContainerStyle(this.Context.theming),
                }, []);
                return this.Context.factory.createElement("LISTITEM", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemContainsDataPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemContainsDataPrefix() + this.Id,
                    tabIndex: 0,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListItemStyle(this.Context.theming),
                    onClick: function () {
                        self.onContainsDataClickHandler();
                    },
                }, [self.containsData ? icon : iconContainer, label]);
            };
            QueryBuilderLinkedEntityNode.prototype.doesNotContainDataButton = function () {
                var self = this;
                var label = this.Context.factory.createElement("LABEL", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutLabelStyle(this.Context.theming),
                }, [QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.LINKED_ENTITY_DOESNOT_CONTAIN_DATA)]);
                var icon = this.Context.factory.createElement("MICROSOFTICON", {
                    id: "MYICON" + "_" + this.Id,
                    key: "MYICON" + "_" + this.Id,
                    type: 25,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropDownIcon(this.Context.theming),
                });
                var iconContainer = this.Context.factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderDropIconContainerStyle(this.Context.theming),
                }, []);
                return this.Context.factory.createElement("LISTITEM", {
                    id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemNotContainsDataPrefix() + this.Id,
                    key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntityElipsisFlyoutListItemNotContainsDataPrefix() + this.Id,
                    tabIndex: 0,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListItemStyle(this.Context.theming),
                    onClick: function () {
                        self.ContainerTree.ConfirmationDialog.ShowConfirmationDialog(QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_DIALOG_TITLE_DELETE), QueryBuilder.Utils.getResourceString(self.Context, QueryBuilder.LocalizedStrings.CONFIRMATION_MESSAGE_REMOVE_LINKED_ENTITY_FILTERS), self.onDoesNotContainClickHandler.bind(self));
                    },
                }, [!self.containsData ? icon : iconContainer, label]);
            };
            QueryBuilderLinkedEntityNode.prototype.toggleFlyoutVisibility = function () {
                this.isFlyoutVisible = !this.isFlyoutVisible;
                this.Context.utils.requestRender();
            };
            QueryBuilderLinkedEntityNode.prototype.onDeleteClickHandler = function () {
                if (this.linkedEntityData.RelationshipType == QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany &&
                    !this.linkedEntityData.IsIntersect) {
                    this.ContainerTree.delete([this.Parent.Id]);
                }
                else {
                    this.ContainerTree.delete([this.Id]);
                }
                this.ContainerTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.RemoveLinkedEntity, Properties: {} });
            };
            QueryBuilderLinkedEntityNode.prototype.onCancelButtonClickHandler = function () {
                this.containsData = true;
                this.updateLinkType(this.containsData);
                this.ContainerTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.LinkedEntityContainsData, Properties: {} });
            };
            QueryBuilderLinkedEntityNode.prototype.onDoesNotContainClickHandler = function () {
                if (this.containsData) {
                    this.containsData = false;
                    this.updateLinkType(this.containsData);
                    this.isFlyoutVisible = !this.isFlyoutVisible;
                    this.ContainerTree.clearLinkedEntity(this.Id);
                    QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntitySectionElipsisButtonPrefix() + this.Id);
                    this.ContainerTree.onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.ClearLinkedEntity, Properties: {} });
                }
                else {
                    this.toggleFlyoutVisibility();
                }
            };
            QueryBuilderLinkedEntityNode.prototype.onContainsDataClickHandler = function () {
                if (!this.containsData) {
                    this.containsData = true;
                    this.updateLinkType(this.containsData);
                    this.isFlyoutVisible = !this.isFlyoutVisible;
                    QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getRelatedEntitySectionElipsisButtonPrefix() + this.Id);
                    this.ContainerTree.onChange({
                        EventType: QueryBuilder.Constants.QueryTreeEventType.LinkedEntityContainsData,
                        Properties: {},
                    });
                }
                else {
                    this.toggleFlyoutVisibility();
                }
            };
            QueryBuilderLinkedEntityNode.prototype.updateLinkType = function (containsData) {
                this.properties["entityAttributes"]["link-type"] = containsData
                    ? QueryBuilder.AdvancedFindConstants.LINK_TYPE_INNER
                    : QueryBuilder.AdvancedFindConstants.LINK_TYPE_OUTER;
                if (this.linkedEntityData.RelationshipType == QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany &&
                    !this.linkedEntityData.IsIntersect) {
                    this.Parent.updateLinkType(containsData);
                }
            };
            return QueryBuilderLinkedEntityNode;
        }(QueryBuilder.QueryBuilderQueryNode));
        QueryBuilder.QueryBuilderLinkedEntityNode = QueryBuilderLinkedEntityNode;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderQueryTreeOption = (function () {
            function QueryBuilderQueryTreeOption(context, usageContext) {
                this.readOnly =
                    context && context.parameters && context.parameters.ReadOnly ? context.parameters.ReadOnly.raw : false;
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        this.linkedEntityEnabled = true;
                        this.notifyOutputChangeOn = QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.RunButtonClick;
                        this.showRootNode = QueryBuilder.Constants.ShowQueryTreeRoot.OnlyIfOR;
                        break;
                    case QueryBuilder.Constants.UsageContext.Sample:
                        this.linkedEntityEnabled = false;
                        this.notifyOutputChangeOn = QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.OutputChange;
                        this.showRootNode = QueryBuilder.Constants.ShowQueryTreeRoot.Always;
                        break;
                    default:
                        this.linkedEntityEnabled = false;
                        this.notifyOutputChangeOn = QueryBuilder.Constants.QueryTreeOptionNotifyOutputChangeOn.ValidOutputChange;
                        this.showRootNode = QueryBuilder.Constants.ShowQueryTreeRoot.Always;
                        break;
                }
            }
            Object.defineProperty(QueryBuilderQueryTreeOption.prototype, "ReadOnly", {
                get: function () {
                    return this.readOnly;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTreeOption.prototype, "LinkedEntityEnabled", {
                get: function () {
                    return this.linkedEntityEnabled;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTreeOption.prototype, "NotifyOutputChangeOn", {
                get: function () {
                    return this.notifyOutputChangeOn;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderQueryTreeOption.prototype, "ShowRootNode", {
                get: function () {
                    return this.showRootNode;
                },
                enumerable: true,
                configurable: true
            });
            return QueryBuilderQueryTreeOption;
        }());
        QueryBuilder.QueryBuilderQueryTreeOption = QueryBuilderQueryTreeOption;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderValidationResult = (function () {
            function QueryBuilderValidationResult() {
                this._idToErrorsMap = {};
            }
            QueryBuilderValidationResult.prototype.hasRecords = function (id) {
                return this._idToErrorsMap[id] ? true : false;
            };
            QueryBuilderValidationResult.prototype.getValidationRecords = function (id) {
                return this._idToErrorsMap[id];
            };
            QueryBuilderValidationResult.prototype.addQueryError = function () {
                var errorKeys = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    errorKeys[_i] = arguments[_i];
                }
                for (var _a = 0, errorKeys_1 = errorKeys; _a < errorKeys_1.length; _a++) {
                    var errorKey = errorKeys_1[_a];
                    this.pushError(QueryBuilder.Utils.EMPTY_GUID, QueryBuilder.Constants.ValidationLevel.ERROR, errorKey);
                }
            };
            QueryBuilderValidationResult.prototype.addNodeError = function (id) {
                var errorKeys = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    errorKeys[_i - 1] = arguments[_i];
                }
                for (var _a = 0, errorKeys_2 = errorKeys; _a < errorKeys_2.length; _a++) {
                    var errorKey = errorKeys_2[_a];
                    this.pushError(id, QueryBuilder.Constants.ValidationLevel.ERROR, errorKey);
                }
            };
            QueryBuilderValidationResult.prototype.pushError = function (id, level, errorKey) {
                this.errorsForId(id).push(new QueryBuilderValidationRecord(level, errorKey));
            };
            QueryBuilderValidationResult.prototype.errorsForId = function (id) {
                if (!this._idToErrorsMap[id])
                    this._idToErrorsMap[id] = [];
                return this._idToErrorsMap[id];
            };
            return QueryBuilderValidationResult;
        }());
        QueryBuilder.QueryBuilderValidationResult = QueryBuilderValidationResult;
        var QueryBuilderValidationRecord = (function () {
            function QueryBuilderValidationRecord(level, errorKey) {
                this.level = level;
                this.errorKey = errorKey;
            }
            Object.defineProperty(QueryBuilderValidationRecord.prototype, "Level", {
                get: function () {
                    return this.level;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryBuilderValidationRecord.prototype, "ErrorKey", {
                get: function () {
                    return this.errorKey;
                },
                enumerable: true,
                configurable: true
            });
            return QueryBuilderValidationRecord;
        }());
        QueryBuilder.QueryBuilderValidationRecord = QueryBuilderValidationRecord;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindOutputConverter = (function () {
            function AdvancedFindOutputConverter() {
                this.listOfDoesNotContainFilters = [];
            }
            AdvancedFindOutputConverter.prototype.convert = function (queryTree) {
                this.listOfDoesNotContainFilters = [];
                var xmlDoc = document.implementation.createDocument(null, "fetch", null);
                var fetchElement = xmlDoc.childNodes[0];
                QueryBuilder.AdvancedFindUtils.addAttributesToElement(queryTree.Properties[QueryBuilder.AdvancedFindConstants.FETCH_ATTRIBUTES], fetchElement);
                var entityElement = xmlDoc.createElement("entity");
                fetchElement.appendChild(entityElement);
                this.addTreeToEntityElement(xmlDoc, queryTree, queryTree, entityElement);
                this.appendDoesNotContainDataFilters(entityElement);
                return new XMLSerializer().serializeToString(xmlDoc);
            };
            AdvancedFindOutputConverter.prototype.addTreeToEntityElement = function (xmlDoc, queryTree, currentTree, entityElement) {
                QueryBuilder.AdvancedFindUtils.addAttributesToElement(currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES], entityElement);
                if (currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES]) {
                    for (var indx = 0; indx < currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES].length; indx++) {
                        var entityChild = currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES][indx];
                        if (entityChild.element instanceof QueryBuilder.QueryBuilderLogicalGroupNode) {
                            var filterElement = this.appendFilterElement(xmlDoc, entityElement, currentTree.Root, this.getFilterType(currentTree.Root));
                            if (filterElement)
                                this.addFilterToXMLElement(xmlDoc, filterElement, currentTree.Root);
                        }
                        else if (entityChild.element instanceof QueryBuilder.QueryBuilderLinkedEntityNode) {
                            var linkedEntity = entityChild.element;
                            if (queryTree.nodeExists(entityChild.id)) {
                                var linkedEntityElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_LINK_ENTITY);
                                entityElement.appendChild(linkedEntityElement);
                                this.addTreeToEntityElement(xmlDoc, queryTree, linkedEntity, linkedEntityElement);
                                if (!linkedEntity.ContainsData) {
                                    this.listOfDoesNotContainFilters.push(this.createDoesNotContainFilterElement(xmlDoc, linkedEntity.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES][QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_ALIAS], linkedEntity.LinkedEntityData.FromAttributeLogicalName));
                                }
                            }
                        }
                        else {
                            entityElement.appendChild(entityChild.element);
                        }
                    }
                }
                if (currentTree.Root &&
                    currentTree.Root.Children.length &&
                    !this.isPresentAsChild(currentTree.Root.Id, currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES])) {
                    var filterElement = this.appendFilterElement(xmlDoc, entityElement, currentTree.Root, this.getFilterType(currentTree.Root));
                    if (filterElement)
                        this.addFilterToXMLElement(xmlDoc, filterElement, currentTree.Root);
                }
                if (currentTree.LinkedEntities.length) {
                    for (var i = 0; i < currentTree.LinkedEntities.length; i++) {
                        if (!this.isPresentAsChild(currentTree.LinkedEntities[i].Id, currentTree.Properties[QueryBuilder.AdvancedFindConstants.ENTITY_CHILD_NODES])) {
                            var linkedEntityElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_LINK_ENTITY);
                            entityElement.appendChild(linkedEntityElement);
                            this.addTreeToEntityElement(xmlDoc, queryTree, currentTree.LinkedEntities[i], linkedEntityElement);
                            if (!currentTree.LinkedEntities[i].ContainsData) {
                                this.listOfDoesNotContainFilters.push(this.createDoesNotContainFilterElement(xmlDoc, currentTree.LinkedEntities[i].Properties[QueryBuilder.AdvancedFindConstants.ENTITY_ATTRIBUTES][QueryBuilder.AdvancedFindConstants.LINK_ENTITY_ATTRIBUTE_ALIAS], currentTree.LinkedEntities[i].LinkedEntityData.FromAttributeLogicalName));
                            }
                        }
                    }
                }
            };
            AdvancedFindOutputConverter.prototype.addFilterToXMLElement = function (xmlDoc, parentElement, filterNode) {
                for (var childIndex = 0; childIndex < filterNode.Children.length; childIndex++) {
                    var childNode = filterNode.Children[childIndex];
                    switch (childNode.NodeType) {
                        case QueryBuilder.Constants.QueryTreeNodeType.Condition:
                            var conditionElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_CONDITION);
                            var conditionControlDefiniftions = childNode.Condition.ControlDefinitions;
                            conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_ATTRIBUTE, QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[0])));
                            conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR, QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[1])));
                            if (!childNode.Condition.IsVisibleInSimpleMode) {
                                conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UIHIDDEN, "1"));
                            }
                            if (conditionControlDefiniftions[2] && QueryBuilder.Utils.isControlDefinitionValueSet(conditionControlDefiniftions[2])) {
                                switch (conditionControlDefiniftions[2].type) {
                                    case QueryBuilder.ConditionModel.ControlTypes.MultiSelectPicklist:
                                        var multiSelectPicklistValues = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[2]);
                                        for (var _i = 0, multiSelectPicklistValues_1 = multiSelectPicklistValues; _i < multiSelectPicklistValues_1.length; _i++) {
                                            var value_1 = multiSelectPicklistValues_1[_i];
                                            var valueElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE);
                                            valueElement.textContent = value_1.toString();
                                            conditionElement.appendChild(valueElement);
                                        }
                                        break;
                                    case QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod:
                                        var fiscalYearValues = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[2]);
                                        var quarterValueElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE);
                                        quarterValueElement.textContent = "0" + fiscalYearValues.periodValue.toString();
                                        var yearValueElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE);
                                        yearValueElement.textContent = fiscalYearValues.yearValue.toString();
                                        conditionElement.appendChild(quarterValueElement);
                                        conditionElement.appendChild(yearValueElement);
                                        break;
                                    case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                                        var lookupValue = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[2]);
                                        conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE, "{" + lookupValue.id + "}"));
                                        conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UINAME, lookupValue.Name));
                                        conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE, lookupValue.LogicalName));
                                        break;
                                    case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                                        var lookupValues = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[2]);
                                        for (var _a = 0, lookupValues_1 = lookupValues; _a < lookupValues_1.length; _a++) {
                                            var lookupValue_1 = lookupValues_1[_a];
                                            var valueElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_VALUE);
                                            valueElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UINAME, lookupValue_1.Name));
                                            valueElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_UITYPE, lookupValue_1.LogicalName));
                                            valueElement.textContent = "{" + lookupValue_1.id + "}";
                                            conditionElement.appendChild(valueElement);
                                        }
                                        break;
                                    default:
                                        var conditionOperator = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[1]);
                                        var value = QueryBuilder.Utils.getControlDefinitionValue(conditionControlDefiniftions[2]);
                                        if (conditionOperator === QueryBuilder.ConditionOperator.like || conditionOperator === QueryBuilder.ConditionOperator.not_like)
                                            value = "%" + value + "%";
                                        conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_VALUE, value));
                                }
                            }
                            QueryBuilder.AdvancedFindUtils.addAttributesToElement(childNode.Properties, conditionElement);
                            parentElement.appendChild(conditionElement);
                            break;
                        case QueryBuilder.Constants.QueryTreeNodeType.AND:
                        case QueryBuilder.Constants.QueryTreeNodeType.OR:
                            var filterElement = this.appendFilterElement(xmlDoc, parentElement, childNode, this.getFilterType(childNode));
                            QueryBuilder.AdvancedFindUtils.addAttributesToElement(childNode.Properties, filterElement);
                            this.addFilterToXMLElement(xmlDoc, filterElement, childNode);
                            break;
                        default:
                            break;
                    }
                }
            };
            AdvancedFindOutputConverter.prototype.appendFilterElement = function (xmlDoc, parentElement, filterNode, type) {
                if (!filterNode.Children.length)
                    return null;
                var filterElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_FILTER);
                filterElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE, type));
                QueryBuilder.AdvancedFindUtils.addAttributesToElement(filterNode.Properties, filterElement);
                parentElement.appendChild(filterElement);
                return filterElement;
            };
            AdvancedFindOutputConverter.prototype.isPresentAsChild = function (childId, entityChildren) {
                if (!entityChildren)
                    return false;
                var foundChild = entityChildren.filter(function (child) {
                    return child.id === childId;
                });
                return foundChild && foundChild.length > 0;
            };
            AdvancedFindOutputConverter.prototype.getFilterType = function (childNode) {
                switch (childNode.NodeType) {
                    case QueryBuilder.Constants.QueryTreeNodeType.AND:
                        return QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_AND;
                    case QueryBuilder.Constants.QueryTreeNodeType.OR:
                        return QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_OR;
                    default:
                        return QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_AND;
                }
            };
            AdvancedFindOutputConverter.prototype.createDoesNotContainFilterElement = function (xmlDoc, entityName, attributeName) {
                var filterElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_FILTER);
                filterElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_TYPE, QueryBuilder.AdvancedFindConstants.ADVANCED_FIND_AND));
                var conditionElement = xmlDoc.createElement(QueryBuilder.AdvancedFindConstants.NODE_NAME_CONDITION);
                conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_ATTRIBUTE, attributeName));
                conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ATTRIBUTE_NAME_OPERATOR, "null"));
                conditionElement.attributes.setNamedItem(QueryBuilder.AdvancedFindUtils.getAttr(QueryBuilder.AdvancedFindConstants.ENTITYNAME, entityName));
                filterElement.appendChild(conditionElement);
                return filterElement;
            };
            AdvancedFindOutputConverter.prototype.appendDoesNotContainDataFilters = function (entityElement) {
                for (var _i = 0, _a = this.listOfDoesNotContainFilters; _i < _a.length; _i++) {
                    var filter = _a[_i];
                    entityElement.appendChild(filter);
                }
            };
            return AdvancedFindOutputConverter;
        }());
        QueryBuilder.AdvancedFindOutputConverter = AdvancedFindOutputConverter;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var ControlDefinitionProviderRegistry = (function () {
            function ControlDefinitionProviderRegistry() {
            }
            ControlDefinitionProviderRegistry.prototype.getProvider = function (usageContext) {
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        return new QueryBuilder.ConditionModel.AdvancedFindControlDefinitionProvider();
                    case QueryBuilder.Constants.UsageContext.Sample:
                        return new QueryBuilder.ConditionModel.SampleControlDefinitionProvider();
                    default:
                        throw new Error("Unknown Usage-Context: " + usageContext);
                }
            };
            return ControlDefinitionProviderRegistry;
        }());
        QueryBuilder.ControlDefinitionProviderRegistry = ControlDefinitionProviderRegistry;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var OutputConverterRegistry = (function () {
            function OutputConverterRegistry() {
            }
            OutputConverterRegistry.prototype.getConverter = function (usageContext) {
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        return new QueryBuilder.AdvancedFindOutputConverter();
                    case QueryBuilder.Constants.UsageContext.Sample:
                        return new QueryBuilder.SampleOutputConverter();
                    default:
                        throw new Error("Unknown Usage-Context: " + usageContext);
                }
            };
            return OutputConverterRegistry;
        }());
        QueryBuilder.OutputConverterRegistry = OutputConverterRegistry;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var InputConverterRegistry = (function () {
            function InputConverterRegistry() {
            }
            InputConverterRegistry.prototype.getConverter = function (usageContext) {
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        return new QueryBuilder.AdvancedFindInputConverter();
                    case QueryBuilder.Constants.UsageContext.Sample:
                        return new QueryBuilder.SampleInputConverter();
                    default:
                        throw new Error("Unknown Usage-Context: " + usageContext);
                }
            };
            return InputConverterRegistry;
        }());
        QueryBuilder.InputConverterRegistry = InputConverterRegistry;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var TelemetryEventHandlerRegistry = (function () {
            function TelemetryEventHandlerRegistry() {
            }
            TelemetryEventHandlerRegistry.prototype.getHandler = function (usageContext) {
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        return new QueryBuilder.AdvancedFindTelemetryEventHandler();
                    case QueryBuilder.Constants.UsageContext.Sample:
                        return new QueryBuilder.SampleTelemetryEventHandler();
                    default:
                        return null;
                }
            };
            return TelemetryEventHandlerRegistry;
        }());
        QueryBuilder.TelemetryEventHandlerRegistry = TelemetryEventHandlerRegistry;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var ValidatorRegistry = (function () {
            function ValidatorRegistry() {
            }
            ValidatorRegistry.prototype.getValidator = function (usageContext) {
                switch (usageContext) {
                    case QueryBuilder.Constants.UsageContext.AdvancedFind:
                        return new QueryBuilder.AdvancedFindValidator();
                    case QueryBuilder.Constants.UsageContext.Sample:
                        return new QueryBuilder.SampleValidator();
                    default:
                        return null;
                }
            };
            return ValidatorRegistry;
        }());
        QueryBuilder.ValidatorRegistry = ValidatorRegistry;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var Condition = (function () {
            function Condition(parentConditionNode, initialConditionDefinition, conditionId) {
                this.conditionId = conditionId;
                this.parentConditionNode = parentConditionNode;
                this.controlDefinitions = initialConditionDefinition;
                this.isVisibleInSimpleMode = true;
            }
            Condition.prototype.initialize = function () {
                var controlDefinitionProvider = new QueryBuilder.ControlDefinitionProviderRegistry().getProvider(this.getUsageContext());
                var self = this;
                controlDefinitionProvider.getInitialControlDefinitions(this.getContext(), this.parentConditionNode).then(function (controlDefinitions) {
                    self.controlDefinitions = controlDefinitions;
                    var firstNonHiddenControlDefinition;
                    for (var _i = 0, _a = self.controlDefinitions; _i < _a.length; _i++) {
                        var tempControlDef = _a[_i];
                        if (!tempControlDef.isHidden) {
                            firstNonHiddenControlDefinition = tempControlDef;
                            break;
                        }
                    }
                    if (firstNonHiddenControlDefinition)
                        QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadTextBoxPrefix() +
                            QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadControlPrefix() +
                            firstNonHiddenControlDefinition.controlId);
                    self.getQueryTree().onChange({ EventType: QueryBuilder.Constants.QueryTreeEventType.AddCondition, Properties: {} });
                }, function (error) {
                    self.getQueryTree().onError(error);
                });
            };
            Object.defineProperty(Condition.prototype, "ParentConditionNode", {
                get: function () {
                    return this.parentConditionNode;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Condition.prototype, "ControlDefinitions", {
                get: function () {
                    return this.controlDefinitions;
                },
                set: function (controlDefinitions) {
                    this.controlDefinitions = controlDefinitions;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Condition.prototype, "IsVisibleInSimpleMode", {
                get: function () {
                    return this.isVisibleInSimpleMode;
                },
                set: function (value) {
                    this.isVisibleInSimpleMode = value;
                },
                enumerable: true,
                configurable: true
            });
            Condition.prototype.getQueryTree = function () {
                return this.parentConditionNode.ContainerTree;
            };
            Condition.prototype.getContext = function () {
                return this.getQueryTree().Context;
            };
            Condition.prototype.getUsageContext = function () {
                return this.getQueryTree().UsageContext;
            };
            Condition.prototype.getView = function () {
                var outputView = new Array();
                if (this.controlDefinitions) {
                    if (QueryBuilder.QueryBuilderQueryTree.IsSimpleMode) {
                        var readOnlyControlDefs = new Array();
                        var valueControlDef = null;
                        var forElementId = "";
                        for (var _i = 0, _a = this.ControlDefinitions; _i < _a.length; _i++) {
                            var controlDef = _a[_i];
                            if (controlDef.name === QueryBuilder.Constants.ConditionFieldName.LHSAttribute ||
                                controlDef.name === QueryBuilder.Constants.ConditionFieldName.LHSEntity ||
                                controlDef.name === QueryBuilder.Constants.ConditionFieldName.Operator) {
                                readOnlyControlDefs.push(controlDef);
                            }
                            else if (controlDef.name === QueryBuilder.Constants.ConditionFieldName.RHSValue) {
                                valueControlDef = controlDef;
                                forElementId = controlDef.getForElementId();
                            }
                        }
                        var accessibilityLabel = QueryBuilder.AdvancedFindUtils.getAccessibilityLabelForSimpleMode(this.getContext(), readOnlyControlDefs);
                        var valueControlContainer = void 0;
                        var readOnlyContainer = new Array();
                        if (valueControlDef != null &&
                            (valueControlDef.type === QueryBuilder.ConditionModel.ControlTypes.DateTime ||
                                valueControlDef.type === QueryBuilder.ConditionModel.ControlTypes.TextBox ||
                                valueControlDef.type === QueryBuilder.ConditionModel.ControlTypes.OptionSet ||
                                valueControlDef.type === QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod)) {
                            var hiddenLabel = this.getContext().factory.createElement("LABEL", {
                                id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getHiddenLabelPrefix() + readOnlyControlDefs[0].controlId,
                                key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getHiddenLabelPrefix() + readOnlyControlDefs[0].controlId,
                                tabIndex: -1,
                                accessibilityLabel: accessibilityLabel,
                                forElementId: forElementId,
                                role: "presentation",
                                title: accessibilityLabel,
                                style: QueryBuilder.QueryBuilderStyle.HiddenLabelStyle(this.getContext().theming),
                            }, [accessibilityLabel]);
                            outputView.push(hiddenLabel);
                        }
                        else {
                            if (valueControlDef != null) {
                                (valueControlDef ||
                                    valueControlDef ||
                                    valueControlDef).accessibilityLabel = accessibilityLabel;
                            }
                        }
                        for (var _b = 0, readOnlyControlDefs_1 = readOnlyControlDefs; _b < readOnlyControlDefs_1.length; _b++) {
                            var controlDefinition = readOnlyControlDefs_1[_b];
                            readOnlyContainer.push(this.getContext().factory.createElement("CONTAINER", {
                                id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + controlDefinition.controlId,
                                key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + controlDefinition.controlId,
                                tabIndex: -1,
                                role: "presentation",
                                title: QueryBuilder.AdvancedFindUtils.getAccessibilityLabelForControlDefinition(controlDefinition),
                                style: QueryBuilder.QueryBuilderStyle.SimpleModeContainerStyle(this.getContext().theming, controlDefinition.name),
                            }, [QueryBuilder.AdvancedFindUtils.getAccessibilityLabelForControlDefinition(controlDefinition)]));
                        }
                        outputView.push.apply(outputView, readOnlyContainer);
                        if (valueControlDef !== null) {
                            var hasError = valueControlDef.errors.length > 0;
                            valueControlContainer = this.getContext().factory.createElement("CONTAINER", {
                                id: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + valueControlDef.controlId,
                                key: QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + valueControlDef.controlId,
                                style: QueryBuilder.QueryBuilderStyle.ControlDefinitionContainerStyle(this.getContext().theming, hasError, true),
                            }, [valueControlDef.getView()]);
                            outputView.push(valueControlContainer);
                        }
                    }
                    else {
                        for (var _c = 0, _d = this.controlDefinitions; _c < _d.length; _c++) {
                            var controldef = _d[_c];
                            var hasError = controldef.errors.length > 0;
                            var isValueControl = false;
                            isValueControl = controldef.name === QueryBuilder.Constants.ConditionFieldName.RHSValue;
                            var idKey = QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + controldef.controlId;
                            var container = this.getContext().factory.createElement("CONTAINER", {
                                id: idKey,
                                key: idKey,
                                onBlur: this.updateLiveRegion.bind(this, controldef),
                                style: QueryBuilder.QueryBuilderStyle.ControlDefinitionContainerStyle(this.getContext().theming, hasError, isValueControl),
                            }, [controldef.getView()]);
                            outputView.push(container);
                        }
                        if (!this.IsVisibleInSimpleMode) {
                            var label = this.getContext().factory.createElement("CONTAINER", {
                                id: QueryBuilder.ComponentIdPrefixesAndSuffixes.gethiddenConditionId() + this.conditionId,
                                key: QueryBuilder.ComponentIdPrefixesAndSuffixes.gethiddenConditionId() + this.conditionId,
                                tabIndex: 0,
                                accessibilityLabel: QueryBuilder.Utils.getResourceString(this.getContext(), QueryBuilder.LocalizedStrings.CONDITION_HIDDEN),
                                style: QueryBuilder.QueryBuilderStyle.QueryBuilderValueReadOnlyStyle(this.getContext().theming, this.getContext().client.isRTL),
                            }, [QueryBuilder.Utils.getResourceString(this.getContext(), QueryBuilder.LocalizedStrings.CONDITION_HIDDEN)]);
                            outputView.push(label);
                        }
                    }
                }
                return this.getContext().factory.createElement("CONTAINER", {
                    id: this.conditionId,
                    key: this.conditionId,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderConditionStyle(this.getContext().theming),
                }, outputView);
            };
            Condition.prototype.updateLiveRegion = function (controlDef, event) {
                var conditionId = this.getContext().accessibility.getUniqueId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getConditionChildPrefix() + controlDef.controlId);
                var associatedFlyoutId = this.getContext().accessibility.getUniqueId(QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadControlFlyoutPrefix() +
                    QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadControlPrefix() +
                    controlDef.controlId);
                var nextFocusElement = event.relatedTarget;
                if (!nextFocusElement ||
                    (!this.isChildOfNode(nextFocusElement, conditionId) &&
                        !this.isChildOfNode(nextFocusElement, associatedFlyoutId))) {
                    if (controlDef.errors.length) {
                        this.setLiveRegionText(controlDef.errors[0]);
                    }
                }
            };
            Condition.prototype.isChildOfNode = function (childNode, parentId) {
                if (!childNode || !parentId)
                    return false;
                var conditionDOM = document.getElementById(parentId);
                return conditionDOM && conditionDOM.contains(childNode);
            };
            Condition.prototype.setLiveRegionText = function (text) {
                document.getElementById(this.getContext().accessibility.getUniqueId(QueryBuilder.ComponentIdPrefixesAndSuffixes.ariaLiveLabelId())).innerHTML = text;
            };
            Condition.prototype.getConditionErrorView = function () {
                var errorView = new Array();
                if (this.controlDefinitions) {
                    for (var _i = 0, _a = this.controlDefinitions; _i < _a.length; _i++) {
                        var controldef = _a[_i];
                        for (var _b = 0, _c = controldef.errors; _b < _c.length; _b++) {
                            var error = _c[_b];
                            errorView.push(this.getErrorComponent(error, QueryBuilder.Constants.ValidationLevel.ERROR));
                        }
                    }
                }
                return errorView;
            };
            Condition.prototype.getErrorComponent = function (error, type) {
                var errMsg = this.getContext().factory.createElement("CONTAINER", {
                    id: "error" + "_" + QueryBuilder.Utils.newGuid(),
                    key: "error" + "_" + QueryBuilder.Utils.newGuid(),
                    style: QueryBuilder.QueryBuilderStyle.ConditionErrorLabelStyle(this.getContext().theming),
                }, [error]);
                var icon = this.getContext().factory.createElement("MICROSOFTICON", {
                    id: "MYICON" + "_" + QueryBuilder.Utils.newGuid(),
                    key: "MYICON" + "_" + QueryBuilder.Utils.newGuid(),
                    type: 252,
                    style: QueryBuilder.QueryBuilderStyle.ConditionErrorIconStyle(this.getContext().theming),
                });
                return this.getContext().factory.createElement("CONTAINER", {
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderGetContextStyle(this.getContext().theming, this.getContext().client.isRTL),
                }, [icon, errMsg]);
            };
            Condition.prototype.pushComponents = function (controlDefinitions) {
                for (var _i = 0, controlDefinitions_1 = controlDefinitions; _i < controlDefinitions_1.length; _i++) {
                    var def = controlDefinitions_1[_i];
                    this.controlDefinitions.push(def);
                }
            };
            return Condition;
        }());
        QueryBuilder.Condition = Condition;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var ODataHelper = (function () {
            function ODataHelper(context) {
                this._context = context;
            }
            ODataHelper.prototype.odataGetRequest = function (oDataEndpointUri) {
                var _this = this;
                return new Promise(function (resolve, reject) {
                    window.$.getJSON(_this._context.page.getClientUrl() + ODataHelper.ODATA_PATH + oDataEndpointUri).then(function (response) {
                        resolve(response);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            ODataHelper.prototype.retrieveEntityData = function (entityLogicalCollectionName, attributeLogicalNames, primaryIdAttribute, recordIds) {
                var attributeString = attributeLogicalNames.join(",");
                var filterString = "";
                for (var i = 0; i < recordIds.length; i++) {
                    filterString += primaryIdAttribute + " eq " + recordIds[i];
                    if (i < recordIds.length - 1) {
                        filterString += " or ";
                    }
                }
                filterString = "(" + filterString + ")";
                var oDataEndpointUri = MscrmCommon.ControlUtils.String.Format("/{0}?$select={1}&$filter={2}", entityLogicalCollectionName, attributeString, filterString);
                return this.odataGetRequest(oDataEndpointUri);
            };
            ODataHelper.prototype.retrieveAttributesAndRelatedEntitiesMetadataByEntityName = function (entityLogicalName) {
                var oDataEndpointUri = MscrmCommon.ControlUtils.String.Format("/RetrieveEntityRelationsWithDependantEntityMetadata(EntityLogicalName='{0}')", entityLogicalName);
                return this.odataGetRequest(oDataEndpointUri);
            };
            ODataHelper.prototype.retrieveAttributesAndRelatedEntitiesMetadataByEntityNames = function (entityLogicalNames) {
                var entityList = "'" + entityLogicalNames.join("','") + "'";
                var oDataEndpointUri = MscrmCommon.ControlUtils.String.Format("/RetrieveEntitiesRelationsWithDependantEntityMetadata(EntityLogicalNames=@EntityLogicalNames,Relations=['Nto1','1toN','NtoN'])?@EntityLogicalNames=[{0}]", entityList);
                return this.odataGetRequest(oDataEndpointUri);
            };
            ODataHelper.prototype.retrieveEntitiesMetadata = function (entityList, columns, additionalFilterClause) {
                var selectClause = columns.join();
                var filters = [];
                if (entityList.length > 0) {
                    filters.push("(LogicalName eq '" + entityList.join("' or LogicalName eq '") + "')");
                }
                if (!MscrmCommon.ControlUtils.String.isNullOrEmpty(additionalFilterClause)) {
                    filters.push("(" + additionalFilterClause + ")");
                }
                var filterClause = filters.join(" and ");
                var odataParamsString = this.constructOdataParamsString({ select: selectClause, filter: filterClause });
                var oDataEndPointUri = MscrmCommon.ControlUtils.String.Format("/EntityDefinitions?{0}", odataParamsString);
                return this.odataGetRequest(oDataEndPointUri);
            };
            ODataHelper.prototype.retrieveViewsForEntities = function (entityList, columns, supportedViewTypes, additionalFilterClause) {
                var selectClause = columns.join();
                var filters = [];
                if (entityList.length > 0) {
                    filters.push("(returnedtypecode eq '" + entityList.join("' or returnedtypecode eq '") + "')");
                }
                if (supportedViewTypes.length > 0) {
                    filters.push("(querytype eq " + supportedViewTypes.join(" or querytype eq ") + ")");
                }
                if (!MscrmCommon.ControlUtils.String.isNullOrEmpty(additionalFilterClause)) {
                    filters.push("(" + additionalFilterClause + ")");
                }
                var filterClause = filters.join(" and ");
                var odataParamsString = this.constructOdataParamsString({ select: selectClause, filter: filterClause });
                var odataEndPointUri = MscrmCommon.ControlUtils.String.Format("/savedqueries/Microsoft.Dynamics.CRM.RetrieveUnpublishedMultiple()?{0}", odataParamsString);
                return this.odataGetRequest(odataEndPointUri);
            };
            ODataHelper.prototype.constructOdataParamsString = function (paramsNameValueMap) {
                var odataParams = [];
                var value;
                for (var key in paramsNameValueMap) {
                    value = paramsNameValueMap[key];
                    if (!MscrmCommon.ControlUtils.String.isNullOrEmpty(value)) {
                        odataParams.push(MscrmCommon.ControlUtils.String.Format("${0}={1}", key, value));
                    }
                }
                return odataParams.join("&");
            };
            ODataHelper.prototype.retrieveOrganizationProvisionedLanguages = function () {
                var oDataEndpointUri = "/RetrieveProvisionedLanguages()";
                return this.odataGetRequest(oDataEndpointUri);
            };
            ODataHelper.ODATA_PATH = "/api/data/v9.1";
            return ODataHelper;
        }());
        QueryBuilder.ODataHelper = ODataHelper;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindInitialMetadataLoader = (function () {
            function AdvancedFindInitialMetadataLoader() {
            }
            AdvancedFindInitialMetadataLoader.prototype.loadInitialEntitiesMetadata = function (context, entities) {
                var self = this;
                return new Promise(function (resolve, reject) {
                    var promises = [];
                    var result;
                    var entityMetadataMap = new QueryBuilder.Dictionary();
                    var entityViewMetadataMap = {};
                    var entityMetadataAndAttributesMap = {};
                    var provisionedLanguageList = [];
                    promises.push(new QueryBuilder.EntityMetadataProvider().getEntitiesMetadata(entities, QueryBuilder.AdvancedFindConstants.ENTITY_METADATA_ATTRIBUTES, "", context));
                    var attributeMetadataProvider = new QueryBuilder.AttributeMetadataProvider();
                    promises.push(attributeMetadataProvider.getAttributeMetadataForEntities(context, entities));
                    promises.push(new QueryBuilder.LanguageDataProvider().getProvisionedLanguageList(context));
                    Promise.all(promises).then(function (responses) {
                        entityMetadataMap = responses[0];
                        entityMetadataAndAttributesMap = responses[1];
                        provisionedLanguageList = responses[2];
                        var result = {
                            entityMetadataMap: entityMetadataMap,
                            entityViewMetadataMap: entityViewMetadataMap,
                            entityMetadataAndAttributesMap: entityMetadataAndAttributesMap,
                            provisionedLanguageList: provisionedLanguageList,
                        };
                        resolve(result);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            AdvancedFindInitialMetadataLoader.prototype.getDisplayNamesForLinkedEntity = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName, context) {
                var promises = [];
                var entityMetadataProvider = new QueryBuilder.EntityMetadataProvider();
                var attributeMetadataProvider = new QueryBuilder.AttributeMetadataProvider();
                var result = {};
                return new Promise(function (resolve, reject) {
                    promises.push(entityMetadataProvider.getEntityDisplayName(fromEntityLogicalName, context));
                    promises.push(entityMetadataProvider.getEntityDisplayName(toEntityLogicalName, context));
                    promises.push(attributeMetadataProvider.getAttributeDisplayName(fromEntityLogicalName, fromAttributeLogicalName, context));
                    promises.push(attributeMetadataProvider.getAttributeDisplayName(toEntityLogicalName, toAttributeLogicalName, context));
                    Promise.all(promises).then(function (responses) {
                        result[fromEntityLogicalName] = responses[0];
                        result[toEntityLogicalName] = responses[1];
                        result[fromAttributeLogicalName] = responses[2];
                        result[toAttributeLogicalName] = responses[3];
                        resolve(result);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
            return AdvancedFindInitialMetadataLoader;
        }());
        QueryBuilder.AdvancedFindInitialMetadataLoader = AdvancedFindInitialMetadataLoader;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SampleOutputConverter = (function () {
            function SampleOutputConverter() {
            }
            SampleOutputConverter.prototype.convert = function (queryTree) {
                if (queryTree && queryTree.Root) {
                    return this.convertNode(queryTree.Root, 0);
                }
                return "";
            };
            SampleOutputConverter.prototype.convertNode = function (node, depth) {
                var result = "";
                for (var childIndex = 0; childIndex < node.Children.length; childIndex++) {
                    var childNode = node.Children[childIndex];
                    if (childNode.NodeType == QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                        result += "(";
                        var controlDefinitions = childNode
                            .Condition.ControlDefinitions;
                        for (var controlDefinitionIndex = 0; controlDefinitionIndex < controlDefinitions.length; controlDefinitionIndex++) {
                            var controlDefinition = controlDefinitions[controlDefinitionIndex];
                            switch (controlDefinition.name) {
                                case QueryBuilder.Constants.ConditionFieldName.SampleField:
                                case QueryBuilder.Constants.ConditionFieldName.Operator:
                                case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                    result += QueryBuilder.Utils.getControlDefinitionValue(controlDefinition);
                                    break;
                                default:
                                    break;
                            }
                            switch (controlDefinition.name) {
                                case QueryBuilder.Constants.ConditionFieldName.SampleField:
                                case QueryBuilder.Constants.ConditionFieldName.Operator:
                                    result += " ";
                                    break;
                                default:
                                    break;
                            }
                        }
                        result += ")";
                    }
                    else if (childNode.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND ||
                        childNode.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        result += this.convertNode(childNode, depth + 1);
                    }
                    if (childNode.Parent && childIndex < node.Children.length - 1) {
                        switch (childNode.Parent.NodeType) {
                            case QueryBuilder.Constants.QueryTreeNodeType.AND:
                                result += " & ";
                                break;
                            case QueryBuilder.Constants.QueryTreeNodeType.OR:
                                result += " | ";
                                break;
                            default:
                                break;
                        }
                    }
                }
                return "(" + result + ")";
            };
            return SampleOutputConverter;
        }());
        QueryBuilder.SampleOutputConverter = SampleOutputConverter;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var AdvancedFind;
        (function (AdvancedFind) {
            "use strict";
            var FieldTypeConstants = (function () {
                function FieldTypeConstants() {
                }
                Object.defineProperty(FieldTypeConstants, "DateTimeType", {
                    get: function () {
                        return "DateTimeType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "OptionSetType", {
                    get: function () {
                        return "OptionSetType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "LookupType", {
                    get: function () {
                        return "LookupType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "TextboxType", {
                    get: function () {
                        return "TextBoxType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "PartyListType", {
                    get: function () {
                        return "PartyListType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "MultiSelectType", {
                    get: function () {
                        return "MultiSelectType";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FieldTypeConstants, "FiscalYearAndPeriodType", {
                    get: function () {
                        return "FiscalYearAndPeriodType";
                    },
                    enumerable: true,
                    configurable: true
                });
                return FieldTypeConstants;
            }());
            AdvancedFind.FieldTypeConstants = FieldTypeConstants;
        })(AdvancedFind = QueryBuilder.AdvancedFind || (QueryBuilder.AdvancedFind = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var AdvancedFind;
        (function (AdvancedFind) {
            "use strict";
            var OperatorsWithNoValueControl = (function () {
                function OperatorsWithNoValueControl() {
                }
                OperatorsWithNoValueControl.initOperatorsMap = function () {
                    var operatorList = [];
                    operatorList.push(QueryBuilder.ConditionOperator.null);
                    operatorList.push(QueryBuilder.ConditionOperator.not_null);
                    operatorList.push(QueryBuilder.ConditionOperator.yesterday);
                    operatorList.push(QueryBuilder.ConditionOperator.today);
                    operatorList.push(QueryBuilder.ConditionOperator.tomorrow);
                    operatorList.push(QueryBuilder.ConditionOperator.next_seven_days);
                    operatorList.push(QueryBuilder.ConditionOperator.last_seven_days);
                    operatorList.push(QueryBuilder.ConditionOperator.next_week);
                    operatorList.push(QueryBuilder.ConditionOperator.last_week);
                    operatorList.push(QueryBuilder.ConditionOperator.this_week);
                    operatorList.push(QueryBuilder.ConditionOperator.next_month);
                    operatorList.push(QueryBuilder.ConditionOperator.last_month);
                    operatorList.push(QueryBuilder.ConditionOperator.this_month);
                    operatorList.push(QueryBuilder.ConditionOperator.next_year);
                    operatorList.push(QueryBuilder.ConditionOperator.last_year);
                    operatorList.push(QueryBuilder.ConditionOperator.this_year);
                    operatorList.push(QueryBuilder.ConditionOperator.last_fiscal_year);
                    operatorList.push(QueryBuilder.ConditionOperator.this_fiscal_year);
                    operatorList.push(QueryBuilder.ConditionOperator.next_fiscal_year);
                    operatorList.push(QueryBuilder.ConditionOperator.last_fiscal_period);
                    operatorList.push(QueryBuilder.ConditionOperator.this_fiscal_period);
                    operatorList.push(QueryBuilder.ConditionOperator.next_fiscal_period);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_userid);
                    operatorList.push(QueryBuilder.ConditionOperator.ne_userid);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_userteams);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_useroruserteams);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_useroruserhierarchyandteams);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_useroruserhierarchy);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_businessid);
                    operatorList.push(QueryBuilder.ConditionOperator.ne_businessid);
                    operatorList.push(QueryBuilder.ConditionOperator.eq_userlanguage);
                    operatorList.push(QueryBuilder.ConditionOperator.any_time);
                    return operatorList;
                };
                OperatorsWithNoValueControl.ConditionOperatorList = function () {
                    return this.operatorList;
                };
                OperatorsWithNoValueControl.operatorList = OperatorsWithNoValueControl.initOperatorsMap();
                return OperatorsWithNoValueControl;
            }());
            AdvancedFind.OperatorsWithNoValueControl = OperatorsWithNoValueControl;
        })(AdvancedFind = QueryBuilder.AdvancedFind || (QueryBuilder.AdvancedFind = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryTreeNodeCounter = (function () {
            function QueryTreeNodeCounter() {
                this.conditionCount = 0;
                this.groupCount = 0;
                this.maxDepth = 0;
                this.oneToManyRelationshipCount = 0;
                this.manyToOneRelationshipCount = 0;
                this.manyToManyRelationshipCount = 0;
                this.doesNotContainCount = 0;
                this.operators = new QueryBuilder.Dictionary();
            }
            Object.defineProperty(QueryTreeNodeCounter.prototype, "ConditionCount", {
                get: function () {
                    return this.conditionCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "GroupCount", {
                get: function () {
                    return this.groupCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "MaxDepth", {
                get: function () {
                    return this.maxDepth;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "OneToManyRelationshipCount", {
                get: function () {
                    return this.oneToManyRelationshipCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "ManyToOneRelationshipCount", {
                get: function () {
                    return this.manyToOneRelationshipCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "ManyToManyRelationshipCount", {
                get: function () {
                    return this.manyToManyRelationshipCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "DoesNotContainCount", {
                get: function () {
                    return this.doesNotContainCount;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(QueryTreeNodeCounter.prototype, "Operators", {
                get: function () {
                    return this.operators;
                },
                enumerable: true,
                configurable: true
            });
            QueryTreeNodeCounter.prototype.handleQueryTree = function (queryTree) { };
            QueryTreeNodeCounter.prototype.handleLogicalGroupNode = function (node, nodeDepth, rootNodeContainer, containerDepth) {
                this.groupCount++;
                this.updateMaxDepth(nodeDepth);
            };
            QueryTreeNodeCounter.prototype.handleConditionNode = function (node, nodeDepth, rootNodeContainer, containerDepth) {
                this.conditionCount++;
                for (var i = 0; i < node.Condition.ControlDefinitions.length; i++) {
                    if (node.Condition.ControlDefinitions[i].name == QueryBuilder.Constants.ConditionFieldName.Operator) {
                        var operator = QueryBuilder.Utils.getControlDefinitionValue(node.Condition.ControlDefinitions[i]);
                        if (operator) {
                            if (this.operators.contains(operator)) {
                                this.operators.put(operator, this.operators.get(operator) + 1);
                            }
                            else {
                                this.operators.put(operator, 1);
                            }
                        }
                        break;
                    }
                }
                this.updateMaxDepth(nodeDepth);
            };
            QueryTreeNodeCounter.prototype.handleLinkedEntityNode = function (node, nodeDepth, rootNodeContainer, containerDepth) {
                switch (node.LinkedEntityData.RelationshipType) {
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.OneToMany:
                        this.oneToManyRelationshipCount++;
                        break;
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToOne:
                        this.manyToOneRelationshipCount++;
                        break;
                    case QueryBuilder.Constants.LinkedEntityRelationshipType.ManyToMany:
                        this.manyToManyRelationshipCount++;
                        break;
                    default:
                        break;
                }
                if (!node.ContainsData) {
                    this.doesNotContainCount++;
                }
                this.updateMaxDepth(nodeDepth);
            };
            QueryTreeNodeCounter.prototype.updateMaxDepth = function (nodeDepth) {
                if (this.maxDepth < nodeDepth) {
                    this.maxDepth = nodeDepth;
                }
            };
            return QueryTreeNodeCounter;
        }());
        QueryBuilder.QueryTreeNodeCounter = QueryTreeNodeCounter;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryTreeIteratorTemplate = (function () {
            function QueryTreeIteratorTemplate(queryTreeIterator) {
                this.queryTreeIterator = queryTreeIterator;
            }
            QueryTreeIteratorTemplate.prototype.iterate = function (queryTree) {
                this.queryTreeIterator.handleQueryTree(queryTree);
                this.handleTree(queryTree, 0);
            };
            QueryTreeIteratorTemplate.prototype.handleTree = function (tree, containerDepth) {
                if (tree.Root) {
                    this.handleNode(tree.Root, containerDepth + 1, tree, containerDepth);
                }
                for (var i = 0; i < tree.LinkedEntities.length; i++) {
                    this.handleNode(tree.LinkedEntities[i], containerDepth + 1, tree, containerDepth);
                }
            };
            QueryTreeIteratorTemplate.prototype.handleNode = function (node, nodeDepth, tree, containerDepth) {
                switch (node.NodeType) {
                    case QueryBuilder.Constants.QueryTreeNodeType.AND:
                    case QueryBuilder.Constants.QueryTreeNodeType.OR:
                        var logicalGroupNode = node;
                        this.queryTreeIterator.handleLogicalGroupNode(logicalGroupNode, nodeDepth, tree, containerDepth);
                        for (var i = 0; i < logicalGroupNode.Children.length; i++) {
                            this.handleNode(logicalGroupNode.Children[i], nodeDepth + 1, tree, containerDepth);
                        }
                        break;
                    case QueryBuilder.Constants.QueryTreeNodeType.Condition:
                        this.queryTreeIterator.handleConditionNode(node, nodeDepth, tree, containerDepth);
                        break;
                    case QueryBuilder.Constants.QueryTreeNodeType.LinkedEntity:
                        var linkedEntityNode = node;
                        this.queryTreeIterator.handleLinkedEntityNode(linkedEntityNode, nodeDepth, tree, containerDepth);
                        this.handleTree(linkedEntityNode, containerDepth + 1);
                        break;
                    default:
                        throw new Error("Unknown Node Type: " + node.NodeType);
                }
            };
            return QueryTreeIteratorTemplate;
        }());
        QueryBuilder.QueryTreeIteratorTemplate = QueryTreeIteratorTemplate;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SampleTelemetryEventHandler = (function () {
            function SampleTelemetryEventHandler() {
            }
            SampleTelemetryEventHandler.prototype.handleQueryTreeEvent = function (queryTree, event) {
                switch (event.EventType) {
                    case QueryBuilder.Constants.QueryTreeEventType.Initialized:
                    case QueryBuilder.Constants.QueryTreeEventType.Destroy:
                        queryTree.Context.reporting.reportEvent(this.getQueryTreeEvent(queryTree, event));
                        break;
                    default:
                        break;
                }
            };
            SampleTelemetryEventHandler.prototype.getQueryTreeEvent = function (queryTree, event) {
                return this.getApplicationEvent(queryTree, QueryBuilder.Constants.QueryTreeEventType[event.EventType]);
            };
            SampleTelemetryEventHandler.prototype.getApplicationEvent = function (queryTree, eventName) {
                return new QueryBuilder.QueryBuilderTelemetryEvent(eventName, this.getEventParameters(queryTree.UsageContext));
            };
            SampleTelemetryEventHandler.prototype.getEventParameters = function (usageContext) {
                return [
                    { name: "UsageContext", value: QueryBuilder.Constants.UsageContext[usageContext] },
                    { name: "EventTime", value: new Date() },
                ];
            };
            SampleTelemetryEventHandler.prototype.handleErrorEvent = function (queryTree, error) {
                var failureMessage = error && error.message ? error.message : "Error Occurred";
                queryTree.Context.reporting.reportFailure(failureMessage, error, undefined, this.getEventParameters(queryTree.UsageContext));
            };
            return SampleTelemetryEventHandler;
        }());
        QueryBuilder.SampleTelemetryEventHandler = SampleTelemetryEventHandler;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var FocusableElementPrefixSuffix = (function () {
            function FocusableElementPrefixSuffix() {
            }
            FocusableElementPrefixSuffix.getClickableListItemPrefix = function (value) {
                if (!value)
                    return "type-ahead-flyout-clickable-listItem-";
                return "type-ahead-flyout-clickable-listItem-" + value;
            };
            FocusableElementPrefixSuffix.getNonClickableListItemPrefix = function (value) {
                if (!value)
                    return "type-ahead-flyout-non-clickable-listItem-";
                return "type-ahead-flyout-non-clickable-listItem-" + value;
            };
            FocusableElementPrefixSuffix.getTypeAheadControlFlyoutPrefix = function () {
                return "type-ahead-flyout-";
            };
            FocusableElementPrefixSuffix.getTypeAheadFlyoutListPrefix = function () {
                return "type-ahead-flyout-list-";
            };
            FocusableElementPrefixSuffix.getTypeAheadControlPrefix = function () {
                return "type-ahead-control-";
            };
            FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix = function () {
                return "textbox-";
            };
            FocusableElementPrefixSuffix.getTypeAheadButtonPrefix = function () {
                return "type-ahead-button-";
            };
            FocusableElementPrefixSuffix.getTypeAheadMSIconPrefix = function () {
                return "MYICON-typeAheadbutton-";
            };
            FocusableElementPrefixSuffix.getTypeAheadListItemLabelPrefix = function (value) {
                if (!value)
                    return "type-ahead-list-icon-label-";
                return "type-ahead-list-icon-label-" + value;
            };
            FocusableElementPrefixSuffix.getDateTimeSuffix = function () {
                return "-date-time-input";
            };
            FocusableElementPrefixSuffix.getOptionSetSuffix = function () {
                return "-option-set-select";
            };
            FocusableElementPrefixSuffix.getMultiSelectSuffix = function () {
                return "_ledit";
            };
            FocusableElementPrefixSuffix.getControlNamePrefix = function () {
                return "MscrmControls.QueryBuilder.QueryBuilderControl";
            };
            return FocusableElementPrefixSuffix;
        }());
        QueryBuilder.FocusableElementPrefixSuffix = FocusableElementPrefixSuffix;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var ListAccessibility = (function () {
            function ListAccessibility() {
            }
            ListAccessibility.keyboardNavigation = function (event, clickTarget) {
                if (ListAccessibility.supportedKeys.indexOf(event.keyCode) === -1) {
                    return;
                }
                var target = event.target;
                var currentTarget = event.currentTarget;
                var isListTraversal = currentTarget === target.parentElement;
                var listItemTarget = isListTraversal ? target : ListAccessibility.findListItem(target, currentTarget);
                switch (event.keyCode) {
                    case 38:
                        var previousItem = listItemTarget.previousElementSibling;
                        previousItem && previousItem.focus();
                        break;
                    case 40:
                        var nextItem = listItemTarget.nextElementSibling;
                        nextItem && nextItem.focus();
                        break;
                    case 36:
                        if (isListTraversal) {
                            var firstItem = listItemTarget.parentElement.firstElementChild;
                            firstItem && firstItem.focus();
                        }
                        break;
                    case 35:
                        if (isListTraversal) {
                            var lastItem = listItemTarget.parentElement.lastElementChild;
                            lastItem && lastItem.focus();
                        }
                        break;
                    case 13:
                        (clickTarget || listItemTarget).click();
                        break;
                }
            };
            ListAccessibility.findListItem = function (el, listContainer) {
                while (el.parentElement !== listContainer && (el = el.parentElement))
                    ;
                return el;
            };
            ListAccessibility.supportedKeys = [
                38,
                40,
                13,
                36,
                35,
            ];
            return ListAccessibility;
        }());
        QueryBuilder.ListAccessibility = ListAccessibility;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var TypeAheadControlProviders = (function () {
            function TypeAheadControlProviders(parentControl) {
                var _this = this;
                this.parentControl = parentControl;
                this.handleTextBoxOnKeyDown = function (event) {
                    var self = _this;
                    if (event.keyCode === 40) {
                        if (!self.parentControl.State.isFlyoutVisible) {
                            self.parentControl.setState({ isFlyoutVisible: true });
                            QueryBuilder.QueryBuilderControl.rerenderControl(self.parentControl.Context, self.flyoutListFirstElementId);
                        }
                        self.parentControl.Context.accessibility.focusElementById(self.flyoutListFirstElementId);
                    }
                };
                this.handleTextBoxOnChange = function (event) {
                    var self = _this;
                    var associatedControl = _this.parentControl;
                    var searchText = event.target.value;
                    associatedControl.setState({ filter: searchText, isFlyoutVisible: true });
                    associatedControl.onChange(null);
                    var timer = setTimeout(function () {
                        associatedControl.Context.utils.requestRender();
                    }, 250);
                };
            }
            TypeAheadControlProviders.prototype.getFlyout = function () {
                var associatedControl = this.parentControl;
                var flyoutDivStyle = {
                    border: " 1px solid #e2e2e2",
                    backgroundColor: "#FFFFFF",
                };
                var filteredList = associatedControl.applyTextSearchFilter();
                var firstFlyoutoption = this.getFirstFlyoutOption(filteredList);
                var lastFlyoutoption = this.getLastFlyoutOption(filteredList);
                if (firstFlyoutoption)
                    this.flyoutListFirstElementId =
                        QueryBuilder.FocusableElementPrefixSuffix.getClickableListItemPrefix(firstFlyoutoption.Value) + associatedControl.Props.id;
                if (lastFlyoutoption)
                    this.flyoutListLastElementId =
                        QueryBuilder.FocusableElementPrefixSuffix.getClickableListItemPrefix(lastFlyoutoption.Value) + associatedControl.Props.id;
                var flyout = associatedControl.Context.factory.createElement("FLYOUT", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadControlFlyoutPrefix() + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadControlFlyoutPrefix() + associatedControl.Props.id,
                    relativeToElementId: associatedControl.Props.id,
                    positionType: "relative",
                    onOutsideClick: function (e) {
                        associatedControl.setState({ isFlyoutVisible: false });
                        QueryBuilder.QueryBuilderControl.rerenderControl(associatedControl.Context, QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix() + associatedControl.Props.id);
                    },
                    flyoutStyle: flyoutDivStyle,
                    flyoutDirection: 7,
                    enforceDirection: true,
                }, this.getList(filteredList));
                return flyout;
            };
            TypeAheadControlProviders.prototype.getFirstFlyoutOption = function (filteredList) {
                if (!filteredList || filteredList.length == 0) {
                    return null;
                }
                if (filteredList[0] && filteredList[0].sectionElements && filteredList[0].sectionElements.length != 0)
                    return filteredList[0].sectionElements[0];
                return null;
            };
            TypeAheadControlProviders.prototype.getLastFlyoutOption = function (filteredList) {
                if (!filteredList || filteredList.length == 0) {
                    return null;
                }
                var lastSection = filteredList[filteredList.length - 1];
                return lastSection.sectionElements[lastSection.sectionElements.length - 1];
            };
            TypeAheadControlProviders.prototype.getList = function (filteredList) {
                var associatedControl = this.parentControl;
                var listItems = [];
                for (var _i = 0, filteredList_1 = filteredList; _i < filteredList_1.length; _i++) {
                    var section = filteredList_1[_i];
                    if (section.sectionName && section.sectionName.trim() != "") {
                        listItems.push(this.getNonClickableListItems(section.sectionName));
                    }
                    for (var _a = 0, _b = section.sectionElements; _a < _b.length; _a++) {
                        var sectionElement = _b[_a];
                        listItems.push(this.getClickableListItems(sectionElement));
                    }
                }
                return associatedControl.Context.factory.createElement("LIST", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadFlyoutListPrefix() + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadFlyoutListPrefix() + associatedControl.Props.id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListStyle(associatedControl.Context.theming),
                    onKeyDown: function (event) {
                        return event.keyCode === 27
                            ? (associatedControl.toggleFlyout(),
                                QueryBuilder.QueryBuilderControl.rerenderControl(associatedControl.Context, QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix() + associatedControl.Props.id))
                            : event.keyCode === 9
                                ? event.preventDefault()
                                : QueryBuilder.ListAccessibility.keyboardNavigation(event);
                    },
                }, listItems);
            };
            TypeAheadControlProviders.prototype.getClickableListItems = function (child) {
                var associatedControl = this.parentControl;
                var label = associatedControl.Context.factory.createElement("LABEL", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadListItemLabelPrefix(child.Value) + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadListItemLabelPrefix(child.Value) + associatedControl.Props.id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutLabelStyle(associatedControl.Context.theming),
                }, [child.Label]);
                return associatedControl.Context.factory.createElement("LISTITEM", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getClickableListItemPrefix(child.Value) + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getClickableListItemPrefix(child.Value) + associatedControl.Props.id,
                    tabIndex: 0,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListItemStyle(associatedControl.Context.theming),
                    onClick: function (e) {
                        var oldSelectedValue = associatedControl.State.selectedValue
                            ? associatedControl.State.selectedValue.Value
                            : null;
                        if (oldSelectedValue || oldSelectedValue != child.Value) {
                            QueryBuilder.QueryBuilderControl.setPostRenderFocusElementId(QueryBuilder.ComponentIdPrefixesAndSuffixes.getTypeAheadTextBoxPrefix() + associatedControl.Props.id);
                            associatedControl.setState({ isFlyoutVisible: false });
                            associatedControl.onChange(child);
                        }
                        e.preventDefault();
                    },
                    onKeyDown: function (event) {
                        event.preventDefault();
                    },
                }, [label]);
            };
            TypeAheadControlProviders.prototype.getNonClickableListItems = function (child) {
                var associatedControl = this.parentControl;
                var label = associatedControl.Context.factory.createElement("LABEL", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadListItemLabelPrefix(child) + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadListItemLabelPrefix(child) + associatedControl.Props.id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderFlyoutListItemLabelStyle(associatedControl.Context.theming, associatedControl.Context.client.isRTL),
                }, [child]);
                return associatedControl.Context.factory.createElement("LISTITEM", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getNonClickableListItemPrefix(child) + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getNonClickableListItemPrefix(child) + associatedControl.Props.id,
                    tabIndex: 0,
                }, [label]);
            };
            TypeAheadControlProviders.prototype.getTextControl = function (textboxWidth) {
                var associatedControl = this.parentControl;
                var style = QueryBuilder.QueryBuilderStyle.QueryBuilderTypeAheadTextBoxStyle(associatedControl.Context.theming);
                return associatedControl.Context.factory.createElement("TEXTINPUT", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix() + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadTextBoxPrefix() + associatedControl.Props.id,
                    style: textboxWidth && textboxWidth !== "" ? Object.assign({}, style, { width: textboxWidth }) : style,
                    value: associatedControl.State && associatedControl.State.selectedValue
                        ? associatedControl.State.selectedValue.Label
                        : associatedControl.State.filter && associatedControl.State.filter.trim() != ""
                            ? associatedControl.State.filter
                            : null,
                    onChange: this.handleTextBoxOnChange,
                    onKeyDown: this.handleTextBoxOnKeyDown,
                    placeholder: "--" + associatedControl.Props.controlLabel + "--",
                }, {});
            };
            TypeAheadControlProviders.prototype.getButtonControl = function () {
                var associatedControl = this.parentControl;
                return associatedControl.Context.factory.createElement("BUTTON", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadButtonPrefix() + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadButtonPrefix() + associatedControl.Props.id,
                    style: QueryBuilder.QueryBuilderStyle.QueryBuilderTextBoxIconStyle(associatedControl.Context.theming),
                    onClick: associatedControl.onClick,
                    tabIndex: -1,
                }, [this.getButtonDownArrowIcon()]);
            };
            TypeAheadControlProviders.prototype.getButtonDownArrowIcon = function () {
                var associatedControl = this.parentControl;
                var style = {
                    paddingLeft: this.parentControl.Context.theming.measures.measure025,
                    paddingRight: this.parentControl.Context.theming.measures.measure025,
                };
                return this.parentControl.Context.factory.createElement("MICROSOFTICON", {
                    id: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadMSIconPrefix() + associatedControl.Props.id,
                    key: QueryBuilder.FocusableElementPrefixSuffix.getTypeAheadMSIconPrefix() + associatedControl.Props.id,
                    type: 72,
                    style: style,
                });
            };
            return TypeAheadControlProviders;
        }());
        QueryBuilder.TypeAheadControlProviders = TypeAheadControlProviders;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var TypeAheadSelect = (function () {
            function TypeAheadSelect(context, props, state) {
                var _this = this;
                this.onChange = function (change) {
                    if (_this.State.selectedValue !== change) {
                        _this.setState({ selectedValue: change });
                        _this.props.onChange(_this.State);
                    }
                };
                this.onClick = function () {
                    _this.toggleFlyout();
                    _this.context.utils.requestRender();
                };
                this.context = context;
                if (!props)
                    this.props = { id: QueryBuilder.Utils.newGuid(), key: QueryBuilder.Utils.newGuid(), options: [] };
                else
                    this.props = props;
                if (state)
                    this.state = state;
                else
                    this.state = {};
            }
            Object.defineProperty(TypeAheadSelect.prototype, "Context", {
                get: function () {
                    return this.context;
                },
                set: function (context) {
                    this.context = context;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TypeAheadSelect.prototype, "Options", {
                get: function () {
                    return this.Props.options;
                },
                set: function (options) {
                    this.Props.options = options;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TypeAheadSelect.prototype, "Props", {
                get: function () {
                    return this.props;
                },
                set: function (props) {
                    this.props = props;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TypeAheadSelect.prototype, "State", {
                get: function () {
                    return this.state;
                },
                set: function (state) {
                    this.state = state;
                },
                enumerable: true,
                configurable: true
            });
            TypeAheadSelect.prototype.setState = function (state) {
                Object.assign(this.state, {}, state);
            };
            TypeAheadSelect.prototype.getView = function () {
                var self = this;
                if (!this.controlProvider)
                    this.controlProvider = new QueryBuilder.TypeAheadControlProviders(this);
                var style = QueryBuilder.QueryBuilderStyle.QueryBuilderSelectBoxStyle(this.context.theming);
                if (this.props.hidden) {
                    Object.assign(style, {}, { display: "none" });
                }
                return this.context.factory.createElement("CONTAINER", {
                    id: this.props.id,
                    key: this.props.key,
                    style: style,
                    testhooks: { testid: self.props.name + "_" + self.props.id },
                }, [
                    this.controlProvider.getTextControl(this.props.style.width),
                    this.controlProvider.getButtonControl(),
                    this.state.isFlyoutVisible ? this.controlProvider.getFlyout() : null,
                ]);
            };
            TypeAheadSelect.prototype.toggleFlyout = function () {
                this.setState({ isFlyoutVisible: !this.State.isFlyoutVisible });
            };
            TypeAheadSelect.prototype.applyTextSearchFilter = function () {
                var _this = this;
                if (!this.State.filter || this.State.filter.trim() == "") {
                    return this.Props.options;
                }
                var options = new Array();
                for (var _i = 0, _a = this.Props.options; _i < _a.length; _i++) {
                    var section = _a[_i];
                    var newSection = {
                        sectionName: section.sectionName,
                        sectionElements: null,
                    };
                    var filteredElements = section.sectionElements.filter(function (element) {
                        return element.Label.toLocaleUpperCase().includes(_this.State.filter.toLocaleUpperCase());
                    });
                    newSection.sectionElements = filteredElements;
                    if (filteredElements && filteredElements.length > 0) {
                        options.push(newSection);
                    }
                }
                return options;
            };
            return TypeAheadSelect;
        }());
        QueryBuilder.TypeAheadSelect = TypeAheadSelect;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryTreeValidationService = (function () {
            function QueryTreeValidationService() {
                this.hasErrors = false;
            }
            QueryTreeValidationService.prototype.validate = function (queryTree, usageContext) {
                var validationResults = [];
                var commonValidatorResult = new QueryBuilder.QueryBuilderValidationResult();
                validationResults.push(commonValidatorResult);
                new QueryBuilder.QueryBuilderCommonValidator().validate(queryTree, commonValidatorResult);
                var validator = new QueryBuilder.ValidatorRegistry().getValidator(usageContext);
                if (validator) {
                    var contextValidatorResult = new QueryBuilder.QueryBuilderValidationResult();
                    validationResults.push(contextValidatorResult);
                    validator.validate(queryTree, contextValidatorResult);
                }
                this.updateQueryTree(queryTree, validationResults);
            };
            QueryTreeValidationService.prototype.updateQueryTree = function (queryTree, validationResults) {
                if (queryTree && validationResults && validationResults.length > 0) {
                    queryTree.Errors.length = 0;
                    queryTree.Errors = this.collateErrors(QueryBuilder.Utils.EMPTY_GUID, validationResults);
                    this.updateNodeErrors(queryTree.Root, validationResults);
                    for (var _i = 0, _a = queryTree.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.updateLinkedEntityErrors(linkedEntity, validationResults);
                    }
                    queryTree.HasErrors = this.hasErrors;
                    validationResults.length = 0;
                }
            };
            QueryTreeValidationService.prototype.collateErrors = function (id, validationResults) {
                var records = [];
                for (var _i = 0, validationResults_1 = validationResults; _i < validationResults_1.length; _i++) {
                    var result = validationResults_1[_i];
                    if (result.hasRecords(id)) {
                        var _loop_3 = function (record) {
                            if (!records.filter(function (x) { return x.ErrorKey == record.ErrorKey && x.Level == record.Level; })[0]) {
                                records.push(record);
                                this_2.hasErrors = true;
                            }
                        };
                        var this_2 = this;
                        for (var _a = 0, _b = result.getValidationRecords(id); _a < _b.length; _a++) {
                            var record = _b[_a];
                            _loop_3(record);
                        }
                    }
                }
                return records;
            };
            QueryTreeValidationService.prototype.updateNodeErrors = function (node, validationResults) {
                if (node) {
                    node.Errors.length = 0;
                    node.Errors = this.collateErrors(node.Id, validationResults);
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.Condition &&
                        node.Condition.ControlDefinitions) {
                        for (var _i = 0, _a = node.Condition.ControlDefinitions; _i < _a.length; _i++) {
                            var controldef = _a[_i];
                            controldef.errors = this.getControlDefinitionErrors(node, controldef);
                        }
                    }
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND || node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        for (var _b = 0, _c = node.Children; _b < _c.length; _b++) {
                            var child = _c[_b];
                            this.updateNodeErrors(child, validationResults);
                        }
                    }
                }
            };
            QueryTreeValidationService.prototype.updateLinkedEntityErrors = function (node, validationResults) {
                if (node) {
                    node.Errors.length = 0;
                    node.Errors = this.collateErrors(node.Id, validationResults);
                    this.updateNodeErrors(node.Root, validationResults);
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.updateLinkedEntityErrors(linkedEntity, validationResults);
                    }
                }
            };
            QueryTreeValidationService.prototype.getControlDefinitionErrors = function (node, controldef) {
                var errorStrings = [];
                if (node.Errors && node.Errors.length > 0) {
                    var errorKeys_3 = [];
                    switch (controldef.name) {
                        case QueryBuilder.Constants.ConditionFieldName.LHSEntity:
                            break;
                        case QueryBuilder.Constants.ConditionFieldName.LHSAttribute:
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_LHS_ATTRIBUTE);
                            break;
                        case QueryBuilder.Constants.ConditionFieldName.RHSValueType:
                        case QueryBuilder.Constants.ConditionFieldName.RHSEntity:
                        case QueryBuilder.Constants.ConditionFieldName.RHSAttribute:
                            break;
                        case QueryBuilder.Constants.ConditionFieldName.Operator:
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_OPERATOR);
                            break;
                        case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE);
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.TOO_LONG_VALUE);
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INVALID_VALUE);
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INVALID_PRECISION);
                            errorKeys_3.push(QueryBuilder.Constants.ValidationErrorKey.INVALID_RANGE);
                            break;
                        default:
                            break;
                    }
                    errorStrings = QueryBuilder.Utils.getErrorStrings(node.Context, node.Errors.filter(function (x) {
                        for (var _i = 0, errorKeys_4 = errorKeys_3; _i < errorKeys_4.length; _i++) {
                            var errorKey = errorKeys_4[_i];
                            if (x.ErrorKey == errorKey) {
                                return true;
                            }
                        }
                        return false;
                    }));
                }
                return errorStrings;
            };
            return QueryTreeValidationService;
        }());
        QueryBuilder.QueryTreeValidationService = QueryTreeValidationService;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindTelemetryEventHandler = (function () {
            function AdvancedFindTelemetryEventHandler() {
            }
            AdvancedFindTelemetryEventHandler.prototype.handleQueryTreeEvent = function (queryTree, event) {
                switch (event.EventType) {
                    case QueryBuilder.Constants.QueryTreeEventType.Initialized:
                    case QueryBuilder.Constants.QueryTreeEventType.Destroy:
                        var counter = new QueryBuilder.QueryTreeNodeCounter();
                        new QueryBuilder.QueryTreeIteratorTemplate(counter).iterate(queryTree);
                        queryTree.Context.reporting.reportEvent(this.getQueryTreeEvent(queryTree, event, counter));
                        break;
                    default:
                        break;
                }
            };
            AdvancedFindTelemetryEventHandler.prototype.getQueryTreeEvent = function (queryTree, event, counter) {
                var eventParameters = this.getEventParameters(queryTree);
                eventParameters.push({ name: "ConditionCount", value: counter.ConditionCount });
                eventParameters.push({ name: "GroupCount", value: counter.GroupCount });
                eventParameters.push({ name: "MaxDepth", value: counter.MaxDepth });
                eventParameters.push({ name: "OneToManyRelationshipCount", value: counter.OneToManyRelationshipCount });
                eventParameters.push({ name: "ManyToOneRelationshipCount", value: counter.ManyToOneRelationshipCount });
                eventParameters.push({ name: "ManyToManyRelationshipCount", value: counter.ManyToManyRelationshipCount });
                eventParameters.push({ name: "DoesNotContainCount", value: counter.DoesNotContainCount });
                eventParameters.push({ name: "OperatorsCount", value: counter.Operators.count() });
                for (var _i = 0, _a = counter.Operators.keys(); _i < _a.length; _i++) {
                    var key = _a[_i];
                    eventParameters.push({ name: "Operator: " + key, value: counter.Operators.get(key) });
                }
                return new QueryBuilder.QueryBuilderTelemetryEvent(QueryBuilder.Constants.QueryTreeEventType[event.EventType], eventParameters);
            };
            AdvancedFindTelemetryEventHandler.prototype.getEventParameters = function (queryTree) {
                return [
                    { name: "UsageContext", value: QueryBuilder.Constants.UsageContext[queryTree.UsageContext] },
                    { name: "EventTime", value: new Date() },
                ];
            };
            AdvancedFindTelemetryEventHandler.prototype.handleErrorEvent = function (queryTree, error) {
                var failureMessage = error && error.message ? error.message : "Error Occurred";
                queryTree.Context.reporting.reportFailure(failureMessage, error, undefined, this.getEventParameters(queryTree));
            };
            return AdvancedFindTelemetryEventHandler;
        }());
        QueryBuilder.AdvancedFindTelemetryEventHandler = AdvancedFindTelemetryEventHandler;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var Dictionary = (function () {
            function Dictionary() {
                this._data = {};
            }
            Dictionary.prototype.put = function (key, value) {
                this._data[key] = value;
            };
            Dictionary.prototype.get = function (key) {
                return this._data[key];
            };
            Dictionary.prototype.remove = function (key) {
                delete this._data[key];
            };
            Dictionary.prototype.contains = function (key) {
                return key in this._data;
            };
            Dictionary.prototype.count = function () {
                return this.keys().length;
            };
            Dictionary.prototype.keys = function () {
                return Object.keys(this._data);
            };
            return Dictionary;
        }());
        QueryBuilder.Dictionary = Dictionary;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var Set = (function () {
            function Set() {
                this._data = new QueryBuilder.Dictionary();
            }
            Set.prototype.put = function (key) {
                if (!this.exists(key)) {
                    this._data.put(key, true);
                }
            };
            Set.prototype.exists = function (key) {
                return this._data.contains(key);
            };
            Set.prototype.count = function () {
                return this._data.count();
            };
            Set.prototype.toList = function () {
                return this._data.keys();
            };
            return Set;
        }());
        QueryBuilder.Set = Set;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var Utils = (function () {
            function Utils() {
            }
            Utils.newGuid = function () {
                return (Utils.getRandomGuidSubstr(null) +
                    Utils.getRandomGuidSubstr(true) +
                    Utils.getRandomGuidSubstr(true) +
                    Utils.getRandomGuidSubstr(null));
            };
            Utils.getRandomGuidSubstr = function (s) {
                var p = (Math.random().toString(16) + "000000000").substr(2, 8);
                return s ? "-" + p.substr(0, 4) + "-" + p.substr(4, 4) : p;
            };
            Utils.getSectionElement = function (displayName, logicalName) {
                return { Value: logicalName, Label: displayName };
            };
            Utils.sortSelectOptions = function (sectionElements) {
                sectionElements.sort(function (a, b) {
                    return a.Label.localeCompare(b.Label);
                });
            };
            Utils.getRelatedEntityAttributeDisplayName = function (entityDisplayName, attributeDisplayName) {
                return MscrmCommon.ControlUtils.String.Format("{0} ({1})", entityDisplayName, attributeDisplayName);
            };
            Utils.getRelatedEntityAttributeLogicalName = function (relationShipType, fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) {
                return [
                    relationShipType,
                    fromEntityLogicalName,
                    fromAttributeLogicalName,
                    toEntityLogicalName,
                    toAttributeLogicalName,
                ].join();
            };
            Utils.getResourceString = function (context, resourceString) {
                return context ? context.resources.getString(resourceString) : resourceString;
            };
            Utils.getErrorStrings = function (context, validationRecords) {
                var errorStrings = [];
                if (validationRecords) {
                    for (var _i = 0, validationRecords_1 = validationRecords; _i < validationRecords_1.length; _i++) {
                        var record = validationRecords_1[_i];
                        if (record.Level == QueryBuilder.Constants.ValidationLevel.ERROR) {
                            errorStrings.push(this.getResourceString(context, this.errorKeyToString(record.ErrorKey)));
                        }
                    }
                }
                return errorStrings;
            };
            Utils.errorKeyToString = function (enumType) {
                switch (enumType) {
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_CONDITION:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_CONDITION;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_LHS_ATTRIBUTE:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_LHS_ATTRIBUTE;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_LHS_ENTITY:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_LHS_ENTITY;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_OPERATOR:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_OPERATOR;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_RHS_ATTRIBUTE:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_RHS_ATTRIBUTE;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_RHS_ENTITY:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_RHS_ENTITY;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_RHS_VALUE_TYPE:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_RHS_VALUE_TYPE;
                    case QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE:
                        return QueryBuilder.LocalizedStrings.INCOMPLETE_VALUE;
                    case QueryBuilder.Constants.ValidationErrorKey.INVALID_VALUE:
                        return QueryBuilder.LocalizedStrings.INVALID_VALUE;
                    case QueryBuilder.Constants.ValidationErrorKey.INVALID_RANGE:
                        return QueryBuilder.LocalizedStrings.INVALID_RANGE;
                    case QueryBuilder.Constants.ValidationErrorKey.INVALID_PRECISION:
                        return QueryBuilder.LocalizedStrings.INVALID_PRECISION;
                }
            };
            Utils.createTextBoxDefinition = function (context, name, isHidden, value, parentCondition) {
                return new QueryBuilder.ConditionModel.TextBoxDefinition(context, name, null, isHidden, null, null, null, null, null, { value: value }, parentCondition);
            };
            Utils.createTypeAheadSelectDefinition = function (context, name, label, isHidden, value, parentCondition, data, width, controlLabel, controlChangeHandler) {
                return new QueryBuilder.ConditionModel.TypeAheadSelectDefinition(context, name, label, isHidden, { value: value }, parentCondition, data, null, controlLabel, width, controlChangeHandler);
            };
            Utils.createOptionSetDefinition = function (context, name, isHidden, data, value, parentCondition) {
                return new QueryBuilder.ConditionModel.OptionSetDefinition(context, name, "Value", isHidden, data, { value: value }, parentCondition);
            };
            Utils.createDateTimeDefinition = function (context, name, isHidden, value, parentCondition) {
                return new QueryBuilder.ConditionModel.DateTimeDefinition(context, name, "Value", isHidden, { value: QueryBuilder.AdvancedFindUtils.GetDateObject(value) }, parentCondition);
            };
            Utils.createOptionSetDefinitionForFiscalPeriod = function (context, name, isHidden, data, value, parentCondition) {
                var valueArg = value ? value : Utils.getCurrentPeriod();
                return new QueryBuilder.ConditionModel.OptionSetDefinition(context, name, "Value", isHidden, data, { value: valueArg }, parentCondition);
            };
            Utils.createOptionSetDefinitionforFiscalYear = function (context, name, isHidden, data, value, parentCondition) {
                var valueArg = value ? value : Utils.getCurrentYear();
                return new QueryBuilder.ConditionModel.OptionSetDefinition(context, name, "Value", isHidden, data, { value: valueArg }, parentCondition);
            };
            Utils.createFiscalYearAndPeriodDefinition = function (context, name, isHidden, data, value, parentCondition) {
                var valueArg = value
                    ? value
                    : {
                        periodValue: Utils.getCurrentPeriod(),
                        yearValue: Utils.getCurrentYear(),
                    };
                return new QueryBuilder.ConditionModel.FiscalYearAndPeriodDefinition(context, name, "Value", isHidden, data, valueArg, parentCondition);
            };
            Utils.createMultiSelectPicklistDefinition = function (context, name, isHidden, data, values, parentCondition) {
                return new QueryBuilder.ConditionModel.MultiSelectPicklistDefinition(context, name, "Value", isHidden, data, values ? Utils.convertToIControlValues(values) : [], parentCondition);
            };
            Utils.createSimpleLookupDefinition = function (context, name, isHidden, targets, value, parentCondition) {
                return new QueryBuilder.ConditionModel.SimpleLookupDefinition(context, name, "Value", isHidden, targets, value, parentCondition);
            };
            Utils.createPartyListLookupDefinition = function (context, name, isHidden, targets, values, parentCondition) {
                return new QueryBuilder.ConditionModel.PartyListLookupDefinition(context, name, "Value", isHidden, targets, values ? values : [], parentCondition);
            };
            Utils.createComboBoxDefinition = function (context, name, isHidden, data, value, parentCondition) {
                return new QueryBuilder.ConditionModel.ComboBoxDefinition(context, name, "ComboBox", isHidden, data, { value: value }, parentCondition);
            };
            Utils.convertToIControlValues = function (values) {
                var controlValues = [];
                for (var i = 0; i < values.length; i++) {
                    controlValues.push({ value: values[i] });
                }
                return controlValues;
            };
            Utils.isControlDefinitionValueSet = function (controlDefinition) {
                switch (controlDefinition.type) {
                    case QueryBuilder.ConditionModel.ControlTypes.TextBox:
                        return controlDefinition.value.value ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.DateTime:
                        return controlDefinition.value.value ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.ComboBox:
                        return controlDefinition.value.value ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.OptionSet:
                        var optionSetId = controlDefinition.value.value;
                        return optionSetId != null && optionSetId >= 0 ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.TypeAheadSelect:
                        return controlDefinition.value.value ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.MultiSelectPicklist:
                        var options = Utils.convertToStringValues(controlDefinition.values);
                        return options && options.length > 0 ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                        return controlDefinition.value ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                        var values = controlDefinition.values;
                        return values && values.length > 0 ? true : false;
                    case QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod:
                        var value = controlDefinition.value;
                        return value.periodValue != null && value.yearValue != null ? true : false;
                    default:
                        return false;
                }
            };
            Utils.getControlDefinitionValue = function (controlDefinition) {
                switch (controlDefinition.type) {
                    case QueryBuilder.ConditionModel.ControlTypes.TextBox:
                        return controlDefinition.value.value;
                    case QueryBuilder.ConditionModel.ControlTypes.DateTime:
                        return QueryBuilder.AdvancedFindUtils.GetDateString(controlDefinition.value.value);
                    case QueryBuilder.ConditionModel.ControlTypes.ComboBox:
                        return controlDefinition.value.value;
                    case QueryBuilder.ConditionModel.ControlTypes.OptionSet:
                        return controlDefinition.value.value;
                    case QueryBuilder.ConditionModel.ControlTypes.TypeAheadSelect:
                        return controlDefinition.value.value;
                    case QueryBuilder.ConditionModel.ControlTypes.MultiSelectPicklist:
                        return Utils.convertToStringValues(controlDefinition.values);
                    case QueryBuilder.ConditionModel.ControlTypes.SimpleLookup:
                        return controlDefinition.value;
                    case QueryBuilder.ConditionModel.ControlTypes.PartyListLookup:
                        return controlDefinition.values;
                    case QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod:
                        return controlDefinition.value;
                    default:
                        return undefined;
                }
            };
            Utils.convertToStringValues = function (controlValues) {
                var values = [];
                for (var i = 0; i < controlValues.length; i++) {
                    values.push(controlValues[i].value);
                }
                return values;
            };
            Utils.deepFreeze = function (obj) {
                var propNames = Object.getOwnPropertyNames(obj);
                propNames.forEach(function (name) {
                    var prop = obj[name];
                    if (typeof prop == "object" && prop !== null)
                        Utils.deepFreeze(prop);
                });
                return Object.freeze(obj);
            };
            Utils.getRelationshipTypeMapKey = function (fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName) {
                return [fromEntityLogicalName, fromAttributeLogicalName, toEntityLogicalName, toAttributeLogicalName].join();
            };
            Utils.getCurrentPeriod = function () {
                return 1;
            };
            Utils.getCurrentYear = function () {
                var date = new Date();
                return date.getFullYear();
            };
            Utils.isHierarchyEnabledForEntity = function (entityMetadata) {
                if (entityMetadata) {
                    for (var _i = 0, _a = entityMetadata.manyToOneRelationships; _i < _a.length; _i++) {
                        var manyToOne = _a[_i];
                        if (manyToOne.isHierarchical) {
                            return true;
                        }
                    }
                }
                return false;
            };
            Utils.EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
            return Utils;
        }());
        QueryBuilder.Utils = Utils;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        var AdvancedFindUtils;
        (function (AdvancedFindUtils) {
            function getAttributesOfElement(node, ignoredAttributes) {
                var attributeList = {};
                for (var i = 0; i < node.attributes.length; i++) {
                    if (!ignoredAttributes || ignoredAttributes.indexOf(node.attributes[i].name) < 0) {
                        attributeList[node.attributes[i].name] = node.attributes[i].value;
                    }
                }
                return attributeList;
            }
            AdvancedFindUtils.getAttributesOfElement = getAttributesOfElement;
            function addAttributesToElement(attributeList, node) {
                for (var attributeName in attributeList) {
                    if (attributeList.hasOwnProperty(attributeName)) {
                        var attribute = getAttr(attributeName, attributeList[attributeName]);
                        node.attributes.setNamedItem(attribute);
                    }
                }
            }
            AdvancedFindUtils.addAttributesToElement = addAttributesToElement;
            function createEntityChild(element) {
                return {
                    id: element instanceof QueryBuilder.QueryBuilderLogicalGroupNode || element instanceof QueryBuilder.QueryBuilderLinkedEntityNode
                        ? element.Id
                        : QueryBuilder.Utils.newGuid(),
                    element: element,
                };
            }
            AdvancedFindUtils.createEntityChild = createEntityChild;
            function getAttr(name, value) {
                var attribute = document.createAttribute(name);
                attribute.value = value;
                return attribute;
            }
            AdvancedFindUtils.getAttr = getAttr;
            function GetValueControlNameByAttributeAndOperator(attributeType, attributeFormatType, operator) {
                var shouldnotrendercontrol = ShouldNotRenderControl(operator);
                var controlName = attributeType;
                if (!shouldnotrendercontrol) {
                    if (operator === QueryBuilder.ConditionOperator.begins_with ||
                        operator === QueryBuilder.ConditionOperator.ends_with ||
                        operator === QueryBuilder.ConditionOperator.like ||
                        operator === QueryBuilder.ConditionOperator.not_begin_with ||
                        operator === QueryBuilder.ConditionOperator.not_end_with ||
                        operator === QueryBuilder.ConditionOperator.not_like) {
                        controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType;
                    }
                    else {
                        switch (attributeType) {
                            case QueryBuilder.EntityAttributeType.DateTime:
                                if (operator === QueryBuilder.ConditionOperator.in_fiscal_year || operator === QueryBuilder.ConditionOperator.in_fiscal_period) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.OptionSetType;
                                }
                                else if (operator === QueryBuilder.ConditionOperator.in_fiscal_period_and_year ||
                                    operator === QueryBuilder.ConditionOperator.in_or_before_fiscal_period_and_year ||
                                    operator === QueryBuilder.ConditionOperator.in_or_after_fiscal_period_and_year) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.FiscalYearAndPeriodType;
                                }
                                else if (operator === QueryBuilder.ConditionOperator.on ||
                                    operator === QueryBuilder.ConditionOperator.on_or_before ||
                                    operator === QueryBuilder.ConditionOperator.on_or_after) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.DateTimeType;
                                }
                                else {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType;
                                }
                                break;
                            case QueryBuilder.EntityAttributeType.OptionSet:
                            case QueryBuilder.EntityAttributeType.State:
                            case QueryBuilder.EntityAttributeType.Status:
                            case QueryBuilder.EntityAttributeType.TwoOptions:
                            case QueryBuilder.EntityAttributeType.EntityNameType:
                            case QueryBuilder.EntityAttributeType.MultiSelectOptionSet:
                                if (operator === QueryBuilder.ConditionOperator.in || operator == QueryBuilder.ConditionOperator.not_in) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.MultiSelectType;
                                }
                                else {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.OptionSetType;
                                }
                                break;
                            case QueryBuilder.EntityAttributeType.LookUp:
                            case QueryBuilder.EntityAttributeType.CustomerType:
                            case QueryBuilder.EntityAttributeType.OwnerType:
                            case QueryBuilder.EntityAttributeType.UniqueIdentifier:
                                if (operator === QueryBuilder.ConditionOperator.eq ||
                                    operator == QueryBuilder.ConditionOperator.neq ||
                                    operator == QueryBuilder.ConditionOperator.under ||
                                    operator == QueryBuilder.ConditionOperator.not_under) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.LookupType;
                                }
                                else if (operator === QueryBuilder.ConditionOperator.in || operator == QueryBuilder.ConditionOperator.not_in) {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.PartyListType;
                                }
                                break;
                            case QueryBuilder.EntityAttributeType.WholeNumber:
                                if (attributeFormatType == QueryBuilder.EntityAttributeTypeFormat.Language) {
                                    if (operator === QueryBuilder.ConditionOperator.in || operator == QueryBuilder.ConditionOperator.not_in) {
                                        controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.MultiSelectType;
                                    }
                                    else {
                                        controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.OptionSetType;
                                    }
                                }
                                else {
                                    controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType;
                                }
                                break;
                            case QueryBuilder.EntityAttributeType.SingleLineofText:
                            case QueryBuilder.EntityAttributeType.MultipleLineofText:
                            case QueryBuilder.EntityAttributeType.FloatingPointNumber:
                            case QueryBuilder.EntityAttributeType.DecimalNumber:
                            case QueryBuilder.EntityAttributeType.BigInt:
                            case QueryBuilder.EntityAttributeType.Currency:
                                controlName = QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType;
                                break;
                            case QueryBuilder.EntityAttributeType.PartyListType:
                            case QueryBuilder.EntityAttributeType.CalendarRulesType:
                            case QueryBuilder.EntityAttributeType.VirtualType:
                            case QueryBuilder.EntityAttributeType.ManagedPropertyType:
                            case QueryBuilder.EntityAttributeType.Image:
                            default:
                                break;
                        }
                    }
                }
                else {
                    controlName = null;
                }
                return controlName;
            }
            AdvancedFindUtils.GetValueControlNameByAttributeAndOperator = GetValueControlNameByAttributeAndOperator;
            function GetValueControlByAttributeAndOperator(context, conditionNode, attributeType, attributeFormatType, operator, value) {
                if (value === void 0) { value = null; }
                var valueControlName = GetValueControlNameByAttributeAndOperator(attributeType, attributeFormatType, operator);
                return GetValueControlByControlName(context, conditionNode, valueControlName, value, operator);
            }
            AdvancedFindUtils.GetValueControlByAttributeAndOperator = GetValueControlByAttributeAndOperator;
            function GetValueControlByControlName(context, conditionNode, valueControlName, value, operator) {
                if (value === void 0) { value = null; }
                switch (valueControlName) {
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.TextboxType:
                        return QueryBuilder.Utils.createTextBoxDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, value, conditionNode.Condition);
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.DateTimeType:
                        return QueryBuilder.Utils.createDateTimeDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, value, conditionNode.Condition);
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.OptionSetType:
                        if (operator === QueryBuilder.ConditionOperator.in_fiscal_year) {
                            return QueryBuilder.Utils.createOptionSetDefinitionforFiscalYear(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                        }
                        else if (operator === QueryBuilder.ConditionOperator.in_fiscal_period) {
                            return QueryBuilder.Utils.createOptionSetDefinitionForFiscalPeriod(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                        }
                        else {
                            return QueryBuilder.Utils.createOptionSetDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                        }
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.MultiSelectType:
                        return QueryBuilder.Utils.createMultiSelectPicklistDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.LookupType:
                        return QueryBuilder.Utils.createSimpleLookupDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.PartyListType:
                        return QueryBuilder.Utils.createPartyListLookupDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, [], value, conditionNode.Condition);
                    case QueryBuilder.AdvancedFind.FieldTypeConstants.FiscalYearAndPeriodType:
                        return QueryBuilder.Utils.createFiscalYearAndPeriodDefinition(context, QueryBuilder.Constants.ConditionFieldName.RHSValue, false, {}, value, conditionNode.Condition);
                    default:
                        return null;
                }
            }
            AdvancedFindUtils.GetValueControlByControlName = GetValueControlByControlName;
            function ShouldNotRenderControl(operator) {
                var shouldnotrendercontrol = false;
                var operatorsListWithNoValueControl = QueryBuilder.AdvancedFind.OperatorsWithNoValueControl.ConditionOperatorList();
                var operators = operatorsListWithNoValueControl.filter(function (op) {
                    return operator === op;
                });
                if (operators.length > 0 && !MscrmCommon.ControlUtils.Object.isNullOrUndefined(operators[0])) {
                    shouldnotrendercontrol = true;
                }
                return shouldnotrendercontrol;
            }
            AdvancedFindUtils.ShouldNotRenderControl = ShouldNotRenderControl;
            function GetDateString(date) {
                var year = date.getFullYear().toString();
                var month = (date.getMonth() + 1).toString();
                var day = date.getDate().toString();
                if (month.length == 1) {
                    month = "0" + month;
                }
                if (day.length == 1) {
                    day = "0" + day;
                }
                return year + "-" + month + "-" + day;
            }
            AdvancedFindUtils.GetDateString = GetDateString;
            function GetDateObject(date) {
                return new Date(date);
            }
            AdvancedFindUtils.GetDateObject = GetDateObject;
            function GetPeriodList(context) {
                var periods = new Array();
                switch (QueryBuilder.QueryBuilderQueryTree.FiscalPeriodType) {
                    case QueryBuilder.Constants.FiscalPeriodType.Annually:
                        periods.push({
                            Value: 1,
                            Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, AdvancedFindUtils.getPeriodFormatString()), [1]),
                        });
                        break;
                    case QueryBuilder.Constants.FiscalPeriodType.Semiannually:
                        for (var semester = 1; semester <= 2; semester++) {
                            periods.push({
                                Value: semester,
                                Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, AdvancedFindUtils.getPeriodFormatString()), [semester]),
                            });
                        }
                        break;
                    case QueryBuilder.Constants.FiscalPeriodType.Quarterly:
                        for (var quarterValue = 1; quarterValue <= 4; quarterValue++) {
                            periods.push({
                                Value: quarterValue,
                                Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, AdvancedFindUtils.getPeriodFormatString()), [quarterValue]),
                            });
                        }
                        break;
                    case QueryBuilder.Constants.FiscalPeriodType.Monthly:
                        for (var month = 1; month <= 12; month++) {
                            periods.push({
                                Value: month,
                                Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, QueryBuilder.QueryBuilderQueryTree.FiscalPeriodFormat === QueryBuilder.Constants.FiscalPeriodFormat.MonthName_Format
                                    ? AdvancedFindUtils.getPeriodFormatString() + month.toString()
                                    : AdvancedFindUtils.getPeriodFormatString()), [month]),
                            });
                        }
                        break;
                    case QueryBuilder.Constants.FiscalPeriodType.FourWeekPeriod:
                        for (var period = 1; period <= 13; period++) {
                            periods.push({
                                Value: period,
                                Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, AdvancedFindUtils.getPeriodFormatString()), [period]),
                            });
                        }
                        break;
                }
                return periods;
            }
            AdvancedFindUtils.GetPeriodList = GetPeriodList;
            function getPeriodFormatString() {
                switch (QueryBuilder.QueryBuilderQueryTree.FiscalPeriodFormat) {
                    case QueryBuilder.Constants.FiscalPeriodFormat.Quarter_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_Quarter_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.Q_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_Q_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.P_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_P_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.Month_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_Month_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.M_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_M_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.Semester_Format:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_Semester_Format;
                    case QueryBuilder.Constants.FiscalPeriodFormat.MonthName_Format:
                        return QueryBuilder.LocalizedStrings.FiscalMonthPrefix;
                    default:
                        return QueryBuilder.LocalizedStrings.FiscalSettings_PeriodFormat_P_Format;
                }
            }
            AdvancedFindUtils.getPeriodFormatString = getPeriodFormatString;
            function GetFiscalYearsList(context) {
                var fiscalYears = new Array();
                var epochYear = getEpochYear();
                var uptoYears = getUptoYears();
                for (var year = epochYear; year < uptoYears; year++) {
                    fiscalYears.push({
                        Value: year,
                        Label: MscrmCommon.ControlUtils.String.Format(QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.FISCAL_YEAR_FORMAT), [year]),
                    });
                }
                return fiscalYears;
            }
            AdvancedFindUtils.GetFiscalYearsList = GetFiscalYearsList;
            function GetFiscalYearAndPeriod(context) {
                var fiscalYearAndPeriod = {};
                fiscalYearAndPeriod.periods = GetPeriodList(context);
                fiscalYearAndPeriod.years = GetFiscalYearsList(context);
                return fiscalYearAndPeriod;
            }
            AdvancedFindUtils.GetFiscalYearAndPeriod = GetFiscalYearAndPeriod;
            function getEpochYear() {
                var epochYear = new Date(1970, 0, 1).getFullYear();
                return epochYear;
            }
            AdvancedFindUtils.getEpochYear = getEpochYear;
            function getUptoYears() {
                var UptoYears = getEpochYear() + 69;
                return UptoYears;
            }
            AdvancedFindUtils.getUptoYears = getUptoYears;
            function createTypeAheadSelectDefinitions(context, conditionNode, entityMetadata, entity, attributeLogicalName, operator) {
                var attributesData = entityMetadata
                    ? new QueryBuilder.AttributeMetadataProvider().populateAttributeListForTypeAheadSelect(context, entityMetadata, entity, true, false)
                    : { isSectioningEnabled: true, sections: [] };
                var operatorData = entityMetadata
                    ? new QueryBuilder.OperatorMetadataProvider().getTypeAheadSelectData(context, entityMetadata.attributes[attributeLogicalName].attributeType.Name, entityMetadata.attributes[attributeLogicalName].attributeFormatType.name)
                    : { isSectioningEnabled: true, sections: [] };
                return new Promise(function (resolve, reject) {
                    new QueryBuilder.SpecialConditionOperatorProvider()
                        .getSpecialConditionOperators(context, operatorData, attributeLogicalName, entityMetadata, true)
                        .then(function (operators) {
                        AdvancedFindUtils.appendOperators(context, operatorData.sections[0].sectionElements, operators);
                        var controlDefinitions = [
                            QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.LHSAttribute, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_ATTRIBUTE), false, attributeLogicalName, null, attributesData, "12.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_ATTRIBUTE), new QueryBuilder.ConditionModel.ConditionControlChangeHandler(conditionNode.Condition)),
                            QueryBuilder.Utils.createTypeAheadSelectDefinition(context, QueryBuilder.Constants.ConditionFieldName.Operator, QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_OPERATOR), false, operator, null, operatorData, "8.5rem", QueryBuilder.Utils.getResourceString(context, QueryBuilder.LocalizedStrings.LS_OPERATOR), new QueryBuilder.ConditionModel.ConditionControlChangeHandler(conditionNode.Condition)),
                        ];
                        resolve(controlDefinitions);
                    }, function (error) {
                        reject(error);
                    });
                });
            }
            AdvancedFindUtils.createTypeAheadSelectDefinitions = createTypeAheadSelectDefinitions;
            function appendOperators(context, currentOperators, operatorsToAppend) {
                for (var i = 0; i < operatorsToAppend.length; i++) {
                    currentOperators.push({
                        Value: operatorsToAppend[i].toString(),
                        Label: QueryBuilder.DisplayNameOperatorMapping.getDisplayName(context, operatorsToAppend[i]),
                    });
                }
            }
            AdvancedFindUtils.appendOperators = appendOperators;
            function hasErrorInAttrAndOperator(controlDefinitions) {
                for (var _i = 0, controlDefinitions_2 = controlDefinitions; _i < controlDefinitions_2.length; _i++) {
                    var controlsDef = controlDefinitions_2[_i];
                    if (controlsDef.name !== QueryBuilder.Constants.ConditionFieldName.RHSValue && controlsDef.errors.length !== 0) {
                        return true;
                    }
                }
                return false;
            }
            AdvancedFindUtils.hasErrorInAttrAndOperator = hasErrorInAttrAndOperator;
            function getAccessibilityLabelForSimpleMode(context, controlDefinitions) {
                var displayValue = "";
                for (var _i = 0, controlDefinitions_3 = controlDefinitions; _i < controlDefinitions_3.length; _i++) {
                    var controlDef = controlDefinitions_3[_i];
                    if (context.client.isRTL) {
                        displayValue = getAccessibilityLabelForControlDefinition(controlDef) + displayValue + " ";
                    }
                    else {
                        displayValue = displayValue + getAccessibilityLabelForControlDefinition(controlDef) + " ";
                    }
                }
                return displayValue;
            }
            AdvancedFindUtils.getAccessibilityLabelForSimpleMode = getAccessibilityLabelForSimpleMode;
            function getAccessibilityLabelForControlDefinition(controlDefinition) {
                if (controlDefinition.value && controlDefinition.value.value) {
                    var foundValue = void 0;
                    for (var _i = 0, _a = controlDefinition.data.sections; _i < _a.length; _i++) {
                        var section = _a[_i];
                        for (var _b = 0, _c = section.sectionElements; _b < _c.length; _b++) {
                            var sectionElem = _c[_b];
                            if (sectionElem.Value == controlDefinition.value.value) {
                                foundValue = sectionElem;
                                break;
                            }
                        }
                        if (foundValue) {
                            return foundValue.Label;
                        }
                    }
                }
            }
            AdvancedFindUtils.getAccessibilityLabelForControlDefinition = getAccessibilityLabelForControlDefinition;
            function getEntityLogicalName(rootNodeContainer) {
                return rootNodeContainer.Properties["entityAttributes"]
                    ? rootNodeContainer.Properties["entityAttributes"]["name"]
                    : undefined;
            }
            AdvancedFindUtils.getEntityLogicalName = getEntityLogicalName;
            function getRangeMinValue(operator) {
                switch (operator) {
                    case QueryBuilder.ConditionOperator.olderthan_x_minutes:
                    case QueryBuilder.ConditionOperator.last_x_hours:
                    case QueryBuilder.ConditionOperator.next_x_hours:
                    case QueryBuilder.ConditionOperator.olderthan_x_hours:
                    case QueryBuilder.ConditionOperator.last_x_days:
                    case QueryBuilder.ConditionOperator.next_x_days:
                    case QueryBuilder.ConditionOperator.olderthan_x_days:
                    case QueryBuilder.ConditionOperator.last_x_weeks:
                    case QueryBuilder.ConditionOperator.next_x_weeks:
                    case QueryBuilder.ConditionOperator.olderthan_x_weeks:
                    case QueryBuilder.ConditionOperator.last_x_months:
                    case QueryBuilder.ConditionOperator.next_x_months:
                    case QueryBuilder.ConditionOperator.olderthan_x_months:
                    case QueryBuilder.ConditionOperator.last_x_years:
                    case QueryBuilder.ConditionOperator.next_x_years:
                    case QueryBuilder.ConditionOperator.olderthan_x_years:
                    case QueryBuilder.ConditionOperator.last_x_fiscal_periods:
                    case QueryBuilder.ConditionOperator.next_x_fiscal_periods:
                    case QueryBuilder.ConditionOperator.last_x_fiscal_years:
                    case QueryBuilder.ConditionOperator.next_x_fiscal_years:
                        return 1;
                    default:
                        return 0;
                }
            }
            AdvancedFindUtils.getRangeMinValue = getRangeMinValue;
            function getRangeMaxValue(operator) {
                switch (operator) {
                    case QueryBuilder.ConditionOperator.olderthan_x_minutes:
                        return 1440;
                    case QueryBuilder.ConditionOperator.last_x_hours:
                    case QueryBuilder.ConditionOperator.next_x_hours:
                    case QueryBuilder.ConditionOperator.olderthan_x_hours:
                        return 2000;
                    case QueryBuilder.ConditionOperator.last_x_days:
                    case QueryBuilder.ConditionOperator.next_x_days:
                    case QueryBuilder.ConditionOperator.olderthan_x_days:
                        return 500;
                    case QueryBuilder.ConditionOperator.last_x_weeks:
                    case QueryBuilder.ConditionOperator.next_x_weeks:
                    case QueryBuilder.ConditionOperator.olderthan_x_weeks:
                    case QueryBuilder.ConditionOperator.last_x_months:
                    case QueryBuilder.ConditionOperator.next_x_months:
                    case QueryBuilder.ConditionOperator.olderthan_x_months:
                    case QueryBuilder.ConditionOperator.last_x_years:
                    case QueryBuilder.ConditionOperator.next_x_years:
                    case QueryBuilder.ConditionOperator.olderthan_x_years:
                    case QueryBuilder.ConditionOperator.last_x_fiscal_periods:
                    case QueryBuilder.ConditionOperator.next_x_fiscal_periods:
                    case QueryBuilder.ConditionOperator.last_x_fiscal_years:
                    case QueryBuilder.ConditionOperator.next_x_fiscal_years:
                        return 100;
                    default:
                        return 0;
                }
            }
            AdvancedFindUtils.getRangeMaxValue = getRangeMaxValue;
        })(AdvancedFindUtils = QueryBuilder.AdvancedFindUtils || (QueryBuilder.AdvancedFindUtils = {}));
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var QueryBuilderCommonValidator = (function () {
            function QueryBuilderCommonValidator() {
            }
            QueryBuilderCommonValidator.prototype.validate = function (queryTree, result) {
                if (queryTree && result) {
                    this.validateNode(queryTree.Root, result);
                    for (var _i = 0, _a = queryTree.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            QueryBuilderCommonValidator.prototype.validateNode = function (node, result) {
                if (node) {
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                        var controlDefinitions = node.Condition
                            .ControlDefinitions;
                        if (controlDefinitions) {
                            for (var _i = 0, controlDefinitions_4 = controlDefinitions; _i < controlDefinitions_4.length; _i++) {
                                var controlDefinition = controlDefinitions_4[_i];
                                switch (controlDefinition.name) {
                                    case QueryBuilder.Constants.ConditionFieldName.LHSEntity:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.LHSAttribute:
                                        var attributeErrorKey = QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_LHS_ATTRIBUTE;
                                        this.validateValue(node, result, controlDefinition, attributeErrorKey);
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.Operator:
                                        var operatorErrorKey = QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_OPERATOR;
                                        this.validateValue(node, result, controlDefinition, operatorErrorKey);
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.RHSValueType:
                                    case QueryBuilder.Constants.ConditionFieldName.RHSEntity:
                                    case QueryBuilder.Constants.ConditionFieldName.RHSAttribute:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                        var errorKey = QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE;
                                        this.validateValue(node, result, controlDefinition, errorKey);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else {
                        }
                    }
                    else if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND ||
                        node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        for (var _a = 0, _b = node.Children; _a < _b.length; _a++) {
                            var child = _b[_a];
                            this.validateNode(child, result);
                        }
                    }
                }
            };
            QueryBuilderCommonValidator.prototype.validateLinkedEntity = function (node, result) {
                if (node) {
                    this.validateNode(node.Root, result);
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            QueryBuilderCommonValidator.prototype.validateValue = function (node, result, controlDefinition, errorKey) {
                if (!errorKey) {
                    errorKey = QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE;
                }
                if (!QueryBuilder.Utils.isControlDefinitionValueSet(controlDefinition)) {
                    result.addNodeError(node.Id, errorKey);
                    return;
                }
                var value = QueryBuilder.Utils.getControlDefinitionValue(controlDefinition);
                switch (controlDefinition.type) {
                    case QueryBuilder.ConditionModel.ControlTypes.OptionSet:
                        var data = controlDefinition.data;
                        if (data && data.filter(function (option) { return option.Value == value; }).length == 0) {
                            controlDefinition.value.value = null;
                            result.addNodeError(node.Id, errorKey);
                        }
                        break;
                    case QueryBuilder.ConditionModel.ControlTypes.TypeAheadSelect:
                        var options = controlDefinition.data.sections[0]
                            .sectionElements;
                        if (options && options.filter(function (option) { return option.Value == value; }).length == 0) {
                            controlDefinition.control.setState({ selectedValue: null });
                            result.addNodeError(node.Id, errorKey);
                        }
                        break;
                    default:
                        break;
                }
            };
            return QueryBuilderCommonValidator;
        }());
        QueryBuilder.QueryBuilderCommonValidator = QueryBuilderCommonValidator;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var AdvancedFindValidator = (function () {
            function AdvancedFindValidator() {
            }
            AdvancedFindValidator.prototype.validate = function (queryTree, result) {
                if (queryTree && result) {
                    this.validateNode(queryTree.Root, result);
                    for (var _i = 0, _a = queryTree.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            AdvancedFindValidator.prototype.validateNode = function (node, result) {
                if (node) {
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                        var controlDefinitions = node.Condition
                            .ControlDefinitions;
                        if (controlDefinitions) {
                            for (var _i = 0, controlDefinitions_5 = controlDefinitions; _i < controlDefinitions_5.length; _i++) {
                                var controlDefinition = controlDefinitions_5[_i];
                                switch (controlDefinition.name) {
                                    case QueryBuilder.Constants.ConditionFieldName.LHSAttribute:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.Operator:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                        if (QueryBuilder.Utils.isControlDefinitionValueSet(controlDefinition)) {
                                            if (controlDefinition.type == QueryBuilder.ConditionModel.ControlTypes.TextBox) {
                                                this.validateTextInput(node, result, controlDefinitions);
                                            }
                                            else if (controlDefinition.type == QueryBuilder.ConditionModel.ControlTypes.FiscalYearAndPeriod) {
                                                this.validateFiscalYearAndPeriod(node, result, controlDefinition);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else {
                        }
                    }
                    else if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND ||
                        node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        for (var _a = 0, _b = node.Children; _a < _b.length; _a++) {
                            var child = _b[_a];
                            this.validateNode(child, result);
                        }
                    }
                }
            };
            AdvancedFindValidator.prototype.validateLinkedEntity = function (node, result) {
                if (node) {
                    this.validateNode(node.Root, result);
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            AdvancedFindValidator.prototype.validateFiscalYearAndPeriod = function (node, result, controlDefinition) {
                var value = QueryBuilder.Utils.getControlDefinitionValue(controlDefinition);
                var data = controlDefinition.data;
                if (data.years.filter(function (year) { return year.Value == value.yearValue; }).length == 0) {
                    controlDefinition.value.yearValue = null;
                    result.addNodeError(node.Id, QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE);
                }
                if (data.periods.filter(function (period) { return period.Value == value.periodValue; }).length == 0) {
                    controlDefinition.value.periodValue = null;
                    result.addNodeError(node.Id, QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE);
                }
            };
            AdvancedFindValidator.prototype.validateTextInput = function (node, result, controlDefinitions) {
                var attributeControlDefinition = controlDefinitions[0];
                var operatorControlDefinition = controlDefinitions[1];
                var valueControlDefinition = controlDefinitions[2];
                var attributeLogicalName = attributeControlDefinition.value.value;
                var operator = operatorControlDefinition.value.value;
                var textValue = valueControlDefinition.value.value;
                var entityLogicalName = QueryBuilder.AdvancedFindUtils.getEntityLogicalName(node.getNodeContainer());
                var attributeMetadata = QueryBuilder.MetadataStore.Instance.getAttributeMetadataByName(entityLogicalName, attributeLogicalName);
                if (!attributeMetadata) {
                    return;
                }
                var attributeType = attributeMetadata.attributeType;
                var rangeBasedValues = this.getRangeBasedValues(attributeMetadata, operator);
                var isRangeBased = rangeBasedValues.isRangeBased;
                var minValue = rangeBasedValues.minValue;
                var maxValue = rangeBasedValues.maxValue;
                var precision = rangeBasedValues.precision;
                var obj = this.getIsNumberAndPrecisionString(attributeType.Name, precision);
                var isNumber = obj.isNumber;
                var precisionString = obj.precisionString;
                var validRegex = new RegExp(precisionString, "g");
                var matchArray = textValue.match(validRegex);
                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(matchArray) || matchArray.length === 0) {
                    var errorKey = MscrmCommon.ControlUtils.String.isNullOrEmpty(textValue)
                        ? QueryBuilder.Constants.ValidationErrorKey.INCOMPLETE_VALUE
                        : QueryBuilder.Constants.ValidationErrorKey.INVALID_VALUE;
                    result.addNodeError(node.Id, errorKey);
                    return;
                }
                if (isRangeBased) {
                    var precisionMatchArray = textValue.match(new RegExp(precisionString, "g"));
                    if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(precisionMatchArray) ||
                        precisionMatchArray.length === 0) {
                        result.addNodeError(node.Id, QueryBuilder.Constants.ValidationErrorKey.INVALID_PRECISION);
                        return;
                    }
                    if (isNumber) {
                        var numValue = parseFloat(textValue);
                        if (numValue < minValue || numValue > maxValue) {
                            result.addNodeError(node.Id, QueryBuilder.Constants.ValidationErrorKey.INVALID_RANGE);
                        }
                    }
                }
            };
            AdvancedFindValidator.prototype.getRangeBasedValues = function (attributeMetadata, operator) {
                var isRangeBased = attributeMetadata.isRangeBased;
                var minValue = 0;
                var maxValue = 0;
                var precision = 0;
                if (isRangeBased) {
                    minValue = attributeMetadata.minValue;
                    maxValue = attributeMetadata.maxValue;
                    precision = attributeMetadata.precision;
                }
                if (attributeMetadata.attributeType.Name == QueryBuilder.EntityAttributeType.DateTime) {
                    isRangeBased = true;
                    minValue = QueryBuilder.AdvancedFindUtils.getRangeMinValue(operator);
                    maxValue = QueryBuilder.AdvancedFindUtils.getRangeMaxValue(operator);
                }
                return {
                    isRangeBased: isRangeBased,
                    minValue: minValue,
                    maxValue: maxValue,
                    precision: precision,
                };
            };
            AdvancedFindValidator.prototype.getIsNumberAndPrecisionString = function (attrubuteTypeName, precision) {
                var isNumber = false;
                var precisionString = "^.+$";
                switch (attrubuteTypeName) {
                    case QueryBuilder.EntityAttributeType.DateTime:
                    case QueryBuilder.EntityAttributeType.BigInt:
                    case QueryBuilder.EntityAttributeType.WholeNumber:
                        isNumber = true;
                        precisionString = "^-?\\d+$";
                        break;
                    case QueryBuilder.EntityAttributeType.FloatingPointNumber:
                    case QueryBuilder.EntityAttributeType.DecimalNumber:
                    case QueryBuilder.EntityAttributeType.Currency:
                        isNumber = true;
                        precisionString = "^-?\\d+(\\.\\d+)?$";
                        if (precision > 0) {
                            precisionString = "^-?\\d+(\\.\\d{1," + precision + "})?$";
                        }
                        break;
                    default:
                        break;
                }
                return {
                    isNumber: isNumber,
                    precisionString: precisionString,
                };
            };
            return AdvancedFindValidator;
        }());
        QueryBuilder.AdvancedFindValidator = AdvancedFindValidator;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var QueryBuilder;
    (function (QueryBuilder) {
        "use strict";
        var SampleValidator = (function () {
            function SampleValidator() {
            }
            SampleValidator.prototype.validate = function (queryTree, result) {
                if (queryTree && result) {
                    this.validateNode(queryTree.Root, result);
                    for (var _i = 0, _a = queryTree.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            SampleValidator.prototype.validateNode = function (node, result) {
                if (node) {
                    if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.Condition) {
                        var controlDefinitions = node.Condition
                            .ControlDefinitions;
                        if (controlDefinitions) {
                            for (var _i = 0, controlDefinitions_6 = controlDefinitions; _i < controlDefinitions_6.length; _i++) {
                                var controlDefinition = controlDefinitions_6[_i];
                                switch (controlDefinition.name) {
                                    case QueryBuilder.Constants.ConditionFieldName.SampleField:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.Operator:
                                        break;
                                    case QueryBuilder.Constants.ConditionFieldName.RHSValue:
                                        if (QueryBuilder.Utils.isControlDefinitionValueSet(controlDefinition)) {
                                            if (QueryBuilder.Utils.getControlDefinitionValue(controlDefinitions[0]) == "tb" &&
                                                QueryBuilder.Utils.getControlDefinitionValue(controlDefinition).length > 5) {
                                                result.addNodeError(node.Id, QueryBuilder.Constants.ValidationErrorKey.TOO_LONG_VALUE);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else {
                        }
                    }
                    else if (node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.AND ||
                        node.NodeType == QueryBuilder.Constants.QueryTreeNodeType.OR) {
                        for (var _a = 0, _b = node.Children; _a < _b.length; _a++) {
                            var child = _b[_a];
                            this.validateNode(child, result);
                        }
                    }
                }
            };
            SampleValidator.prototype.validateLinkedEntity = function (node, result) {
                if (node) {
                    this.validateNode(node.Root, result);
                    for (var _i = 0, _a = node.LinkedEntities; _i < _a.length; _i++) {
                        var linkedEntity = _a[_i];
                        this.validateLinkedEntity(linkedEntity, result);
                    }
                }
            };
            return SampleValidator;
        }());
        QueryBuilder.SampleValidator = SampleValidator;
    })(QueryBuilder = MscrmControls.QueryBuilder || (MscrmControls.QueryBuilder = {}));
})(MscrmControls || (MscrmControls = {}));
