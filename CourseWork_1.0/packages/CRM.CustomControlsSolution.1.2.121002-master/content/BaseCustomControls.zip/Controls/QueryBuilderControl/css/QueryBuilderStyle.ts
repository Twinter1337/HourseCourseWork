﻿/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
namespace MscrmControls.QueryBuilder {
	export class QueryBuilderStyle {
		public static commandBarNavStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				flexDirection: "column",
				background: theme.colors.grays.gray05,
				paddingRight: theme.measures.measure075,
				paddingLeft: theme.measures.measure075,
				fontFamily: theme.fontfamilies.regular,
				marginBottom: theme.measures.measure075,
				height: theme.measures.measure225,
				minHeight: theme.measures.measure225,
			};
		}
		public static commandBarContainerStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				flexDirection: "column",
				position: "relative",
			};
		}
		public static commandBarButtonStyle(theme: Mscrm.Theme, enable: boolean): any {
			return {
				fontSize: theme.fontsizes.font085,
				background: "transparent",
				width: "auto",
				color: "#FFFFFF",
				border: "0",
				padding: theme.measures.measure050,
				lineHeight: "18px",
				":hover": {
					background: "transparent",
				},
				flexDirection: "row",
				opacity: enable ? "1" : "0.50",
				fontFamily: theme.fontfamilies.regular,
			};
		}
		public static commandBarResetButtonStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				fontSize: theme.fontsizes.font085,
				background: "transparent",
				width: "auto",
				color: "#FFFFFF",
				border: "0",
				padding: theme.measures.measure050,
				lineHeight: "18px",
				marginLeft: isRTL ? "0" : undefined,
				marginRight: isRTL ? undefined : "0",
				":hover": {
					background: "transparent",
				},
				flexDirection: "row",
				fontFamily: theme.fontfamilies.regular,
			};
		}
		public static commandBarAdvancedButtonStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				fontSize: theme.fontsizes.font085,
				background: "transparent",
				width: "auto",
				color: "#FFFFFF",
				border: "0",
				padding: theme.measures.measure050,
				lineHeight: "18px",
				marginLeft: isRTL ? "0" : "auto",
				marginRight: isRTL ? "auto" : "0",
				":hover": {
					background: "transparent",
				},
				flexDirection: "row",
				fontFamily: theme.fontfamilies.regular,
			};
		}
		public static commandBarIconStyle(theme: Mscrm.Theme, enable: boolean): any {
			return {
				paddingRight: theme.measures.measure025,
				paddingLeft: theme.measures.measure025,
				fontSize: theme.fontsizes.font085,
				borderWidth: "0px",
				opacity: enable ? "1" : "0.50",
				fontFamily: theme.fontfamilies.regular,
			};
		}
		public static commandBarLabelConatinerStyle(theme: Mscrm.Theme): any {
			return {
				paddingRight: theme.measures.measure025,
				paddingLeft: theme.measures.measure025,
				cursor: "pointer",
			};
		}
		public static QueryBuilderConditionStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				display: "flex",
				flexDirection: "row",
			};
		}
		public static QueryBuilderGetEntityIconStyle(theme: Mscrm.Theme): any {
			return {
				fontSize: theme.fontsizes.font085,
				color: theme.colors.grays.gray05,
				paddingLeft: theme.measures.measure050,
				paddingRight: theme.measures.measure050,
				alignSelf: "center",
			};
		}
		public static QueryBuilderGetEntitylabeltStyle(theme: Mscrm.Theme): any {
			return {
				fontSize: theme.fontsizes.font085,
				fontFamily: theme.fontfamilies.regular,
				color: theme.colors.grays.gray05,
			};
		}

		public static QueryBuilderFilterStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				display: "flex",
				flexDirection: "column",
				padding: "0 0.50rem",
				height: "calc(100% - 3.5rem)",
			};
		}
		public static QueryBuilderFilterSectionStyle(theme: Mscrm.Theme): any {
			return {
				overflowY: "auto",
				display: "inline-block",
			};
		}
		public static QueryBuilderGetContextStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				width: "auto",
				display: "flex",
				flexDirection: "row",
				paddingTop: theme.measures.measure050,
				paddingBottom: theme.measures.measure050,
				marginRight: isRTL ? undefined : theme.measures.measure025,
				marginLeft: isRTL ? theme.measures.measure025 : undefined,
				backgroundColor: "rgba(234,6,0,0.1)",
			};
		}
		public static QueryBuilderGetEntityContainerStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				display: "flex",
				flexDirection: "row",
				paddingBottom: theme.measures.measure050,
				backgroundColor: "transparent",
			};
		}
		public static QueryBuilderSelectBoxStyle(theme: Mscrm.Theme): any {
			return {
				display: "flex",
				flexDirection: "row",
				width: "fit-content",
				height: "auto",
				fontFamily: theme.fontfamilies.regular,
				color: theme.colors.grays.gray05,
			};
		}
		public static QueryBuilderRelatedSelectboxStyle(theme: Mscrm.Theme): any {
			return {
				borderWidth: "1px",
				borderStyle: "solid",
				borderColor: theme.colors.grays.gray04,
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
			};
		}
		public static QueryBuilderRelatedEntitySelectboxStyle(theme: Mscrm.Theme): any {
			return {
				border: "none",
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
			};
		}
		public static CommandBarButtonConatinerStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				flexDirection: "row",
			};
		}
		public static RelatedEntityConatinerStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				flexDirection: "column",
				paddingLeft: isRTL ? undefined : theme.measures.measure200,
				paddingRight: isRTL ? theme.measures.measure200 : undefined,
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: " solid",
				borderColor: theme.colors.grays.gray02,
			};
		}
		public static LinkedEntityHeaderConatinerStyle(theme: Mscrm.Theme): any {
			return {
				display: "flex",
				flexDirection: "row",
				height: "100%",
				background: theme.colors.grays.gray01,
				marginBottom: theme.measures.measure050,
				alignItems: "center",
			};
		}
		public static QueryBuilderDropDownLinkButtonStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				marginLeft: isRTL ? "0" : "auto",
				marginRight: isRTL ? "auto" : "0",
				background: theme.colors.grays.gray01,
				color: theme.colors.grays.gray06,
				lineHeight: theme.measures.measure225,
				border: "0",
				":hover": {
					background: theme.colors.grays.gray03,
				},
			};
		}
		public static RelatedEntityDisplayTextLabelStyle(theme: Mscrm.Theme): any {
			return {
				paddingLeft: theme.measures.measure050,
				paddingRight: theme.measures.measure050,
				color: theme.colors.grays.gray06,
				fontSize: theme.fontsizes.font085,
				overflow: "hidden",
				width: "auto",
				maxWidth: "20rem",
				whiteSpace: "nowrap",
				textOverflow: "ellipsis",
			};
		}
		public static EmptyFilterSectionSimpleModeStyle(theme: Mscrm.Theme): any {
			return {
				paddingLeft: theme.measures.measure050,
				paddingRight: theme.measures.measure050,
				color: theme.colors.grays.gray06,
				fontSize: theme.fontsizes.font085,
				overflow: "hidden",
				width: "auto",
				whiteSpace: "nowrap",
				textOverflow: "ellipsis",
			};
		}
		public static RelatedEntityDisplayIconLabelStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				paddingLeft: theme.measures.measure050,
				paddingRight: theme.measures.measure050,
				fontFamily: theme.fontfamilies.regular,
				color: theme.colors.grays.gray06,
				fontSize: theme.fontsizes.font085,
				marginLeft: isRTL ? undefined : "auto",
				marginRight: isRTL ? "auto" : undefined,
			};
		}
		public static ConditionNodeConatinerStyle(theme: Mscrm.Theme): any {
			return {
				display: "flex",
				flexDirection: "row",
				width: "auto",
			};
		}
		public static ConditionNodeWrapConatinerStyle(theme: Mscrm.Theme, nodeHasError: Boolean, isRTL: boolean): any {
			return {
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: "solid",
				borderColor: nodeHasError ? theme.colors.basecolor.red["red3"] : theme.colors.grays.gray04,
				display: "flex",
				flexDirection: "column",
				marginBottom: theme.measures.measure050,
				width: "auto",
			};
		}
		public static ConditionErrorConatinerStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				display: "flex",
				flexDirection: "column",
			};
		}
		public static ConditionErrorLabelStyle(theme: Mscrm.Theme): any {
			return {
				fontFamily: theme.fontfamilies.semibold,
				fontSize: theme.fontsizes.font085,
				color: theme.colors.basecolor.red["red4"],
				paddingLeft: theme.measures.measure025,
				paddingRight: theme.measures.measure025,
				alignSelf: "center",
			};
		}
		public static ConditionErrorIconStyle(theme: Mscrm.Theme): any {
			return {
				fontSize: theme.fontsizes.font085,
				color: theme.colors.basecolor.red["red4"],
				paddingLeft: theme.measures.measure025,
				paddingRight: theme.measures.measure025,
				alignSelf: "center",
			};
		}
		public static commandBarTextConatinerStyle(theme: Mscrm.Theme): any {
			return {
				display: "flex",
				flexDirection: "column",
			};
		}
		public static GroupNodeListStyle(theme: Mscrm.Theme, isRootNode: boolean, isMarginBottomNotRequired: boolean): any {
			return {
				flexDirection: "row",
				marginBottom: isMarginBottomNotRequired ? undefined : theme.measures.measure050,
			};
		}
		public static GroupAndViewConatinerStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: " solid",
				borderColor: theme.colors.grays.gray04,
				display: "flex",
				flexDirection: "column",
				position: "relative",
				width: theme.measures.measure225,
				textAlign: "center",
			};
		}
		public static GroupOrViewConatinerStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: " dashed",
				borderColor: theme.colors.grays.gray04,
				display: "flex",
				flexDirection: "column",
				position: "relative",
				width: theme.measures.measure225,
				textAlign: "center",
			};
		}
		public static ChildViewConatinerStyle(theme: Mscrm.Theme): any {
			return {
				display: "flex",
				flexDirection: "column",
			};
		}
		public static QueryBuilderTypeAheadTextBoxStyle(theme: Mscrm.Theme): any {
			return {
				border: "none",
				padding: theme.measures.measure025,
				height: "auto",
				color: theme.colors.grays.gray05,
				fontFamily: theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
			};
		}

		public static QueryBuilderTypeAheadContainerStyle(width: string): ITypeAheadStyle {
			return {
				width: width ? width : "auto",
				background: "#ffffff",
				border: "1px solid #b3b3b3",
			};
		}

		public static QueryBuilderValueTextBoxStyle(theme: Mscrm.Theme): any {
			return {
				padding: theme.measures.measure025,
				height: "auto",
				color: theme.colors.grays.gray05,
				fontFamily: theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
				border: "none",
				width: "100%",
			};
		}
		public static QueryBuilderValueReadOnlyStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				paddingLeft: theme.measures.measure025,
				paddingRight: theme.measures.measure025,
				fontSize: theme.fontsizes.font085,
				fontFamily: theme.fontfamilies.regular,
				color: theme.colors.grays.gray05,
				width: "auto",
				textAlign: isRTL ? "right" : "left",
				lineHeight: "275%",
			};
		}

		public static QueryBuilderValueFiscalYearAndPeriodStyle(theme: Mscrm.Theme): any {
			return {
				height: "auto",
				width: "100%",
				color: theme.colors.grays.gray05,
				fontFamily: theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
				border: "none",
			};
		}
		public static QueryBuilderTextBoxIconStyle(theme: Mscrm.Theme): any {
			return {
				background: theme.colors.basecolor.white,
				height: "100%",
				width: "auto",
				padding: theme.measures.measure025,
				border: "none",
				color: theme.colors.grays.gray05,
				fontFamily: theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
				lineHeight: theme.measures.measure200,
				":hover": {
					background: theme.colors.grays.gray01,
				},
			};
		}
		public static QueryBuilderCheckboxStyle(theme: Mscrm.Theme): any {
			return {
				cursor: "pointer",
				marginLeft: theme.measures.measure050,
				marginRight: theme.measures.measure050,
				marginTop: theme.measures.measure075,
				marginBottom: theme.measures.measure075,
				height: "12px",
				width: "12px",
			};
		}
		public static QueryBuilderCommandBarCheckboxStyle(theme: Mscrm.Theme): any {
			return {
				cursor: "pointer",
				marginLeft: theme.measures.measure050,
				marginRight: theme.measures.measure050,
				height: "12px",
				width: "12px",
			};
		}
		public static QueryBuilderLinkButtonStyle(theme: Mscrm.Theme): any {
			return {
				background: "none",
				border: "none",
				padding: "0",
				cursor: "pointer",
				color: theme.colors.basecolor.blue["blue3"],
				textDecoration: "none",
				lineHeight: theme.measures.measure200,
				fontSize: theme.fontsizes.font085,
				fontFamily: theme.fontfamilies.regular,
				":hover": {
					background: "none",
					color: theme.colors.basecolor.blue["blue3"],
				},
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
			};
		}
		public static QueryBuilderLabelIconStyle(theme: Mscrm.Theme): any {
			return {
				color: theme.colors.basecolor.blue["blue3"],
				fontSize: theme.fontsizes.font100,
				paddingRight: theme.measures.measure050,
				paddingLeft: theme.measures.measure050,
			};
		}
		public static QueryBuilderLogicalLabelStyle(theme: Mscrm.Theme): any {
			return {
				color: theme.colors.grays.gray05,
				fontSize: theme.fontsizes.font085,
				fontFamily: theme.fontfamilies.regular,
				width: "100%",
				textAlign: "center",
			};
		}
		public static QueryBuilderRelatedLinkButtonStyle(theme: Mscrm.Theme): any {
			return {
				background: "none",
				border: "none",
				padding: "0",
				cursor: "pointer",
				color: "#3472b9",
				textDecoration: "none",
				lineHeight: theme.measures.measure200,
				fontSize: theme.fontsizes.font085,
				fontFamily: theme.fontfamilies.regular,
				paddingRight: theme.measures.measure025,
				paddingLeft: theme.measures.measure025,
				":hover": {
					background: "none",
					color: "#3b79b7",
				},
			};
		}
		public static QueryBuilderFilterLinkContainerStyle(theme: Mscrm.Theme): any {
			return {
				margin: "0",
				width: "auto",
				display: "flex",
				flexDirection: "row",
			};
		}
		public static QueryBuilderRelatedLinkContainerStyle(theme: Mscrm.Theme): any {
			return {
				margin: "0",
				width: "auto",
				flexDirection: "row",
			};
		}

		public static QueryBuilderAddFilterAndRelatedEntityButtons(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				display: "flex",
				flexDirection: "row",
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: " solid",
				borderColor: theme.colors.grays.gray02,
			};
		}
		public static ControlDefinitionContainerStyle(theme: Mscrm.Theme, error: boolean, isValueControl: boolean): any {
			return {
				width: "auto",
				display: "flex",
				flexDirection: "row",
				height: isValueControl ? "auto" : "35px",
				border:
					QueryBuilderQueryTree.IsSimpleMode && !isValueControl
						? "none"
						: error
						? "1px solid #ea0600"
						: "1px solid #b3b3b3",
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
				color: theme.colors.grays.gray05,
				fontFamily: theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
				minWidth: isValueControl ? "14.5rem" : undefined,
				overflow: !isValueControl ? "hidden" : undefined,
			};
		}

		public static SimpleModeContainerStyle(theme: Mscrm.Theme, name: Constants.ConditionFieldName): any {
			return {
				width: "auto",
				maxwidth: "20rem",
				flexDirection: "row",
				height: "35px",
				lineHeight: "35px",
				border: "none",
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
				color: theme.colors.grays.gray05,
				fontFamily:
					name === Constants.ConditionFieldName.LHSAttribute ? theme.fontfamilies.semibold : theme.fontfamilies.regular,
				fontSize: theme.fontsizes.font085,
				overflow: "hidden",
				whiteSpace: "nowrap",
				textOverflow: "ellipsis",
			};
		}

		public static HiddenLabelStyle(theme: Mscrm.Theme): any {
			return {
				width: "0px",
				height: "0px",
				position: "absolute",
				left: "-1000px",
				top: "-1000px",
			};
		}

		public static DialogFlyoutOkButtonStyle(theme: Mscrm.Theme): any {
			return {
				display: "block",
				width: theme.measures.measure600,
				height: theme.measures.measure250,
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
				background: theme.colors.basecolor.blue["blue3"],
				color: theme.colors.basecolor.white,
				textAlign: "center",
				borderWidth: "1px",
				borderStyle: "solid",
				borderColor: theme.colors.basecolor.blue["blue3"],
				":hover": {
					background: theme.colors.basecolor.blue["blue4"],
					color: theme.colors.basecolor.white,
				},
			};
		}
		public static DialogFlyoutCancelButtonStyle(theme: Mscrm.Theme): any {
			return {
				display: "block",
				width: theme.measures.measure600,
				height: theme.measures.measure250,
				marginLeft: theme.measures.measure025,
				marginRight: theme.measures.measure025,
				background: theme.colors.basecolor.white,
				color: theme.colors.basecolor.blue["blue3"],
				textAlign: "center",
				borderWidth: "1px",
				borderStyle: "solid",
				borderColor: theme.colors.basecolor.blue["blue3"],
				":hover": {
					borderColor: theme.colors.basecolor.blue["blue4"],
				},
			};
		}
		public static ConfirmationDialogContainerStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				justifyContent: "center",
				alignItems: "center",
			};
		}
		public static ConfirmationDialogButtonContainerStyle(theme: Mscrm.Theme): any {
			return {
				marginTop: theme.measures.measure300,
				flexDirection: "row",
				alignSelf: "flex-end",
				justifyContent: "flex-end",
				flex: "0 0 auto",
				width: "100%",
			};
		}
		public static ConfirmationDialogTitleLabelStyle(theme: Mscrm.Theme): any {
			return {
				fontFamily: theme.fontfamilies.semilight,
				color: theme.colors.grays.gray07,
				fontSize: theme.fontsizes.font125,
			};
		}
		public static ConfirmationDialogMessageLabelStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				fontFamily: theme.fontfamilies.regular,
				color: theme.colors.grays.gray07,
				fontSize: theme.fontsizes.font100,
				marginTop: theme.measures.measure125,
				marginLeft: isRTL ? undefined : "2.75rem",
				marginRight: isRTL ? "2.75rem" : undefined,
			};
		}
		public static ConfirmationTitleIconContainerStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				alignItems: "center",
			};
		}
		public static DialogContainerContentStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				flexDirection: "column",
			};
		}
		public static ConfirmationDialogWarningIconStyle(theme: Mscrm.Theme): any {
			return {
				color: theme.colors.basecolor.yellow["yellow3"],
				fontSize: theme.fontsizes.font125,
				marginLeft: theme.measures.measure075,
				marginRight: theme.measures.measure075,
			};
		}
		public static ConfirmationDialogCloseIconStyle(theme: Mscrm.Theme): any {
			return {
				color: theme.colors.grays.gray07,
				fontSize: theme.fontsizes.font125,
			};
		}
		public static DialogContainerHeaderStyle(theme: Mscrm.Theme): any {
			return {
				width: "100%",
			};
		}
		public static getDialogContainerContent(theme: Mscrm.Theme): any {
			return {
				width: "100%",
				flexDirection: "column",
			};
		}
		public static ConfirmationDialogCloseButtonStyle(theme: Mscrm.Theme): any {
			return {
				width: "auto",
				border: "0",
				background: "none",
				color: theme.colors.grays.gray07,
				fontSize: theme.fontsizes.font125,
			};
		}
		public static DialogOverlayContainerStyle(theme: Mscrm.Theme): any {
			return {
				position: "fixed",
				width: "100%",
				height: "100%",
				top: "0px",
				left: "0px",
				backgroundColor: "rgba(0,0,0,0.6)",
				zIndex: "1",
			};
		}
		public static QueryBuilderFlyoutLabelStyle(theme: Mscrm.Theme): any {
			return {
				fontFamily: theme.fontfamilies.regular,
				marginRight: theme.measures.measure025,
				marginLeft: theme.measures.measure025,
			};
		}
		public static QueryBuilderFlyoutListItemLabelStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				fontFamily: theme.fontfamilies.regular,
				fontWeight: "bold",
				paddingLeft: theme.measures.measure100,
				paddingRight: theme.measures.measure100,
			};
		}
		public static QueryBuilderFlyoutListItemStyle(theme: Mscrm.Theme): any {
			return {
				fontSize: theme.fontsizes.font085,
				color: theme.colors.grays.gray07,
				fontFamily: theme.fontfamilies.regular,
				paddingTop: theme.measures.measure050,
				paddingBottom: theme.measures.measure050,
				display: "flex",
				":hover": {
					backgroundColor: theme.colors.grays.gray01,
				},
				":focus": {
					backgroundColor: theme.colors.grays.gray03,
				},
			};
		}
		public static QueryBuilderFlyoutRemoveListItemStyle(theme: Mscrm.Theme): any {
			return {
				fontSize: theme.fontsizes.font100,
				color: theme.colors.grays.gray07,
				fontFamily: theme.fontfamilies.regular,
				paddingTop: theme.measures.measure050,
				paddingBottom: theme.measures.measure050,
				paddingLeft: theme.measures.measure100,
				paddingRight: theme.measures.measure100,
				borderTopWidth: "1px",
				borderTopStyle: "solid",
				borderTopColor: theme.colors.grays.gray03,
				display: "flex",
				":hover": {
					backgroundColor: theme.colors.grays.gray01,
				},
				":focus": {
					backgroundColor: theme.colors.grays.gray03,
				},
			};
		}
		public static QueryBuilderFlyoutListStyle(theme: Mscrm.Theme): any {
			return {
				listStyle: "none",
				display: "inline-block",
				maxHeight: "322px",
			};
		}
		public static QueryBuilderEntityHeaderStyle(theme: Mscrm.Theme): any {
			return {
				border: theme.borders.border02,
				background: theme.colors.grays.gray03,
				display: "flex",
				flexDirection: "row",
				width: "auto",
				height: theme.measures.measure175,
				marginRight: theme.measures.measure025,
				marginLeft: theme.measures.measure025,
				alignItems: "center",
			};
		}
		public static QueryBuilderEntityHeaderSelectStyle(theme: Mscrm.Theme): any {
			return {
				borderWidth: "1px",
				borderStyle: "solid",
				borderColor: theme.colors.grays.gray04,
				display: "flex",
				flexDirection: "row",
				height: theme.measures.measure175,
				marginRight: theme.measures.measure025,
				marginLeft: theme.measures.measure025,
				width: "auto",
				alignItems: "center",
			};
		}
		public static QueryBuilderEntityIconButtonStyle(theme: Mscrm.Theme): any {
			return {
				background: "transparent",
				width: "auto",
				paddingLeft: theme.measures.measure050,
				paddingRight: theme.measures.measure050,
				color: theme.colors.grays.gray06,
				fontSize: theme.fontsizes.font085,
				border: "0",
				":hover": {
					background: "transparent",
				},
				flexDirection: "row",
			};
		}

		public static ConditionListContainerStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				display: "flex",
				flexDirection: "column",
				alignItems: "flex-start",
			};
		}

		public static AddButtonsContainerStyle(theme: Mscrm.Theme, isRTL: boolean): any {
			return {
				display: "flex",
				flexDirection: "row",
				borderLeftWidth: isRTL ? undefined : "2px",
				borderRightWidth: isRTL ? "2px" : undefined,
				borderStyle: "solid",
				borderColor: theme.colors.grays.gray02,
			};
		}

		public static GroupNodeChildListItemStyle(theme: Mscrm.Theme): any {
			return {
				listStyleType: "none",
				display: "flex",
				flexDirection: "column",
			};
		}
		public static QueryBuilderDropIconContainerStyle(theme: Mscrm.Theme): any {
			return {
				width: theme.measures.measure100,
				display: "flex",
				marginRight: theme.measures.measure025,
				marginLeft: theme.measures.measure025,
			};
		}
		public static QueryBuilderDropDownIcon(theme: Mscrm.Theme): any {
			return {
				marginRight: theme.measures.measure025,
				marginLeft: theme.measures.measure025,
				display: "flex",
				fontSize: theme.fontsizes.font085,
			};
		}
	}
}
