/// <reference path="../../../../../../src/Shared/libs/XrmClientApi.d.ts" />
declare module MscrmControls.Containers {
    class ContextManager implements IContextManager {
        private _breadCrumbSavedState;
        private _stageSavedState;
        private _hasBreadCrumbChanged;
        private _hasStageChanged;
        private _breadCrumbContext;
        private _processStageContext;
        static navigationButtonKey: string;
        context(any?: boolean, controlMode?: ControlMode): Mscrm.ControlData<void>;
        setContext(context: Mscrm.ControlData<void>, controlMode: ControlMode, businessProcessFlowWrapper?: Mscrm.IBusinessProcessFlowWrapper): void;
        private _updateSavedState(context, controlMode, businessProcessFlowWrapper?);
        getUniqueId(controlMode: ControlMode, key: string): string;
        hasChanged(controlMode: ControlMode): boolean;
    }
}
declare module MscrmControls.Containers {
    interface IconDescriptor {
        symbol: string;
    }
    interface IconConfiguration {
        [iconType: number]: IconDescriptor;
    }
}
declare module MscrmControls.Containers {
    interface IContextManager {
        getUniqueId(controlMode: ControlMode, key: string): string;
        context(any?: boolean, controlMode?: ControlMode): Mscrm.ControlData<void>;
        hasChanged(controlMode: ControlMode): boolean;
    }
}
declare module MscrmControls.Containers {
    class INavigationEntitiesData {
        entityDisplayName: string;
        entityLogicalName: string;
        entityTypeCode: number;
        showCreate: boolean;
        navigationEntities: INavigationEntity[];
    }
}
declare module MscrmControls.Containers {
    class INavigationEntity {
        id: Guid;
        primaryField: string;
        entityTypeCode: number;
        entityLogicalName: string;
        primaryKeyName: string;
    }
}
declare module MscrmControls.Containers {
    interface IProcessSavedState {
        entityId?: Mscrm.Guid;
        processId?: Mscrm.Guid;
        processInstanceId?: Mscrm.Guid;
        displayState?: string;
        selectedStage?: Mscrm.Guid;
    }
}
declare module MscrmControls.Containers {
    class ProcessControlManager {
        _context: Mscrm.ControlData<void>;
        private static _instance;
        private _contextManager;
        private _businessProcessFlowWrapper;
        private _crossEntityFlyoutDisplayState;
        forwardNavigationEntitiesData: INavigationEntitiesData;
        private stageValidationResult;
        private _alertMessage;
        private _getStageWithId(stageId);
        static readonly Instance: ProcessControlManager;
        init(businessProcessFlowWrapper: Mscrm.IBusinessProcessFlowWrapper, context: Mscrm.ControlData<void>, controlMode: ControlMode): void;
        readonly contextManager: IContextManager;
        getBusinessProcessFlowWrapper(): Mscrm.IBusinessProcessFlowWrapper;
        getCurrentEntity(): Mscrm.EntityReference;
        getStageIds(): Mscrm.Guid[];
        getStageIndex(stageId: Mscrm.Guid): number;
        getStageName(stageId: Mscrm.Guid): string;
        getStageStatus(stageId: Mscrm.Guid): string;
        getStageStatusText(stageId: Mscrm.Guid): string;
        getStageEntityName(stageId: Mscrm.Guid): string;
        getStageEntityDisplayName(stageId: Mscrm.Guid): string;
        getStageRelatedEntityReference(stageId: Mscrm.Guid): Mscrm.EntityReference;
        getStageSteps(stageId: Mscrm.Guid): Mscrm.IBusinessProcessFlowWrapperStep[];
        getStepIdsAndProperties(stageId: Mscrm.Guid): {
            [stepId: string]: any;
        }[];
        private _getPropertiesByEntityFieldNameAndLabel(step, isStepInStageGatingError);
        getBPFId(): Mscrm.Guid;
        getBPFName(): string;
        getBPFInstanceId(): Mscrm.Guid;
        getBPFInstanceName(): string;
        getBPFState(): Mscrm.BusinessProcessFlowInstanceState;
        getBPFStatus(): Mscrm.BusinessProcessFlowInstanceStatus;
        private getStageEntityLogicalName(stageId);
        isBusinessProcessCompleted(): boolean;
        isBusinessProcessActive(): boolean;
        isStageForCurrentEntity(stageId: Mscrm.Guid): boolean;
        isSelectedStage(stageId: Mscrm.Guid): boolean;
        isFirstStage(stageId: Mscrm.Guid): boolean;
        isLastStage(stageId: Mscrm.Guid): boolean;
        isActiveStage(stageId: Mscrm.Guid): boolean;
        getActiveStageId(): Mscrm.Guid;
        getActivePath(): Mscrm.Guid[];
        isStageComplete(stageId: Mscrm.Guid): boolean;
        isStageLocked(stageId: Mscrm.Guid): boolean;
        isBusinessProcessAborted(): boolean;
        isBusinessProcessDisabled(): boolean;
        completeProcess(): any;
        moveToNextStage(): any;
        moveToPreviousStage(): any;
        validateRequiredFields(): boolean;
        waitForOngoingWork(): any;
        setActiveStage(stageId: Mscrm.Guid): any;
        triggerActionStepClick(controlId: string): void;
        triggerFlowStepClick(flowStepId: string, controlId: string): void;
        setSelectedStage(stageId: Mscrm.Guid, isUserSelectedStage?: boolean): void;
        getSelectedStageId(): Mscrm.Guid;
        getActionLog(stepId: Mscrm.Guid): Mscrm.IActionLog;
        setDisplayState(displayState: DisplayState): void;
        getDisplayState(): DisplayState;
        isVisible(): boolean;
        getIsFormHeaderCollapsed(): boolean;
        getNextOrPreviousSelectedStageId(isNext: boolean, selectedStageId: Mscrm.Guid): Mscrm.Guid;
        getProcessStages(): Mscrm.IBusinessProcessFlowWrapperStage[];
        isCurrentSelectedStage(stageId: Mscrm.Guid): boolean;
        setCrossEntityDisplayState(displayState: DisplayState): void;
        isCrossEntityFlyoutOpen(): boolean;
        getForwardNavigationEntitiesPromise(): any;
        getNavigateToNextEntityPromise(nextEntity: Mscrm.EntityReference): any;
        getNextStage(): Mscrm.IBusinessProcessFlowWrapperStage;
        getPreviousStage(): Mscrm.IBusinessProcessFlowWrapperStage;
        private _isStageOnActivePath(stageId);
        isMobileMode(): boolean;
        isTabletMode(): boolean;
        getActiveStageActiveFor(isShort?: boolean): string;
        getBpfInstanceActiveFor(): string;
        getActiveForStatus(time: string): string;
        getBpfInstanceCompletedIn(): string;
        setNarratorNotification(message: string): void;
        isCrossEntityNavigation(isMoveNext: boolean): boolean;
        private _getHumanTimeFormatFromMilliseconds(milliseconds, isShort);
        getBpfNavigationBehavior(): XrmClientApi.XrmProcessNavigationBehavior;
        getCurrentStage(): XrmClientApi.Process.Stage;
    }
}
declare module MscrmControls.Containers {
    class AccessibilityHelper {
        static addDockedNotification: boolean;
        static determineFirstFocusableAndEditableElementInSubtree(element: HTMLElement): any;
        private static _elementIsFocusableByTab(element);
        static _elementIsEditable(element: HTMLElement): boolean;
        static _isFocusable(element: HTMLElement, byTabFocusable?: boolean): boolean;
        static _elementIsVisible(element: HTMLElement): boolean;
        static _elementIsDisabled(element: HTMLElement): boolean;
        private static _determineFirstFocusableAndEditableElementInSubtree(element, firstEditableElement?, firstFocusableElement?);
    }
}
declare enum BusinessProcessFlowInstanceState {
    Active = 0,
    Inactive = 1,
}
declare enum BusinessProcessFlowInstanceStatus {
    Active = 1,
    Finished = 2,
    Aborted = 3,
}
declare enum BusinessProcessFlowStageStatus {
    Active = 0,
    Inactive = 1,
    Completed = 2,
}
declare module MscrmControls.Containers {
    enum ControlMode {
        breadCrumb = 0,
        stage = 1,
    }
}
declare module MscrmControls.Containers {
    enum DisplayState {
        collapsed = 0,
        expanded = 1,
        floating = 2,
    }
}
declare module MscrmControls.Containers {
    class FlyoutTabbingHelper {
        static addCircularTabbing(event: KeyboardEvent, elementId: string): void;
    }
}
declare module MscrmControls.Containers {
    enum ProcessControlIconSymbol {
        Dock = 1,
        Previous = 2,
        Next = 3,
        Close = 4,
        Flag = 5,
        CheckMark = 6,
        Locked = 7,
        ActiveStageIndicatorLeft = 8,
        ActiveStageIndicatorRight = 9,
        CreateNew = 10,
        Completed = 11,
        None = 12,
        Failure = 13,
    }
}
declare module MscrmControls.Containers {
    class ResourceStrings {
        static getResourceString(resource: string): string;
        static AbandonedStage: string;
        static AbortedAfterLessThanOneMinute: string;
        static AbortedIn: string;
        static ActiveForLessThanOneMinute: string;
        static ActiveDurationIn: string;
        static Advance: string;
        static Back: string;
        static BusinessProcessFlow: string;
        static BusinessProcessFlowShortcut: string;
        static InactiveProcess: string;
        static Close: string;
        static Completed: string;
        static CompletedIn: string;
        static CompletedInLessThanOneMinute: string;
        static CreateNew: string;
        static Day: string;
        static Days: string;
        static DurationInDays: string;
        static DurationInHours: string;
        static DurationInMinutes: string;
        static DurationInMonths: string;
        static DurationInWeeks: string;
        static DurationInYears: string;
        static DurationLessThanOneMinute: string;
        static Finish: string;
        static Finished: string;
        static Hour: string;
        static Hours: string;
        static HumanTimeFormat: string;
        static Inactive: string;
        static Locked: string;
        static Minute: string;
        static Minutes: string;
        static Months: string;
        static MoveToTheLeft: string;
        static MoveToTheRight: string;
        static DisabledTextForNavigationButtons: string;
        static NoRecordsFound: string;
        static NarratorNotification: string;
        static Pin: string;
        static RequiredStepWarningMesage: string;
        static SelectChild: string;
        static SetActive: string;
        static Stage: string;
        static StageFlyoutDocked: string;
        static StageStatusTitleTemplate: string;
        static Weeks: string;
        static Years: string;
        static ProcessingActionStepData: string;
        static ActionStepExecute: string;
        static ProcessingFlowStepData: string;
        static FlowStepExecute: string;
    }
}
declare module MscrmControls.Containers {
    class CrossEntityFlyout {
        private _flyoutContainer;
        static crossEntityFlyoutContainerKey: string;
        constructor();
        render(relativeToElementId: string): Mscrm.Component;
        private _manageFocus();
    }
}
declare module MscrmControls.Containers {
    class CrossEntityFlyoutContainer {
        private _relativeToElementId;
        private _flyoutHeaderContainer;
        private _flyoutItemsContainer;
        private _flyoutFooterContainer;
        constructor();
        render(relativeToElementId: string): Mscrm.Component;
        private _keyDownHandler(event);
        private _closeCrossEntityFlyoutHandler();
    }
}
declare module MscrmControls.Containers {
    class CrossEntityFlyoutFooterContainer {
        flyoutCreateIcon: ProcessControlIcon;
        constructor();
        render(): Mscrm.Component;
        private _renderCancel();
        private _renderCreateNew();
        private _createNewClickHandler();
    }
}
declare module MscrmControls.Containers {
    class CrossEntityFlyoutHeaderContainer {
        render(): Mscrm.Component;
        private _renderFlyoutTitle(title);
    }
}
declare module MscrmControls.Containers {
    class CrossEntityItem {
        render(navigationEntity: INavigationEntity, idNumber: number): Mscrm.Component;
        private _clickHandler(navigationEntity);
    }
}
declare module MscrmControls.Containers {
    class CrossEntityFlyoutItemsContainer {
        render(): Mscrm.Component;
        private _getStyle(key);
    }
}
declare module MscrmControls.Containers {
    class ProcessControlIcon {
        private _iconsMap;
        render(name: string, iconSymbol: number, onClick?: () => void, style?: any, role?: string, title?: string): Mscrm.Component;
    }
}
declare module MscrmControls.Containers {
    class ProcessHeaderNameLabel {
        render(name: string, label: string, properties?: any): Mscrm.Component;
    }
}
declare enum Shades {
    WhiteBackGround = 0,
    MainThemeColor3 = 1,
    MainThemeColor3Text = 2,
    MainThemeLight = 3,
    MainThemeLightText = 4,
    MainThemeDark = 5,
    MainThemeDarkText = 6,
    AccentLight = 7,
    AccentLightText = 8,
    AccentDark = 9,
    AccentDarkText = 10,
    Green = 11,
    Grey1 = 12,
    Grey2 = 13,
    Grey3 = 14,
    Grey4 = 15,
    Grey5 = 16,
    Grey6 = 17,
    Grey7 = 18,
    Black = 19,
    Red = 20,
    Transparent = 21,
}
declare module MscrmControls.Containers {
    class StyleHelper {
        static lineHeight: string;
        static readonly statusFontFamily: string;
        static processHeaderDataContainerPadding: number;
        static ProcessNameContainerWidth: number;
        static processControlHeight: number;
        static getStatusFontSize(): string;
        static getprocessNameFontSize(): string;
        static processHeaderStageContent: string;
        static headerStageContainerName: string;
        static headerStageFlyoutContainer: string;
        static stageDockContainer: string;
        static processControlAlertContainer: string;
        static borderWidth: number;
        private static _crossEntityFlyoutWidth;
        static getShade(shade: Shades): string;
        static setCrossEntityFlyoutWidth(width: number): void;
        static getCrossEntityFlyoutWidth(): number;
        static getFontSize(): number;
        static getFlyoutContainerId(stageId: Mscrm.Guid): string;
        static isEnoughSpaceAvailableForFlyout(elementId: string, controlMode: ControlMode, flyoutHeight: number): boolean;
        static getProcessStageListItemId(stageId: string): string;
        static top: number;
        static scrollIntoView(stageId: Mscrm.Guid): void;
        static addTabIndexes(stageId: Mscrm.Guid): void;
        static removeTabIndexes(): void;
    }
}
