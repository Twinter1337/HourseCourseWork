declare module MscrmControls.Containers {
    interface IDashboardInputBag {
        value: NestedDashboardValue;
        ForbiddenControlIdList?: Mscrm.StringProperty;
    }
    interface NestedDashboardValue {
        FormDescriptor: Mscrm.IFormDescriptor;
        Columns: number;
        Width?: number;
        Height?: number;
        DeviceHeight?: number;
        RefreshCounters?: {
            [control: string]: number;
        };
        ScrollTop?: number;
        UpdatedControlParameters?: {
            [control: string]: {
                [parameter: string]: any;
            };
        };
        DataSetColumns?: {
            [control: string]: any;
        };
    }
    interface IDashboardOutputBag {
        value: any;
    }
}
declare module MscrmControls.Containers.Dashboard {
    interface TabInternal {
        component: Mscrm.Component;
        height: number;
        hidden?: boolean;
        layoutType?: LayoutType;
    }
    interface TabEx extends TabInternal, Mscrm.TabDescriptor {
    }
}
declare module MscrmControls.Containers.Dashboard {
    type Style = {
        [key: string]: string;
    };
    const BORDER_WIDTH = 1;
    const BORDER_TOP_WIDTH = 3;
    const BASE_STYLE: string;
    const NO_STYLE: string;
    class DashboardStyling {
        private _baseStyle;
        private readonly baseStyle;
        parent: DashboardControl;
        parameters: any;
        protected readonly overrideBaseStyles: any;
        protected readonly isMobile: boolean;
        protected readonly isMailApp: boolean;
        protected readonly hideControlBorder: boolean;
        protected readonly rowHeight: number;
        constructor(parent: DashboardControl);
        static convertFromRemToPixelValue(remValue: string): number;
        applyStyling(baseStyle: Style, overrideBaseStyle: Style): Style;
        private computeStyling(style);
        getDashboardContainerStyle(): Style;
        getTabContainerStyle(height: number): Style;
        getTabColumnStyle(columnHeight: number, column: Mscrm.ColumnDescriptor, layoutType: LayoutType): Style;
        getTabColumnContainerStyle(tabHeight: number, tab: Mscrm.TabDescriptor, layoutType: LayoutType): Style;
        getTabStyle(tabHeight: number, tab: Mscrm.TabDescriptor, layoutType: LayoutType): Style;
        getSectionStyle(section: Mscrm.SectionDescriptor, hidden: boolean, isAutoHeight: boolean, controlCount: number, height: number, layoutType: LayoutType): Style;
        getRowStyle(section: Mscrm.SectionDescriptor, isAutoHeight: boolean): Style;
        getCellOuterStyle(section: Mscrm.SectionDescriptor, control: IDashboardControl, columns: number, componentKey: string, borderContainers: ComponentEx, isRowAutoHeight: boolean, layoutType: LayoutType): Style;
        getCellInnerStyle(section: Mscrm.SectionDescriptor, control: IDashboardControl, component: ComponentEx, componentKey: string): Style;
    }
}
declare module MscrmControls.Containers.Dashboard {
    class PowerBIDashboardStyling extends DashboardStyling {
        protected readonly overrideBaseStyles: any;
    }
}
declare module MscrmControls.Containers.Dashboard {
    const enum ControlType {
        Chart = "Chart",
        Grid = "Grid",
        WebResource = "WebResource",
        IFrame = "IFrame",
        PowerBI = "PowerBI",
        SocialInsight = "SocialInsight",
        TimelineWall = "TimelineWall",
        CustomControl = "CustomControl",
        UnknownControl = "UnknownControl",
    }
    class TelemetryReporter {
        private _eventName;
        private _dashboard;
        private _slaParameters;
        private reflow;
        private timeOnDashboardStart;
        private _createdControls;
        private hasReportedLoadEvent;
        constructor(dashboard: DashboardControl, eventName?: string);
        dashboardLoaded(dashboardId: Mscrm.Guid): void;
        startTimeOnDashboard(): void;
        endTimeOnDashboard(dashboardId: Mscrm.Guid): void;
        startReflow(): void;
        endReflow(): void;
        unknownControlType(type: any): void;
        unknownChartGridMode(chartGridMode: string): void;
        createdControl(type: ControlType | string): void;
        reportSuccess(): void;
        reportFailure(error: Error): void;
        startSLAReport(): void;
        addSLAParameter(name: string, value: string | number | Date | Mscrm.Guid): void;
    }
}
declare module MscrmCommon {
    const enum ClientApiFormFactor {
        Unknown = 0,
        Desktop = 1,
        Tablet = 2,
        Phone = 3,
    }
}
declare module MscrmCommon {
    class GridHelper {
        static shouldRenderAsReadOnlyGridOnPhone(context: Mscrm.ControlData<any>, customControlConfiguration: Mscrm.ICustomControlConfiguration, deviceFormFactor: MscrmCommon.ClientApiFormFactor): boolean;
    }
}
declare module MscrmControls.Containers.Dashboard {
    const enum ChartGridMode {
        Chart = "Chart",
        Grid = "Grid",
        ChartAndGrid = "All",
    }
    type ControlProperties = {
        properties: {
            [prop: string]: any;
        };
        setWidth: boolean;
        setHeight: boolean;
    };
    class DashboardControlFactory {
        context: Mscrm.ControlData<IDashboardInputBag>;
        parent: DashboardControl;
        section: Mscrm.SectionDescriptor;
        telemetry: Dashboard.TelemetryReporter;
        mailAppControlFactory: Dashboard.MailAppControlFactory;
        constructor(parent: DashboardControl, section: Mscrm.SectionDescriptor);
        create(cell: Mscrm.CellDescriptor): ComponentEx | ComponentEx[];
        getControlCount(): number;
        isControlEntityUnsupported(control: {
            Id?: string;
        }): boolean;
        private getCustomControlConfiguration(control);
        getChildControlFactory(control: Mscrm.IControlDescriptor): Function;
        isWebResourceControl(control: Mscrm.IControlDescriptor): boolean;
        getEventListeners(control: Mscrm.IControlDescriptor): Mscrm.IVirtualComponentEventHandlerPair[];
        getControlParameters(control: Mscrm.IControlDescriptor | Mscrm.ICustomControlConfiguration, extraParameters?: any, isDataSetHost?: boolean | {
            dataSetName?: string;
            dataSetParameters: {
                [parameter: string]: any;
            };
        }, controlName?: string, hasNestedParameters?: boolean): any;
        private createControl(componentName, control, properties, setWidth?, setHeight?, manifestName?);
        private createTimelineWallControl(control);
        private createChartControl(control);
        protected getChartControlProperties(control: Mscrm.IControlDescriptor): ControlProperties;
        private stringToBoolean(value);
        getDataSetColumns(controlName: string): string[];
        private createGridControl(control);
        private createIFrameOrWebResourceControl(control);
        private _isSupportedWebResource(control);
        private _isIFrameWebResource(protocol);
        private createPowerBIControl(control);
        private createSocialInsightsControl(control);
        private createDummyControl(control);
        private createCustomControl(control);
        private _updatePropertiesForGridMultipleScroll(properties);
        private _getGridControlStates();
        createCustomControlWithProps(control: Mscrm.IControlDescriptor, schemaName: string, baseProps: any): ComponentEx;
    }
}
declare module MscrmControls.Containers.Dashboard {
    class MailAppControlFactory {
        _dashboardControlFactory: Dashboard.DashboardControlFactory;
        constructor(dashboardControlFactory: Dashboard.DashboardControlFactory);
        getMailAppControlFactory(control: Mscrm.IControlDescriptor): Function;
        private getOutputParameter();
        private getLinkedInputParameter(value);
        private createMailAppHiddenDataControl(control);
        private createMailAppRecipientsTabControl(control);
        private createMailAppUnknownRecipientSummaryControl(control);
        private createMailAppQuickFormWrapper(control, dataValue);
        private createMailAppRegardingObjectQuickCardControl(control);
        private createMailAppSelectedRecipientQuickFormControl(control);
        private createMailAppSelectedRecipientQuickFormCardControl(control);
        private createMailAppEmailEngagementControl(control);
        private createMailAppTrackBarControl(control);
    }
}
declare module MscrmControls.Containers.Dashboard {
    function chartSkipKeyShortcut(): void;
}
declare module MscrmControls.Containers.Dashboard {
    const enum LayoutType {
        Strict = 0,
        NonStrict = 1,
        Horizontal = 2,
        HorizontalWrap = 3,
        Vertical = 4,
    }
    enum RenderPass {
        Layout = 0,
        All = 1,
    }
    class DashboardLayout {
        static DEFAULT_ROW_HEIGHT: number;
        context: Mscrm.ControlData<IDashboardInputBag>;
        telemetry: Dashboard.TelemetryReporter;
        columns: number;
        parent: DashboardControl;
        desiredColumns: {
            [sectionId: string]: number;
        };
        private headerHeight;
        renderPass: RenderPass;
        private renderPassMutationObserver;
        private _getControlFactory;
        constructor(parent: DashboardControl, getControlFactory: (section: Mscrm.SectionDescriptor) => DashboardControlFactory);
        getTabs(): {
            [tabName: string]: Mscrm.TabDescriptor;
        };
        getSectionHeader(section: Mscrm.SectionDescriptor): Mscrm.Component;
        isSectionHidden(section: Mscrm.SectionDescriptor): boolean;
        canMemoizeSection(section: Mscrm.SectionDescriptor): boolean;
        getCellComponentKeys(): string[];
        isCellComponentHidden(componentKey: string, control?: ComponentEx): boolean;
        isCellComponentOnTheDOM(control: IDashboardControl, componentKey: string): boolean;
        private getHeaderHeight();
        shouldControlRender(section: Mscrm.SectionDescriptor, control: IDashboardControl, offset: number, previousValue?: boolean, componentKey?: string): boolean;
        checkIfMetadataAvailable(controlName: string): boolean;
        resetRenderPass(): void;
        nextRenderPass(): void;
        controlRendered(control: IDashboardControl, componentKey: string, outerCell: boolean): void;
        controlRenderedInternal(controlId: string, manifestName: string): boolean;
        getCellComponentSize(componentKey: string, section?: Mscrm.SectionDescriptor, control?: IDashboardControl): {
            [style: string]: string;
        };
        getControlWidth(columns: number, control: IDashboardControl, section: Mscrm.SectionDescriptor, controlStyle?: Style): number;
        getControlHeight(control: IDashboardControl, section: Mscrm.SectionDescriptor, controlStyle?: Style): number;
        getRowHeight(section: Mscrm.SectionDescriptor): number;
        getSectionHeight(section: Mscrm.SectionDescriptor, controlCount: number, rowCount: number, layoutType: LayoutType, isAutoHeight: boolean): number;
        getLayoutType(componentKey: string, control: ComponentEx): LayoutType;
        checkIfLayoutChanged(): boolean;
        getSectionColumnCount(section: Mscrm.SectionDescriptor, controls: IDashboardControl[]): number;
        createControlsInLayout(section: Mscrm.SectionDescriptor): ILayout;
        getDesiredColumnCount(section: Mscrm.SectionDescriptor): number;
        isReflow(layout: ILayout, section: Mscrm.SectionDescriptor): boolean;
        protected reflowLayout(controls: IDashboardControl[], section: Mscrm.SectionDescriptor): ILayout;
        private useGoldenRatio(control);
        private getRowSpan(columns, control, section);
        private getGoldenRatioHeight(section, control, columnWidth);
        private cellIsOccupied(layout, row, column);
        private createControlsInDesiredLayout(section);
        getSectionRowCount(rowCount: number, section: Mscrm.SectionDescriptor): number;
    }
    interface ILayout {
        controls: IDashboardControl[];
        rowCount: number;
    }
    interface IDashboardControl {
        id: string;
        name?: string;
        componentIndex?: number;
        component: ComponentEx;
        row: number;
        rowHeight?: string;
        column: number;
        rowSpan: number;
        colSpan: number;
        canMemoize: boolean;
        visible: boolean;
        forceRenderIfInvisible: boolean;
    }
}
declare module MscrmControls.Containers.Dashboard {
    type ComponentEx = (Mscrm.Component | ComponentExObject | Function) & {
        isNotFiltered?: boolean;
        manifestName?: string;
    };
    interface ComponentExObject {
        [key: string]: ComponentEx;
    }
    const enum RenderReason {
        None = "",
        InitialRender = "InitialRender",
        Layout = "Layout",
        ControlsRefreshed = "ControlsRefreshed",
        FormInitialized = "FormInitialized",
        DashboardId = "DashboardId",
        NextRenderPass = "NextRenderPass",
        Width = "Width",
        Height = "Height",
        DeviceHeight = "DeviceHeight",
        DataSetColumns = "DataSetColumns",
        Scroll = "Scroll",
        UnknownSize = "UnknownSize",
    }
    class MemoizedDashboardValue {
        dashboard: DashboardControl;
        private isFormDescriptorInitialized;
        private dashboardId;
        container: Mscrm.Component[];
        memoizedSections: {
            [key: string]: {
                components: Mscrm.Component[];
                height: number;
            };
        };
        memoizedCells: {
            [key: string]: ComponentEx;
        };
        private width;
        private height;
        private deviceHeight;
        private refreshCounters;
        private scrollTop;
        private _renderedControlIds;
        renderedControlCounts: {
            [manifestName: string]: number;
        };
        private renderPass;
        private dataSetColumns;
        renderChecks: {
            reason: RenderReason | string;
            check: () => boolean;
        }[];
        private readonly layoutChanged;
        private _layoutChanged;
        private readonly areControlsRefreshed;
        private _areControlsRefreshed;
        private readonly controlCount;
        private _controlCount;
        constructor(dashboard: DashboardControl);
        needsUpdate(): RenderReason;
        resetMemoizedValues(): void;
        updateMemoizedValues(): void;
        private resetRenderedControls();
        isControlRendered(controlId: string): boolean;
        areAllControlsRendered(): boolean;
        addRenderedControl(controlId: string, manifestName: string): void;
        private areRefreshCountersChanged();
    }
}
declare module MscrmControls.Containers.Dashboard {
    const enum NotSimpleRenderReason {
        None = "",
        IsPowerBIDashboard = "IsPowerBIDashboard",
        MultipleColumns = "MultipleColumns",
        RowHeightSpecified = "RowHeightSpecified",
        DashboardNotInitialized = "DashboardNotInitialized",
        UnsupportedSection = "UnsupportedSection",
    }
    class SimpleDashboardRenderer {
        dashboard: DashboardControl;
        private _canUseSimpleRenderer;
        constructor(dashboard: DashboardControl);
        reset(): void;
        canUseSimpleRenderer(section?: Mscrm.SectionDescriptor): NotSimpleRenderReason;
        private _getSectionIds(form);
        render(): Mscrm.Component[];
        renderSectionControls(section: Mscrm.SectionDescriptor, offsetHeight: number, layoutType: LayoutType, componentKey: string): {
            sectionControls: Mscrm.Component[];
            sectionHeight: number;
            layoutType: LayoutType;
        };
    }
}
declare module MscrmControls.Containers.Dashboard {
    class SimpleDashboardStyling extends DashboardStyling {
        protected readonly overrideBaseStyles: any;
        private _overridenStyle;
        constructor(parent: DashboardControl);
    }
}
declare module MscrmControls.Containers {
    const enum ClientApiFormFactor {
        Unknown = 0,
        Desktop = 1,
        Tablet = 2,
        Phone = 3,
    }
    class DashboardControl {
        static PowerBIControlClassId: string;
        static POWERBI_DASHBOARD: number;
        isPowerBIDashboard: boolean;
        context: Mscrm.ControlData<IDashboardInputBag>;
        readonly layout: Dashboard.DashboardLayout;
        private _layout;
        forbiddenUCIControlList: string[];
        readonly styling: Dashboard.DashboardStyling;
        private _styling;
        readonly telemetry: Dashboard.TelemetryReporter;
        private _telemetry;
        readonly memoizedValue: Dashboard.MemoizedDashboardValue;
        private _memoizedValue;
        readonly simpleRenderer: Dashboard.SimpleDashboardRenderer;
        private _simpleRenderer;
        private injectStyles();
        constructor();
        init(context: Mscrm.ControlData<IDashboardInputBag>, notifyOutputChanged: () => void, state: Mscrm.Dictionary): void;
        private _topCommandBarFirstElementShortCut();
        private determineIfCurrentDashboardIsPBIDashboard();
        updateView(context: Mscrm.ControlData<IDashboardInputBag>): Mscrm.Component;
        protected renderHiddenContent(): Mscrm.Component[];
        protected initDashboardTypeContext(): void;
        getOnParametersUpdated(controlName: string): Mscrm.IVirtualComponentEventHandlerPair;
        getDashboardId(): Mscrm.Guid;
        isFormDescriptorInitialized(): boolean;
        isTouchDevice(): boolean;
        private createContainerWithControls();
        private createTabControl(tab, offsetTop);
        private createSectionControl(section, offsetTop);
        private createRowControl(rowIndex, columns, controls, section, layoutType, offsetTop);
        private createCellControl(rowIndex, columnIndex, columns, controls, section, offsetTop);
        private createCellControlInternal(control, componentKeys, dashboardColumns, shouldControlRender, section);
        getOutputs(): Mscrm.ControlData<IDashboardOutputBag>;
        destroy(): void;
    }
}
