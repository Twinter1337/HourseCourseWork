/// <reference path="../../../../../../src/shared/mscrm.d.ts" />
declare module MscrmControls.DateRangeControl {
    interface IInputBag {
        DateRangeAttribute: Mscrm.StringProperty;
        DateRangeTimeframe: Mscrm.StringProperty;
        CustomTimeFrameStartDate?: Mscrm.StringProperty;
        CustomTimeFrameEndDate?: Mscrm.StringProperty;
        DashboardColumns: Mscrm.NumberProperty;
        DisplayName?: Mscrm.StringProperty;
        DashboardWidth?: Mscrm.NumberProperty;
    }
    interface IOutputBag {
        DateRangeOutput: string;
        TimeFrameOutput: string;
    }
}
declare module MscrmControls.DateRangeControl {
    interface LocalizedStrings {
        DATERANGE_FILTER_ACCESSIBILITY_BUTTON: string;
        DATERANGEFILTER_CUSTOMTIMEFRAME_TEXT: string;
        DATERANGEFILTER_ACCESSIBILITY_CUSTOMTIMEFRAMEAPPLYBUTTON: string;
        DATERANGEFILTER_CUSTOMTIMEFRAMEAPPLYBUTTON_TEXT: string;
        DATERANGEFILTER_CUSTOMTIMEFRAMECLOSEBUTTON_TEXT: string;
        DATERANGEFILTER_ACCESSIBILITY_CUSTOMTIMEFRAMECLOSEBUTTON: string;
        DATERANGEFILTER_DATERANGEINPUT_TODAY: string;
        DATERANGEFILTER_DATERANGEINPUT_YESTERDAY: string;
        DATERANGEFILTER_DATERANGEINPUT_THISWEEK: string;
        DATERANGEFILTER_DATERANGEINPUT_LASTWEEK: string;
        DATERANGEFILTER_DATERANGEINPUT_THISMONTH: string;
        DATERANGEFILTER_DATERANGEINPUT_LASTMONTH: string;
        DATERANGEFILTER_DATERANGEINPUT_MONTHTODATE: string;
        DATERANGEFILTER_DATERANGEINPUT_THISQUARTER: string;
        DATERANGEFILTER_DATERANGEINPUT_LASTQUARTER: string;
        DATERANGEFILTER_DATERANGEINPUT_CUSTOMTIMEFRAME: string;
        DATERANGEFILTER_CUSTOMINPUT_STARTDATE: string;
        DATERANGEFILTER_CUSTOMINPUT_ENDDATE: string;
        DATERANGE_FILTER_ACCESSIBILITY_CUSTOMTIMEFRAMEBACKICON: string;
        DATERANGEFILTER_BUTTON_FORMATTEDDATERANGETEXT: string;
    }
}
declare module MscrmControls.DateRangeControl {
    class DateRangeInput {
        static Today: string;
        static Yesterday: string;
        static ThisWeek: string;
        static LastWeek: string;
        static ThisMonth: string;
        static LastMonth: string;
        static MonthToDate: string;
        static ThisQuarter: string;
        static LastQuarter: string;
        static CustomTimeFrame: string;
        static FormattedDateRange: string;
        static StartDate: string;
        static EndDate: string;
        static DateRangeInputByTimeFrame: string[];
        static initialize(_localizedStrings: LocalizedStrings): void;
        static ConvertStringToDate(dateStr: string): Date;
        static GenerateStartEndDateForTimeFrame(timeFrame: string | number): {
            [dateType: string]: Date;
        };
        static GetUTCDateString(inputDate: Date): string;
        static GetDateConditionExpression(startDate: Date, endDate: Date, attributeName: string): Mscrm.ConditionExpression[];
        static GetDefaultDateConditionExpression(attributeName: string, timeFrame: number): Mscrm.ConditionExpression[];
        static GetFormattedDateRangeFromUTCDateStrings(start: string, end: string, context: any): string;
        static GetFormattedDateRange(startDate: Date, endDate: Date, context: any): string;
    }
}
declare module MscrmControls.DateRangeControl {
    class DateRangeFilterControl implements Mscrm.Control<IInputBag, IOutputBag> {
        private _changeHandler;
        private _notifyOutputChangedInternal;
        private _dateConditionExpArr;
        private _valueFromStartDateControlInput;
        private _valueFromEndDateControlInput;
        private _isOpen;
        private _isCustomDatePaneOpen;
        private _attributeName;
        private _defaultTimeFrame;
        private _currentTimeFrame;
        private _valueFromStartDateControl;
        private _valueFromEndDateControl;
        private _buttonText;
        context: Mscrm.ControlData<IInputBag>;
        static ROW_HEIGHT: number;
        private static DATETIME_INPUT_ID;
        static MARGIN: number;
        private _localizedStrings;
        private dateRangeFilterFlyout;
        private _dateRangeTimeframe;
        private _customTimeFrameStartDate;
        private _customTimeFrameEndDate;
        private _isCustomTimeFrameApplyClicked;
        private _customTimeFrameID;
        constructor();
        private _onChange(type, change);
        private _correctDate(change, controlValue);
        private optionsClickHandler();
        private optionsClickHandlerSetFocus();
        private _updateButtonText(label);
        private handleDateRangeButtonClick(event);
        init(context: Mscrm.ControlData<IInputBag>, notifyOutputChanged: () => void, state: Mscrm.Dictionary): void;
        private dateRangeFilterControlShortCut();
        updateView(context: Mscrm.ControlData<IInputBag>): Mscrm.Component;
        addCircularTabbing(event: KeyboardEvent, elementId: string): void;
        private _keyDownHelper(event);
        private _setFocusOnSelectedElement(listItemKey, style, outline?);
        private _getSelectedElement(listItemKey, style, outline?);
        private _setFocusOnElement(listItemKey, style, outline?);
        _setFocus(listItemKey: any, style: string, outline?: string): void;
        private _setFocusOnCalendarControl(listItemKey, style);
        getOutputs(): IOutputBag;
        private _notifyOutputChanged(timeFrameLabel, canNotifyFilterChanged?);
        private _reportDateRangeTelemetry(timeFrame);
        destroy(): void;
        private _createCustomDateTimeFlyout();
        private _createFlyout();
        private _toggleFlyout(_this);
        private _toggleCustomDateSelector(_this);
        private createDateTimeControlRow(_this);
        private addAttributesToDateTimeControls(typeString);
        private _createDateTimeControl(typeString, inputDate);
        private _reverseCompensateTimeZoneForInputBehavior(date);
        private _applyButtonClickHandler(_this);
        private _closeButtonClickHandler(_this);
        private _backButtonClickHandler(_this);
        private _nextButtonClickHandler(_this);
        private _updateDateConditionExpression();
        private _createDateTimeControlHeader(_this);
        private _createDateTimeControlFooter(_this);
        private _parseInput(_this, label);
        private _focusHandler(event);
    }
}
declare module MscrmControls.DateRangeControl {
    class DateRangeFilterControlUtils {
        static getLocalizedStrings(context: Mscrm.ControlData<IInputBag>): LocalizedStrings;
    }
}
