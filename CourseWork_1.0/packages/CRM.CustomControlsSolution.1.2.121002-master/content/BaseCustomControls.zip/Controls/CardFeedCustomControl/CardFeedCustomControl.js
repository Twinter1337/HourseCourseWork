/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer_1) {
        "use strict";
        var ReasonForCardDismiss;
        (function (ReasonForCardDismiss) {
            ReasonForCardDismiss[ReasonForCardDismiss["None"] = 0] = "None";
            ReasonForCardDismiss[ReasonForCardDismiss["IncorrectEmail"] = 1] = "IncorrectEmail";
            ReasonForCardDismiss[ReasonForCardDismiss["ReasonAlreadyProvided"] = 2] = "ReasonAlreadyProvided";
            ReasonForCardDismiss[ReasonForCardDismiss["IncorrectRequest"] = 3] = "IncorrectRequest";
            ReasonForCardDismiss[ReasonForCardDismiss["OtherReasons"] = 4] = "OtherReasons";
        })(ReasonForCardDismiss || (ReasonForCardDismiss = {}));
        var CardFeedContainer = (function () {
            function CardFeedContainer() {
                this.cardTypeEntities = {};
                this.recordsArray = [];
                this.nextMeetingCards = [];
                this.recordsEntityImageArray = [];
                this.viewType = "Main";
                this.groupCards = [];
                this.state = {
                    menucards: {},
                };
                this.isLoad = false;
                this.renderedElements = [];
                this.focusedElement = 0;
                this.previousFocusElement = 0;
                this.dismissClickedCardIndex = null;
                this.dismissNegativeClickedIndex = null;
                this.filterSet = false;
                this.showSeeMore = false;
                this.checkForTranslate = true;
                this.reasonForCardDismissList = [
                    ReasonForCardDismiss.None,
                    ReasonForCardDismiss.IncorrectEmail,
                    ReasonForCardDismiss.ReasonAlreadyProvided,
                    ReasonForCardDismiss.IncorrectRequest,
                    ReasonForCardDismiss.OtherReasons,
                ];
                this.maxCardCountInCurrentContainer = 0;
                this.twoColumnLayout = false;
                this.secondColumnCards = [];
                this.secondColumnPrevCards = [];
                this.secondColumnCardsClicked = false;
                this.isNextMeeting = false;
                this.focusElementStr = "cardWithActionsContainer";
                this.isGlobalPanelEnabled = false;
                this.isDashboard = false;
                this.isFCBEnabled = false;
                this.isGetStartedClicked = false;
                this.initialPageLoad = false;
                this.flyoutId = -1;
                this.scrolling = true;
                this.timerId = 0;
                this.isTeaserFCBEnabled = false;
                this.mapControlBaseUrl = "//www.bing.com/api/maps/mapcontrol";
                this.focusElementHandler = this.setFocusCardElement.bind(this);
                this.renderMapHandler = this.renderMap.bind(this);
                this.renderNextMapHandler = this.renderNextMeetingMap.bind(this);
                this.dismissCardHandler = this.handleDismissCard.bind(this);
                this.snoozeCardHandler = this.handleSnoozCard.bind(this);
                this.dismissGroupCardHandler = this.handleGroupDismissCard.bind(this);
                this.snoozeGroupCardHandler = this.handleGroupSnoozCard.bind(this);
                this.fetchAllCardsHandler = this.fetchAllCards.bind(this);
            }
            CardFeedContainer.prototype.renderMap = function () {
                var _this = this;
                this._context.accessibility.focusElementById("cardWithActionsContainer" + this.focusedElement);
                var mapLocation = CardFeedContainer.cardData.data.cardRelatedInfo.address
                    ? CardFeedContainer.cardData.data.cardRelatedInfo.address
                    : "";
                CardFeedContainer_1.CardService.cfcscope = this;
                if (CardFeedContainer.cardData &&
                    CardFeedContainer.cardData.data &&
                    CardFeedContainer.cardData.data.cardRelatedInfo.bingApiKey) {
                    jQuery
                        .getScript(this.mapControlBaseUrl)
                        .done(function (script, textStatus) {
                        var url = window.location.href.toLocaleLowerCase().indexOf("https://") != -1
                            ? "https://dev.virtualearth.net/REST/v1/Locations?query="
                            : "http://dev.virtualearth.net/REST/v1/Locations?query=";
                        var geocodeRequest = url +
                            encodeURIComponent(CardFeedContainer.cardData.data.cardRelatedInfo.address) +
                            "&key=" +
                            (CardFeedContainer.cardData.data.cardRelatedInfo.bingApiKey
                                ? CardFeedContainer.cardData.data.cardRelatedInfo.bingApiKey
                                : "");
                        _this.dataFactories["Productivity"].callLocationService(geocodeRequest, _this.dataFactories["Productivity"].refreshFrame);
                    })
                        .fail(function (jqxhr, settings, exception) {
                        console.log("Error in downloading mapcontrol resource");
                    });
                }
            };
            CardFeedContainer.prototype.renderNextMeetingMap = function () {
                var _this = this;
                for (var i = 0; i < 26; i++) {
                    var e = document.getElementById(CardFeedContainer.cfcContext.accessibility.getUniqueId("menuDotContainer" + i));
                    if (e)
                        e.style.backgroundColor = this._context.theming.colors.base.white;
                }
                if (this.isGlobalPanelEnabled) {
                    this._context.accessibility.focusElementById("cardWithActionsContainer" + this.focusedElement);
                }
                if (this.nextMeetingCards.length > 0) {
                    var main_card = this.nextMeetingCards[0];
                    var mapLocation = main_card.data.cardRelatedInfo.address ? main_card.data.cardRelatedInfo.address : "";
                    if (CardFeedContainer.nmrendered)
                        return;
                    CardFeedContainer.nmrendered = true;
                    CardFeedContainer_1.CardService.cfcscope = this;
                    if (main_card && main_card.data && main_card.data.cardRelatedInfo.bingApiKey) {
                        jQuery
                            .getScript(this.mapControlBaseUrl)
                            .done(function (script, textStatus) {
                            for (var _i = 0, _a = _this.nextMeetingCards; _i < _a.length; _i++) {
                                var card = _a[_i];
                                var url = window.location.href.toLocaleLowerCase().indexOf("https://") != -1
                                    ? "https://dev.virtualearth.net/REST/v1/Locations?query="
                                    : "http://dev.virtualearth.net/REST/v1/Locations?query=";
                                var geocodeRequest = url +
                                    encodeURIComponent(card.data.cardRelatedInfo.address) +
                                    "&key=" +
                                    (card.data.cardRelatedInfo.bingApiKey ? card.data.cardRelatedInfo.bingApiKey : "");
                                CardFeedContainer.nextMapPromises.push({ card: card, geocodeRequest: geocodeRequest });
                            }
                            if (CardFeedContainer.nmrendered)
                                _this.dataFactories["UPCOMING_MEETING"].callLocationService(CardFeedContainer.nextMapPromises, _this.dataFactories["UPCOMING_MEETING"].refreshFrame);
                        })
                            .fail(function (jqxhr, settings, exception) {
                            console.log("Error in downloading mapcontrol resource");
                        });
                    }
                }
            };
            CardFeedContainer.prototype.getRecordsArray = function () {
                return this.recordsArray;
            };
            CardFeedContainer.prototype.getCommandManager = function () {
                return this.commandManager;
            };
            CardFeedContainer.prototype.getGroupCards = function () {
                return this.groupCards;
            };
            CardFeedContainer.prototype.getGroupData = function () {
                return this.groupedData;
            };
            CardFeedContainer.prototype.getActionData = function () {
                return this.actionData;
            };
            CardFeedContainer.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this.showSeeMore = context.client.disableScroll;
                CardFeedContainer.cfcContext = context;
                this.getCardTypes(false);
                this.callPopulateCard();
                CardFeedContainer.nextMapPromises = [];
                var location = this._context.parameters.Location.raw.toString();
                var isLocationSet = this._context.parameters.Location != undefined &&
                    this._context.parameters.Location != null &&
                    this._context.parameters.Location.raw != undefined &&
                    this._context.parameters.Location.raw != null;
                this.isGlobalPanelEnabled = isLocationSet && this._context.parameters.Location.raw == 0;
                this.isDashboard = isLocationSet && this._context.parameters.Location.raw == 2;
                if (!this.isGlobalPanelEnabled) {
                    document.addEventListener("raglobalpanelclosed", this.onGlobalPanelClose);
                    CardFeedContainer.currentScope = this;
                }
                this.isFCBEnabled = this._context.utils.isFeatureEnabled("ActionCard");
                this.isTeaserFCBEnabled = this._context.utils.isFeatureEnabled("TeaserCards");
                var relationshipAssistantEntryPoint = new RelationshipAssistantEntryPoint(location, "TBD");
                this._context.reporting.reportEvent(relationshipAssistantEntryPoint);
                this.initialPageLoad = true;
                this.commandManager = new MscrmControls.CardFeedContainer.ActionCommandsManager(this);
                this.cardEvents = new CardFeedContainer_1.CardsEventsHandler(context, this);
                CardFeedContainer.nmrendered = false;
                this.dataFactories = {
                    UPCOMING_FLIGHT: new CardFeedContainer_1.FlightCardControl(context, this),
                    AGENDA: new CardFeedContainer_1.AgendaCardControl(context, this),
                    "AGENDA:ACTIVITY_MAIL": new CardFeedContainer_1.AgendaCardControl(context, this),
                    "AGENDA:ACTIVITY_MEETING": new CardFeedContainer_1.AgendaCardControl(context, this),
                    "AGENDA:ACTIVITY_PHONE": new CardFeedContainer_1.AgendaCardControl(context, this),
                    "AGENDA:ACTIVITY_TASK": new CardFeedContainer_1.AgendaCardControl(context, this),
                    "AGENDA:ACTIVITY_OTHERS": new CardFeedContainer_1.AgendaCardControl(context, this),
                    Productivity: new CardFeedContainer_1.ProductivityCardControl(context, this),
                    Generic: new CardFeedContainer_1.GenericCardControl(context, this),
                    TOP_PEOPLE: new CardFeedContainer_1.TopPeopleControl(context, this),
                    TOP_RECORD: new CardFeedContainer_1.TopPeopleControl(context, this),
                    GettingStarted: new CardFeedContainer_1.GettingStarted(context, this),
                    UPCOMING_MEETING: new CardFeedContainer_1.UpcomingMeeting(context, this),
                    TEASER: new CardFeedContainer_1.TeaserCard(context, this),
                };
                this._context.client.trackContainerResize(true);
                this.initializeToastTimeout();
            };
            CardFeedContainer.prototype.callPopulateCard = function () {
                if (sessionStorage) {
                    var dateNow = this.getUserTimeZoneDateString();
                    var populateCardCalledOn = sessionStorage.getItem("populatecardcalledon");
                    if (!populateCardCalledOn || dateNow != populateCardCalledOn) {
                        MscrmControls.CardFeedContainer.CardService.callPopulateCards({});
                        sessionStorage.setItem("populatecardcalledon", dateNow);
                    }
                }
                else {
                    MscrmControls.CardFeedContainer.CardService.callPopulateCards({});
                }
            };
            CardFeedContainer.prototype.getUserTimeZoneDateString = function () {
                var now = new Date();
                var xrmGlobalContext = Xrm.Utility.getGlobalContext();
                now.setMinutes(now.getMinutes() + now.getTimezoneOffset() + xrmGlobalContext.getTimeZoneOffsetMinutes());
                return now.toDateString();
            };
            CardFeedContainer.prototype.updateView = function (context, controlData) {
                var _this = this;
                this._context = context;
                CardFeedContainer.cfcContext = context;
                if (this.isGlobalPanelEnabled) {
                    this.twoColumnLayout = false;
                }
                else {
                }
                var controls = [];
                controls.push(this.sectionHeader());
                if (this.isFCBEnabled) {
                    if (context.parameters.SubGrid.filtering == undefined || context.parameters.SubGrid.filtering == null) {
                        return;
                    }
                    else if (!this.isGlobalPanelEnabled && this.isFormsComponentView && this.isNewRecord(context)) {
                        controls.push(this.renderEmptyForNewEntity());
                    }
                    else {
                        if (!this.isLoad) {
                            var that = this;
                            this.load();
                        }
                        if (context.updatedProperties.length > 0 &&
                            context.updatedProperties[context.updatedProperties.length - 1] == "fullscreen_close") {
                            this.showSeeMore = true;
                        }
                        else if (context.updatedProperties.length > 0 &&
                            context.updatedProperties[context.updatedProperties.length - 1] == "fullscreen_open") {
                            this.showSeeMore = false;
                            this.scrolling = false;
                        }
                        if (this.isGlobalPanelEnabled)
                            this.showSeeMore = false;
                        if (this._context.mode && this._context.mode.isOffline) {
                            controls.push(this.renderNoCardsContainer("Offline"));
                        }
                        else {
                            if (this.recordsArray.length > 0) {
                                controls.push(this.renderMainCardContainer());
                            }
                            else if (this.recordsArray.length == 0 && this._context.parameters.SubGrid.loading == false) {
                                controls.push(this.renderNoCardsContainer("NoCards"));
                            }
                        }
                        if (this.isGlobalPanelEnabled) {
                            controls.push(this.renderCloseButton());
                            setTimeout(function () {
                                if (_this.recordsArray.length == 0) {
                                    _this._context.accessibility.focusElementById("closeIconContainer");
                                }
                            }, 500);
                        }
                    }
                }
                else {
                    controls.push(this.sectionHeader());
                    controls.push(this.renderFCBDisabledContainer());
                }
                return this.createContainerWithControls(controls, "completePage");
            };
            CardFeedContainer.prototype.isNewRecord = function (context) {
                return context.mode.contextInfo.entityId == null && context.mode.contextInfo.entityTypeName != null;
            };
            CardFeedContainer.prototype.renderEmptyForNewEntity = function () {
                var noCardsLabel = this._context.resources.getString("Record_Not_Yet_Created");
                var noCardsIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "noCardsIcon",
                    key: "noCardsIcon",
                    style: {
                        fontSize: "medium",
                    },
                    type: 181,
                });
                var noCardsTitle = this._context.factory.createElement("LABEL", {
                    key: "noCardsTitle",
                    id: "noCardsTitle",
                    style: {
                        paddingLeft: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray04,
                    },
                }, noCardsLabel);
                var noCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "noCardsContainer",
                    id: "noCardsContainer",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        alignItems: "center",
                    },
                }, [noCardsIcon, noCardsTitle]);
                return this._context.factory.createElement("LIST", {
                    key: "mainCard",
                    id: "mainCard",
                    accessibilityLabel: this._context.resources.getString("RI_FCB_Card_Header"),
                    describedByElementId: this._context.accessibility.getUniqueId("ariaNavigationDescriptionId"),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        boxSizing: "border-box",
                        maxWidth: "420px",
                        minWidth: "0px",
                        width: "100%",
                        display: "block",
                        overflowY: "auto",
                        overflowX: "hidden",
                        marginTop: this._context.theming.measures.measure100,
                        marginRight: this._context.theming.measures.measure100,
                        marginLeft: this._context.theming.measures.measure100,
                    },
                }, noCardsContainer);
            };
            CardFeedContainer.prototype.renderNoCardsContainer = function (noCardsType) {
                var noCardsLabel = noCardsType == "NoCards"
                    ? this._context.resources.getString("ActionCard.CFC.Common.NoCardsTitle")
                    : this._context.resources.getString("ActionCard.CFC.Common.OfflineTitle");
                var noCardsIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "noCardsIcon",
                    key: "noCardsIcon",
                    style: {
                        fontSize: "medium",
                    },
                    type: 181,
                });
                var noCardsTitle = this._context.factory.createElement("LABEL", {
                    key: "noCardsTitle",
                    id: "noCardsTitle",
                    style: {
                        paddingLeft: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray04,
                    },
                }, noCardsLabel);
                var noCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "noCardsContainer",
                    id: "noCardsContainer",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        alignItems: "center",
                    },
                }, [noCardsIcon, noCardsTitle]);
                return this._context.factory.createElement("LIST", {
                    key: "mainCard",
                    id: "mainCard",
                    accessibilityLabel: this._context.resources.getString("RI_FCB_Card_Header"),
                    describedByElementId: this._context.accessibility.getUniqueId("ariaNavigationDescriptionId"),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        boxSizing: "border-box",
                        maxWidth: "420px",
                        minWidth: "0px",
                        width: "100%",
                        display: "block",
                        overflowY: "auto",
                        overflowX: "hidden",
                        marginTop: this._context.theming.measures.measure100,
                        marginRight: this._context.theming.measures.measure100,
                        marginLeft: this._context.theming.measures.measure100,
                    },
                }, noCardsContainer);
            };
            CardFeedContainer.prototype.renderFCBDisabledContainer = function () {
                var FCBDisabledLabel = this._context.resources.getString("RI_FCB_Card_Label");
                var FCBDisabledTitle = this._context.factory.createElement("LABEL", {
                    key: "FCBDisabledTitle",
                    id: "FCBDisabledTitle",
                    style: {
                        paddingLeft: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray04,
                    },
                }, FCBDisabledLabel);
                var FCBDisabledContainer = this._context.factory.createElement("CONTAINER", {
                    key: "FCBDisabledContainer",
                    id: "FCBDisabledContainer",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        color: this._context.theming.colors.grays.gray04,
                        alignItems: "center",
                    },
                }, FCBDisabledTitle);
                return this._context.factory.createElement("LIST", {
                    key: "mainCard",
                    id: "mainCard",
                    accessibilityLabel: this._context.resources.getString("RI_FCB_Card_Header"),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        boxSizing: "border-box",
                        maxWidth: "420px",
                        minWidth: "0px",
                        width: "100%",
                        display: "block",
                        overflowY: "auto",
                        overflowX: "hidden",
                        marginTop: this._context.theming.measures.measure100,
                    },
                }, FCBDisabledContainer);
            };
            CardFeedContainer.prototype.renderCloseButton = function () {
                var closeIcon = this._context.factory.createElement("MICROSOFTICON", {
                    key: "closeIcon",
                    id: "closeIcon",
                    type: 9,
                    style: {
                        cursor: "pointer",
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray06,
                    },
                });
                return this._context.factory.createElement("CONTAINER", {
                    id: "closeIconContainer",
                    key: "closeIconContainer",
                    tabIndex: 0,
                    accessibilityLabel: this.recordsArray.length == 0
                        ? this._context.resources.getString("RA_Close_Header_NoCards")
                        : this._context.resources.getString("RA_Close_Header"),
                    role: "button",
                    style: {
                        position: "absolute",
                        whiteSpace: "normal",
                        top: this._context.theming.measures.measure050,
                        right: this._context.client.isRTL ? "unset" : this._context.theming.measures.measure200,
                        left: !this._context.client.isRTL ? "unset" : this._context.theming.measures.measure200,
                    },
                    onClick: this.cardEvents.closeIconClickHandler.bind(this),
                    onKeyDown: this.cardEvents.closeIconKeyPressHandler.bind(this, this),
                }, closeIcon);
            };
            CardFeedContainer.prototype.renderMainCardContainer = function () {
                var controls = [];
                var accessibilityFocusId = 0;
                this.renderedElements = [];
                if (this.recordsArray.length == 1 && this.recordsArray[0]["cardName"] == "LETSGETSTARTED") {
                    controls.push(this.dataFactories["GettingStarted"].renderLetsGoCard());
                    return this._context.factory.createElement("CONTAINER", {
                        key: "mainCardContainer",
                        id: "mainCardContainer",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            display: "block",
                            height: "auto",
                            overflowX: "hidden",
                            marginRight: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                            marginLeft: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        },
                    }, controls);
                }
                if (this.viewType == "Main") {
                    this.groupedData = CardFeedContainer_1.Utils.groupData(this.recordsArray);
                    var groupKeys = Object.keys(this.groupedData);
                    if (this.secondColumnCards && this.secondColumnCards.length == 0) {
                        this.secondColumnCards = this.groupedData[groupKeys[0]];
                        this.secondColumnCards.length >= 3 ? (this.prevViewType = "Group") : (this.prevViewType = "Main");
                    }
                    for (var index = 0; index < groupKeys.length; index++) {
                        this.typeOfCard = groupKeys[index];
                        var cards = this.groupedData[groupKeys[index]];
                        if (cards.length > 2 &&
                            cards[0].cardName !== "UPCOMING_MEETING" &&
                            cards[0].cardName !== "UPCOMING_MEETING_EXCHANGE" &&
                            cards[0].cardName !== "UPCOMING_FLIGHT") {
                            var cardName = cards[0].cardName.split(":")[0];
                            if (this.dataFactories[cardName]) {
                                var um = this.dataFactories[cardName].renderGroupCardView(index, cards, accessibilityFocusId);
                                if (um !== "") {
                                    controls.push(um);
                                    accessibilityFocusId++;
                                }
                            }
                            else {
                                controls.push(this.dataFactories["Generic"].renderGroupCardView(index, cards, accessibilityFocusId));
                                accessibilityFocusId++;
                            }
                        }
                        else {
                            if (cards[0].cardName == "TOP_PEOPLE" || cards[0].cardName == "TOP_RECORD") {
                                continue;
                            }
                            for (var _i = 0, cards_1 = cards; _i < cards_1.length; _i++) {
                                var card = cards_1[_i];
                                if (card.cardName == "UPCOMING_MEETING" || card.cardName == "UPCOMING_MEETING_EXCHANGE") {
                                    var um = this.dataFactories["UPCOMING_MEETING"].renderCardView(card, accessibilityFocusId);
                                    if (um !== "") {
                                        controls.push(um);
                                        accessibilityFocusId++;
                                    }
                                }
                                else {
                                    if (groupKeys[index] == "UPCOMING_FLIGHT") {
                                        controls.push(this.dataFactories["UPCOMING_FLIGHT"].renderCards(card, accessibilityFocusId));
                                        accessibilityFocusId++;
                                    }
                                    else if (card.cardName == "TEASER") {
                                        if (this.isTeaserFCBEnabled) {
                                            var teasersCard = this.dataFactories["TEASER"].prepareExchangeTeaserCardView(card, accessibilityFocusId);
                                            if (teasersCard) {
                                                controls.push(teasersCard);
                                                accessibilityFocusId++;
                                            }
                                        }
                                    }
                                    else {
                                        controls.push(this.dataFactories["Generic"].renderCardView(card, accessibilityFocusId, "firstColumn"));
                                        accessibilityFocusId++;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (this.viewType == "Group" && this.groupCards.length > 0) {
                    controls.push(this.dataFactories["Generic"].backToMainElement(accessibilityFocusId, this.groupCards.length > 0 ? this.groupCards[0].softTitle : ""));
                    accessibilityFocusId++;
                    if (this.groupCardType == "nearby") {
                        controls.push(this.dataFactories["Productivity"].renderNearByCardView(this.groupCards, accessibilityFocusId));
                        accessibilityFocusId++;
                    }
                    else if (this.groupCardType == "Attendees") {
                        for (var attIndex in CardFeedContainer_1.CardService.attData) {
                            controls.push(this.dataFactories["Productivity"].renderAttendeeIndividualCardView(attIndex, accessibilityFocusId));
                            accessibilityFocusId++;
                        }
                    }
                    else {
                        for (var _a = 0, _b = this.groupCards; _a < _b.length; _a++) {
                            var card = _b[_a];
                            controls.push(this.dataFactories["Generic"].renderCardView(card, accessibilityFocusId));
                            accessibilityFocusId++;
                        }
                    }
                }
                else if (this.viewType == "Group" && this.groupCards.length == 0) {
                    this.viewType = "Main";
                    this.renderControl(true, this.renderNextMapHandler);
                    return;
                }
                else if (this.viewType == "Card") {
                    var cardNameForDisplay = this.card.title
                        ? this.card.title
                        : CardFeedContainer_1.Utils.getReferenceTokenDataTitle(this.card, this._context);
                    controls.push(this.dataFactories["Generic"].backToMainElement(accessibilityFocusId, cardNameForDisplay));
                    accessibilityFocusId++;
                    if (this.card.cardName == "UPCOMING_MEETING" || this.card.cardName == "UPCOMING_MEETING_EXCHANGE") {
                        this.renderProductiveCards(this.card, controls, accessibilityFocusId, "firstColumn", "UPCOMING_MEETING");
                    }
                    else if (this.card.cardName == "RECENTMEETING" ||
                        this.card.cardName == "AGENDA:ACTIVITY_MEETING" ||
                        this.card.cardName == "AGENDA:ACTIVITY_MEETING_EXCHANGE") {
                        this.renderProductiveCards(this.card, controls, accessibilityFocusId, "firstColumn", "Generic");
                    }
                    else {
                        controls.push(this.dataFactories["Generic"].renderCardView(this.card, accessibilityFocusId, "firstColumn"));
                        accessibilityFocusId++;
                        var regardingCard = this.dataFactories["Productivity"].renderRegardingCardView(this.card, accessibilityFocusId);
                        if (regardingCard) {
                            controls.push(regardingCard);
                            accessibilityFocusId++;
                        }
                        if (this.card.cardName == "AGENDA:ACTIVITY_TASK" || this.card.cardName == "AGENDA:ACTIVITY_PHONE") {
                            var stockCard = this.dataFactories["Productivity"].renderStockCardView(this.card, accessibilityFocusId);
                            if (stockCard) {
                                controls.push(stockCard);
                                accessibilityFocusId++;
                            }
                            var newsCard = this.dataFactories["Productivity"].renderNewsCardView(this.card, accessibilityFocusId);
                            if (newsCard) {
                                controls.push(newsCard);
                                accessibilityFocusId++;
                            }
                        }
                    }
                }
                if (this.showSeeMore && controls.length > this.maxCardCountInCurrentContainer) {
                    accessibilityFocusId++;
                    var seeallLabel = this._context.factory.createElement("LABEL", {
                        key: "seeallLabel",
                        id: "seeallLabel",
                        style: {
                            fontSize: this._context.theming.fontsizes.font100,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                            display: "block",
                            border: "none",
                            background: "none",
                            fontFamily: this._context.theming.fontfamilies.semilight,
                            color: "#3b79b7",
                        },
                    }, this._context.resources.getString("ActionCard.CFC.Common.SeeMore"));
                    var seeAllContainer = this._context.factory.createElement("CONTAINER", {
                        key: "seeAllContainer" + accessibilityFocusId,
                        id: "seeAllContainer" + accessibilityFocusId,
                        style: {
                            display: "block",
                            height: this._context.theming.measures.measure225,
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            marginTop: this._context.theming.measures.measure175,
                        },
                        onClick: this.handleSeeMore.bind(this),
                    }, seeallLabel);
                    if (this.viewType == "Group" ||
                        (this.viewType == "Card" && controls[0]._componentId == "backToMainContainer")) {
                        if (this.isDashboardView())
                            this.maxCardCountInCurrentContainer = 3;
                        else
                            this.maxCardCountInCurrentContainer = 4;
                    }
                    else if (this.viewType == "Main") {
                        if (this.isDashboardView())
                            this.maxCardCountInCurrentContainer = 2;
                        else
                            this.maxCardCountInCurrentContainer = 3;
                    }
                    controls = controls.slice(0, this.maxCardCountInCurrentContainer);
                    controls.push(seeAllContainer);
                }
                var maincardsContainer = this._context.factory.createElement("LIST", {
                    key: "mainCard",
                    id: "mainCard",
                    accessibilityLabel: this._context.resources.getString("RI_FCB_Card_Header"),
                    describedByElementId: this._context.accessibility.getUniqueId("ariaNavigationDescriptionId"),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "95%",
                        maxWidth: "420px",
                        minWidth: "0px",
                        display: "block",
                        overflow: "hidden",
                        height: "auto",
                    },
                }, controls);
                var firstColumnContainer = this._context.factory.createElement("CONTAINER", {
                    key: "firstColumnContainer",
                    id: "firstColumnContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        maxWidth: "420px",
                        minWidth: "0px",
                        marginLeft: this._context.theming.measures.measure100,
                        display: "block",
                    },
                }, maincardsContainer);
                var secondColumnContainer = null;
                if (this.twoColumnLayout == true) {
                    var secondColumnList = this._context.factory.createElement("LIST", {
                        key: "secondColumnList",
                        id: "secondColumnList",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            width: "100%",
                            maxWidth: "420px",
                            minWidth: "0px",
                            display: "block",
                            overflow: "hidden",
                            height: "auto",
                        },
                    }, this.renderSecondColumnContainer(this.secondColumnCards, accessibilityFocusId));
                    secondColumnContainer = this._context.factory.createElement("CONTAINER", {
                        key: "secondColumnMainCard",
                        id: "secondColumnMainCard",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            width: "100%",
                            maxWidth: "420px",
                            minWidth: "0px",
                            marginLeft: this._context.theming.measures.measure100,
                            display: "block",
                        },
                    }, secondColumnList);
                    return this._context.factory.createElement("CONTAINER", {
                        key: "mainCardContainer",
                        id: "mainCardContainer",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            display: "flex",
                            height: "auto",
                            overflowX: "hidden",
                            marginRight: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                            marginLeft: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        },
                    }, [firstColumnContainer, secondColumnContainer]);
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "mainCardContainer",
                    id: "mainCardContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                        height: "auto",
                        overflowX: "hidden",
                        marginRight: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        marginLeft: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                    },
                }, [maincardsContainer]);
            };
            CardFeedContainer.prototype.onGlobalPanelClose = function () {
                var _this = this;
                var scope = MscrmControls.CardFeedContainer.CardFeedContainer.currentScope;
                scope.getCardTypes(true).then(function () {
                    scope.isLoad = false;
                    scope.renderControl(true, scope.renderNextMapHandler);
                    document.removeEventListener("raglobalpanelclosed", _this.onGlobalPanelClose);
                });
            };
            CardFeedContainer.prototype.renderProductiveCards = function (card, controls, accessibilityFocusId, secondColumn, cardName) {
                var um = this.dataFactories[cardName].renderCardView(card, accessibilityFocusId, secondColumn);
                if (um !== "") {
                    controls.push(um);
                    accessibilityFocusId++;
                }
                this.mapFocusId = accessibilityFocusId;
                if (card.data.cardRelatedInfo.address !== "")
                    controls.push(this.dataFactories["Productivity"].mapList);
                this.cardEvents.pushrenderedElements(accessibilityFocusId, this);
                accessibilityFocusId++;
                var attendeesCard = this.dataFactories["Productivity"].renderAttendeeCardView(card, accessibilityFocusId);
                if (attendeesCard) {
                    controls.push(attendeesCard);
                    accessibilityFocusId++;
                }
                var regardingCard = this.dataFactories["Productivity"].renderRegardingCardView(card, accessibilityFocusId);
                if (regardingCard) {
                    controls.push(regardingCard);
                    accessibilityFocusId++;
                }
                var nearByCard = this.dataFactories["Productivity"].renderNearByGroupCardView(card, accessibilityFocusId);
                if (nearByCard) {
                    controls.push(nearByCard);
                    accessibilityFocusId++;
                }
                var newsCard = this.dataFactories["Productivity"].renderNewsCardView(card, accessibilityFocusId);
                if (newsCard) {
                    controls.push(newsCard);
                    accessibilityFocusId++;
                }
                var stockCard = this.dataFactories["Productivity"].renderStockCardView(card, accessibilityFocusId);
                if (stockCard) {
                    controls.push(stockCard);
                    accessibilityFocusId++;
                }
            };
            CardFeedContainer.prototype.renderSecondColumnContainer = function (cards, accessibilityFocusId) {
                var controls = [];
                if (cards[0].cardName == "TOP_PEOPLE" ||
                    cards[0].cardName == "TOP_RECORD" ||
                    cards[0].cardName == "UPCOMING_FLIGHT") {
                    return null;
                }
                if (this.secondColumnCardsClicked) {
                    var cardNameForDisplay = cards[0].title
                        ? cards[0].title
                        : CardFeedContainer_1.Utils.getReferenceTokenDataTitle(cards[0], this._context);
                    if (this.groupCardType == "Attendees" || this.groupCardType == "nearby")
                        cardNameForDisplay = "";
                    controls.push(this.dataFactories["Generic"].backToMainElement(accessibilityFocusId, cardNameForDisplay));
                    this.secondColumnStartindex = accessibilityFocusId;
                    accessibilityFocusId++;
                }
                if (cards.length >= 3) {
                    this.prevViewType = "Group";
                    if (this.groupCardType == "nearby") {
                        controls.push(this.dataFactories["Productivity"].renderNearByCardView(cards, accessibilityFocusId));
                        accessibilityFocusId++;
                    }
                    else if (this.groupCardType == "Attendees") {
                        for (var attIndex in CardFeedContainer_1.CardService.attData) {
                            controls.push(this.dataFactories["Productivity"].renderAttendeeIndividualCardView(attIndex, accessibilityFocusId));
                            accessibilityFocusId++;
                        }
                    }
                    else {
                        for (var _i = 0, cards_2 = cards; _i < cards_2.length; _i++) {
                            var card = cards_2[_i];
                            controls.push(this.dataFactories["Generic"].renderCardView(card, accessibilityFocusId, "SecondColumn"));
                            accessibilityFocusId++;
                        }
                    }
                }
                else {
                    var scope_1 = this;
                    this.prevViewType = "Main";
                    var promise = void 0;
                    if (cards[0].cardName == "UPCOMING_MEETING" ||
                        cards[0].cardName == "UPCOMING_MEETING_EXCHANGE" ||
                        cards[0].cardName == "RECENTMEETING" ||
                        cards[0].cardName == "AGENDA:ACTIVITY_MEETING" ||
                        cards[0].cardName == "AGENDA:ACTIVITY_MEETING_EXCHANGE") {
                        if (this.initialPageLoad) {
                            this.initialPageLoad = false;
                            promise = this.dataFactories["Productivity"].generateAdditionalData(cards[0], this);
                            promise.then(function (data) {
                                scope_1.card = cards[0];
                                scope_1.secondColumnCards[0] = cards[0];
                                CardFeedContainer.cardData = cards[0];
                                cards[0].cardName == "UPCOMING_MEETING" || cards[0].cardName == "UPCOMING_MEETING_EXCHANGE"
                                    ? scope_1.renderControl(true, scope_1.renderNextMapHandler)
                                    : scope_1.renderControl(true, scope_1.renderMapHandler);
                            }, function (rejectReason) {
                                console.log(rejectReason);
                            });
                        }
                        if (cards[0].cardName == "UPCOMING_MEETING" || cards[0].cardName == "UPCOMING_MEETING_EXCHANGE") {
                            this.renderProductiveCards(cards[0], controls, accessibilityFocusId, "SecondColumn", "UPCOMING_MEETING");
                        }
                        else {
                            this.renderProductiveCards(cards[0], controls, accessibilityFocusId, "SecondColumn", "Generic");
                        }
                    }
                    else {
                        controls.push(this.dataFactories["Generic"].renderCardView(cards[0], accessibilityFocusId, "SecondColumn"));
                        accessibilityFocusId++;
                        if (this.initialPageLoad) {
                            this.initialPageLoad = false;
                            if (cards[0].cardName == "AGENDA:ACTIVITY_TASK" || cards[0].cardName == "AGENDA:ACTIVITY_PHONE") {
                                promise = scope_1.dataFactories["Productivity"].generateAgendaAdditionalData(cards[0], scope_1);
                            }
                            else {
                                promise = scope_1.dataFactories["Productivity"].generateGenericAdditionalData(cards[0], scope_1);
                            }
                            promise.then(function (data) {
                                scope_1.card = cards[0];
                                scope_1.secondColumnCards[0] = cards[0];
                                CardFeedContainer.cardData = cards[0];
                                scope_1.focusedElement = 0;
                            }, function (rejectReason) {
                                console.log(rejectReason);
                            });
                        }
                        var regardingCard = this.dataFactories["Productivity"].renderRegardingCardView(cards[0], accessibilityFocusId);
                        if (regardingCard) {
                            controls.push(regardingCard);
                            accessibilityFocusId++;
                        }
                        if (cards[0].cardName == "AGENDA:ACTIVITY_TASK" || cards[0].cardName == "AGENDA:ACTIVITY_PHONE") {
                            var stockCard = this.dataFactories["Productivity"].renderStockCardView(cards[0], accessibilityFocusId);
                            if (stockCard) {
                                controls.push(stockCard);
                                accessibilityFocusId++;
                            }
                            var newsCard = this.dataFactories["Productivity"].renderNewsCardView(cards[0], accessibilityFocusId);
                            if (newsCard) {
                                controls.push(newsCard);
                                accessibilityFocusId++;
                            }
                        }
                    }
                }
                return controls;
            };
            CardFeedContainer.prototype.handleSeeMore = function (event) {
                this.showSeeMore = false;
                this.scrolling = false;
                this._context.client.setFullscreen(true);
                this.renderControl(true, this.focusElementHandler);
            };
            CardFeedContainer.prototype.manageNumberOfCardsInContainer = function () {
                var ccfContext = this._context;
                if (this.isDashboardView()) {
                    var container = document.getElementById(this._context.accessibility.getUniqueId("mainCard"));
                    var RAHeader = document.getElementById(this._context.accessibility.getUniqueId("cardFeedLabel"));
                    var cardCount = 0;
                    this.maxCardCountInCurrentContainer = 2;
                }
                else if (this.isFormsComponentView()) {
                    this.maxCardCountInCurrentContainer = 3;
                }
            };
            CardFeedContainer.prototype.isDashboardView = function () {
                var params = this._context.parameters;
                return (params.Location != undefined &&
                    params.Location != null &&
                    params.Location.raw != undefined &&
                    params.Location.raw != null &&
                    params.Location.raw == "2");
            };
            CardFeedContainer.prototype.isFormsComponentView = function () {
                var params = this._context.parameters;
                return (params.Location != undefined &&
                    params.Location != null &&
                    params.Location.raw != undefined &&
                    params.Location.raw != null &&
                    params.Location.raw == "1");
            };
            CardFeedContainer.prototype.seeMorePopUpScrolling = function () {
                var height = "auto";
                if (!this.showSeeMore && !this.isGlobalPanelEnabled && !this.scrolling)
                    height = "100%";
                return height;
            };
            CardFeedContainer.prototype.createContainerWithControls = function (controls, containerSuffix) {
                return this._context.factory.createElement("CONTAINER", {
                    key: "containerWithControls" + containerSuffix,
                    id: "containerWithControls" + containerSuffix,
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        position: "relative",
                        overflowX: "hidden",
                        height: this.seeMorePopUpScrolling(),
                        width: "100%",
                        paddingLeft: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        paddingRight: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                    },
                }, controls);
            };
            CardFeedContainer.prototype.sectionHeader = function () {
                var headerText = this._context.resources.getString("RI_FCB_Card_Header");
                var cardFeedLabel = this._context.factory.createElement("LABEL", {
                    key: "cardFeedLabel",
                    id: "cardFeedLabel",
                    style: {
                        display: "block",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        paddingTop: this._context.theming.measures.measure050,
                        paddingBottom: this._context.theming.measures.measure050,
                        borderBottom: this._context.theming.borders.border02,
                        color: this._context.theming.colors.grays.gray07,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                    },
                }, headerText);
                var ariaNavigationDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "ariaNavigationDescriptionId",
                    id: "ariaNavigationDescriptionId",
                    accessibilityLabel: this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_AccessibilityText"),
                    style: {
                        display: "none",
                    },
                }, "");
                var headerContainer = this._context.factory.createElement("CONTAINER", {
                    key: "headerContainer",
                    id: "headerContainer",
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        marginLeft: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        marginRight: this.isGlobalPanelEnabled ? this._context.theming.measures.measure100 : 0,
                        marginBottom: this._context.theming.measures.measure100,
                    },
                }, [cardFeedLabel, ariaNavigationDescriptionId]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "cardFeedContainer",
                    id: "cardFeedContainer",
                    style: {
                        width: "100%",
                        display: "block",
                    },
                }, headerContainer);
            };
            CardFeedContainer.prototype.getCardTypes = function (forceRefresh) {
                var xrmGlobalContext = Xrm.Utility.getGlobalContext();
                var serverVersion = xrmGlobalContext.getVersion();
                var cardTypesJson = { version: "", cardTypes: "" };
                if (sessionStorage) {
                    try {
                        cardTypesJson = JSON.parse(sessionStorage.getItem("actioncardtypes"));
                    }
                    catch (ex) {
                    }
                }
                if (cardTypesJson && cardTypesJson.version == serverVersion && !$.isEmptyObject(cardTypesJson.cardTypes)) {
                    this.cardTypeEntities = cardTypesJson.cardTypes;
                    if (!this.filterSet || forceRefresh) {
                        this.setFilter(this._context);
                        this._context.parameters.SubGrid.refresh();
                    }
                }
                if ($.isEmptyObject(this.cardTypeEntities)) {
                    this.loadAndPrepareCardTypes(serverVersion, forceRefresh);
                }
            };
            CardFeedContainer.prototype.loadAndPrepareCardTypes = function (serverVersion, forceRefresh) {
                var that = this;
                var cardTypes = this.getCardTypeEntities();
                cardTypes.then(function (data) {
                    if (data && data.entityCollection && data.entityCollection.get_entities().length > 0) {
                        var entities = data.entityCollection.get_entities();
                        for (var i in entities) {
                            if (entities[i].fields.cardtypeid) {
                                that.cardTypeEntities[entities[i].fields.cardtypeid.toString()] = entities[i].fields;
                            }
                        }
                    }
                    else {
                        var entities = data.entities;
                        for (var i in entities) {
                            that.cardTypeEntities[entities[i].cardtypeid.toString()] = entities[i];
                        }
                    }
                    var cardTypesJson = { version: serverVersion, cardTypes: that.cardTypeEntities };
                    sessionStorage.setItem("actioncardtypes", JSON.stringify(cardTypesJson));
                    if (!that.filterSet || forceRefresh) {
                        that.setFilter(that._context);
                        that._context.parameters.SubGrid.refresh();
                    }
                }, function (failure) {
                    console.error("Error:" + failure + console.trace());
                });
            };
            CardFeedContainer.prototype.setFilter = function (context) {
                CardFeedContainer_1.CardUtils.userUtcOffset = context.client.getUserTimeZoneUtcOffset(new Date());
                var currentDate = CardFeedContainer_1.CardUtils.getUserTime(new Date().toString(), "formatShortDate24Hour", context);
                var startDateCondition = {
                    attributeName: "startdate",
                    conditionOperator: 5,
                    value: currentDate,
                };
                var expiryDateCondition = {
                    attributeName: "expirydate",
                    conditionOperator: 4,
                    value: currentDate,
                };
                var conditions = [startDateCondition, expiryDateCondition];
                var params = context.parameters;
                if (params.EntityTypeCode != undefined &&
                    params.EntityTypeCode.raw != undefined &&
                    params.EntityTypeCode.raw != null) {
                    var recordId = {
                        attributeName: "recordid",
                        conditionOperator: 0,
                        value: context.mode.contextInfo.entityId,
                    };
                    var recordObjectTypeCode = {
                        attributeName: "recordidobjecttypecode2",
                        conditionOperator: 0,
                        value: params.EntityTypeCode.raw + "",
                    };
                    if (recordId.value == null ||
                        recordId.value == "undefined" ||
                        recordObjectTypeCode.value == null ||
                        recordObjectTypeCode.value == "undefined") {
                        return;
                    }
                    conditions = [startDateCondition, expiryDateCondition, recordId, recordObjectTypeCode];
                }
                var filterExpression = {
                    conditions: conditions,
                    filterOperator: 0,
                };
                context.parameters.SubGrid.filtering.setFilter(filterExpression);
                this.filterSet = true;
                context.parameters.SubGrid.refresh();
            };
            CardFeedContainer.prototype.getCardTypeEntities = function () {
                var fetchXML = "<fetch mapping='logical'><entity name='cardtype'><attribute name='cardtypeid'/><attribute name='cardname'/><attribute name='softtitle'/><attribute name='hassnoozedismiss'/><attribute name='grouptype'/><attribute name='summarytext'/><attribute name='actions'/><attribute name='cardtypeicon'/></entity></fetch>";
                return this._context.webAPI.retrieveMultipleRecords("cardtype", "?fetchXml=" + fetchXML);
            };
            CardFeedContainer.prototype.fetchEntityImages = function (entityImageRequests, promises) {
                var outerContext = this;
                Object.keys(entityImageRequests).forEach(function (entityName) {
                    if (entityName === "opportunity") {
                        return;
                    }
                    var conditions = "";
                    entityImageRequests[entityName].forEach(function (entityId) {
                        conditions += "<condition attribute='" + entityName + "id" + "' operator='eq' value='" + entityId + "' />";
                    });
                    var fetchXML = "<fetch mapping='logical'><entity name='" +
                        entityName +
                        "'><attribute name='entityimage_url' /><filter type='or'>" +
                        conditions +
                        "</filter></entity></fetch>";
                    promises.push(outerContext._context.webAPI.retrieveMultipleRecords(entityName, "?fetchXml=" + fetchXML).then(function (data) {
                        if (data && data.entities && data.entities.length > 0) {
                            data.entities.forEach(function (img) {
                                var imgUrl = img ? img.entityimage_url : "";
                                for (var entity in outerContext.recordsEntityImageArray) {
                                    var entityName_1 = outerContext.recordsEntityImageArray[entity].entityName;
                                    if (outerContext.recordsEntityImageArray[entity].entityGuid == img[entityName_1 + "id"]) {
                                        outerContext.recordsArray[outerContext.recordsEntityImageArray[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = imgUrl;
                                        break;
                                    }
                                }
                            });
                        }
                    }, function (failure) {
                        console.log("Error:" + failure);
                    }));
                });
            };
            CardFeedContainer.prototype.fetchActionCommands = function (thisContext) {
                if (thisContext.recordsArray.length > 0) {
                    for (var card in thisContext.recordsArray) {
                        thisContext.commandFetchCounter = 0;
                        var commands = thisContext.getActionCommands(thisContext.recordsArray[card]);
                    }
                    thisContext.renderControl(true, thisContext.renderNextMapHandler);
                }
            };
            CardFeedContainer.prototype.getActionCommands = function (cardData) {
                var _this = this;
                var commands = this.commandManager.getCommandByCardId(cardData.cardId);
                if (commands && commands.length > 0) {
                    return commands;
                }
                else {
                    if (this.commandFetchCounter < 3) {
                        this.commandFetchCounter++;
                        window.setTimeout(function () {
                            _this.getActionCommands(cardData);
                        }, 500);
                    }
                }
            };
            CardFeedContainer.prototype.retrieveActionData = function (card) {
                var cardActions;
                var actionData = [];
                var self = this;
                var commands = this.commandManager.getCommandByCardId(card.cardId);
                if (commands && commands.length > 0) {
                    var command = void 0;
                    var i = commands.length;
                    while (i--) {
                        command = commands[i];
                        if (command.commandId == "Mscrm.HomepageGrid.actioncard.Open" &&
                            card.regardingobjectid &&
                            card.regardingobjectid.id &&
                            card.regardingobjectid.id.guid == this._context.mode.contextInfo.entityId) {
                            commands.splice(i, 1);
                        }
                    }
                }
                var canShowEmail = true;
                if (card.actions && commands && commands.length > 0) {
                    var filteredCommands_1 = _.filter(commands, function (cmd) {
                        if (cmd.commandId != null) {
                            cmd.command = cmd.commandId;
                        }
                        return (cmd.command != "Mscrm.HomepageGrid.actioncard.DismissCommand" &&
                            cmd.command != "Mscrm.HomepageGrid.actioncard.SnoozeCommand" &&
                            (cmd.command == "Mscrm.Modern.EmailAttendeesCommand" || cmd.command == "Mscrm.Modern.SendEmailCommand"
                                ? canShowEmail
                                : true));
                    });
                    if (card.actions.Mobile)
                        cardActions = card.actions.Mobile.Actions;
                    else if (card.actions.WebClient)
                        cardActions = card.actions.WebClient.Actions;
                    if (cardActions) {
                        var actionCount_1 = 0;
                        $.each(cardActions, function (label, command) {
                            if (actionCount_1 < 2) {
                                var curcommand = _.find(filteredCommands_1, function (cmd) {
                                    if (cmd.commandId != null) {
                                        cmd.command = cmd.commandId;
                                    }
                                    return cmd.command == command || cmd.command == command + "Solution";
                                });
                                if (curcommand) {
                                    var actionLinkName = self._context.resources.getString(label);
                                    if (actionLinkName) {
                                        curcommand.label = actionLinkName;
                                    }
                                    actionData.push(curcommand);
                                    actionCount_1++;
                                }
                            }
                        });
                        return actionData;
                    }
                }
            };
            CardFeedContainer.prototype.addTelemetryForError = function (functionName, errMsg) {
                var caughtError = new ActionCardAlertsAndErrors(functionName, errMsg);
                this._context.reporting.reportEvent(caughtError);
            };
            CardFeedContainer.prototype.load = function () {
                var _this = this;
                if (this.cardTypeEntities &&
                    this.cardTypeEntities != undefined &&
                    this._context.parameters.SubGrid.loading == false) {
                    if (Object.keys(this.cardTypeEntities).length > 0) {
                        this.recordsArray = [];
                        this.recordsEntityImageArray = [];
                        var promises = [];
                        var recordSet = this._context.parameters.SubGrid.records;
                        var entityGUIDMappings = {};
                        for (var record in recordSet) {
                            try {
                                var typedRecord = recordSet[record];
                                var cardTypeId = typedRecord.getValue("cardtypeid");
                                if (cardTypeId && cardTypeId != null) {
                                    var cardTypeRecord = this.cardTypeEntities[cardTypeId.id.guid];
                                    if (cardTypeRecord != undefined) {
                                        typedRecord["cardName"] = cardTypeRecord["cardname"].toUpperCase();
                                        typedRecord["grouptype"] = cardTypeRecord["grouptype"];
                                        typedRecord["cardtype"] = typedRecord.getValue("cardtype");
                                        typedRecord["hasSnoozeDismiss"] = Number(cardTypeRecord["hassnoozedismiss"]);
                                        typedRecord["originalTitle"] = typedRecord.getValue("title");
                                        typedRecord["title"] = typedRecord.getValue("title");
                                        typedRecord["priority"] = typedRecord.getValue("priority");
                                        typedRecord["description"] =
                                            typedRecord.getValue("description") == null ? "" : typedRecord.getValue("description");
                                        typedRecord["softTitle"] = this._context.resources.getString(cardTypeRecord["softtitle"]);
                                        typedRecord["summaryText"] = this._context.resources.getString(cardTypeRecord["summarytext"]);
                                        var parsedActions = cardTypeRecord["actions"] != null && typeof cardTypeRecord["actions"] === "string"
                                            ? JSON.parse(cardTypeRecord["actions"])
                                            : null;
                                        typedRecord["actions"] = parsedActions ? parsedActions : null;
                                        var refTokens = typedRecord.getValue("referencetokens");
                                        typedRecord["referencetokens"] =
                                            refTokens != null && typeof refTokens === "string"
                                                ? JSON.parse(typedRecord.getValue("referencetokens"))
                                                : refTokens;
                                        var data = typedRecord.getValue("data");
                                        typedRecord["data"] =
                                            typeof data == "object"
                                                ? data
                                                : JSON.parse(data != null ? data.slice(0, data.length - 1) + "}" : "{}");
                                        typedRecord["cardId"] = typedRecord.getValue("actioncardid").guid;
                                        typedRecord["actioncardid"] = typedRecord["cardId"];
                                        typedRecord["regardingobjectid"] = typedRecord.getValue("regardingobjectid");
                                        typedRecord["icon"] = cardTypeRecord["cardtypeicon"];
                                        if (typedRecord["cardName"] != undefined &&
                                            typedRecord["cardName"] != null &&
                                            typedRecord["cardName"] != "") {
                                            var recordsArrayIndex = this.recordsArray.push(typedRecord);
                                            var isParamLocationDefined = this._context.parameters.Location != undefined &&
                                                this._context.parameters.Location != null &&
                                                this._context.parameters.Location.raw != undefined &&
                                                this._context.parameters.Location.raw != null;
                                            var entryPoint = isParamLocationDefined ? this._context.parameters.Location.raw : "-1";
                                            var actionCardDisplay = new ActionCardDisplay(entryPoint, typedRecord["cardtype"], typedRecord["cardId"]);
                                            this._context.reporting.reportEvent(actionCardDisplay);
                                            if (typedRecord["data"] && typedRecord["data"].cardContextDetails) {
                                                var contextObject = typedRecord["data"].cardContextDetails[0] != undefined
                                                    ? typedRecord["data"].cardContextDetails[0].contextObject
                                                    : "";
                                                if (contextObject &&
                                                    contextObject.guid != "" &&
                                                    contextObject.guid != undefined &&
                                                    contextObject.entityName != "" &&
                                                    contextObject.entityName != undefined) {
                                                    var imageRequestsForEntity = entityGUIDMappings[contextObject.entityName];
                                                    if (imageRequestsForEntity) {
                                                        imageRequestsForEntity.push(contextObject.guid);
                                                    }
                                                    else {
                                                        entityGUIDMappings[contextObject.entityName] = [contextObject.guid];
                                                    }
                                                    this.recordsEntityImageArray.push({
                                                        entityGuid: contextObject.guid,
                                                        index: recordsArrayIndex - 1,
                                                        entityName: contextObject.entityName,
                                                    });
                                                }
                                            }
                                            this.isLoad = true;
                                        }
                                    }
                                }
                            }
                            catch (ex) {
                                this.addTelemetryForError("load", ex);
                            }
                        }
                        if (!$.isEmptyObject(entityGUIDMappings)) {
                            this.fetchEntityImages(entityGUIDMappings, promises);
                        }
                        try {
                            window.top.Mscrm.ActionCardsRecords = [];
                            for (var record in this.recordsArray) {
                                window.top.Mscrm.ActionCardsRecords.push(this.recordsArray[record]);
                            }
                        }
                        catch (e) {
                            localStorage.setItem("actionCardRecords", JSON.stringify(this.recordsArray));
                        }
                        this.groupedData = CardFeedContainer_1.Utils.groupData(this.recordsArray);
                        var groupKeys = Object.keys(this.groupedData);
                        var upPromises = [];
                        CardFeedContainer.nextMeetingAttendees = {};
                        if (groupKeys.indexOf("UPCOMING_MEETING") > -1 || groupKeys.indexOf("UPCOMING_MEETING_EXCHANGE") > -1) {
                            this.isNextMeeting = true;
                            var cards = [];
                            if (groupKeys.indexOf("UPCOMING_MEETING") > -1)
                                this.nextMeetingCards = this.groupedData["UPCOMING_MEETING"];
                            if (groupKeys.indexOf("UPCOMING_MEETING_EXCHANGE") > -1)
                                this.nextMeetingCards = this.nextMeetingCards.concat(this.groupedData["UPCOMING_MEETING_EXCHANGE"]);
                            for (var _i = 0, _a = this.nextMeetingCards; _i < _a.length; _i++) {
                                var card = _a[_i];
                                CardFeedContainer.nextMeetingAttendees[card.cardId] = [];
                                CardFeedContainer.flightMeetingData[card.cardId] = [];
                                var attParams = this.dataFactories["Productivity"].getParameterInfo(card, true);
                                attParams["logicalName"] = "meetingData";
                                promises.push(CardFeedContainer_1.CardService.getAttendeesData(attParams, { cardData: card }, this));
                            }
                        }
                        if (groupKeys.indexOf("UPCOMING_FLIGHT") !== -1) {
                            for (var _b = 0, _c = this.groupedData["UPCOMING_FLIGHT"]; _b < _c.length; _b++) {
                                var filghtCard = _c[_b];
                                promises.push(this.dataFactories["UPCOMING_FLIGHT"].generateAdditionalData(filghtCard));
                            }
                        }
                        if (this.isLoad) {
                            this.manageNumberOfCardsInContainer();
                        }
                        if (this.commandManager && this.isLoad) {
                            this.commandManager.subGrid = this._context.parameters.SubGrid;
                            this.commandManager.fetchCommands(0, this.fetchActionCommands);
                        }
                        if (promises.length > 0) {
                            Promise.all(promises).then(function () {
                                _this.renderControl(true, _this.renderNextMapHandler);
                            });
                        }
                    }
                }
            };
            CardFeedContainer.prototype.renderControl = function (render, callback) {
                if (render === void 0) { render = false; }
                if (render) {
                    this._context.utils.requestRender(callback);
                }
            };
            CardFeedContainer.prototype.setFocusCardElement = function () {
                this._context.accessibility.focusElementById(this.focusElementStr + this.focusedElement);
                this.renderControl(true);
            };
            CardFeedContainer.prototype.handleDismissCard = function () {
                var that = this;
                this.menuClickedCardId = null;
                this.flyoutId = -1;
                var timeout = CardFeedContainer.toastTimeoutInMillis;
                if (that.typeOfCard == "TEASER") {
                    timeout = 0;
                }
                this.dismissTimerId = setTimeout(function () {
                    that.dismissClickedCardIndex = null;
                    that.dismissNegativeClickedIndex = null;
                    that.menuClickedCardId = null;
                    that.flyoutId = -1;
                    that.checkForTranslate = true;
                    that.cardEvents.handleDismissEvent(that.dimissCardId);
                }, timeout);
            };
            CardFeedContainer.prototype.handleSnoozCard = function () {
                var that = this;
                this.menuClickedCardId = null;
                this.flyoutId = -1;
                this.dismissTimerId = setTimeout(function () {
                    that.dismissClickedCardIndex = null;
                    that.dismissNegativeClickedIndex = null;
                    that.menuClickedCardId = null;
                    that.flyoutId = -1;
                    that.checkForTranslate = true;
                    that.cardEvents.handleSnoozeEvent(that.dimissCardId);
                }, CardFeedContainer.toastTimeoutInMillis);
            };
            CardFeedContainer.prototype.handleGroupDismissCard = function () {
                var that = this;
                this.menuClickedCardId = null;
                this.flyoutId = -1;
                this.dismissTimerId = setTimeout(function () {
                    that.dismissClickedCardIndex = null;
                    that.dismissNegativeClickedIndex = null;
                    that.menuClickedCardId = null;
                    that.checkForTranslate = true;
                    that.cardEvents.handleDismissAllEvent(that.dimissCardId);
                }, CardFeedContainer.toastTimeoutInMillis);
            };
            CardFeedContainer.prototype.handleGroupSnoozCard = function () {
                var that = this;
                this.menuClickedCardId = null;
                this.flyoutId = -1;
                this.dismissTimerId = setTimeout(function () {
                    that.dismissClickedCardIndex = null;
                    that.dismissNegativeClickedIndex = null;
                    that.menuClickedCardId = null;
                    that.checkForTranslate = true;
                    that.cardEvents.handleSnoozeAllEvent(that.dimissCardId);
                }, CardFeedContainer.toastTimeoutInMillis);
            };
            CardFeedContainer.prototype.swipeStartObserver = function (mdEvent, card, type, accessibilityFocusId) {
                var swipeEvent = mdEvent;
                CardFeedContainer.mouseDown = true;
                CardFeedContainer.mouseMoved = false;
                CardFeedContainer.swipeCardType = type;
                this.cardBoundary = swipeEvent.currentTarget.getBoundingClientRect();
                if (swipeEvent.type == "pointerdown") {
                    this.startX = swipeEvent.clientX;
                    this.startY = swipeEvent.clientY;
                }
                else if (swipeEvent.type == "touchstart") {
                    this.startX = swipeEvent.changedTouches[0].clientX;
                    this.startY = swipeEvent.changedTouches[0].clientY;
                }
                if (swipeEvent.nativeEvent.pointerType == "touch") {
                    var lscope_1 = this;
                    swipeEvent.target.addEventListener("touchend", function (event) {
                        lscope_1.swipeEndObserver(event, card, type, accessibilityFocusId);
                    });
                    swipeEvent.target.addEventListener("touchmove", function (event) {
                        lscope_1.elementMove(event, card, type, accessibilityFocusId);
                    });
                }
            };
            CardFeedContainer.prototype.swipeEndObserver = function (muEvent, card, type, accessibilityFocusId) {
                var endPosX;
                var endPosY;
                var swipeEvent = muEvent;
                CardFeedContainer.swipeCardType = type;
                var self = this;
                CardFeedContainer.mouseDown = false;
                if (swipeEvent.type == "pointerup" || swipeEvent.type == "pointermove") {
                    endPosX = swipeEvent.clientX;
                    endPosY = swipeEvent.clientY;
                }
                else if (swipeEvent.type == "touchend" || swipeEvent.type == "touchmove") {
                    endPosX = swipeEvent.changedTouches[0].clientX;
                    endPosY = swipeEvent.changedTouches[0].clientY;
                }
                if (this.cardBoundary && this.cardBoundary.width) {
                    CardFeedContainer.swipingCardId = accessibilityFocusId;
                    if ((Math.abs(this.startX - endPosX) / this.cardBoundary.width) * 100 < 30 ||
                        !(endPosY > this.cardBoundary.top && endPosY < this.cardBoundary.bottom)) {
                        if (type == "group") {
                            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else if (type == "mincard") {
                            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else {
                            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                        }
                    }
                    else if (((endPosX - this.startX) / this.cardBoundary.width) * 100 > 30) {
                        if (this.cardBoundary.right >= endPosX) {
                            if (type == "group") {
                                CardFeedContainer.groupCardTransition = "transform 0.25s ease-out";
                                CardFeedContainer.groupCardTransform = "translate3d(" + this.cardBoundary.width + "px, 0, 0)";
                                CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                                CardFeedContainer.cardTransition = "transform .3s linear";
                                CardFeedContainer.minCardTransition = "transform .3s linear";
                                CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                            }
                            else if (type == "mincard") {
                                CardFeedContainer.minCardTransition = "transform 0.25s ease-out";
                                CardFeedContainer.minCardTransform = "translate3d(418px, 0, 0)";
                                CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                                CardFeedContainer.groupCardTransition = "transform .3s linear";
                                CardFeedContainer.cardTransition = "transform .3s linear";
                                CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                            }
                            else {
                                CardFeedContainer.cardTransition = "transform 0.25s ease-out";
                                CardFeedContainer.groupCardTransition = "transform .3s linear";
                                CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                                CardFeedContainer.cardTransform = "translate3d(" + this.cardBoundary.width + "px, 0, 0)";
                                CardFeedContainer.minCardTransition = "transform .3s linear";
                                CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                            }
                            CardFeedContainer.moveBelow30Per = false;
                            if (type == "group") {
                                this.cardEvents.handleGroupSnoozSwipe(card, accessibilityFocusId, muEvent);
                            }
                            else if (type == "mincard") {
                                this.cardEvents.handleMinCardSnoozSwipe(card.cardId, accessibilityFocusId, muEvent);
                            }
                            else {
                                this.cardEvents.handleSnoozSwipe(card.cardId, accessibilityFocusId, muEvent);
                            }
                        }
                    }
                    else if (((this.startX - endPosX) / this.cardBoundary.width) * 100 > 30) {
                        CardFeedContainer.cardTransition = "transform 0.25s ease-out";
                        if (type == "group") {
                            CardFeedContainer.groupCardTransform = "translate3d(-" + this.cardBoundary.width + "px, 0, 0)";
                            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else if (type == "mincard") {
                            CardFeedContainer.minCardTransform = "translate3d(-" + this.cardBoundary.width + "px, 0, 0)";
                            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else {
                            CardFeedContainer.cardTransform = "translate3d(-" + this.cardBoundary.width + "px, 0, 0)";
                            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        this.dismissClickedCardIndex = accessibilityFocusId;
                        CardFeedContainer.moveBelow30Per = false;
                        if (type == "group") {
                            this.dimissCardId = card;
                            this.cardEvents.handleGroupDismissInMenu(card, accessibilityFocusId, muEvent);
                        }
                        else if (type == "mincard") {
                            this.dimissCardId = card.cardId;
                            this.cardEvents.handleMinCardDismissInMenu(card.cardId, accessibilityFocusId, muEvent);
                        }
                        else {
                            this.dimissCardId = card.cardId;
                            if (card.cardName == "TEASER") {
                                this.cardEvents.handleSnoozSwipe(card.cardId, accessibilityFocusId, muEvent);
                            }
                            else {
                                this.cardEvents.handleDismissInMenu(card.cardId, accessibilityFocusId, muEvent);
                            }
                        }
                    }
                }
                if (swipeEvent.nativeEvent.pointerType == "touch") {
                    swipeEvent.target.off("touchend");
                    swipeEvent.target.off("touchmove");
                }
                this.renderControl(true);
            };
            CardFeedContainer.prototype.elementMove = function (mmEvent, card, type, accessibilityFocusId) {
                var currentPosY;
                var currentPosX;
                var swipeEvent = mmEvent;
                var canPerformOp = true;
                CardFeedContainer.swipeCardType = type;
                if (this.cardBoundary && this.cardBoundary.width) {
                    if (swipeEvent.type == "pointermove") {
                        currentPosX = swipeEvent.clientX;
                        currentPosY = swipeEvent.clientY;
                    }
                    else if (swipeEvent.type == "touchmove") {
                        currentPosX = swipeEvent.changedTouches[0].clientX;
                        currentPosY = swipeEvent.changedTouches[0].clientY;
                    }
                    var swipediffY = currentPosY - this.startY;
                    var swipediffX = currentPosX - this.startX;
                    if (Math.abs(swipediffX) > 10) {
                        mmEvent.preventDefault();
                    }
                    if (this.startX - currentPosX <= 0) {
                        if ((type == "group" && !Boolean(card[0].hasSnoozeDismiss)) ||
                            (type == "card" && !Boolean(card.hasSnoozeDismiss))) {
                            canPerformOp = false;
                        }
                    }
                    else {
                        canPerformOp = true;
                    }
                    if (canPerformOp) {
                        if (swipediffX != 0)
                            CardFeedContainer.mouseMoved = true;
                        CardFeedContainer.swipingCardId = accessibilityFocusId;
                        if (type == "group") {
                            CardFeedContainer.groupCardTransition = "transform 0s ease-out";
                            CardFeedContainer.groupCardTransform = "translate3d(" + swipediffX + "px, 0, 0)";
                            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.cardTransition = "transform .3s linear";
                            CardFeedContainer.minCardTransition = "transform .3s linear";
                            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else if (type == "mincard") {
                            CardFeedContainer.minCardTransition = "transform 0s ease-out";
                            CardFeedContainer.minCardTransform = "translate3d(" + swipediffX + "px, 0, 0)";
                            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.groupCardTransition = "transform .3s linear";
                            CardFeedContainer.cardTransition = "transform .3s linear";
                            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        else {
                            CardFeedContainer.cardTransition = "transform 0s ease-out";
                            CardFeedContainer.cardTransform = "translate3d(" + swipediffX + "px, 0, 0)";
                            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
                            CardFeedContainer.groupCardTransition = "transform .3s linear";
                            CardFeedContainer.minCardTransition = "transform .3s linear";
                            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                        }
                        if (!(currentPosX > this.cardBoundary.left && currentPosX < this.cardBoundary.right) ||
                            !(currentPosY > this.cardBoundary.top && currentPosY < this.cardBoundary.bottom)) {
                            this.swipeEndObserver(mmEvent, card, type, accessibilityFocusId);
                        }
                        else {
                            CardFeedContainer.moveBelow30Per = true;
                        }
                    }
                    this.renderControl(true);
                }
            };
            CardFeedContainer.prototype.fetchAllCards = function () {
                var _this = this;
                if (this.recordsArray.length > 0) {
                    var commands = this.getActionCommands(this.recordsArray[0]);
                    for (var i in commands) {
                        var cmd = commands[i];
                        if (cmd && cmd.commandId == "Mscrm.HomepageGrid.actioncard.GotItActionCommand") {
                            cmd.execute();
                            setTimeout(function () {
                                _this._context.parameters.SubGrid.refresh();
                                _this.isLoad = false;
                                _this.renderControl(true);
                            }, 30000);
                            break;
                        }
                    }
                }
            };
            CardFeedContainer.prototype.initializeToastTimeout = function () {
                if (sessionStorage) {
                    var cachedToastTimeoutInMillis = sessionStorage.getItem("cachedtoasttimeoutmillis");
                    if (cachedToastTimeoutInMillis && $.isNumeric(cachedToastTimeoutInMillis)) {
                        CardFeedContainer.toastTimeoutInMillis = parseInt(cachedToastTimeoutInMillis);
                        return;
                    }
                }
                this.loadToastTimeoutFromCard();
            };
            CardFeedContainer.prototype.loadToastTimeoutFromCard = function () {
                var parentContext = this;
                this.getToastConfigCard().then(function (data) {
                    if (data && data.entities.length > 0)
                        CardFeedContainer.toastTimeoutInMillis = data.entities[0].intcardoption * 1000;
                    sessionStorage.setItem("cachedtoasttimeoutmillis", CardFeedContainer.toastTimeoutInMillis);
                }, function (failure) {
                    parentContext.addTelemetryForToastTimeoutFetchError("initializeToastTimeout", failure);
                });
            };
            CardFeedContainer.prototype.getToastConfigCard = function () {
                var fetchXML = "<fetch mapping='logical'><entity name='actioncardusersettings'><attribute name='intcardoption'/>" +
                    "<filter><condition attribute='cardtypeid' operator='eq' value='3C78DDC8-AA4C-4B5E-AE77-F67960B19825'/></filter></entity></fetch>";
                return this._context.webAPI.retrieveMultipleRecords("actioncardusersettings", "?fetchXml=" + fetchXML);
            };
            CardFeedContainer.prototype.addTelemetryForToastTimeoutFetchError = function (functionName, errMsg) {
                var toastTimeoutFetchError = new ActionCardAlertsAndErrors(functionName, errMsg);
                this._context.reporting.reportEvent(toastTimeoutFetchError);
            };
            CardFeedContainer.prototype.getOutputs = function () {
                return null;
            };
            CardFeedContainer.prototype.destroy = function () {
                this._context = null;
                CardFeedContainer.cfcContext = null;
            };
            CardFeedContainer.flightNearByData = {};
            CardFeedContainer.flightMeetingData = {};
            CardFeedContainer.nextMeetingAttendees = {};
            CardFeedContainer.mouseDown = false;
            CardFeedContainer.mouseMoved = false;
            CardFeedContainer.moveBelow30Per = false;
            CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
            CardFeedContainer.groupCardTransform = "translate3d(0px, 0px, 0px)";
            CardFeedContainer.cardTransition = "transform .3s linear";
            CardFeedContainer.groupCardTransition = "transform .3s linear";
            CardFeedContainer.minCardTransition = "transform .3s linear";
            CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
            CardFeedContainer.nmrendered = false;
            CardFeedContainer.nextMapPromises = [];
            CardFeedContainer.toastTimeoutInMillis = 2000;
            return CardFeedContainer;
        }());
        CardFeedContainer_1.CardFeedContainer = CardFeedContainer;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var CardUtils;
        (function (CardUtils) {
            CardUtils.isGetStartedClicked = false;
            CardUtils.isUci = false;
            function checkWhetherGroupPresent(data) {
                var hasGroup = false;
                for (var i in data) {
                    if (data[i].length > 1) {
                        hasGroup = true;
                    }
                }
                return hasGroup;
            }
            CardUtils.checkWhetherGroupPresent = checkWhetherGroupPresent;
            function sortDataSource(source) {
                var keys = [];
                for (var key in source) {
                    keys[keys.length] = key;
                }
                var values = [];
                for (var i = 0; i < keys.length; i++) {
                    values[values.length] = source[keys[i]];
                }
                var sortedValues = values.sort(function (a, b) {
                    return a.length - b.length;
                });
                return sortedValues;
            }
            CardUtils.sortDataSource = sortDataSource;
            function isCCFMode() {
                return CardUtils.isUci;
            }
            CardUtils.isCCFMode = isCCFMode;
            function getEntityImage(entityName, entityId) {
                var fetchXML = "<fetch mapping='logical'> <entity name='" +
                    entityName +
                    "'> <attribute name='entityimage_url' /> <filter> <condition attribute='" +
                    entityName +
                    "id" +
                    "' operator='eq' value='" +
                    entityId +
                    "' /> </filter> </entity> </fetch>";
                var _window = window;
                var context = CardFeedContainer.CardFeedContainer.cfcContext;
                return context.webAPI.retrieveMultipleRecords(entityName, "?fetchXml=" + fetchXML);
            }
            CardUtils.getEntityImage = getEntityImage;
            function fetchEntityImages(entityImageRequests) {
                var promises = [];
                Object.keys(entityImageRequests).forEach(function (entityName) {
                    var conditions = "";
                    entityImageRequests[entityName].forEach(function (entityId) {
                        conditions += "<condition attribute='" + entityName + "id" + "' operator='eq' value='" + entityId + "' />";
                    });
                    var fetchXML = "<fetch mapping='logical'><entity name='" +
                        entityName +
                        "'><attribute name='entityimage_url' /><filter type='or'>" +
                        conditions +
                        "</filter></entity></fetch>";
                    var _window = window;
                    var context = CardFeedContainer.CardFeedContainer.cfcContext;
                    promises.push(context.webAPI.retrieveMultipleRecords(entityName, "?fetchXml=" + fetchXML));
                });
                return promises;
            }
            CardUtils.fetchEntityImages = fetchEntityImages;
            function getCardTypeEntities() {
                var fetchXML = "<fetch mapping='logical'> <entity name='cardtype'> <attribute name='cardtypeid' /><attribute name='cardname' />	<attribute name='softtitle' /><attribute name='hassnoozedismiss' /><attribute name='grouptype' /><attribute name='summarytext' /><attribute name='actions' /><attribute name='cardtypeicon'/></entity> </fetch>";
                var context = CardUtils.ccfContext;
                return context.webAPI.retrieveMultipleRecords("cardtype", "?fetchXml=" + fetchXML);
            }
            CardUtils.getCardTypeEntities = getCardTypeEntities;
            function getOrgName() {
                var url = window.location.href;
                var params = url.split("?")[1];
                var orgParam = params.split("&")[0];
                var org = orgParam.split("=")[1];
                return org;
            }
            function formatStringArray(format, array) {
                var returnValue = format;
                if (array != undefined && array.length > 0) {
                    for (var i = 0; i < array.length; i++) {
                        var actualValue = typeof array[i] == "undefined" || array[i] == null ? "" : array[i].toString();
                        returnValue = returnValue.replace(new RegExp("\\{" + i + "\\}", "g"), actualValue);
                    }
                }
                return returnValue;
            }
            CardUtils.formatStringArray = formatStringArray;
            function getCCFLocaleFormat(utcTime, format) {
                return utcTime._toFormattedString(format, CardFeedContainer.CardFeedContainer.cfcContext.formatting._currentCultureInfo);
            }
            CardUtils.getCCFLocaleFormat = getCCFLocaleFormat;
            function getCCFUserTime(utcTime) {
                utcTime = moment(utcTime).toDate();
                var userDateTime = utcTime;
                if (userDateTime != undefined && userDateTime != "") {
                    utcTime.setMinutes(moment(utcTime)
                        .toDate()
                        .getMinutes() +
                        moment(utcTime)
                            .toDate()
                            .getTimezoneOffset() +
                        CardFeedContainer.CardFeedContainer.cfcContext.client.getUserTimeZoneUtcOffset(moment(utcTime).toDate()));
                    userDateTime = utcTime;
                }
                return utcTime;
            }
            CardUtils.getCCFUserTime = getCCFUserTime;
            function getUserTime(utcTime, format, context) {
                var formattedDate;
                var userDateTimeStr;
                utcTime = moment(utcTime).toDate();
                var userDateTime = utcTime;
                if (userDateTime != undefined && userDateTime != "") {
                    switch (format) {
                        case "formatShortDate24Hour": {
                            utcTime.setMinutes(moment(utcTime)
                                .toDate()
                                .getMinutes() +
                                moment(utcTime)
                                    .toDate()
                                    .getTimezoneOffset() +
                                context.client.getUserTimeZoneUtcOffset(moment(utcTime).toDate()));
                            userDateTime = utcTime;
                            formattedDate = userDateTime.format("MM/dd/yyyy HH:mm");
                            return formattedDate;
                        }
                        case "formatDateShort": {
                            formattedDate = context.formatting.formatDateShort(userDateTime, false);
                            return formattedDate;
                        }
                        case "formatTime": {
                            var dateOnly = context.formatting.formatDateShort(userDateTime, false);
                            var dateTime = context.formatting.formatTime(userDateTime, 1);
                            var time = dateTime.replace(dateOnly, "").trim();
                            return time;
                        }
                        case "formatDateLong": {
                            formattedDate = context.formatting.formatDateLong(utcTime);
                            return formattedDate;
                        }
                        case "formatDateLongWithTime": {
                            var time = context.formatting
                                .formatTime(userDateTime, 1)
                                .split(/\s/);
                            formattedDate = context.formatting.formatDateLong(userDateTime);
                            return formattedDate + " " + time[1] + (time[2] != undefined ? " " + time[2] : "");
                        }
                        default: {
                            formattedDate = context.formatting.formatTime(userDateTime, 1);
                            return formattedDate;
                        }
                    }
                }
            }
            CardUtils.getUserTime = getUserTime;
            function htmlDecoder(htmlString) {
                var decodedHtml = htmlString.replace(/&quot;/g, '"');
                decodedHtml = decodedHtml.replace(/&apos;/g, "'");
                decodedHtml = decodedHtml.replace(/&lt;/g, "<");
                decodedHtml = decodedHtml.replace(/&gt;/g, ">");
                decodedHtml = decodedHtml.replace(/&amp;/g, "&");
                return decodedHtml;
            }
            CardUtils.htmlDecoder = htmlDecoder;
            function defaultCardIcon(cardName) {
                var defaultIconCode = 31;
                switch (cardName) {
                    case "CLOSEDATECOMINGSOON": {
                        defaultIconCode = 339;
                        return defaultIconCode;
                    }
                    case "TOP_RECORD": {
                        defaultIconCode = 31;
                        return defaultIconCode;
                    }
                    case "TOP_PEOPLE": {
                        defaultIconCode = 31;
                        return defaultIconCode;
                    }
                    case "NEARBY_CUSTOMERS": {
                        defaultIconCode = 340;
                        return defaultIconCode;
                    }
                    case "AGENDA:ACTIVITY_EMAIL": {
                        defaultIconCode = 77;
                        return defaultIconCode;
                    }
                    case "RELEVANT_NEWS": {
                        defaultIconCode = 341;
                        return defaultIconCode;
                    }
                    case "STOCK_ACTIVITY": {
                        defaultIconCode = 305;
                        return defaultIconCode;
                    }
                    case "TEASER": {
                        defaultIconCode = 391;
                        return defaultIconCode;
                    }
                    case "UPCOMING_MEETING":
                    case "UPCOMING_MEETING_EXCHANGE": {
                        defaultIconCode = 342;
                        return defaultIconCode;
                    }
                    case "RECENTMEETING":
                    case "RECENTMEETINGEXCHANGE": {
                        defaultIconCode = 343;
                        return defaultIconCode;
                    }
                    case "EMAILOPENED:EMAILOPEN":
                    case "REMINDERWITHOUTCALL": {
                        defaultIconCode = 77;
                        return defaultIconCode;
                    }
                    case "REMINDERWITHCALL": {
                        defaultIconCode = 344;
                        return defaultIconCode;
                    }
                    case "ATTENDEE": {
                        defaultIconCode = 168;
                        return defaultIconCode;
                    }
                    case "account": {
                        defaultIconCode = 175;
                        return defaultIconCode;
                    }
                    case "contact": {
                        defaultIconCode = 29;
                        return defaultIconCode;
                    }
                    case "appointment": {
                        defaultIconCode = 82;
                        return defaultIconCode;
                    }
                    case "task": {
                        defaultIconCode = 345;
                        return defaultIconCode;
                    }
                    case "quote": {
                        defaultIconCode = 346;
                        return defaultIconCode;
                    }
                    case "opportunity": {
                        defaultIconCode = 347;
                        return defaultIconCode;
                    }
                    case "invoice": {
                        defaultIconCode = 348;
                        return defaultIconCode;
                    }
                    case "dashboard": {
                        defaultIconCode = 349;
                        return defaultIconCode;
                    }
                    case "lead": {
                        defaultIconCode = 350;
                        return defaultIconCode;
                    }
                    case "LEAD":
                    case "LEADDETECTION": {
                        defaultIconCode = 174;
                        return defaultIconCode;
                    }
                    case "OPPORTUNITY":
                    case "NOACTIVITYWITHOPPORTUNITY": {
                        defaultIconCode = 351;
                        return defaultIconCode;
                    }
                    case "EMAIL": {
                        defaultIconCode = 77;
                        return defaultIconCode;
                    }
                    case "CASE":
                    case "NOACTIVITYWITHCASE": {
                        defaultIconCode = 352;
                        return defaultIconCode;
                    }
                    case "COMPETITORMENTIONED": {
                        defaultIconCode = 352;
                        return defaultIconCode;
                    }
                    case "MEETING_REQUEST": {
                        defaultIconCode = 354;
                        return defaultIconCode;
                    }
                    case "STAKEHOLDER": {
                        defaultIconCode = 267;
                        return defaultIconCode;
                    }
                    case "MISSEDCLOSEDATE": {
                        defaultIconCode = 355;
                        return defaultIconCode;
                    }
                    case "ISSUEDETECTION": {
                        defaultIconCode = 356;
                        return defaultIconCode;
                    }
                    case "DEFAULT_EXCHANGE": {
                        defaultIconCode = 300;
                        return defaultIconCode;
                    }
                    case "NOACTIVITYWITHACCOUNT":
                    case "NOACTIVITYWITHLEAD":
                    case "NOACTIVITYWITHCONTACT ": {
                        defaultIconCode = 357;
                        return defaultIconCode;
                    }
                    case "YES_NO": {
                        defaultIconCode = 358;
                        return defaultIconCode;
                    }
                    case "MISSEDEMAIL": {
                        defaultIconCode = 300;
                        return defaultIconCode;
                    }
                    case "AGENDA:ACTIVITY_SERVICEAPPOINTMENT": {
                        defaultIconCode = 359;
                        return defaultIconCode;
                    }
                    case "AGENDA:ACTIVITY_FAX": {
                        defaultIconCode = 360;
                        return defaultIconCode;
                    }
                    case "REGARDING": {
                        defaultIconCode = 74;
                        return defaultIconCode;
                    }
                    case "SEND_CONTENT_REQUEST": {
                        defaultIconCode = 157;
                        return defaultIconCode;
                    }
                    case "EMAILOPENED:BESTTIMETOCALL": {
                        defaultIconCode = 302;
                        return defaultIconCode;
                    }
                    case "AGENDA:ACTIVITY_LETTER": {
                        defaultIconCode = 276;
                        return defaultIconCode;
                    }
                    case "UPCOMING_FLIGHT": {
                        defaultIconCode = 361;
                        return defaultIconCode;
                    }
                    case "OpportunityAtRiskSentiment": {
                        defaultIconCode = 362;
                        return defaultIconCode;
                    }
                    case "OpportunityAtRiskKTGModel": {
                        defaultIconCode = 362;
                        return defaultIconCode;
                    }
                    case "AGENDA:ACTIVITY_MEETING":
                    case "AGENDA:ACTIVITY_PHONE":
                    case "AGENDA:ACTIVITY_TASK":
                    default: {
                        defaultIconCode = 363;
                        return defaultIconCode;
                    }
                }
            }
            CardUtils.defaultCardIcon = defaultCardIcon;
            function defaultCardTitleColor(cardName) {
                switch (cardName) {
                    case "MISSEDCLOSEDATE":
                    case "OpportunityAtRiskSentiment":
                    case "OpportunityAtRiskKTGModel":
                    case "ISSUEDETECTION":
                    case "MEETING_REQUEST":
                    case "EMAILOPENED:EMAILOPEN":
                    case "REMINDERWITHOUTCALL":
                    case "REMINDERWITHCALL":
                    case "RECENTMEETING":
                    case "RECENTMEETINGEXCHANGE": {
                        return "#B22912";
                    }
                    case "REGARDING":
                    case "STOCK_ACTIVITY":
                    case "ATTENDEE":
                    case "LEAD":
                    case "OPPORTUNITY":
                    case "DEFAULT_EXCHANGE":
                    case "CASE":
                    case "EMAIL":
                    case "NEARBY_CUSTOMERS":
                    case "RELEVANT_NEWS": {
                        return "#358717";
                    }
                    case "UPCOMING_FLIGHT":
                    case "UPCOMING_MEETING":
                    case "UPCOMING_MEETING_EXCHANGE": {
                        return "#ea0600";
                    }
                    case "AGENDA:ACTIVITY_MEETING":
                    case "COMPETITORMENTIONED":
                    case "STAKEHOLDER":
                    case "TOP_RECORD":
                    case "TOP_PEOPLE":
                    case "EMAILOPENED:BESTTIMETOCALL": {
                        return "#0e5c61";
                    }
                    case "AGENDA:ACTIVITY_PHONE":
                    case "AGENDA:ACTIVITY_TASK":
                    case "AGENDA:ACTIVITY_LETTER":
                    case "AGENDA ACTIVITY_EMAIL":
                    case "AGENDA:ACTIVITY_SERVICEAPPOINTMENT":
                    case "AGENDA:ACTIVITY_FAX":
                    case "SEND_CONTENT_REQUEST":
                    case "NOACTIVITYWITHACCOUNT":
                    case "NOACTIVITYWITHLEAD":
                    case "NOACTIVITYWITHCONTACT":
                    case "YES_NO":
                    case "MISSEDEMAIL":
                    case "NOACTIVITYWITHCASE":
                    case "NOACTIVITYWITHOPPORTUNITY":
                    case "LEADDETECTION":
                    case "CLOSEDATECOMINGSOON": {
                        return "#8C24B5";
                    }
                    case "account": {
                        return "#ffffff";
                    }
                    case "contact": {
                        return "#ffffff";
                    }
                    case "appointment": {
                        return "#ffffff";
                    }
                    case "task": {
                        return "#ffffff";
                    }
                    case "quote": {
                        return "#ffffff";
                    }
                    case "opportunity": {
                        return "#ffffff";
                    }
                    case "invoice": {
                        return "#ffffff";
                    }
                    case "dashboard": {
                        return "#ffffff";
                    }
                    case "lead": {
                        return "#ffffff";
                    }
                    default: {
                        return "#8C24B5";
                    }
                }
            }
            CardUtils.defaultCardTitleColor = defaultCardTitleColor;
            function collapseLandingPage() {
                return;
            }
            CardUtils.collapseLandingPage = collapseLandingPage;
            function isNoActivityCard(cardName) {
                switch (cardName) {
                    case "NOACTIVITYWITHOPPORTUNITY":
                    case "NOACTIVITYWITHCASE":
                    case "NOACTIVITYWITHACCOUNT":
                    case "NOACTIVITYWITHLEAD":
                    case "NOACTIVITYWITHCONTACT ":
                        return true;
                    default:
                        return false;
                }
            }
            CardUtils.isNoActivityCard = isNoActivityCard;
            function isMOCAOffline() {
                var context = CardUtils.ccfContext;
                return context.client.isOffline();
            }
            CardUtils.isMOCAOffline = isMOCAOffline;
        })(CardUtils = CardFeedContainer.CardUtils || (CardFeedContainer.CardUtils = {}));
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var CardsEventsHandler = (function () {
            function CardsEventsHandler(context, ccfScope) {
                this.globalPanelCloseCards = {
                    "Mscrm.HomepageGrid.actioncard.CreateCaseCommand": "Mscrm.HomepageGrid.actioncard.CreateCaseCommand",
                    "Mscrm.SubGrid.actioncard.CreateCaseCommand": "Mscrm.SubGrid.actioncard.CreateCaseCommand",
                    "Mscrm.Modern.OpenEmailCommand": "Mscrm.Modern.OpenEmailCommand",
                    "Mscrm.HomepageGrid.actioncard.TakeNotesCommand": "Mscrm.HomepageGrid.actioncard.TakeNotesCommand",
                    "Mscrm.SubGrid.actioncard.TakeNotesCommand": "Mscrm.SubGrid.actioncard.TakeNotesCommand",
                    "Mscrm.HomepageGrid.actioncard.Open": "Mscrm.HomepageGrid.actioncard.Open",
                    "Mscrm.SubGrid.actioncard.Open": "Mscrm.SubGrid.actioncard.Open",
                    "Mscrm.Modern.SendEmailCommand": "Mscrm.Modern.SendEmailCommand",
                    "Mscrm.HomepageGrid.actioncard.OpenRecipientView": "Mscrm.HomepageGrid.actioncard.OpenRecipientView",
                    "Mscrm.SubGrid.actioncard.OpenRecipientView": "Mscrm.SubGrid.actioncard.OpenRecipientView",
                    "Mscrm.HomepageGrid.actioncard.OpenEmailView": "Mscrm.HomepageGrid.actioncard.OpenEmailView",
                    "Mscrm.SubGrid.actioncard.OpenEmailView": "Mscrm.SubGrid.actioncard.OpenEmailView",
                    "Mscrm.HomepageGrid.actioncard.CreateNewMeetingCardCommand": "Mscrm.HomepageGrid.actioncard.CreateNewMeetingCardCommand",
                    "Mscrm.SubGrid.actioncard.CreateNewMeetingCardCommand": "Mscrm.SubGrid.actioncard.CreateNewMeetingCardCommand",
                    "Mscrm.HomepageGrid.actioncard.OpenOpportunity": "Mscrm.HomepageGrid.actioncard.OpenOpportunity",
                    "Mscrm.SubGrid.actioncard.OpenOpportunity": "Mscrm.SubGrid.actioncard.OpenOpportunity",
                    "Mscrm.Modern.EmailAttendeesCommand": "Mscrm.Modern.EmailAttendeesCommand",
                    "Mscrm.HomepageGrid.actioncard.CreateContactCommand": "Mscrm.HomepageGrid.actioncard.CreateContactCommand",
                };
                this.autoDissmissCards = {
                    "3": [
                        "Mscrm.HomepageGrid.actioncard.CreateNewMeetingCardCommand",
                        "Mscrm.SubGrid.actioncard.CreateNewMeetingCardCommand",
                    ],
                    "4": [
                        "Mscrm.HomepageGrid.actioncard.AddAsStakeHolderCommand",
                        "Mscrm.HomepageGrid.actioncard.DoThisAutomaticallyCommand",
                        "Mscrm.SubGrid.actioncard.AddAsStakeHolderCommand",
                        "Mscrm.SubGrid.actioncard.DoThisAutomaticallyCommand",
                    ],
                    "5": [
                        "Mscrm.HomepageGrid.actioncard.AddAsCompetitorCommand",
                        "Mscrm.HomepageGrid.actioncard.DoThisAutomaticallyCommand",
                        "Mscrm.SubGrid.actioncard.AddAsCompetitorCommand",
                        "Mscrm.SubGrid.actioncard.DoThisAutomaticallyCommand",
                    ],
                    "7": ["Mscrm.HomepageGrid.actioncard.CompleteTaskCommand", "Mscrm.SubGrid.actioncard.CompleteTaskCommand"],
                    "11": [
                        "Mscrm.HomepageGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.HomepageGrid.actioncard.CancelOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CancelOtherActivityCommand",
                    ],
                    "12": [
                        "Mscrm.HomepageGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CompleteOtherActivityCommand",
                    ],
                    "13": [
                        "Mscrm.HomepageGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CompleteOtherActivityCommand",
                    ],
                    "14": [
                        "Mscrm.HomepageGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CompleteOtherActivityCommand",
                    ],
                    "15": [
                        "Mscrm.HomepageGrid.actioncard.CompleteOtherActivityCommand",
                        "Mscrm.SubGrid.actioncard.CompleteOtherActivityCommand",
                    ],
                    "120": ["Mscrm.HomepageGrid.actioncard.CreateContactCommand"],
                };
                this._context = context;
                this.ccfScope = ccfScope;
            }
            CardsEventsHandler.prototype.menuSelection = function (flag, event) {
                var element = document.getElementById(event.currentTarget.id);
                if (flag) {
                    element.style.backgroundColor = this._context.theming.colors.grays.gray02;
                }
                else {
                    element.style.backgroundColor = "";
                }
            };
            CardsEventsHandler.prototype.menuClickHandler = function (accessibilityFocusId, event) {
                this.ccfScope.focusedElement = accessibilityFocusId;
                this.ccfScope.initialPageLoad = false;
                this.ccfScope.menuClickedCardId =
                    this.ccfScope.flyoutId == accessibilityFocusId || this.ccfScope.menuClickedCardId == accessibilityFocusId
                        ? -1
                        : accessibilityFocusId;
                if (this.ccfScope.menuClickedCardId >= 0) {
                    this.ccfScope.flyoutId = this.ccfScope.menuClickedCardId;
                    this.ccfScope.focusElementStr = "menuSnoozeContainer";
                    event.stopPropagation();
                    this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                }
                else {
                    this.ccfScope.flyoutId = -1;
                    event.currentTarget.blur();
                    event.stopPropagation();
                    this.ccfScope.renderControl(true);
                }
            };
            CardsEventsHandler.prototype.menuKeyPressHandler = function (accessibilityFocusId, event) {
                if (event.type === "keydown") {
                    if (event.keyCode == 13) {
                        this.ccfScope.initialPageLoad = false;
                        this.ccfScope.menuClickedCardId =
                            this.ccfScope.menuClickedCardId == accessibilityFocusId ? null : accessibilityFocusId;
                        this.ccfScope.focusElementStr = "menuSnoozeContainer";
                        event.stopPropagation();
                        this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                    }
                }
            };
            CardsEventsHandler.prototype.menuItemKeyPressHandler = function (index, accessibilityFocusId, prevElement, nextElement, action, cards, scope, event) {
                if (event.type === "keydown" &&
                    (event.keyCode == 40 ||
                        event.keyCode == 38 ||
                        event.keyCode == 13 ||
                        event.keyCode == 9 ||
                        event.keyCode == 27)) {
                    var isGroupCard = typeof cards == "object" && cards.length > 0;
                    var isTopPeople = isGroupCard
                        ? cards[0].cardName == "TOP_PEOPLE" || cards[0].cardName == "TOP_RECORD"
                        : false;
                    if (event.keyCode == 40) {
                        if (nextElement != "menuSnoozeContainer") {
                            this.ccfScope.cardEvents.focusOnNextMenuItem(scope, nextElement, accessibilityFocusId);
                        }
                    }
                    else if (event.keyCode == 38) {
                        this.ccfScope.cardEvents.navigatePreviousMenuItemForCard(scope, prevElement, accessibilityFocusId, isGroupCard);
                    }
                    else if (event.type == "keydown" && (event.shiftKey && event.keyCode == 9)) {
                        this.ccfScope.cardEvents.navigatePreviousMenuItemForCard(scope, prevElement, accessibilityFocusId, isGroupCard);
                    }
                    else if (event.keyCode == 9) {
                        if (isGroupCard) {
                            var isLastOptionInGroupCard = (!isTopPeople && nextElement == "menuSnoozeContainer") ||
                                (isTopPeople && nextElement == "menuDismissContainer");
                            if (!isLastOptionInGroupCard) {
                                this.ccfScope.cardEvents.focusOnNextMenuItem(scope, nextElement, accessibilityFocusId);
                            }
                        }
                        else {
                            if (nextElement != "menuSnoozeContainer") {
                                this.ccfScope.cardEvents.focusOnNextMenuItem(scope, nextElement, accessibilityFocusId);
                            }
                        }
                    }
                    else if (event.keyCode == 27) {
                        scope.focusElementStr = "menuDotContainer" + accessibilityFocusId;
                        scope.menuClickedCardId = null;
                        this._context.accessibility.focusElementById(scope.focusElementStr);
                        scope.renderControl(true, scope.focusElementHandler);
                        this.ccfScope.flyoutId = -1;
                        event.preventDefault();
                        event.stopPropagation();
                        return false;
                    }
                    else if (event.keyCode == 13) {
                        this.ccfScope.menuClickedCardId = null;
                        this.ccfScope.flyoutId = -1;
                        switch (action) {
                            case "snooze": {
                                scope.cardEvents.handleSnoozeEvent(cards, event);
                                break;
                            }
                            case "dismiss": {
                                scope.cardEvents.handleDismissInMenu(cards, accessibilityFocusId, event);
                                break;
                            }
                            case "snoozeAll": {
                                scope.cardEvents.handleSnoozeAllEvent(cards, event);
                                break;
                            }
                            case "dismissAll": {
                                scope.cardEvents.handleDismissAllEvent(cards, event);
                                break;
                            }
                            case "showAll": {
                                scope.cardEvents.groupCardClickHandler(accessibilityFocusId, cards, scope);
                                break;
                            }
                        }
                    }
                    event.preventDefault();
                    event.stopPropagation();
                }
            };
            CardsEventsHandler.prototype.focusOnPreviousMenuItem = function (scope, prevElement, accessibilityFocusId) {
                scope.focusElementStr = prevElement + accessibilityFocusId;
                this._context.accessibility.focusElementById(scope.focusElementStr);
                scope.renderControl(true, scope.focusElementHandler);
            };
            CardsEventsHandler.prototype.focusOnNextMenuItem = function (scope, nextElement, accessibilityFocusId) {
                scope.focusElementStr = nextElement + accessibilityFocusId;
                this._context.accessibility.focusElementById(scope.focusElementStr);
                scope.renderControl(true, scope.focusElementHandler);
            };
            CardsEventsHandler.prototype.navigatePreviousMenuItemForCard = function (scope, prevElement, accessibilityFocusId, isGroupCard) {
                var firstMenuItem = isGroupCard ? "menuShowAllContainer" : "menuDismissContainer";
                if (prevElement != firstMenuItem) {
                    this.ccfScope.cardEvents.focusOnPreviousMenuItem(scope, prevElement, accessibilityFocusId);
                }
            };
            CardsEventsHandler.prototype.getMenuDisplay = function (cardId) {
                return this.ccfScope.state.menucards[cardId];
            };
            CardsEventsHandler.prototype.renderNextAndFocusHandler = function (scope) {
                if (scope.isNextMeeting) {
                    scope.renderControl(true, scope.renderNextMapHandler);
                }
                else {
                    scope.renderControl(true, scope.focusElementHandler);
                }
            };
            CardsEventsHandler.prototype.handleMinCardDismissInMenu = function (cardId, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("minCardList" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cardId;
                this.ccfScope.dismissClickedCardIndex = accessibilityFocusId;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.dismissCardHandler);
            };
            CardsEventsHandler.prototype.handleMinCardSnoozSwipe = function (cardId, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("minCardList" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cardId;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.snoozeCardHandler);
            };
            CardsEventsHandler.prototype.handleDismissInMenu = function (cardId, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("listItemCardContainer" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cardId;
                this.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.dismissClickedCardIndex = accessibilityFocusId;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.dismissCardHandler);
            };
            CardsEventsHandler.prototype.handleSnoozSwipe = function (cardId, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("listItemCardContainer" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cardId;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.snoozeCardHandler);
            };
            CardsEventsHandler.prototype.handleGroupDismissInMenu = function (cards, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("listItemCardContainer" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cards;
                this.ccfScope.dismissClickedCardIndex = accessibilityFocusId;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.dismissGroupCardHandler);
            };
            CardsEventsHandler.prototype.handleGroupSnoozSwipe = function (cards, accessibilityFocusId, event) {
                var listElement = document.getElementById(this._context.accessibility.getUniqueId("listItemCardContainer" + accessibilityFocusId));
                this.ccfScope.cardBoundary = listElement.getBoundingClientRect();
                this.ccfScope.dimissCardId = cards;
                event.stopPropagation();
                this.ccfScope.renderControl(true, this.ccfScope.snoozeGroupCardHandler);
            };
            CardsEventsHandler.prototype.handleDismissEvent = function (cardId, event) {
                var curSource = this.ccfScope.getRecordsArray();
                var cardIndex;
                var commands = this.ccfScope.getCommandManager().getCommandByCardId(cardId);
                var command = _.filter(commands, function (cmd) {
                    return (cmd.command == "Mscrm.HomepageGrid.actioncard.DismissCommand" ||
                        cmd.commandId == "Mscrm.HomepageGrid.actioncard.DismissCommand");
                });
                if (command && command.length > 0) {
                    if (!command[0].execute()) {
                        return;
                    }
                }
                for (var card in this.ccfScope.getRecordsArray()) {
                    if (cardId == this.ccfScope.getRecordsArray()[card].cardId)
                        cardIndex = card;
                }
                this.ccfScope.cardEvents.addTelemetryForActionOnRAActionCard(curSource[cardIndex].cardtype, command[0].commandId.substring(command[0].commandId.lastIndexOf(".") + 1));
                this.ccfScope.getRecordsArray().splice(cardIndex, 1);
                this.ccfScope.secondColumnCards = this.ccfScope.secondColumnCards.filter(function (i) { return i.cardId !== cardId; });
                if (this.ccfScope.viewType == "Group") {
                    for (var card in this.ccfScope.getGroupCards()) {
                        if (cardId == this.ccfScope.getGroupCards()[card].cardId)
                            cardIndex = card;
                    }
                    this.ccfScope.getGroupCards().splice(cardIndex, 1);
                }
                if (event) {
                    event.stopPropagation();
                }
                this.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.initialPageLoad = true;
                this.ccfScope.focusElementStr = "cardWithActionsContainer";
                this.ccfScope.dimissCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
            };
            CardsEventsHandler.prototype.handleSnoozeEvent = function (cardId, event) {
                var cardIndex;
                var curSource = this.ccfScope.getRecordsArray();
                var commands = this.ccfScope.getCommandManager().getCommandByCardId(cardId);
                var command = _.filter(commands, function (cmd) {
                    return (cmd.command == "Mscrm.HomepageGrid.actioncard.SnoozeCommand" ||
                        cmd.commandId == "Mscrm.HomepageGrid.actioncard.SnoozeCommand");
                });
                if (command && command.length > 0) {
                    if (!command[0].execute()) {
                        return;
                    }
                }
                for (var card in this.ccfScope.getRecordsArray()) {
                    if (cardId == this.ccfScope.getRecordsArray()[card].cardId)
                        cardIndex = card;
                }
                this.ccfScope.cardEvents.addTelemetryForActionOnRAActionCard(curSource[cardIndex].cardtype, command[0].commandId.substring(command[0].commandId.lastIndexOf(".") + 1));
                this.ccfScope.getRecordsArray().splice(cardIndex, 1);
                this.ccfScope.secondColumnCards = this.ccfScope.secondColumnCards.filter(function (i) { return i.cardId !== cardId; });
                if (this.ccfScope.viewType == "Group") {
                    for (var card in this.ccfScope.getGroupCards()) {
                        if (cardId == this.ccfScope.getGroupCards()[card].cardId)
                            cardIndex = card;
                    }
                    this.ccfScope.getGroupCards().splice(cardIndex, 1);
                }
                if (event) {
                    event.stopPropagation();
                }
                this.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.initialPageLoad = true;
                this.ccfScope.dimissCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.focusElementStr = "cardWithActionsContainer";
                this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
            };
            CardsEventsHandler.prototype.handleSnoozeAllEvent = function (cardsGroup, event) {
                var curSource = this.ccfScope.getRecordsArray();
                for (var _i = 0, cardsGroup_1 = cardsGroup; _i < cardsGroup_1.length; _i++) {
                    var card = cardsGroup_1[_i];
                    var cardIndex = void 0;
                    var commands = this.ccfScope.getCommandManager().getCommandByCardId(card.cardId);
                    var command = _.filter(commands, function (cmd) {
                        return (cmd.command == "Mscrm.HomepageGrid.actioncard.SnoozeCommand" ||
                            cmd.commandId == "Mscrm.HomepageGrid.actioncard.SnoozeCommand");
                    });
                    if (command && command.length > 0) {
                        if (!command[0].execute()) {
                            return;
                        }
                    }
                    for (var indCard in this.ccfScope.getRecordsArray()) {
                        if (card.cardId == this.ccfScope.getRecordsArray()[indCard].cardId)
                            cardIndex = indCard;
                    }
                    this.ccfScope.cardEvents.addTelemetryForActionOnRAActionCard(curSource[cardIndex].cardtype, command[0].commandId.substring(command[0].commandId.lastIndexOf(".") + 1));
                    this.ccfScope.getRecordsArray().splice(cardIndex, 1);
                }
                if (event) {
                    event.stopPropagation();
                }
                this.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.initialPageLoad = true;
                this.ccfScope.focusElementStr = "cardWithActionsContainer";
                this.ccfScope.dimissCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
            };
            CardsEventsHandler.prototype.handleDismissAllEvent = function (cardsGroup, event) {
                var curSource = this.ccfScope.getRecordsArray();
                for (var _i = 0, cardsGroup_2 = cardsGroup; _i < cardsGroup_2.length; _i++) {
                    var card = cardsGroup_2[_i];
                    var cardIndex = void 0;
                    var commands = this.ccfScope.getCommandManager().getCommandByCardId(card.cardId);
                    var command = _.filter(commands, function (cmd) {
                        return (cmd.command == "Mscrm.HomepageGrid.actioncard.DismissCommand" ||
                            cmd.commandId == "Mscrm.HomepageGrid.actioncard.DismissCommand");
                    });
                    if (command && command.length > 0) {
                        if (!command[0].execute()) {
                            return;
                        }
                    }
                    for (var indCard in this.ccfScope.getRecordsArray()) {
                        if (card.cardId == this.ccfScope.getRecordsArray()[indCard].cardId)
                            cardIndex = indCard;
                    }
                    this.ccfScope.cardEvents.addTelemetryForActionOnRAActionCard(curSource[cardIndex].cardtype, command[0].commandId.substring(command[0].commandId.lastIndexOf(".") + 1));
                    this.ccfScope.getRecordsArray().splice(cardIndex, 1);
                }
                this.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.initialPageLoad = true;
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                if (event) {
                    event.stopPropagation();
                }
                this.ccfScope.focusElementStr = "cardWithActionsContainer";
                this.ccfScope.dimissCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
            };
            CardsEventsHandler.prototype.handleActionClickEvent = function (card, action, buttonActionId, accessibilityFocusId, event) {
                if (event) {
                    event.stopPropagation();
                }
                var commands = this.ccfScope.getCommandManager().getCommandByCardId(card.cardId);
                var command = _.filter(commands, function (cmd) {
                    return cmd.command == action.command || cmd.commandId == action.command;
                });
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(buttonActionId) &&
                    !MscrmCommon.ControlUtils.Object.isNullOrUndefined(accessibilityFocusId)) {
                    if (parseInt(buttonActionId) >= 0 && accessibilityFocusId >= 0) {
                        var buttonClickedCardId = this._context.accessibility.getUniqueId(buttonActionId + "button" + accessibilityFocusId);
                        sessionStorage.setItem("buttonPressedId", buttonClickedCardId);
                        var selectedCard = this._context.accessibility.getUniqueId("listItemCardContainer" + accessibilityFocusId);
                        sessionStorage.setItem("selectedCard", selectedCard);
                        var buttonActionCommandId = command[0].commandId;
                        sessionStorage.setItem("buttonActionCommandId", buttonActionCommandId);
                    }
                }
                if (command && command.length > 0) {
                    var curCommand = command[0].command;
                    if (this.ccfScope.cardEvents.globalPanelCloseCards[curCommand]) {
                        this.ccfScope._context.utils.fireEvent("close", {});
                    }
                    if (!command[0].execute()) {
                        return;
                    }
                    else {
                        var autoDismisscommands = this.ccfScope.cardEvents.autoDissmissCards[card.cardtype];
                        if (autoDismisscommands.indexOf(curCommand) > -1) {
                            var cardId = card.cardId;
                            for (var card_1 in this.ccfScope.getGroupCards()) {
                                if (cardId == this.ccfScope.getGroupCards()[card_1].cardId) {
                                    this.ccfScope.getGroupCards().splice(card_1, 1);
                                    break;
                                }
                            }
                            for (var card_2 in this.ccfScope.getRecordsArray()) {
                                if (cardId == this.ccfScope.getRecordsArray()[card_2].cardId) {
                                    this.ccfScope.getRecordsArray().splice(card_2, 1);
                                    break;
                                }
                            }
                            if (this.ccfScope.viewType == "Card" || this.ccfScope.getGroupCards().length == 0) {
                                this.ccfScope.cardEvents.backToMainClickHandler();
                            }
                        }
                    }
                    this.ccfScope.cardEvents.addTelemetryForActionOnRAActionCard(card.cardtype, command[0].commandId.substring(command[0].commandId.lastIndexOf(".") + 1));
                    this.ccfScope.renderControl(true);
                }
            };
            CardsEventsHandler.prototype.handleActionKeyPress = function (card, action, buttonActionId, accessibilityFocusId, event) {
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(event)) {
                    if (event.type === "keydown" && event.keyCode == 13) {
                        if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(buttonActionId) &&
                            !MscrmCommon.ControlUtils.Object.isNullOrUndefined(accessibilityFocusId)) {
                            if (parseInt(buttonActionId) >= 0 && accessibilityFocusId >= 0) {
                                event.stopPropagation();
                                event.stopImmediatePropagation();
                                this.ccfScope.cardEvents.handleActionClickEvent(card, action, buttonActionId, accessibilityFocusId);
                            }
                        }
                        else {
                            this.ccfScope.cardEvents.handleActionClickEvent(card, action);
                        }
                        event.preventDefault();
                        return;
                    }
                }
            };
            CardsEventsHandler.prototype.swipeStartHandler = function (card, accessibilityFocusId, type, event) {
                if ((this.ccfScope.viewType != "Main" && this.ccfScope.viewType != "Group") ||
                    this.ccfScope.twoColumnLayout == true)
                    return;
                this.ccfScope.swipeStartObserver(event, card, type, accessibilityFocusId);
            };
            CardsEventsHandler.prototype.swipeEndHandler = function (card, accessibilityFocusId, type, event) {
                if ((this.ccfScope.viewType != "Main" && this.ccfScope.viewType != "Group") ||
                    this.ccfScope.twoColumnLayout == true)
                    return;
                this.ccfScope.swipeEndObserver(event, card, type, accessibilityFocusId);
            };
            CardsEventsHandler.prototype.elementMoveHandle = function (card, accessibilityFocusId, type, event) {
                if ((this.ccfScope.viewType != "Main" && this.ccfScope.viewType != "Group") ||
                    this.ccfScope.twoColumnLayout == true)
                    return;
                var reset = true;
                if (CardFeedContainer.CardFeedContainer.mouseDown) {
                    reset = false;
                    this.ccfScope.elementMove(event, card, type, accessibilityFocusId);
                }
            };
            CardsEventsHandler.prototype.resetCard = function () {
                CardFeedContainer.CardFeedContainer.mouseDown = false;
            };
            CardsEventsHandler.prototype.groupCardClickHandler = function (index, cards, scope, groupCardType) {
                if (CardFeedContainer.CardFeedContainer.mouseMoved)
                    return;
                CardFeedContainer.CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                CardFeedContainer.CardFeedContainer.cardTransition = "transform .3s linear";
                CardFeedContainer.CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                CardFeedContainer.CardFeedContainer.minCardTransition = "transform .3s linear";
                scope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.groupCardType = groupCardType;
                this.ccfScope.initialPageLoad = false;
                if (scope.twoColumnLayout == true) {
                    scope.secondColumnCards = [];
                    scope.secondColumnCards = cards;
                    scope.viewType = "Main";
                    scope.focusedElement = index;
                    scope.secondColumnCardsClicked = false;
                    if (this.ccfScope.groupCardType == "Attendees" || this.ccfScope.groupCardType == "nearby") {
                        scope.secondColumnCardsClicked = true;
                    }
                    scope.focusElementStr = "cardWithActionsContainer";
                    scope.renderControl(true, scope.focusElementHandler);
                }
                else {
                    scope.viewType = "Group";
                    scope.groupCards = cards;
                    scope.previousFocusElement = index;
                    scope.focusedElement = 0;
                    scope.focusElementStr = "cardWithActionsContainer";
                    scope.renderControl(true, scope.focusElementHandler);
                }
            };
            CardsEventsHandler.prototype.cardClickHandler = function (index, card, scope, columnPosition) {
                if (CardFeedContainer.CardFeedContainer.mouseMoved)
                    return;
                CardFeedContainer.CardFeedContainer.cardTransform = "translate3d(0px, 0px, 0px)";
                CardFeedContainer.CardFeedContainer.cardTransition = "transform .3s linear";
                CardFeedContainer.CardFeedContainer.minCardTransform = "translate3d(0px, 0px, 0px)";
                CardFeedContainer.CardFeedContainer.minCardTransition = "transform .3s linear";
                scope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                this.ccfScope.initialPageLoad = false;
                if (scope.viewType == "Group") {
                    scope.prevViewType = "Group";
                }
                else {
                    scope.prevViewType = "Main";
                }
                if (card.cardName == "TOP_PEOPLE" || card.cardName == "TOP_RECORD") {
                    var entityLogicalName = card.data.cardContextDetails[0].contextObject.entityName;
                    var entityId = card.data.cardContextDetails[0].contextObject.guid;
                    if (entityLogicalName && entityId) {
                        this._context.navigation.openForm({ entityName: entityLogicalName, entityId: entityId });
                        if (this.ccfScope.isGlobalPanelEnabled) {
                            this._context.utils.fireEvent("close", {});
                        }
                        return;
                    }
                }
                if (scope.twoColumnLayout == true) {
                    scope.secondColumnPrevCards = scope.secondColumnCards;
                    scope.secondColumnCards = [];
                    scope.secondColumnCards[0] = card;
                    scope.viewType = "Main";
                    scope.focusedElement = scope.secondColumnStartindex;
                    if (columnPosition == "SecondColumn") {
                        if (scope.prevViewType !== "Group") {
                            if (card.data && card.data.mailweblink) {
                                this._context.navigation.openUrl(card.data.mailweblink);
                                if (this.ccfScope.isGlobalPanelEnabled) {
                                    this._context.utils.fireEvent("close", {});
                                }
                                return;
                            }
                            var entityLogicalName = card.regardingobjectid.etn;
                            var entityId = card.regardingobjectid.id.guid;
                            if (entityLogicalName && entityId) {
                                this._context.navigation.openForm({ entityName: entityLogicalName, entityId: entityId });
                                if (this.ccfScope.isGlobalPanelEnabled) {
                                    this._context.utils.fireEvent("close", {});
                                }
                                return;
                            }
                        }
                        else {
                            this.ccfScope.secondColumnCardsClicked = true;
                        }
                    }
                    var promise = void 0;
                    if (card.cardName == "UPCOMING_MEETING" ||
                        card.cardName == "UPCOMING_MEETING_EXCHANGE" ||
                        card.cardName == "RECENTMEETING" ||
                        card.cardName == "AGENDA:ACTIVITY_MEETING" ||
                        card.cardName == "AGENDA:ACTIVITY_MEETING_EXCHANGE") {
                        promise = scope.dataFactories["Productivity"].generateAdditionalData(card, scope);
                        promise.then(function (data) {
                            scope.secondColumnCards[0] = card;
                            CardFeedContainer.CardFeedContainer.cardData = card;
                            scope.focusedElement = index;
                            scope.renderControl(true, scope.renderMapHandler);
                        }, function (rejectReason) {
                            console.log(rejectReason);
                        });
                    }
                    else {
                        if (card.cardName == "AGENDA:ACTIVITY_TASK" || card.cardName == "AGENDA:ACTIVITY_PHONE") {
                            promise = scope.dataFactories["Productivity"].generateAgendaAdditionalData(card, scope);
                        }
                        else {
                            promise = scope.dataFactories["Productivity"].generateGenericAdditionalData(card, scope);
                        }
                        promise.then(function (data) {
                            scope.card = card;
                            scope.secondColumnCards[0] = card;
                            CardFeedContainer.CardFeedContainer.cardData = card;
                            scope.focusedElement = index;
                            scope.renderControl(true, scope.focusElementHandler);
                        }, function (rejectReason) {
                            console.log(rejectReason);
                        });
                    }
                }
                else {
                    if (scope.viewType == "Main" || scope.viewType == "Group") {
                        var promise = void 0;
                        if (card.cardName == "UPCOMING_MEETING" ||
                            card.cardName == "UPCOMING_MEETING_EXCHANGE" ||
                            card.cardName == "RECENTMEETING" ||
                            card.cardName == "AGENDA:ACTIVITY_MEETING" ||
                            card.cardName == "AGENDA:ACTIVITY_MEETING_EXCHANGE") {
                            promise = scope.dataFactories["Productivity"].generateAdditionalData(card, scope);
                            promise.then(function (data) {
                                scope.viewType = "Card";
                                scope.card = card;
                                CardFeedContainer.CardFeedContainer.cardData = card;
                                scope.previousFocusElement = index;
                                scope.focusedElement = 0;
                                scope.renderControl(true, scope.renderMapHandler);
                            }, function (rejectReason) {
                                console.log(rejectReason);
                            });
                        }
                        else {
                            if (card.cardName == "AGENDA:ACTIVITY_TASK" || card.cardName == "AGENDA:ACTIVITY_PHONE") {
                                promise = scope.dataFactories["Productivity"].generateAgendaAdditionalData(card, scope);
                            }
                            else {
                                promise = scope.dataFactories["Productivity"].generateGenericAdditionalData(card, scope);
                            }
                            promise.then(function (data) {
                                scope.viewType = "Card";
                                scope.card = card;
                                CardFeedContainer.CardFeedContainer.cardData = card;
                                scope.previousFocusElement = index;
                                scope.focusedElement = 0;
                                scope.renderControl(true, scope.focusElementHandler);
                            }, function (rejectReason) {
                                console.log(rejectReason);
                            });
                        }
                    }
                    else if (scope.viewType == "Card") {
                        if (card.data && card.data.mailweblink) {
                            this._context.navigation.openUrl(card.data.mailweblink);
                            if (this.ccfScope.isGlobalPanelEnabled) {
                                this._context.utils.fireEvent("close", {});
                            }
                            return;
                        }
                        var entityLogicalName = card.regardingobjectid.etn;
                        var entityId = card.regardingobjectid.id.guid;
                        if (entityLogicalName && entityId) {
                            this._context.navigation.openForm({ entityName: entityLogicalName, entityId: entityId });
                            if (this.ccfScope.isGlobalPanelEnabled) {
                                this._context.utils.fireEvent("close", {});
                            }
                            return;
                        }
                    }
                }
            };
            CardsEventsHandler.prototype.backToMainClickHandler = function () {
                this.ccfScope.flyoutId = -1;
                this.ccfScope.menuClickedCardId = null;
                CardFeedContainer.CardFeedContainer.nmrendered = false;
                if (this.ccfScope.twoColumnLayout == true) {
                    this.ccfScope.secondColumnCards = this.ccfScope.secondColumnPrevCards;
                    this.ccfScope.viewType = "Main";
                    this.ccfScope.focusedElement = 0;
                    this.ccfScope.secondColumnCardsClicked = false;
                    this.ccfScope.focusElementStr = "cardWithActionsContainer";
                    this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                }
                else {
                    if (this.ccfScope.groupCardType == "Attendees" || this.ccfScope.groupCardType == "nearby") {
                        this.ccfScope.viewType = "Card";
                        this.ccfScope.groupCardType = "";
                    }
                    else {
                        this.ccfScope.viewType = this.ccfScope.prevViewType || "Main";
                    }
                    this.ccfScope.focusedElement = this.ccfScope.previousFocusElement;
                    this.ccfScope.prevViewType = "Main";
                    this.ccfScope.previousFocusElement = 0;
                    this.ccfScope.focusElementStr = "cardWithActionsContainer";
                    if (this.ccfScope.isNextMeeting) {
                        this.ccfScope.renderControl(true, this.ccfScope.renderNextMapHandler);
                    }
                    else {
                        this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                    }
                }
            };
            CardsEventsHandler.prototype.pushrenderedElements = function (index, scope) {
                scope.renderedElements.push(index);
            };
            CardsEventsHandler.prototype.isfocusedElement = function (index) {
                return index === this.ccfScope.focusedElement;
            };
            CardsEventsHandler.prototype.navigateKeyHandler = function (index, type, card, scope, columnPosition, event) {
                if (event.type === "keydown" &&
                    (event.keyCode == 40 ||
                        event.keyCode == 38 ||
                        event.keyCode == 13)) {
                    scope.initialPageLoad = false;
                    if (event.keyCode == 40) {
                        scope.focusElementStr = "cardWithActionsContainer";
                        scope.focusedElement = index < scope.renderedElements.length - 1 ? index + 1 : 0;
                        scope.renderControl(true, scope.focusElementHandler);
                    }
                    else if (event.keyCode == 38) {
                        scope.focusElementStr = "cardWithActionsContainer";
                        scope.focusedElement = index == 0 ? scope.renderedElements.length - 1 : index - 1;
                        scope.renderControl(true, scope.focusElementHandler);
                    }
                    else if (event.keyCode == 13) {
                        if (type == "card") {
                            if (event.target.id.indexOf("newsItemLink") > -1 ||
                                event.target.id.indexOf("stockItemLink") > -1)
                                event.target.click();
                            else
                                scope.cardEvents.cardClickHandler(index, card, scope, columnPosition);
                        }
                        else if (type == "group") {
                            scope.cardEvents.groupCardClickHandler(index, card, scope);
                        }
                        else if (type == "back") {
                            scope.cardEvents.backToMainClickHandler();
                        }
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    return;
                }
                if (event.type === "keydown" && event.shiftKey && event.keyCode == 9) {
                    var x = event.target;
                    if (this.ccfScope.isGlobalPanelEnabled && x.id.indexOf("cardWithActionsContainer") > 0) {
                        if (scope.focusedElement === 0)
                            this._context.accessibility.focusElementById("closeIconContainer");
                        else {
                            scope.focusElementStr = "cardWithActionsContainer";
                            scope.focusedElement = 0;
                            this._context.accessibility.focusElementById(scope.focusElementStr + scope.focusedElement);
                        }
                        event.preventDefault();
                        event.stopPropagation();
                        return false;
                    }
                }
                else if (type == "back" && event.type === "keydown" && event.keyCode == 9) {
                    scope.focusElementStr = "cardWithActionsContainer";
                    scope.focusedElement = scope.focusedElement || 1;
                    this._context.accessibility.focusElementById(scope.focusElementStr + scope.focusedElement);
                    this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                    event.preventDefault();
                    event.stopPropagation();
                    return false;
                }
            };
            CardsEventsHandler.prototype.getDeviceName = function () {
                var deviceName = "";
                var ccfContext = this._context;
                if (ccfContext != null &&
                    ccfContext != undefined &&
                    ccfContext.client != null &&
                    ccfContext.client != undefined) {
                    if (ccfContext.client.userAgent != null && ccfContext.client.userAgent != undefined) {
                        var userAgent = ccfContext.client.userAgent;
                        if (userAgent.isWin) {
                            deviceName = "Windows";
                        }
                        else if (userAgent.isAndroidModern || userAgent.isAndroid) {
                            deviceName = "Android";
                        }
                        else if (userAgent.isIos) {
                            deviceName = "iOS";
                        }
                    }
                }
                return deviceName;
            };
            CardsEventsHandler.prototype.addTelemetryForActionOnRAActionCard = function (cardtype, command) {
                var params = this._context.parameters;
                var entryPoint = params != null &&
                    params != undefined &&
                    params.Location != undefined &&
                    params.Location != null &&
                    params.Location.raw != undefined &&
                    params.Location.raw != null
                    ? params.Location.raw
                    : "0";
                var isUCI = true;
                var actionOnRelationshipAssistantCard = new ActionOnRelationshipAssistantCard(cardtype, command, entryPoint, "TBD", isUCI, this.getDeviceName());
                this._context.reporting.reportEvent(actionOnRelationshipAssistantCard);
            };
            CardsEventsHandler.prototype.IsKTGExchangeCard = function (cardType) {
                switch (cardType) {
                    case 1:
                    case 2:
                    case 3:
                    case 22:
                    case 23:
                    case 35:
                        return true;
                    default:
                        return false;
                }
            };
            CardsEventsHandler.prototype.undoDismissHandler = function () {
                clearTimeout(this.ccfScope.dismissTimerId);
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                this.ccfScope.renderControl(true);
            };
            CardsEventsHandler.prototype.undoSnoozeHandler = function () {
                clearTimeout(this.ccfScope.dismissTimerId);
                CardFeedContainer.CardFeedContainer.swipingCardId = null;
                this.ccfScope.dismissClickedCardIndex = null;
                this.ccfScope.renderControl(true);
            };
            CardsEventsHandler.prototype.negativeFeedbackHandler = function (accessibilityFocusId, card) {
                clearTimeout(this.ccfScope.dismissTimerId);
                if (this.ccfScope.cardEvents.IsKTGExchangeCard(card.cardtype)) {
                    this.ccfScope.dismissNegativeClickedIndex = accessibilityFocusId;
                    this.ccfScope.focusElementStr = "closeIcon";
                    this.ccfScope.renderControl(true, this.ccfScope.focusElementHandler);
                }
                else {
                    this.ccfScope.cardEvents.handleDismissFeedbackHandler(card, this.ccfScope.reasonForCardDismissList[0]);
                }
            };
            CardsEventsHandler.prototype.handleDismissFeedbackHandler = function (card, reason) {
                clearTimeout(this.ccfScope.dismissTimerId);
                var that = this;
                that.ccfScope.cardEvents.addTelemetryForCardDismiss(card, reason, true);
                that.ccfScope.dimissCardId = card.cardId;
                that.ccfScope.dismissClickedCardIndex = null;
                that.ccfScope.dismissNegativeClickedIndex = null;
                that.ccfScope.menuClickedCardId = null;
                this.ccfScope.flyoutId = -1;
                that.ccfScope.cardEvents.handleDismissEvent(that.ccfScope.dimissCardId);
                that.ccfScope.renderControl(true);
            };
            CardsEventsHandler.prototype.addTelemetryForCardDismiss = function (card, reason, response) {
                var cardDismissEvent = new ActionCardFeedback(card.cardtype, response, reason);
                this._context.reporting.reportEvent(cardDismissEvent);
            };
            CardsEventsHandler.prototype.convertRemToPixels = function (rem, element) {
                return rem * parseFloat(getComputedStyle(element).fontSize);
            };
            CardsEventsHandler.prototype.showElipsis = function (cardId) {
                var descElement = document.getElementById(this._context.accessibility.getUniqueId("cardDescription" + cardId));
                if (descElement != null) {
                    var rem = parseFloat(this._context.theming.measures.measure450);
                    var remToPx = this.convertRemToPixels(rem, descElement);
                    if (descElement.scrollHeight > remToPx) {
                        return true;
                    }
                }
                else {
                    return false;
                }
                return false;
            };
            CardsEventsHandler.prototype.closeIconClickHandler = function (event) {
                this._context.utils.fireEvent("close", {});
                document.getElementById("cardFeedContainerLauncher").focus();
                event.stopPropagation();
                return;
            };
            CardsEventsHandler.prototype.closeIconKeyPressHandler = function (scope, event) {
                if (event.type === "keydown") {
                    if (event.keyCode == 13) {
                        this._context.utils.fireEvent("close", {});
                        document.getElementById("cardFeedContainerLauncher").focus();
                        event.stopPropagation();
                        return;
                    }
                    else if (event.keyCode == 9) {
                        scope.focusElementStr = "cardWithActionsContainer";
                        this._context.accessibility.focusElementById(scope.focusElementStr + "0");
                        event.preventDefault();
                        event.stopPropagation();
                        return false;
                    }
                }
            };
            CardsEventsHandler.prototype.letsGetStartedHandler = function () {
                this.ccfScope.isGetStartedClicked = true;
                this.ccfScope.renderControl(true, this.ccfScope.fetchAllCardsHandler);
            };
            CardsEventsHandler.prototype.letsGetStartedKeyPressHandler = function (event) {
                if (event.type === "keydown") {
                    if (event.keyCode == 13) {
                        this.ccfScope.isGetStartedClicked = true;
                        this.ccfScope.renderControl(true, this.ccfScope.fetchAllCardsHandler);
                        event.stopPropagation();
                    }
                }
            };
            return CardsEventsHandler;
        }());
        CardFeedContainer.CardsEventsHandler = CardsEventsHandler;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var GenericCardControl = (function () {
            function GenericCardControl(context, ccfScope) {
                this.isMouseDown = false;
                this._context = context;
                this.ccfScope = ccfScope;
            }
            GenericCardControl.prototype.backToMainElement = function (accessibilityFocusId, softTitle) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var backButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "backButtonIcon" + accessibilityFocusId,
                    key: "backButtonIcon" + accessibilityFocusId,
                    style: {
                        margin: "0 auto",
                        fontSize: this._context.theming.measures.measure100,
                        color: this._context.theming.colors.grays.gray07,
                    },
                    type: 56,
                });
                var backButton = this._context.factory.createElement("BUTTON", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    autoFocus: true,
                    tabIndex: 0,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "back", null, this.ccfScope, null),
                    accessibilityLabel: this._context.resources.getString("ActionCard.RelationshipAssistance.BackButton_Label"),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        border: "none",
                        cursor: "pointer",
                        marginLeft: this._context.theming.measures.measure015,
                        marginTop: this._context.theming.measures.measure015,
                    },
                    onClick: this.ccfScope.cardEvents.backToMainClickHandler.bind(this),
                }, backButtonIcon);
                var backButtonContainer = this._context.factory.createElement("CONTAINER", {
                    key: "backButtonContainer",
                    id: "backButtonContainer",
                }, backButton);
                if (softTitle) {
                    var backButtonTitle = this._context.factory.createElement("LABEL", {
                        key: "backButtonTitle",
                        id: "backButtonTitle",
                        style: {
                            fontFamily: this._context.theming.fontfamilies.bold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                            maxWidth: "calc(100% - 1rem)",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            display: "block",
                            whiteSpace: "nowrap",
                        },
                    }, softTitle.split(":")[0]);
                    var backButtonTitleContainer = this._context.factory.createElement("CONTAINER", {
                        key: "backButtonTitleContainer",
                        id: "backButtonTitleContainer",
                        style: {
                            marginLeft: this._context.theming.measures.measure025,
                            width: "100%",
                            overflow: "hidden",
                            display: "block",
                        },
                    }, backButtonTitle);
                    return this._context.factory.createElement("CONTAINER", {
                        key: "backToMainContainer",
                        id: "backToMainContainer",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            width: "100%",
                            paddingBottom: this._context.theming.measures.measure050,
                        },
                    }, [backButtonContainer, backButtonTitleContainer]);
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "backToMainContainer",
                    id: "backToMainContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                    },
                }, backButtonContainer);
            };
            GenericCardControl.prototype.renderCardView = function (card, accessibilityFocusId, columnPosition) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var formatedTitle;
                if (card.softTitle.indexOf(":") != -1) {
                    var titleArray = card.softTitle.split(":");
                    if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                        formatedTitle = titleArray[1];
                    }
                    else {
                        formatedTitle = card.softTitle;
                    }
                }
                else {
                    formatedTitle = card.softTitle;
                }
                if (card.data) {
                    formatedTitle = card.data.cardRelatedInfo
                        ? CardFeedContainer.Utils.softTitleGenerator(formatedTitle, card.data.cardRelatedInfo.starttime, this._context)
                        : formatedTitle;
                }
                var cardTitleLabel = card.title ? card.title : CardFeedContainer.Utils.getReferenceTokenDataTitle(card, this._context);
                var cardTitleDescription = formatedTitle + " " + cardTitleLabel;
                var cardDescriptionLabel = card.description
                    ? card.description
                    : CardFeedContainer.Utils.getReferenceTokenDataDescription(card, this._context);
                var icon = CardFeedContainer.CardUtils.defaultCardIcon(card.cardName);
                var cardIcon;
                if (card.cardtype > 10000 && icon === 363 && card.icon != undefined) {
                    cardIcon = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "entityImage" + card,
                        id: "entityImage" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                            height: "100%",
                        },
                        hasPrimaryImageField: true,
                        mode: 0,
                        imageSrc: card["icon"],
                        entityPrimaryField: card.softTitle,
                    });
                }
                else {
                    cardIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "imginfo_id" + card.cardId,
                        key: "imginfo_key" + card.cardId,
                        style: {
                            margin: "0 auto",
                            fontSize: "large",
                        },
                        type: icon,
                    });
                }
                var iconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + card.cardId,
                    key: "cardIcon" + card.cardId,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure015,
                        fontSize: this._context.theming.measures.measure100,
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#e2e2e2",
                        display: "block",
                    },
                }, cardIcon);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + card.cardId,
                    key: "iconContainer" + card.cardId,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                    },
                }, iconContainer);
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + card.cardId,
                    id: "cardDueTitle" + card.cardId,
                    title: formatedTitle,
                    tabIndex: 0,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(card.cardName),
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        maxWidth: "calc(100% - 1rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, formatedTitle);
                var cardTitle = this._context.factory.createElement("LABEL", {
                    key: "cardTitle" + card.cardId,
                    id: "cardTitle" + card.cardId,
                    title: cardTitleLabel,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        maxWidth: "calc(100% - 1rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, cardTitleLabel);
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + card.cardId,
                    id: "cardTitleDescriptionId" + card.cardId,
                    accessibilityLabel: cardTitleDescription,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + card.cardId,
                    id: "cardDescription" + card.cardId,
                    title: cardDescriptionLabel,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray07,
                        lineHeight: this._context.theming.measures.measure150,
                        maxHeight: this._context.theming.measures.measure450,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        position: "relative",
                        wordBreak: "break-word",
                        display: "block",
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                    },
                }, cardDescriptionLabel);
                var descriptionElipsis = this._context.factory.createElement("LABEL", {
                    key: "descriptionElipsis" + card.cardId,
                    id: "descriptionElipsis" + card.cardId,
                    style: {
                        display: this.ccfScope.cardEvents.showElipsis(card.cardId) ? "block" : "none",
                        position: "absolute",
                        right: "0",
                        bottom: "0",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, "...");
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                        position: "relative",
                        width: "100%",
                        overflow: "hidden",
                    },
                }, [cardDueTitle, cardTitle, cardDescription, descriptionElipsis, cardTitleDescriptionId]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + card.cardId,
                    id: "cardLabelsMainContainer" + card.cardId,
                    style: {
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        display: "block",
                        width: "calc(100% - 4rem)",
                        overflow: "hidden",
                    },
                }, cardLabelsContainer);
                var buttonContainer = this._context.factory.createElement("CONTAINER", {
                    key: "buttonContainer" + card.cardId,
                    id: "buttonContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray01,
                        whiteSpace: "normal",
                        display: "block",
                        height: this._context.theming.measures.measure250,
                        boxSizing: "border-box",
                    },
                }, this.getButtonContainer(card, accessibilityFocusId));
                var cardDetailsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardDetailsContainer" + card.cardId,
                    id: "cardDetailsContainer" + card.cardId,
                    style: {
                        justifyContent: "space-between",
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingBottom: this._context.theming.measures.measure075,
                        whiteSpace: "normal",
                    },
                }, [cardIconContainer, cardLabelsMainContainer, this.renderMenuForCardView(card, accessibilityFocusId)]);
                var cardWithActionsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cardTitleDescription),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) &&
                        this.ccfScope.dismissClickedCardIndex != accessibilityFocusId
                        ? 0
                        : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, columnPosition),
                    autoFocus: true,
                    style: {
                        whiteSpace: "normal",
                        flexDirection: "column",
                        width: "100%",
                    },
                }, [cardDetailsContainer, buttonContainer]);
                var cardContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsMainContainer" + card.cardId,
                    id: "cardWithActionsMainContainer" + card.cardId,
                    onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, card, this.ccfScope, columnPosition),
                    onPointerDown: this.ccfScope.cardEvents.swipeStartHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerUp: this.ccfScope.cardEvents.swipeEndHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerMove: this.ccfScope.cardEvents.elementMoveHandle.bind(this, card, accessibilityFocusId, "card"),
                    onPointerLeave: this.ccfScope.cardEvents.resetCard.bind(this),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        boxSizing: "border-box",
                        position: "relative",
                        width: "100%",
                    },
                }, cardWithActionsContainer);
                var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "swipeContentContainer" + card.cardId,
                    id: "swipeContentContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.rendersnoozeContainer(card, accessibilityFocusId, "card"),
                    cardContainer,
                    this.renderdismissContainer(card, accessibilityFocusId, "card"),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "flex",
                        marginBottom: "0.5rem",
                        transform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        webkitTransform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        transition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                        WebkitTransition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                        boxSizing: "border-box",
                        width: "100%",
                    },
                }, swipeContentContainer);
            };
            GenericCardControl.prototype.getButtonContainer = function (card, accessibilityFocusId) {
                var cardActions = this.ccfScope.getActionData();
                var commands = this.ccfScope.getActionCommands(card);
                var actions;
                if (commands && commands.length > 0) {
                    actions = this.ccfScope.retrieveActionData(card);
                }
                var buttonsArray = [];
                for (var action in actions) {
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: action + "descriptionContainer" + accessibilityFocusId,
                        id: action + "descriptionContainer" + accessibilityFocusId,
                        style: this.getStyleForItem("descriptionContainer"),
                        tabIndex: -1,
                    }, this._context.resources.getString("ActionCard.CFC.Common.ButtonPressText") + " " + actions[action].label);
                    var buttonClose = this._context.factory.createElement("BUTTON", {
                        key: action + "button" + accessibilityFocusId,
                        id: action + "button" + accessibilityFocusId,
                        title: actions[action].label,
                        describedByElementId: this._context.accessibility.getUniqueId(action + "descriptionContainer" + accessibilityFocusId),
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                        autoFocus: true,
                        style: {
                            border: "none",
                            display: "block",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            backgroundColor: this._context.theming.colors.grays.gray01,
                            color: this._context.theming.colors.grays.gray07,
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                            paddingLeft: this._context.theming.measures.measure100,
                            paddingRight: this._context.theming.measures.measure100,
                            textAlign: "left",
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            width: "100%",
                            textOverflow: "ellipsis",
                            cursor: "pointer",
                        },
                        onClick: this.ccfScope.cardEvents.handleActionClickEvent.bind(this, card, actions[action], action, accessibilityFocusId),
                        onKeyDown: this.ccfScope.cardEvents.handleActionKeyPress.bind(this, card, actions[action], action, accessibilityFocusId),
                    }, actions[action].label);
                    var buttonContainer = this._context.factory.createElement("CONTAINER", {
                        key: card.cardId + "buttonContainer" + action,
                        id: card.cardId + "buttonContainer" + action,
                        style: {
                            display: "inline-block",
                            maxWidth: "calc(50% - 1rem)",
                            marginLeft: this._context.theming.measures.measure015,
                            cursor: "pointer",
                        },
                    }, [buttonClose, descriptionContainer]);
                    buttonsArray.push(buttonContainer);
                }
                return buttonsArray;
            };
            GenericCardControl.prototype.renderGroupCardView = function (index, cards, accessibilityFocusId) {
                var groupContainer = [];
                var firstThreeCards = [];
                if (cards.length > 3) {
                    firstThreeCards = cards.slice(0, 3);
                }
                else {
                    firstThreeCards = cards;
                }
                var groupTitleLabel = cards[0].softTitle;
                var individualCardTitleLabel;
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + index,
                    key: "imginfo_key" + index,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: 84,
                });
                var groupIcon = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + index,
                    key: "iconContainer" + index,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        fontSize: this._context.theming.measures.measure100,
                        float: "left",
                        overflow: "hidden",
                        color: this._context.theming.colors.base.black,
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: this._context.theming.colors.grays.gray01,
                    },
                }, imginfoControl);
                var groupIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "groupIcon" + index,
                    key: "groupIcon" + index,
                    accessibilityHidden: true,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                        paddingRight: this._context.theming.measures.measure075,
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                    },
                }, groupIcon);
                var groupTitlePlusIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitlePlusIcon" + index,
                    key: "groupTitlePlusIcon" + index,
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: "0.65rem",
                        paddingRight: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 198,
                });
                if (cards.length <= 3) {
                    groupTitlePlusIcon = null;
                }
                var groupTitleRightArrowIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitleRightArrowIcon" + index,
                    key: "groupTitleRightArrowIcon" + index,
                    tabIndex: 0,
                    role: "button",
                    accessibilityLabel: this.ccfScope._context.resources.getString("ActionCard.GroupCardView.ShowMore_AccessibilityText"),
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 62,
                });
                var static3Label = this._context.factory.createElement("LABEL", {
                    key: "static3Label" + index,
                    id: "static3Label" + index,
                    style: {
                        color: this._context.theming.colors.grays.gray05,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, "3");
                var groupcount = this._context.factory.createElement("CONTAINER", {
                    key: "groupcount" + index,
                    id: "groupcount" + index,
                    style: {
                        fontSize: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, [static3Label, groupTitlePlusIcon, groupTitleRightArrowIcon]);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitle" + index,
                    id: "groupTitle" + index,
                    tabIndex: 0,
                    title: groupTitleLabel,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(firstThreeCards[0].cardName),
                        lineHeight: this._context.theming.measures.measure150,
                        maxWidth: "calc(100% - 7rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, groupTitleLabel);
                var groupTitleContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitleContainer" + index,
                    id: "groupTitleContainer" + index,
                    style: {
                        display: "flex",
                    },
                }, [groupTitle, groupcount]);
                var groupTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "groupTitleDescriptionId" + index,
                    id: "groupTitleDescriptionId" + index,
                    accessibilityLabel: groupTitleLabel,
                    style: {
                        display: "none",
                    },
                }, "");
                var groupSummary = this._context.factory.createElement("LABEL", {
                    key: "groupSummaryTitle" + index,
                    id: "groupSummaryTitle" + index,
                    title: cards[0].summaryText,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure015,
                        cursor: "pointer",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                }, cards[0].summaryText);
                var groupLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsContainer" + index,
                    id: "groupLabelsContainer" + index,
                    style: {
                        display: "block",
                    },
                }, [groupTitleContainer, groupSummary, groupTitleDescriptionId]);
                var groupLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsMainContainer" + index,
                    id: "groupLabelsMainContainer" + index,
                    style: {
                        flexDirection: "column",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        width: "100%",
                        maxWidth: "calc(100% - 5.75rem)",
                    },
                }, groupLabelsContainer);
                var groupHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupHeaderContainer" + index,
                    id: "groupHeaderContainer" + index,
                    style: {
                        justifyContent: "space-between",
                        whiteSpace: "normal",
                        width: "100%",
                    },
                }, [groupIconContainer, groupLabelsMainContainer]);
                var groupsHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupsHeaderContainer" + index,
                    id: "groupsHeaderContainer" + index,
                    onPointerDown: this.ccfScope.cardEvents.swipeStartHandler.bind(this, cards, accessibilityFocusId, "group"),
                    onPointerUp: this.ccfScope.cardEvents.swipeEndHandler.bind(this, cards, accessibilityFocusId, "group"),
                    onPointerMove: this.ccfScope.cardEvents.elementMoveHandle.bind(this, cards, accessibilityFocusId, "group"),
                    onPointerLeave: this.ccfScope.cardEvents.resetCard.bind(this),
                    onClick: this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, cards, this.ccfScope),
                    style: {
                        justifyContent: "space-between",
                        whiteSpace: "normal",
                        cursor: "pointer",
                    },
                }, groupHeaderContainer);
                for (var card in firstThreeCards) {
                    individualCardTitleLabel = cards[card].title
                        ? cards[card].title
                        : CardFeedContainer.Utils.getReferenceTokenDataTitle(cards[card], this._context);
                    var cardTitleContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardTitleContainer" + card,
                        id: "cardTitleContainer" + card,
                        title: individualCardTitleLabel,
                        tabIndex: 0,
                        onPointerDown: this.ccfScope.cardEvents.swipeStartHandler.bind(this, firstThreeCards[card], card + String(accessibilityFocusId), "mincard"),
                        onPointerUp: this.ccfScope.cardEvents.swipeEndHandler.bind(this, firstThreeCards[card], card + String(accessibilityFocusId), "mincard"),
                        onPointerMove: this.ccfScope.cardEvents.elementMoveHandle.bind(this, firstThreeCards[card], card + String(accessibilityFocusId), "mincard"),
                        onPointerLeave: this.ccfScope.cardEvents.resetCard.bind(this),
                        style: {
                            borderTop: this._context.theming.borders.border02,
                            paddingTop: this._context.theming.measures.measure050,
                            marginBottom: this._context.theming.measures.measure050,
                            marginLeft: this._context.theming.measures.measure100,
                            marginRight: this._context.theming.measures.measure100,
                            position: "relative",
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                            lineHeight: this._context.theming.measures.measure150,
                            maxHeight: this._context.theming.measures.measure150,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            wordBreak: "break-word",
                            whiteSpace: "initial",
                            wordWrap: "break-word",
                            textDecoration: "none",
                        },
                        onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, firstThreeCards[card], this.ccfScope),
                    }, individualCardTitleLabel);
                    var groupCardsListContainer = this._context.factory.createElement("CONTAINER", {
                        key: "groupCardsListContainer" + index,
                        id: "groupCardsListContainer" + index,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [
                        this.rendersnoozeContainer(cards[card], accessibilityFocusId, "mincard"),
                        cardTitleContainer,
                        this.renderdismissContainer(cards[card], accessibilityFocusId, "mincard"),
                    ]);
                    var temp = CardFeedContainer.CardFeedContainer.swipingCardId + "" == card + "" + accessibilityFocusId
                        ? CardFeedContainer.CardFeedContainer.minCardTransform
                        : "translate3d(0px, 0px, 0px)";
                    var cardTitle = this._context.factory.createElement("LISTITEM", {
                        key: "minCardList" + card + accessibilityFocusId,
                        id: "minCardList" + card + accessibilityFocusId,
                        accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), groupTitleLabel + " " + individualCardTitleLabel),
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: -1,
                        autoFocus: true,
                        onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", cards[card], this.ccfScope, null),
                        style: {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            display: "block",
                            transform: String(this.ccfScope.dismissClickedCardIndex) == card + String(accessibilityFocusId) &&
                                "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                                : String(CardFeedContainer.CardFeedContainer.swipingCardId) == card + String(accessibilityFocusId) &&
                                    "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType
                                    ? CardFeedContainer.CardFeedContainer.minCardTransform
                                    : "translate3d(0px, 0px, 0px)",
                            webkitTransform: String(this.ccfScope.dismissClickedCardIndex) == card + String(accessibilityFocusId) &&
                                "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                                : String(CardFeedContainer.CardFeedContainer.swipingCardId) == card + String(accessibilityFocusId) &&
                                    "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType
                                    ? CardFeedContainer.CardFeedContainer.minCardTransform
                                    : "translate3d(0px, 0px, 0px)",
                            transition: String(CardFeedContainer.CardFeedContainer.swipingCardId) ==
                                card + String(accessibilityFocusId && "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType)
                                ? CardFeedContainer.CardFeedContainer.minCardTransition
                                : "transform 0s ease-out",
                            WebkitTransition: String(CardFeedContainer.CardFeedContainer.swipingCardId) ==
                                card + String(accessibilityFocusId && "mincard" == CardFeedContainer.CardFeedContainer.swipeCardType)
                                ? CardFeedContainer.CardFeedContainer.minCardTransition
                                : "transform 0s ease-out",
                            transformStyle: "preserve-3d",
                            width: "100%",
                        },
                    }, groupCardsListContainer);
                    groupContainer.push(cardTitle);
                }
                var groupCardsContainer = this._context.factory.createElement("LIST", {
                    key: "groupCardsContainer" + index,
                    id: "groupCardsContainer" + index,
                    style: {
                        display: "block",
                        justifyContent: "space-between",
                        paddingTop: this._context.theming.measures.measure075,
                        paddingBottom: this._context.theming.measures.measure050,
                        whiteSpace: "normal",
                        listStyleType: "disc",
                    },
                }, groupContainer);
                var groupCardsContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupCardsContentContainer" + index,
                    id: "groupCardsContentContainer" + index,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                    },
                }, [
                    groupsHeaderContainer,
                    this.renderMenuForGroupCardView(index, accessibilityFocusId, cards),
                    groupCardsContainer,
                ]);
                var groupCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cards[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "group", cards, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                        width: "100%",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.renderGroupsnoozeContainer(index, accessibilityFocusId),
                    groupCardsContentContainer,
                    this.renderGroupdismissContainer(index, accessibilityFocusId),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #ccc",
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId &&
                            "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.groupCardTransform
                                : "translate3d(0px, 0px, 0px)",
                        webkitTransform: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId &&
                            "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.groupCardTransform
                                : "translate3d(0px, 0px, 0px)",
                        transition: CardFeedContainer.CardFeedContainer.cardTransition == accessibilityFocusId && "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.groupCardTransition
                            : "transform 0s ease-out",
                        WebkitTransition: CardFeedContainer.CardFeedContainer.cardTransition == accessibilityFocusId && "group" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.groupCardTransition
                            : "transform 0s ease-out",
                        transformStyle: "preserve-3d",
                        width: "calc(100 % - 2px)",
                        cursor: "pointer",
                    },
                }, groupCardsMainContainer);
            };
            GenericCardControl.prototype.renderMenuForCardView = function (card, accessibilityFocusId) {
                var snoozeLabel = this._context.resources.getString("ActionCard.CFC.Common.Snooze");
                var dismissLabel = this._context.resources.getString("ActionCard.CFC.Common.Dismiss");
                if (this.ccfScope.viewType == "Card") {
                    return null;
                }
                var symbolContainer = this._context.factory.createElement("CONTAINER", {
                    className: "symbolFont More-symbol",
                    style: this.getStyleForItem("symbolContainer"),
                });
                var symbolWrapper = this._context.factory.createElement("CONTAINER", {
                    style: this.getStyleForItem("symbolWrapper"),
                }, symbolContainer);
                var menuDotContainer = this._context.factory.createElement("BUTTON", {
                    key: "menuDotContainer" + accessibilityFocusId,
                    id: "menuDotContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    type: "button",
                    onKeyDown: this.ccfScope.cardEvents.menuKeyPressHandler.bind(this, accessibilityFocusId),
                    onClick: this.ccfScope.cardEvents.menuClickHandler.bind(this, accessibilityFocusId),
                    onBlur: this.ccfScope.cardEvents.menuSelection.bind(this, accessibilityFocusId === this.ccfScope.menuClickedCardId),
                    tabIndex: -1,
                    style: this.getStyleForItem("menuDotContainer"),
                }, symbolWrapper);
                if (accessibilityFocusId === this.ccfScope.menuClickedCardId) {
                    var menuSnoozeIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "menuSnoozeIcon" + card.cardId,
                        key: "menuSnoozeIcon" + card.cardId,
                        style: this.getStyleForItem("menuIcon"),
                        type: 181,
                    });
                    var menuSnoozeLabel = this._context.factory.createElement("LABEL", {
                        key: "menuSnoozeLabel" + card.cardId,
                        id: "menuSnoozeLabel" + card.cardId,
                        style: this.getStyleForItem("menuLabel"),
                    }, snoozeLabel);
                    var menuSnoozeContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuSnoozeContainer" + accessibilityFocusId,
                        id: "menuSnoozeContainer" + accessibilityFocusId,
                        title: snoozeLabel,
                        accessibilityLabel: snoozeLabel,
                        role: "menuitem",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemContainer"),
                        onClick: this.ccfScope.cardEvents.handleSnoozeEvent.bind(this, card.cardId),
                        onKeyDown: this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, card.cardId, accessibilityFocusId, "menuDismissContainer", "menuDismissContainer", "snooze", card.cardId, this.ccfScope),
                    }, [menuSnoozeIcon, menuSnoozeLabel]);
                    var menuDismissIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "menuDismissIcon" + card.cardId,
                        key: "menuDismissIcon" + card.cardId,
                        style: this.getStyleForItem("menuIcon"),
                        type: 181,
                    });
                    var menuDismissLabel = this._context.factory.createElement("LABEL", {
                        key: "menuDismissLabel" + card.cardId,
                        id: "menuDismissLabel" + card.cardId,
                        style: this.getStyleForItem("menuLabel"),
                    }, dismissLabel);
                    var menuDismissContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuDismissContainer" + accessibilityFocusId,
                        id: "menuDismissContainer" + accessibilityFocusId,
                        title: dismissLabel,
                        accessibilityLabel: dismissLabel,
                        role: "menuitem",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemContainer"),
                        onClick: this.ccfScope.cardEvents.handleDismissInMenu.bind(this, card.cardId, accessibilityFocusId),
                        onKeyDown: this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, card.cardId, accessibilityFocusId, "menuSnoozeContainer", "menuSnoozeContainer", "dismiss", card.cardId, this.ccfScope),
                    }, [menuDismissIcon, menuDismissLabel]);
                    var menuItemsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuItemsContainer" + card.cardId,
                        id: "menuItemsContainer" + card.cardId,
                        role: "menu",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemsContainer"),
                    }, [menuSnoozeContainer, menuDismissContainer]);
                    var menuFlyoutWrapper = this.getFlyoutForMenu(this._context.client.isRTL, "menuSnoozeContainer" + accessibilityFocusId, "menuDotContainer" + accessibilityFocusId, this.dismissFlyout.bind(this, "menuDotContainer" + accessibilityFocusId), menuItemsContainer);
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: "flyoutButton_ariaDescription",
                        id: "flyoutButton_ariaDescription",
                        tabIndex: -1,
                        style: this.getStyleForItem("descriptionContainer"),
                    }, this._context.resources.getString("RI_CARDS_MENU_ARIADESCRIPTION"));
                    var menuContainer = this._context.factory.createElement("LISTITEM", {
                        key: "menuContainer" + card.cardId,
                        id: "menuContainer" + card.cardId,
                        tabIndex: 0,
                        onKeyDown: this.ccfScope.cardEvents.menuKeyPressHandler.bind(this, accessibilityFocusId),
                        title: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityLabel: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityHasPopup: true,
                        role: "menuitem",
                        describedByElementId: this._context.accessibility.getUniqueId("flyoutButton_ariaDescription"),
                        autoFocus: true,
                        style: this.getStyleForItem("menuContainer"),
                    }, [menuDotContainer, descriptionContainer]);
                    return this._context.factory.createElement("LIST", {
                        key: "menuWrapperContainer" + card.cardId,
                        id: "menuWrapperContainer" + card.cardId,
                        style: this.getStyleForItem("menuParentContainer"),
                    }, [menuContainer, menuFlyoutWrapper]);
                }
                else {
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: "flyoutButton_ariaDescription",
                        id: "flyoutButton_ariaDescription",
                        tabIndex: -1,
                        style: this.getStyleForItem("descriptionContainer"),
                    }, this._context.resources.getString("RI_CARDS_MENU_ARIADESCRIPTION"));
                    var menuContainer = this._context.factory.createElement("LISTITEM", {
                        key: "menuContainer" + card.cardId,
                        id: "menuContainer" + card.cardId,
                        title: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityLabel: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityHasPopup: true,
                        role: "menuitem",
                        tabIndex: 0,
                        onKeyDown: this.ccfScope.cardEvents.menuKeyPressHandler.bind(this, accessibilityFocusId),
                        describedByElementId: this._context.accessibility.getUniqueId("flyoutButton_ariaDescription"),
                        autoFocus: true,
                        style: this.getStyleForItem("menuContainer"),
                    }, [menuDotContainer, descriptionContainer]);
                    return this._context.factory.createElement("LIST", {
                        key: "menuWrapperContainer" + card.cardId,
                        id: "menuWrapperContainer" + card.cardId,
                        accessibilityLabel: this._context.resources.getString("RI_CARDS_MENU_LIST"),
                        role: "menubar",
                        style: this.getStyleForItem("menuParentContainer"),
                    }, menuContainer);
                }
            };
            GenericCardControl.prototype.getFlyoutForMenu = function (isRTL, focusElement, relativeToElement, outsideClickCB, childElement) {
                return this._context.factory.createElement("FLYOUT", {
                    id: "cardsMenuFlyout",
                    key: "cardsMenuFlyout",
                    flyoutDirection: isRTL ? 3 : 7,
                    enforceDirection: isRTL ? true : false,
                    tabIndex: 0,
                    autoFocus: true,
                    focusElementId: focusElement,
                    positionType: "relative",
                    relativeToElementId: relativeToElement,
                    onOutsideClick: outsideClickCB,
                    flyoutStyle: this.getStyleForItem("FLYOUT"),
                }, childElement);
            };
            GenericCardControl.prototype.getStyleForItem = function (type) {
                switch (type.toLowerCase()) {
                    case "menudotcontainer":
                        return {
                            lineHeight: "1rem",
                            height: "1rem",
                            borderWidths: "0",
                            padding: "0px",
                            cursor: "pointer",
                            alignItems: "center",
                            border: "none",
                            ":hover": {
                                backgroundColor: this._context.theming.colors.grays.gray03,
                            },
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            right: 0,
                        };
                    case "menuicon":
                        return {
                            backgroundColor: "transparent",
                            fontSize: "small",
                            paddingRight: this._context.theming.measures.measure050,
                            paddingLeft: this._context.theming.measures.measure100,
                        };
                    case "menulabel":
                        return {
                            backgroundColor: "transparent",
                            cursor: "pointer",
                            paddingRight: this._context.theming.measures.measure100,
                            whiteSpace: "normal",
                        };
                    case "menuitemcontainer":
                        return {
                            ":hover": {
                                backgroundColor: this._context.theming.colors.grays.gray03,
                            },
                            whiteSpace: "normal",
                            lineHeight: this._context.theming.measures.measure200,
                        };
                    case "menuitemscontainer":
                        return {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            fontFamily: this._context.theming.fontfamilies.regular,
                            color: this._context.theming.colors.base.black,
                            right: 0,
                            zIndex: "5",
                            display: "block",
                            marginBottom: this._context.theming.measures.measure050,
                            marginTop: this._context.theming.measures.measure050,
                        };
                    case "menuparentcontainer":
                        return {
                            width: "16px",
                            height: "16px",
                            margin: "0",
                            listStyleType: "none",
                            right: this._context.theming.measures.measure100,
                            position: "absolute",
                            top: "10px",
                        };
                    case "flyout":
                        return {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            cursor: "pointer",
                            display: "block",
                            border: this._context.theming.borders.border01,
                            boxShadow: "0px 2px 4px 0px rgba(0, 0, 0, 0.5);",
                            overflowY: "hidden",
                            overflowX: "hidden",
                        };
                    case "descriptioncontainer":
                        return {
                            display: "none",
                        };
                    case "menucontainer":
                        return {
                            width: "16px",
                            height: "16px",
                            margin: "0",
                            lineHeight: "1rem",
                        };
                    case "symbolwrapper":
                        return {
                            flexGrow: "1",
                            display: "flex",
                            textAlign: "left",
                        };
                    case "symbolcontainer":
                        return {
                            lineHeight: "1.5rem",
                            height: "16px",
                            color: "#333333",
                            width: "16px",
                        };
                    default:
                        return {};
                }
            };
            GenericCardControl.prototype.renderMenuForGroupCardView = function (index, accessibilityFocusId, cards) {
                if (this.ccfScope.viewType != "Main") {
                    return null;
                }
                var snoozeAllLabel = this._context.resources.getString("ActionCard.CFC.Menu.SnoozeAll");
                var dismissAllLabel = this._context.resources.getString("ActionCard.CFC.Menu.DismissAll");
                var showAllLabel = this._context.resources.getString("ActionCard.CFC.Menu.ShowAllCards");
                var topPeople = false;
                var menuItemsContainerElems = [];
                if (cards[0].cardName == "TOP_PEOPLE" || cards[0].cardName == "TOP_RECORD") {
                    topPeople = true;
                }
                var symbolContainer = this._context.factory.createElement("CONTAINER", {
                    className: "symbolFont More-symbol",
                    style: this.getStyleForItem("symbolContainer"),
                });
                var symbolWrapper = this._context.factory.createElement("CONTAINER", {
                    style: this.getStyleForItem("symbolWrapper"),
                }, symbolContainer);
                var menuDotContainer = this._context.factory.createElement("BUTTON", {
                    key: "menuDotContainer" + accessibilityFocusId,
                    id: "menuDotContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    type: "button",
                    onClick: this.ccfScope.cardEvents.menuClickHandler.bind(this, accessibilityFocusId),
                    onBlur: this.ccfScope.cardEvents.menuSelection.bind(this, accessibilityFocusId === this.ccfScope.menuClickedCardId),
                    tabIndex: -1,
                    style: this.getStyleForItem("menuDotContainer"),
                }, symbolWrapper);
                if (accessibilityFocusId === this.ccfScope.menuClickedCardId) {
                    var menuSnoozeIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "menuSnoozeIcon" + index,
                        key: "menuSnoozeIcon" + index,
                        style: this.getStyleForItem("menuIcon"),
                        type: 181,
                    });
                    var menuSnoozeLabel = this._context.factory.createElement("LABEL", {
                        key: "menuSnoozeLabel" + index,
                        id: "menuSnoozeLabel" + index,
                        style: this.getStyleForItem("menuLabel"),
                        onClick: this.ccfScope.cardEvents.handleSnoozeAllEvent.bind(this, cards),
                    }, snoozeAllLabel);
                    var menuSnoozeContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuSnoozeContainer" + accessibilityFocusId,
                        id: "menuSnoozeContainer" + accessibilityFocusId,
                        title: snoozeAllLabel,
                        accessibilityLabel: snoozeAllLabel,
                        role: "menuitem",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemContainer"),
                        onClick: this.ccfScope.cardEvents.handleSnoozeAllEvent.bind(this, cards),
                        onKeyDown: topPeople
                            ? this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, index, accessibilityFocusId, "menuDismissContainer", "menuDismissContainer", "snoozeAll", cards, this.ccfScope)
                            : this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, index, accessibilityFocusId, "menuShowAllContainer", "menuDismissContainer", "snoozeAll", cards, this.ccfScope),
                    }, [menuSnoozeIcon, menuSnoozeLabel]);
                    var menuDismissIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "menuDismissIcon" + index,
                        key: "menuDismissIcon" + index,
                        style: this.getStyleForItem("menuIcon"),
                        type: 181,
                    });
                    var menuDismissLabel = this._context.factory.createElement("LABEL", {
                        key: "menuDismissLabel" + index,
                        id: "menuDismissLabel" + index,
                        style: this.getStyleForItem("menuLabel"),
                    }, dismissAllLabel);
                    var menuDismissContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuDismissContainer" + accessibilityFocusId,
                        id: "menuDismissContainer" + accessibilityFocusId,
                        title: dismissAllLabel,
                        accessibilityLabel: dismissAllLabel,
                        role: "menuitem",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemContainer"),
                        onClick: this.ccfScope.cardEvents.handleDismissAllEvent.bind(this, cards),
                        onKeyDown: topPeople
                            ? this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, index, accessibilityFocusId, "menuSnoozeContainer", "menuSnoozeContainer", "dismissAll", cards, this.ccfScope)
                            : this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, index, accessibilityFocusId, "menuSnoozeContainer", "menuShowAllContainer", "dismissAll", cards, this.ccfScope),
                    }, [menuDismissIcon, menuDismissLabel]);
                    var menuShowAllIcon = this._context.factory.createElement("MICROSOFTICON", {
                        id: "menuShowAllIcon" + index,
                        key: "menuShowAllIcon" + index,
                        style: this.getStyleForItem("menuIcon"),
                        type: 181,
                    });
                    var menuShowAllLabel = this._context.factory.createElement("LABEL", {
                        key: "menuShowAllLabel" + index,
                        id: "menuShowAllLabel" + index,
                        style: this.getStyleForItem("menuLabel"),
                    }, showAllLabel);
                    var menuShowAllContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuShowAllContainer" + accessibilityFocusId,
                        id: "menuShowAllContainer" + accessibilityFocusId,
                        title: showAllLabel,
                        accessibilityLabel: showAllLabel,
                        role: "menuitem",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemContainer"),
                        onClick: this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, cards, this.ccfScope),
                        onKeyDown: this.ccfScope.cardEvents.menuItemKeyPressHandler.bind(this, index, accessibilityFocusId, "menuDismissContainer", "menuSnoozeContainer", "showAll", cards, this.ccfScope),
                    }, [menuShowAllIcon, menuShowAllLabel]);
                    if (topPeople) {
                        menuItemsContainerElems = [menuSnoozeContainer, menuDismissContainer];
                    }
                    else {
                        menuItemsContainerElems = [menuSnoozeContainer, menuDismissContainer, menuShowAllContainer];
                    }
                    var menuItemsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "menuItemsContainer" + index,
                        id: "menuItemsContainer" + index,
                        role: "menu",
                        tabIndex: 0,
                        style: this.getStyleForItem("menuItemsContainer"),
                    }, menuItemsContainerElems);
                    var _this = this;
                    var menuFlyoutWrapper = this.getFlyoutForMenu(this._context.client.isRTL, "menuSnoozeContainer" + accessibilityFocusId, "menuDotContainer" + accessibilityFocusId, this.dismissFlyout.bind(this, "menuDotContainer" + accessibilityFocusId), menuItemsContainer);
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: "flyoutButton_ariaDescription",
                        id: "flyoutButton_ariaDescription",
                        tabIndex: -1,
                        style: this.getStyleForItem("descriptionContainer"),
                    }, this._context.resources.getString("RI_CARDS_MENU_ARIADESCRIPTION"));
                    var menuContainer = this._context.factory.createElement("LISTITEM", {
                        key: "menuContainer" + accessibilityFocusId,
                        id: "menuContainer" + accessibilityFocusId,
                        tabIndex: 0,
                        onKeyDown: this.ccfScope.cardEvents.menuKeyPressHandler.bind(this, accessibilityFocusId),
                        title: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityLabel: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityHasPopup: true,
                        role: "menuitem",
                        autoFocus: true,
                        describedByElementId: this._context.accessibility.getUniqueId("flyoutButton_ariaDescription"),
                        style: this.getStyleForItem("menuContainer"),
                    }, [menuDotContainer, descriptionContainer]);
                    return this._context.factory.createElement("LIST", {
                        key: "menuWrapperContainer" + index,
                        id: "menuWrapperContainer" + index,
                        accessibilityLabel: this._context.resources.getString("RI_CARDS_MENU_LIST"),
                        role: "menubar",
                        style: this.getStyleForItem("menuParentContainer"),
                    }, [menuContainer, menuFlyoutWrapper]);
                }
                else {
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: "flyoutButton_ariaDescription",
                        id: "flyoutButton_ariaDescription",
                        tabIndex: -1,
                        style: this.getStyleForItem("descriptionContainer"),
                    }, this._context.resources.getString("RI_CARDS_MENU_ARIADESCRIPTION"));
                    var menuContainer = this._context.factory.createElement("LISTITEM", {
                        key: "menuContainer" + accessibilityFocusId,
                        id: "menuContainer" + accessibilityFocusId,
                        tabIndex: 0,
                        onKeyDown: this.ccfScope.cardEvents.menuKeyPressHandler.bind(this, accessibilityFocusId),
                        title: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityLabel: this.ccfScope._context.resources.getString("RI_CARDS_MENU_LISTITEM"),
                        accessibilityHasPopup: true,
                        role: "menuitem",
                        autoFocus: true,
                        describedByElementId: this._context.accessibility.getUniqueId("flyoutButton_ariaDescription"),
                        style: this.getStyleForItem("menuContainer"),
                    }, [menuDotContainer, descriptionContainer]);
                    return this._context.factory.createElement("LIST", {
                        key: "menuWrapperContainer" + accessibilityFocusId,
                        id: "menuWrapperContainer" + accessibilityFocusId,
                        accessibilityLabel: this._context.resources.getString("RI_CARDS_MENU_LIST"),
                        role: "menubar",
                        style: this.getStyleForItem("menuParentContainer"),
                    }, menuContainer);
                }
            };
            GenericCardControl.prototype.dismissFlyout = function (focusElementId) {
                this.ccfScope.focusElementStr = focusElementId;
                this.ccfScope.menuClickedCardId = null;
                this._context.accessibility.focusElementById(this.ccfScope.focusElementStr + this.ccfScope.focusedElement);
                this.ccfScope.cardEvents.renderNextAndFocusHandler(this.ccfScope);
                var that = this;
                setTimeout(function () {
                    that.ccfScope.flyoutId = -1;
                }, 100);
            };
            GenericCardControl.prototype.rendersnoozeContainer = function (card, accessibilityFocusId, type) {
                var snoozedString = "";
                if (card.cardtype === 36 || card.cardtype === 108) {
                    snoozedString = this._context.resources.getString("ActionCard.CFC.Common.Snooze5m");
                }
                else if (card.cardtype === 109 || card.cardtype === 21 || card.cardtype === 37) {
                    snoozedString = this._context.resources.getString("ActionCard.CFC.Common.Snooze15m");
                }
                else {
                    snoozedString = this._context.resources.getString("ActionCard.CFC.Common.Snooze12h");
                }
                var undoButtonLabel = this._context.resources.getString("ActionCard.CFC.Common.Undo");
                var undoButtonAccessibilityLabel = this._context.resources.getString("ActionCard.CFC.Common.UndoCardSnooze");
                if (this.ccfScope.viewType == "Card") {
                    return null;
                }
                var snoozedLabel = this._context.factory.createElement("LABEL", {
                    key: "snoozedLabel" + accessibilityFocusId,
                    id: "snoozedLabel" + accessibilityFocusId,
                    accessibilityHidden: true,
                }, snoozedString);
                var snoozedLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozedLabelContainer" + accessibilityFocusId,
                    id: "snoozedLabelContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    style: {
                        paddingBottom: type == "mincard" ? "" : this._context.theming.measures.measure100,
                        float: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "right" : "",
                        color: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "#315FA2" : this._context.theming.colors.grays.gray05,
                        position: type == "mincard" ? "absolute" : "",
                        right: type == "mincard" ? this._context.theming.measures.measure200 : "",
                    },
                }, snoozedLabel);
                var undoButton = this._context.factory.createElement("BUTTON", {
                    key: "snoozedUndoButton" + accessibilityFocusId,
                    id: "snoozedUndoButton" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    accessibilityLabel: undoButtonAccessibilityLabel,
                    onClick: this.ccfScope.cardEvents.undoSnoozeHandler.bind(this),
                    accessibilityHidden: true,
                    style: {
                        border: "none",
                        color: this._context.theming.colors.linkcolor.normal.text,
                        textAlign: "left",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        background: "initial",
                    },
                }, undoButtonLabel);
                var undoLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "undoLabelContainer" + accessibilityFocusId,
                    id: "undoLabelContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    style: {
                        paddingBottom: type == "mincard" ? "" : this._context.theming.measures.measure100,
                        float: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "right" : "",
                        color: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "#315FA2" : this._context.theming.colors.grays.gray05,
                    },
                }, undoButton);
                var snoozedTextContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozedTextContainer" + accessibilityFocusId,
                    id: "snoozedTextContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    style: {
                        paddingRight: this._context.theming.measures.measure150,
                        paddingLeft: this._context.theming.measures.measure150,
                        display: "block",
                        width: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "100%" : "",
                    },
                }, [snoozedLabelContainer, undoLabelContainer]);
                var snoozedMinCardTextContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozedMinCardTextContainer" + accessibilityFocusId,
                    id: "snoozedMinCardTextContainer" + accessibilityFocusId,
                    accessibilityHidden: true,
                    style: {
                        paddingRight: this._context.theming.measures.measure150,
                        paddingLeft: this._context.theming.measures.measure150,
                        display: "flex",
                        width: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "100%" : "",
                    },
                }, [undoButton, snoozedLabelContainer]);
                var snoozeLeftContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozeLeftContainer" + card.cardId,
                    id: "snoozeLeftContainer" + card.cardId,
                    accessibilityHidden: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        height: "100%",
                        width: "100%",
                        transform: "translateX(-100.5%)",
                        background: "#D8D8D8",
                        display: "flex",
                        color: "#315FA2",
                        position: "absolute",
                        alignItems: "center",
                    },
                }, [type == "mincard" ? snoozedMinCardTextContainer : snoozedTextContainer]);
                return snoozeLeftContainer;
            };
            GenericCardControl.prototype.renderdismissContainer = function (card, accessibilityFocusId, type) {
                if (this.ccfScope.viewType == "Card") {
                    return null;
                }
                if (this.ccfScope.dismissNegativeClickedIndex == accessibilityFocusId) {
                    return this.renderDismissFeedbackOptionsContainer(card, accessibilityFocusId, type);
                }
                else {
                    return this.renderDismissIsUsefulContainer(card, accessibilityFocusId, type);
                }
            };
            GenericCardControl.prototype.renderDismissIsUsefulContainer = function (card, accessibilityFocusId, type) {
                var dismissedString = this._context.resources.getString("ActionCard.CFC.Common.Dismissed");
                var undoButtonLabel = this._context.resources.getString("ActionCard.CFC.Common.Undo");
                var undoButtonAccessibilityLabel = this._context.resources.getString("ActionCard.CFC.Common.UndoCardDismiss");
                undoButtonAccessibilityLabel = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.CFC.Common.UndoCardDismiss"), (parseInt(sessionStorage.getItem("cachedtoasttimeoutmillis")) / 1000).toString());
                var dismissedLabel = this._context.factory.createElement("LABEL", {
                    key: "dismissedLabel" + accessibilityFocusId,
                    id: "dismissedLabel" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                }, dismissedString);
                var dismissedLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissedLabelContainer" + accessibilityFocusId,
                    id: "dismissedLabelContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                        color: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "#BF0900" : this._context.theming.colors.grays.gray05,
                    },
                }, dismissedLabel);
                var undoButton = this._context.factory.createElement("BUTTON", {
                    key: "undoButton" + accessibilityFocusId,
                    id: "undoButton" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    accessibilityLabel: undoButtonAccessibilityLabel,
                    onClick: this.ccfScope.cardEvents.undoDismissHandler.bind(this),
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        border: "none",
                        color: this._context.theming.colors.linkcolor.normal.text,
                        textAlign: "left",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        background: "initial",
                    },
                }, undoButtonLabel);
                var dismissedTextContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissedTextContainer" + accessibilityFocusId,
                    id: "dismissedTextContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        paddingRight: this._context.theming.measures.measure150,
                        display: "block",
                        width: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "100%" : "",
                    },
                }, [type == "mincard" ? "" : dismissedLabelContainer, undoButton]);
                var negativeFeedbackLabel = this._context.factory.createElement("BUTTON", {
                    key: "negativefeedback" + accessibilityFocusId,
                    id: "negativefeedback" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    onClick: this.ccfScope.cardEvents.negativeFeedbackHandler.bind(this, accessibilityFocusId, card),
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        border: "none",
                        color: "#BF0900",
                        textAlign: "right",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: "0",
                        background: "initial",
                    },
                }, this._context.resources.getString("ActionCard.CFC.Common.No"));
                var negativeFeedbackIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "negativeFeedbackIcon" + accessibilityFocusId,
                    key: "negativeFeedbackIcon" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        margin: "0 auto",
                        fontSize: "medium",
                        color: this._context.theming.colors.statuscolor.alert2.fill,
                    },
                    type: 180,
                });
                var negativeFeedbackLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "negativeFeedbackLabelContainer" + accessibilityFocusId,
                    id: "negativeFeedbackLabelContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        color: this._context.theming.colors.statuscolor.alert2.fill,
                        textAlign: "right",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, [negativeFeedbackIcon, negativeFeedbackLabel]);
                var positiveFeedbackLabel = this._context.factory.createElement("BUTTON", {
                    key: "positiveFeedbackLabel" + accessibilityFocusId,
                    id: "positiveFeedbackLabel" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    onClick: this.ccfScope.cardEvents.handleDismissFeedbackHandler.bind(this, card, this.ccfScope.reasonForCardDismissList[0]),
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        border: "none",
                        color: "#1C6512",
                        textAlign: "right",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        background: "initial",
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: "0",
                    },
                }, this._context.resources.getString("ActionCard.CFC.Common.Yes"));
                var positiveFeedbackIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "positiveFeedbackIcon" + accessibilityFocusId,
                    key: "positiveFeedbackIcon" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        margin: "0 auto",
                        fontSize: "medium",
                        color: this._context.theming.colors.statuscolor.positive1.fill,
                    },
                    type: 182,
                });
                var positiveFeedbackLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "positiveFeedbackLabelContainer" + accessibilityFocusId,
                    id: "positiveFeedbackLabelContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        color: this._context.theming.colors.statuscolor.positive2.fill,
                        textAlign: "right",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingRight: this._context.theming.measures.measure150,
                    },
                }, [positiveFeedbackIcon, positiveFeedbackLabel]);
                var feedbackString = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackString" + accessibilityFocusId,
                    id: "feedbackString" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    tabIndex: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? 0 : -1,
                    title: this._context.resources.getString("ActionCard.CFC.Common.FeedbackString"),
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                    },
                }, this._context.resources.getString("ActionCard.CFC.Common.FeedbackString"));
                var feedbackUsefulstring = this._context.factory.createElement("LABEL", {
                    key: "feedbackUsefulstring" + accessibilityFocusId,
                    id: "feedbackUsefulstring" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                }, this._context.resources.getString("ActionCard.CFC.Common.FeedbackString-short"));
                var feedbackUsefulstringCont = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackUsefulstringCont" + accessibilityFocusId,
                    id: "feedbackUsefulstringCont" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                    },
                }, feedbackUsefulstring);
                var feedbackResponses = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackResponses" + accessibilityFocusId,
                    id: "feedbackResponses" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                        paddingLeft: type == "mincard" ? this._context.theming.measures.measure200 : "",
                    },
                }, [positiveFeedbackLabelContainer, negativeFeedbackLabelContainer]);
                var feedbackDiv = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackDiv" + accessibilityFocusId,
                    id: "feedbackDiv" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        display: type == "mincard" ? "flex" : "block",
                    },
                }, [type == "mincard" ? feedbackUsefulstringCont : feedbackString, feedbackResponses]);
                var feedbackContainer = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackContainer" + accessibilityFocusId,
                    id: "feedbackContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        position: "absolute",
                        right: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure150,
                        paddingRight: this._context.theming.measures.measure050,
                        top: "50%",
                        transform: "translateY(-50%)",
                    },
                }, feedbackDiv);
                var dismissRightContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissRightContainer" + accessibilityFocusId,
                    id: "dismissRightContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissClickedCardIndex == accessibilityFocusId ? false : true,
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray01,
                        whiteSpace: "normal",
                        height: "100%",
                        width: "100%",
                        transform: "translateX(100.6%)",
                        display: "flex",
                        position: "absolute",
                        right: "0",
                        top: "0",
                        alignItems: "center",
                        boxSizing: "border-box",
                        paddingLeft: this._context.theming.measures.measure150,
                        paddingRight: this._context.theming.measures.measure150,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray05,
                    },
                }, [dismissedTextContainer, feedbackContainer]);
                return dismissRightContainer;
            };
            GenericCardControl.prototype.renderDismissFeedbackOptionsContainer = function (card, accessibilityFocusId, type) {
                var askFeedbackLabel = this._context.resources.getString("ActionCard.CFC.Common.AskForFeedback");
                var closeIconLabel = this._context.resources.getString("ActionCard.CFC.Common.Close");
                var feedbackOptionsDiv = [];
                var feedbackOptions = [
                    this._context.resources.getString("ActionCard.CFC.Common.IncorrectEmail"),
                    this._context.resources.getString("ActionCard.CFC.Common.ReasonAlreadyProvided"),
                    this._context.resources.getString("ActionCard.CFC.Common.IncorrectRequest"),
                    this._context.resources.getString("ActionCard.CFC.Common.OtherReasons"),
                ];
                var optionsContainer = [];
                var askFeedbackContainer = this._context.factory.createElement("CONTAINER", {
                    key: "askFeedbackContainer" + accessibilityFocusId,
                    id: "askFeedbackContainer" + accessibilityFocusId,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray05,
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, askFeedbackLabel);
                var closeIcon = this._context.factory.createElement("MICROSOFTICON", {
                    key: "closeIcon" + accessibilityFocusId,
                    id: "closeIcon" + accessibilityFocusId,
                    onClick: this.ccfScope.cardEvents.handleDismissFeedbackHandler.bind(this, card, this.ccfScope.reasonForCardDismissList[0]),
                    accessibilityLabel: closeIconLabel,
                    focus: this.ccfScope.dismissNegativeClickedIndex == accessibilityFocusId ? true : false,
                    tabIndex: this.ccfScope.dismissNegativeClickedIndex == accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    style: {
                        margin: "0",
                        fontSize: this._context.theming.measures.measure100,
                        position: "absolute",
                        top: this._context.theming.measures.measure100,
                        right: this._context.theming.measures.measure150,
                    },
                    type: 97,
                });
                for (var option = 0; option < feedbackOptions.length; option++) {
                    var radioIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: "radioIcon" + accessibilityFocusId,
                        id: "radioIcon" + accessibilityFocusId,
                        style: {
                            margin: "0",
                            fontSize: "medium",
                            paddingRight: this._context.theming.measures.measure050,
                        },
                        type: 296,
                    });
                    var feedbackOption = this._context.factory.createElement("CONTAINER", {
                        key: "feedbackOption" + accessibilityFocusId + option,
                        id: "feedbackOption" + accessibilityFocusId + option,
                        onClick: this.ccfScope.cardEvents.handleDismissFeedbackHandler.bind(this, card, this.ccfScope.reasonForCardDismissList[option + 1]),
                        style: {
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            color: this._context.theming.colors.grays.gray07,
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                            alignItems: "center",
                        },
                    }, [radioIcon, feedbackOptions[option]]);
                    optionsContainer.push(feedbackOption);
                }
                var feedbackOptionsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "feedbackOptionsContainer" + accessibilityFocusId,
                    id: "feedbackOptionsContainer" + accessibilityFocusId,
                }, optionsContainer);
                var dismissFeedbackContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissFeedbackContainer" + accessibilityFocusId,
                    id: "dismissFeedbackContainer" + accessibilityFocusId,
                    style: {
                        display: "block",
                        width: "100%",
                        height: "auto",
                    },
                }, [askFeedbackContainer, closeIcon, feedbackOptionsContainer]);
                var dismissRightContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissRightContainer" + accessibilityFocusId,
                    id: "dismissRightContainer" + accessibilityFocusId,
                    accessibilityHidden: this.ccfScope.dismissNegativeClickedIndex == accessibilityFocusId ? false : true,
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray01,
                        whiteSpace: "normal",
                        height: "100%",
                        width: "100%",
                        transform: "translateX(100.6%)",
                        display: "flex",
                        position: "absolute",
                        right: "0",
                        top: "0",
                        alignItems: "center",
                        boxSizing: "border-box",
                        paddingLeft: this._context.theming.measures.measure150,
                        paddingRight: this._context.theming.measures.measure150,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingBottom: this._context.theming.measures.measure100,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray05,
                    },
                }, dismissFeedbackContainer);
                return dismissRightContainer;
            };
            GenericCardControl.prototype.renderGroupsnoozeContainer = function (index, accessibilityFocusId) {
                var snoozedString = this._context.resources.getString("ActionCard.CFC.Common.Snooze12h");
                var undoButtonLabel = this._context.resources.getString("ActionCard.CFC.Common.Undo");
                var undoButtonAccessibilityLabel = this._context.resources.getString("ActionCard.CFC.Common.UndoCardSnooze");
                var snoozed = this._context.resources.getString("ActionCard.CFC.Common.Snoozed");
                if (this.ccfScope.viewType != "Main") {
                    return null;
                }
                var snoozedGroupLabel = this._context.factory.createElement("LABEL", {
                    key: "snoozedGroupLabel" + accessibilityFocusId,
                    id: "snoozedGroupLabel" + accessibilityFocusId,
                }, CardFeedContainer.CardFeedContainer.moveBelow30Per ? snoozedString : snoozed);
                var snoozedGroupLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozedGroupLabelContainer" + accessibilityFocusId,
                    id: "snoozedGroupLabelContainer" + accessibilityFocusId,
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                        float: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "right" : "",
                        color: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "#315FA2" : this._context.theming.colors.grays.gray05,
                    },
                }, snoozedGroupLabel);
                var undoButton = this._context.factory.createElement("BUTTON", {
                    key: "snoozedGroupUndoButton" + accessibilityFocusId,
                    id: "snoozedGroupUndoButton" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    accessibilityLabel: undoButtonAccessibilityLabel,
                    onClick: this.ccfScope.cardEvents.undoDismissHandler.bind(this),
                    style: {
                        border: "none",
                        color: this._context.theming.colors.linkcolor.normal.text,
                        textAlign: "left",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        background: "initial",
                    },
                }, undoButtonLabel);
                var snoozedGroupTextContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozedGroupTextContainer" + accessibilityFocusId,
                    id: "snoozedGroupTextContainer" + accessibilityFocusId,
                    style: {
                        padding: this._context.theming.measures.measure100,
                        display: "block",
                        width: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "100%" : "",
                    },
                }, [snoozedGroupLabelContainer, undoButton]);
                var snoozeLeftContainer = this._context.factory.createElement("CONTAINER", {
                    key: "snoozeLeftContainer" + index,
                    id: "snoozeLeftContainer" + index,
                    accessibilityHidden: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        height: "100%",
                        width: "100%",
                        transform: "translateX(-100.5%)",
                        background: "#D8D8D8",
                        zIndex: "5",
                        display: "flex",
                        color: "#315FA2",
                        position: "absolute",
                        alignItems: "center",
                    },
                }, [snoozedGroupTextContainer]);
                return snoozeLeftContainer;
            };
            GenericCardControl.prototype.renderGroupdismissContainer = function (index, accessibilityFocusId) {
                var dismissedString = this._context.resources.getString("ActionCard.CFC.Common.Dismissed");
                var undoButtonLabel = this._context.resources.getString("ActionCard.CFC.Common.Undo");
                var undoButtonAccessibilityLabel = this._context.resources.getString("ActionCard.CFC.Common.UndoCardDismiss");
                undoButtonAccessibilityLabel = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.CFC.Common.UndoCardDismiss"), (parseInt(sessionStorage.getItem("cachedtoasttimeoutmillis")) / 1000).toString());
                if (this.ccfScope.viewType != "Main") {
                    return null;
                }
                var dismissedGroupLabel = this._context.factory.createElement("LABEL", {
                    key: "dismissedGroupLabel" + accessibilityFocusId,
                    id: "dismissedGroupLabel" + accessibilityFocusId,
                }, dismissedString);
                var dismissedGroupLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissedGroupLabelContainer" + accessibilityFocusId,
                    id: "dismissedGroupLabelContainer" + accessibilityFocusId,
                    style: {
                        paddingBottom: this._context.theming.measures.measure100,
                        color: CardFeedContainer.CardFeedContainer.moveBelow30Per ? "#BF0900" : this._context.theming.colors.grays.gray05,
                    },
                }, dismissedGroupLabel);
                var undoButton = this._context.factory.createElement("BUTTON", {
                    key: "undoButtonGroup" + accessibilityFocusId,
                    id: "undoButtonGroup" + accessibilityFocusId,
                    tabIndex: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    accessibilityLabel: undoButtonAccessibilityLabel,
                    onClick: this.ccfScope.cardEvents.undoDismissHandler.bind(this),
                    style: {
                        border: "none",
                        color: this._context.theming.colors.linkcolor.normal.text,
                        textAlign: "left",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        background: "initial",
                    },
                }, undoButtonLabel);
                var dismissedGroupTextContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissedGroupTextContainer" + accessibilityFocusId,
                    id: "dismissedGroupTextContainer" + accessibilityFocusId,
                    style: {
                        padding: this._context.theming.measures.measure100,
                        display: "block",
                    },
                }, [dismissedGroupLabelContainer, undoButton]);
                var dismissRightContainer = this._context.factory.createElement("CONTAINER", {
                    key: "dismissRightContainer" + index,
                    id: "dismissRightContainer" + index,
                    accessibilityHidden: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        height: "100%",
                        width: "100%",
                        transform: "translateX(100.6%)",
                        background: "#D8D8D8",
                        display: "flex",
                        color: "#315FA2",
                        position: "absolute",
                        right: "0",
                        top: "0",
                        alignItems: "center",
                    },
                }, [dismissedGroupTextContainer]);
                return dismissRightContainer;
            };
            return GenericCardControl;
        }());
        CardFeedContainer.GenericCardControl = GenericCardControl;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var Utils;
        (function (Utils) {
            function getCardName(data) {
                switch (data.cardtype) {
                    case 6:
                    case 36: {
                        return "RECENTMEETING";
                    }
                    case 26:
                    case 27: {
                        return "EMAILREMINDER";
                    }
                    case 100:
                    case 108: {
                        return "UPCOMING_MEETING";
                    }
                    default: {
                        return data.cardName;
                    }
                }
            }
            Utils.getCardName = getCardName;
            function groupData(dataSource) {
                var groupedData = _.groupBy(dataSource, function (data) {
                    if (data.cardName.indexOf(":") != -1) {
                        var cardTypeArray = data.cardName.split(":");
                        if (cardTypeArray.length > 0) {
                            if (cardTypeArray[0] != undefined && cardTypeArray[0] != "" && cardTypeArray[0].length > 0)
                                return cardTypeArray[0];
                            else
                                return data.cardName;
                        }
                        else {
                            return data.cardName;
                        }
                    }
                    else
                        return Utils.getCardName(data);
                });
                return groupedData;
            }
            Utils.groupData = groupData;
            function getReferenceTokenDataTitle(cardData, context) {
                if (typeof cardData.referencetokens == "string") {
                    cardData.referencetokens = JSON.parse(cardData.referencetokens);
                }
                if (cardData.referencetokens && cardData.referencetokens.Tokens) {
                    var tokens = cardData.referencetokens.Tokens;
                    var value = "";
                    var title = "";
                    if (tokens.title) {
                        value = context.resources.getString(tokens.title.ResourceId);
                        if (tokens.title.ResourceId != value || cardData.title == undefined || cardData.title == null) {
                            var paramsNameValues = [];
                            if (tokens.title.Params && tokens.title.Params.length > 0) {
                                paramsNameValues = tokens.title.Params.map(function (param) {
                                    if (param.Name) {
                                        return param.Name;
                                    }
                                });
                            }
                            if (paramsNameValues && paramsNameValues.length > 0) {
                                if (paramsNameValues && paramsNameValues.length > 1) {
                                    return (title = CardFeedContainer.CardUtils.formatStringArray(value, paramsNameValues));
                                }
                                else {
                                    return (title = MscrmCommon.ControlUtils.String.Format(value, paramsNameValues));
                                }
                            }
                        }
                    }
                }
            }
            Utils.getReferenceTokenDataTitle = getReferenceTokenDataTitle;
            function getReferenceTokenDataDescription(cardData, context) {
                if (typeof cardData.referencetokens == "string") {
                    cardData.referencetokens = JSON.parse(cardData.referencetokens);
                }
                if (cardData.referencetokens && cardData.referencetokens.Tokens) {
                    var tokens = cardData.referencetokens.Tokens;
                    var value = "";
                    var description = "";
                    if (tokens.body) {
                        value = context.resources.getString(tokens.body.ResourceId);
                        if (tokens.body.ResourceId != value || cardData.description == undefined || cardData.description == null) {
                            var paramsNameValues = [];
                            if (tokens.body.Params && tokens.body.Params.length > 0) {
                                paramsNameValues = tokens.body.Params.map(function (param) {
                                    if (param.Name) {
                                        var name_1 = param.Name;
                                        if (param.Type == 1) {
                                            var dateTime = new Date(name_1);
                                            if (!isNaN(dateTime.getTime())) {
                                                if (dateTime != null) {
                                                    var dformat = "formatDateLong";
                                                    if (name_1.indexOf("T") != -1) {
                                                        name_1 = context.formatting.formatDateLong(dateTime);
                                                    }
                                                    else {
                                                        return dateTime.localeFormat(context.client.dateFormattingInfo.LongDatePattern);
                                                    }
                                                }
                                            }
                                            else {
                                                var curDate = new Date();
                                                var dateStr = curDate.toDateString();
                                                dateStr += " " + name_1;
                                                var dateOnly = context.formatting.formatDateShort(curDate, false);
                                                var formatTime = context.formatting.formatTime(curDate, 1);
                                                name_1 = formatTime.replace(dateOnly, "").trim();
                                            }
                                            return name_1;
                                        }
                                        else {
                                            return name_1;
                                        }
                                    }
                                });
                                if (paramsNameValues && paramsNameValues.length > 0) {
                                    if (paramsNameValues && paramsNameValues.length > 1) {
                                        return (description = CardFeedContainer.CardUtils.formatStringArray(value, paramsNameValues));
                                    }
                                    else {
                                        return (description = MscrmCommon.ControlUtils.String.Format(value, paramsNameValues));
                                    }
                                }
                            }
                            else {
                                return (description = value);
                            }
                        }
                    }
                }
            }
            Utils.getReferenceTokenDataDescription = getReferenceTokenDataDescription;
            function softTitleGenerator(softTitle, starttime, context) {
                var formatedSoftTitle = softTitle ? softTitle : "";
                var startDateTime = new Date(starttime);
                if (starttime && softTitle) {
                    var dateOnly = context.formatting.formatDateShort(startDateTime, false);
                    var dateTime = context.formatting.formatTime(startDateTime, 1);
                    var formatedMeetingTime = dateTime.replace(dateOnly, "").trim();
                    formatedSoftTitle = MscrmCommon.ControlUtils.String.Format(softTitle, formatedMeetingTime);
                }
                return formatedSoftTitle;
            }
            Utils.softTitleGenerator = softTitleGenerator;
        })(Utils = CardFeedContainer.Utils || (CardFeedContainer.Utils = {}));
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var AgendaCardControl = (function () {
            function AgendaCardControl(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
            }
            AgendaCardControl.prototype.renderCardView = function (card, accessibilityFocusId) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var formatedTitle;
                if (card.softTitle.indexOf(":") != -1) {
                    var titleArray = card.softTitle.split(":");
                    if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                        formatedTitle = titleArray[1];
                    }
                    else {
                        formatedTitle = card.softTitle;
                    }
                }
                else {
                    formatedTitle = card.softTitle;
                }
                if (card.data) {
                    formatedTitle = card.data.cardRelatedInfo
                        ? CardFeedContainer.Utils.softTitleGenerator(formatedTitle, card.data.cardRelatedInfo.starttime, this._context)
                        : formatedTitle;
                }
                var cardTitleLabel = card.title ? card.title : CardFeedContainer.Utils.getReferenceTokenDataTitle(card, this._context);
                var cardTitleDescription = formatedTitle + " " + cardTitleLabel;
                var cardDescriptionLabel = card.description
                    ? card.description
                    : CardFeedContainer.Utils.getReferenceTokenDataDescription(card, this._context);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + card.cardId,
                    key: "imginfo_key" + card.cardId,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                });
                var cardIcon = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + card.cardId,
                    key: "cardIcon" + card.cardId,
                    style: {
                        width: "3rem",
                        height: "3rem",
                        lineHeight: "3rem",
                        marginRight: "0.15rem",
                        fontSize: "1rem",
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "1.5rem",
                        backgroundColor: "#e2e2e2",
                        display: "block",
                    },
                }, imginfoControl);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + card.cardId,
                    key: "iconContainer" + card.cardId,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                    },
                }, cardIcon);
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + card.cardId,
                    id: "cardDueTitle" + card.cardId,
                    tabIndex: 0,
                    title: formatedTitle,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(card.cardName),
                        fontSize: "1rem",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, formatedTitle);
                var cardTitle = this._context.factory.createElement("LABEL", {
                    key: "cardTitle" + card.cardId,
                    id: "cardTitle" + card.cardId,
                    title: cardTitleLabel,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, cardTitleLabel);
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + card.cardId,
                    id: "cardTitleDescriptionId" + card.cardId,
                    accessibilityLabel: cardTitleDescription,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + card.cardId,
                    id: "cardDescription" + card.cardId,
                    title: cardDescriptionLabel,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: 400,
                        color: this._context.theming.colors.grays.gray07,
                        lineHeight: this._context.theming.measures.measure150,
                        maxHeight: this._context.theming.measures.measure450,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        position: "relative",
                        wordBreak: "break-word",
                        display: "block",
                        whiteSpace: "initial",
                        wordWrap: "break-word",
                        textDecoration: "none",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                    },
                }, cardDescriptionLabel);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                    },
                }, [cardDueTitle, cardTitle, cardDescription, cardTitleDescriptionId]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + card.cardId,
                    id: "cardLabelsMainContainer" + card.cardId,
                    style: {
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        display: "block",
                        width: "100%",
                    },
                }, cardLabelsContainer);
                var buttonContainer = this._context.factory.createElement("CONTAINER", {
                    key: "buttonContainer" + card.cardId,
                    id: "buttonContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray01,
                        whiteSpace: "normal",
                        display: "block",
                        height: this._context.theming.measures.measure250,
                    },
                }, this.ccfScope.dataFactories["Generic"].getButtonContainer(card, accessibilityFocusId));
                var cardDetailsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardDetailsContainer" + card.cardId,
                    id: "cardDetailsContainer" + card.cardId,
                    style: {
                        justifyContent: "space-between",
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingBottom: this._context.theming.measures.measure075,
                        whiteSpace: "normal",
                    },
                }, [
                    cardIconContainer,
                    cardLabelsMainContainer,
                    this.ccfScope.dataFactories["Generic"].renderMenuForCardView(card, accessibilityFocusId),
                ]);
                var cardWithActionsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cardTitleDescription),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope),
                    autoFocus: true,
                    style: {
                        whiteSpace: "normal",
                        flexDirection: "column",
                        width: "100%",
                    },
                }, [cardDetailsContainer, buttonContainer]);
                var cardContainer = this._context.factory.createElement("CONTAINER", {
                    key: "sampleCard" + card.cardId,
                    id: "sampleCard" + card.cardId,
                    onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, card, this.ccfScope),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #d8d8d8",
                        boxSizing: "border-box",
                        position: "relative",
                        width: "100%",
                    },
                }, cardWithActionsContainer);
                var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "swipeContentContainer" + card.cardId,
                    id: "swipeContentContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.ccfScope.dataFactories["Generic"].rendersnoozeContainer(card),
                    cardContainer,
                    this.ccfScope.dataFactories["Generic"].renderdismissContainer(card, accessibilityFocusId),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #ccc",
                        display: "flex",
                        marginBottom: "0.5rem",
                        transform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, swipeContentContainer);
            };
            AgendaCardControl.prototype.renderGroupCardView = function (index, cards, accessibilityFocusId) {
                var groupContainer = [];
                var firstThreeCards = [];
                if (cards.length > 3) {
                    firstThreeCards = cards.slice(0, 3);
                }
                else {
                    firstThreeCards = cards;
                }
                var groupTitleLabel = cards[0].softTitle.split(":")[0].toUpperCase();
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + index,
                    key: "imginfo_key" + index,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: 66,
                });
                var groupIcon = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + index,
                    key: "iconContainer" + index,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure015,
                        fontSize: this._context.theming.measures.measure100,
                        float: "left",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: this._context.theming.colors.grays.gray01,
                    },
                }, imginfoControl);
                var groupIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "groupIcon" + index,
                    key: "groupIcon" + index,
                    accessibilityHidden: true,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                        paddingRight: this._context.theming.measures.measure075,
                    },
                }, groupIcon);
                var groupTitlePlusIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitlePlusIcon" + index,
                    key: "groupTitlePlusIcon" + index,
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: "0.65rem",
                        paddingRight: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 198,
                });
                var groupTitleRightArrowIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitleRightArrowIcon" + index,
                    key: "groupTitleRightArrowIcon" + index,
                    tabIndex: 0,
                    role: "button",
                    accessibilityLabel: this.ccfScope._context.resources.getString("ActionCard.GroupCardView.ShowMore_AccessibilityText"),
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 62,
                });
                var static3Label = this._context.factory.createElement("LABEL", {
                    key: "static3Label" + index,
                    id: "static3Label" + index,
                    style: {
                        color: this._context.theming.colors.grays.gray05,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, "3");
                var groupcount = this._context.factory.createElement("CONTAINER", {
                    key: "groupcount" + index,
                    id: "groupcount" + index,
                    style: {
                        fontSize: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, [static3Label, groupTitlePlusIcon, groupTitleRightArrowIcon]);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitle" + index,
                    id: "groupTitle" + index,
                    title: groupTitleLabel,
                    tabIndex: 0,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(firstThreeCards[0].cardName),
                        lineHeight: this._context.theming.measures.measure150,
                        maxWidth: "calc(100% - 4rem)",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, groupTitleLabel);
                var groupTitleContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitleContainer" + index,
                    id: "groupTitleContainer" + index,
                    style: {
                        display: "flex",
                    },
                }, [groupTitle, groupcount]);
                var groupTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "groupTitleDescriptionId" + index,
                    id: "groupTitleDescriptionId" + index,
                    accessibilityLabel: groupTitleLabel,
                    style: {
                        display: "none",
                    },
                }, "");
                var groupSummary = this._context.factory.createElement("LABEL", {
                    key: "groupSummaryTitle" + index,
                    id: "groupSummaryTitle" + index,
                    title: cards[0].summaryText,
                    tabIndex: 0,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure015,
                        cursor: "pointer",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                }, cards[0].summaryText);
                var groupLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsContainer" + index,
                    id: "groupLabelsContainer" + index,
                    style: {
                        display: "block",
                    },
                }, [groupTitleContainer, groupSummary, groupTitleDescriptionId]);
                var groupLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsMainContainer" + index,
                    id: "groupLabelsMainContainer" + index,
                    style: {
                        flexDirection: "column",
                    },
                }, groupLabelsContainer);
                var groupHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupHeaderContainer" + index,
                    id: "groupHeaderContainer" + index,
                    style: {
                        justifyContent: "space-between",
                        whiteSpace: "normal",
                    },
                }, [groupIconContainer, groupLabelsMainContainer]);
                var groupsHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupsHeaderContainer" + index,
                    id: "groupsHeaderContainer" + index,
                    onClick: this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, cards, this.ccfScope),
                    style: {
                        justifyContent: "space-between",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        whiteSpace: "normal",
                        cursor: "pointer",
                    },
                }, groupHeaderContainer);
                for (var card in firstThreeCards) {
                    var softTitle = void 0;
                    if (cards[card].softTitle.indexOf(":") != -1) {
                        var titleArray = cards[card].softTitle.split(":");
                        if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                            softTitle = titleArray[1];
                        }
                        else {
                            softTitle = cards[card].softTitle;
                        }
                    }
                    else {
                        softTitle = cards[card].softTitle;
                    }
                    var formatedTitle = cards[card].data
                        ? CardFeedContainer.Utils.softTitleGenerator(softTitle, cards[card].data.cardRelatedInfo.starttime, this._context)
                        : softTitle;
                    var indvCardTitle = cards[card].title
                        ? cards[card].title
                        : CardFeedContainer.Utils.getReferenceTokenDataTitle(cards[card], this._context);
                    var cardNameAndTime = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + card,
                        id: "cardDueTitle" + card,
                        tabIndex: 0,
                        style: {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                            lineHeight: this._context.theming.measures.measure150,
                            maxHeight: this._context.theming.measures.measure150,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            wordBreak: "break-word",
                            whiteSpace: "initial",
                            wordWrap: "break-word",
                            textDecoration: "none",
                        },
                    }, formatedTitle);
                    var cardTitleLabel = this._context.factory.createElement("LABEL", {
                        key: "cardTitleLabel" + card,
                        id: "cardTitleLabel" + card,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.grays.gray05,
                        },
                    }, indvCardTitle);
                    var individualCardTitleLabel = this._context.factory.createElement("CONTAINER", {
                        key: "individualCardTitleLabel" + card,
                        id: "individualCardTitleLabel" + card,
                    }, [cardNameAndTime, cardTitleLabel]);
                    var cardTitleContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardTitleContainer" + card,
                        id: "cardTitleContainer" + card,
                        title: formatedTitle + " " + indvCardTitle,
                        style: {
                            borderTop: this._context.theming.borders.border02,
                            paddingTop: this._context.theming.measures.measure050,
                            marginBottom: this._context.theming.measures.measure050,
                            marginLeft: this._context.theming.measures.measure100,
                            marginRight: this._context.theming.measures.measure100,
                            position: "relative",
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                        },
                        onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, firstThreeCards[card], this.ccfScope),
                    }, individualCardTitleLabel);
                    var groupCardsListContainer = this._context.factory.createElement("CONTAINER", {
                        key: "groupCardsListContainer" + index,
                        id: "groupCardsListContainer" + index,
                        tabIndex: 0,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [
                        this.ccfScope.dataFactories["Generic"].rendersnoozeContainer(cards[card]),
                        cardTitleContainer,
                        this.ccfScope.dataFactories["Generic"].renderdismissContainer(cards[card], accessibilityFocusId),
                    ]);
                    var cardTitle = this._context.factory.createElement("LISTITEM", {
                        key: "cardDueTitle" + card + accessibilityFocusId,
                        id: "cardDueTitle" + card + accessibilityFocusId,
                        accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), groupTitleLabel + " " + formatedTitle + " " + indvCardTitle),
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        autoFocus: true,
                        onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", cards[card], this.ccfScope, null),
                        style: {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            display: "block",
                            transform: "translate3d(0px, 0px, 0px)",
                            transformStyle: "preserve-3d",
                            transition: "transform .3s linear",
                            width: "calc(100 % - 2px)",
                            boxSizing: "border-box",
                        },
                    }, groupCardsListContainer);
                    groupContainer.push(cardTitle);
                }
                var groupCardsContainer = this._context.factory.createElement("LIST", {
                    key: "groupCardsContainer" + index,
                    id: "groupCardsContainer" + index,
                    style: {
                        display: "block",
                        justifyContent: "space-between",
                        paddingTop: this._context.theming.measures.measure075,
                        paddingBottom: this._context.theming.measures.measure050,
                        whiteSpace: "normal",
                        listStyleType: "disc",
                    },
                }, groupContainer);
                var groupCardsContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupCardsContentContainer" + index,
                    id: "groupCardsContentContainer" + index,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                    },
                }, [
                    groupsHeaderContainer,
                    this.ccfScope.dataFactories["Generic"].renderMenuForGroupCardView(index, accessibilityFocusId, cards),
                    groupCardsContainer,
                ]);
                var groupCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cards[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "group", cards, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                        width: "100%",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.ccfScope.dataFactories["Generic"].renderGroupsnoozeContainer(index),
                    groupCardsContentContainer,
                    this.ccfScope.dataFactories["Generic"].renderGroupdismissContainer(index),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #ccc",
                        display: "flex",
                        marginBottom: "0.5rem",
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "100%",
                        cursor: "pointer",
                        boxSizing: "border-box",
                    },
                }, groupCardsMainContainer);
            };
            return AgendaCardControl;
        }());
        CardFeedContainer.AgendaCardControl = AgendaCardControl;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var TopPeopleControl = (function () {
            function TopPeopleControl(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
            }
            TopPeopleControl.prototype.renderGroupCardView = function (index, cards, accessibilityFocusId) {
                var groupContainer = [];
                var firstThreeCards = [];
                if (cards.length > 3) {
                    firstThreeCards = cards.slice(0, 3);
                }
                else {
                    firstThreeCards = cards;
                }
                var groupTitleLabel = cards[0].softTitle.split(":")[0].toUpperCase();
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitle" + index,
                    id: "groupTitle" + index,
                    title: groupTitleLabel,
                    tabIndex: 0,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(firstThreeCards[0].cardName),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "calc(100% - 7rem)",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingRight: this._context.theming.measures.measure050,
                    },
                }, groupTitleLabel);
                var groupTitleContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitleContainer" + index,
                    id: "groupTitleContainer" + index,
                    style: {
                        display: "flex",
                    },
                }, groupTitle);
                var groupTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "groupTitleDescriptionId" + index,
                    id: "groupTitleDescriptionId" + index,
                    accessibilityLabel: groupTitleLabel,
                    style: {
                        display: "none",
                    },
                }, "");
                var groupSummary = this._context.factory.createElement("LABEL", {
                    key: "groupSummaryTitle" + index,
                    id: "groupSummaryTitle" + index,
                    title: cards[0].summaryText,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure015,
                        cursor: "pointer",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                }, cards[0].summaryText);
                var groupLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsContainer" + index,
                    id: "groupLabelsContainer" + index,
                    style: {
                        display: "block",
                    },
                }, [groupTitleContainer, groupSummary, groupTitleDescriptionId]);
                var groupLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupLabelsMainContainer" + index,
                    id: "groupLabelsMainContainer" + index,
                    style: {
                        flexDirection: "column",
                    },
                }, groupLabelsContainer);
                var groupHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupHeaderContainer" + index,
                    id: "groupHeaderContainer" + index,
                    style: {
                        justifyContent: "space-between",
                        whiteSpace: "normal",
                    },
                }, [groupLabelsMainContainer]);
                var groupsHeaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupsHeaderContainer" + index,
                    id: "groupsHeaderContainer" + index,
                    style: {
                        justifyContent: "space-between",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        whiteSpace: "normal",
                        cursor: "pointer",
                    },
                }, groupHeaderContainer);
                for (var card in firstThreeCards) {
                    var softTitle = void 0;
                    if (cards[card].softTitle.indexOf(":") != -1) {
                        var titleArray = cards[card].softTitle.split(":");
                        if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                            softTitle = titleArray[1];
                        }
                        else {
                            softTitle = cards[card].softTitle;
                        }
                    }
                    else {
                        softTitle = cards[card].softTitle;
                    }
                    var formatedTitle = cards[card].data
                        ? CardFeedContainer.Utils.softTitleGenerator(softTitle, cards[card].data.cardRelatedInfo.starttime, this._context)
                        : softTitle;
                    var cardsTitle = cards[card].title
                        ? cards[card].title
                        : CardFeedContainer.Utils.getReferenceTokenDataTitle(cards[card], this._context);
                    var cardsDescription = this._context.resources.getString(cards[card].description);
                    var img_entity = cards[card].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = cards[card].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var entityImage = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "entityImage" + card,
                        id: "entityImage" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + card,
                        key: "entityImageContainer" + card,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: this._context.theming.colors.base.black,
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: this._context.theming.colors.grays.gray01,
                        },
                    }, entityImage);
                    var entityImageContainerFlex = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainerFlex" + card,
                        key: "entityImageContainerFlex" + card,
                        style: {
                            textAlign: "center",
                            marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                            paddingRight: this._context.theming.measures.measure075,
                        },
                    }, entityImageContainer);
                    var cardNameAndTime = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + card + accessibilityFocusId,
                        id: "cardDueTitle" + card + accessibilityFocusId,
                        title: cardsTitle,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        autoFocus: true,
                        onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", cards[card], this.ccfScope, null),
                        style: {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                            lineHeight: this._context.theming.measures.measure150,
                            maxHeight: this._context.theming.measures.measure150,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            wordBreak: "break-word",
                            whiteSpace: "initial",
                            wordWrap: "break-word",
                            textDecoration: "none",
                        },
                    }, cardsTitle);
                    var cardTitleLabel = this._context.factory.createElement("LABEL", {
                        key: "cardTitleLabel" + card,
                        id: "cardTitleLabel" + card,
                        title: cardsDescription,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.grays.gray05,
                        },
                    }, cardsDescription);
                    var indvLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "indvLabelsContainer" + card,
                        id: "indvLabelsContainer" + card,
                        style: {
                            display: "block",
                        },
                    }, [cardNameAndTime, cardTitleLabel]);
                    var indvLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "indvLabelsMainContainer" + card,
                        id: "indvLabelsMainContainer" + card,
                        style: {
                            flexDirection: "column",
                        },
                    }, indvLabelsContainer);
                    var individualCardTitleLabel = this._context.factory.createElement("CONTAINER", {
                        key: "individualCardTitleLabel" + card,
                        id: "individualCardTitleLabel" + card,
                    }, [entityImageContainer, indvLabelsMainContainer]);
                    var cardTitleContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardTitleContainer" + card,
                        id: "cardTitleContainer" + card,
                        style: {
                            borderTop: this._context.theming.borders.border02,
                            paddingTop: this._context.theming.measures.measure050,
                            marginBottom: this._context.theming.measures.measure050,
                            marginLeft: this._context.theming.measures.measure100,
                            marginRight: this._context.theming.measures.measure100,
                            position: "relative",
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            color: this._context.theming.colors.base.black,
                        },
                        onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, firstThreeCards[card], this.ccfScope),
                    }, individualCardTitleLabel);
                    var groupCardsListContainer = this._context.factory.createElement("CONTAINER", {
                        key: "groupCardsListContainer" + index,
                        id: "groupCardsListContainer" + index,
                        tabIndex: 0,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, cardTitleContainer);
                    var cardTitle = this._context.factory.createElement("LISTITEM", {
                        key: "cardTitle" + card,
                        id: "cardTitle" + card,
                        style: {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            display: "block",
                            transform: "translate3d(0px, 0px, 0px)",
                            transformStyle: "preserve-3d",
                            transition: "transform .3s linear",
                            width: "calc(100 % - 2px)",
                            boxSizing: "border-box",
                        },
                    }, groupCardsListContainer);
                    groupContainer.push(cardTitle);
                }
                var groupCardsContainer = this._context.factory.createElement("LIST", {
                    key: "groupCardsContainer" + index,
                    id: "groupCardsContainer" + index,
                    style: {
                        display: "block",
                        justifyContent: "space-between",
                        paddingTop: this._context.theming.measures.measure075,
                        paddingBottom: this._context.theming.measures.measure050,
                        whiteSpace: "normal",
                        listStyleType: "disc",
                    },
                }, groupContainer);
                var groupCardsContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupCardsContentContainer" + index,
                    id: "groupCardsContentContainer" + index,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                    },
                }, [
                    groupsHeaderContainer,
                    this.ccfScope.dataFactories["Generic"].renderMenuForGroupCardView(index, accessibilityFocusId, cards),
                    groupCardsContainer,
                ]);
                var groupCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), groupTitleLabel),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "", cards, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "block",
                        width: "100%",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.ccfScope.dataFactories["Generic"].renderGroupsnoozeContainer(index),
                    groupCardsContentContainer,
                    this.ccfScope.dataFactories["Generic"].renderGroupdismissContainer(index),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #ccc",
                        display: "flex",
                        marginBottom: "0.5rem",
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "100%",
                        cursor: "pointer",
                        boxSizing: "border-box",
                    },
                }, groupCardsMainContainer);
            };
            return TopPeopleControl;
        }());
        CardFeedContainer.TopPeopleControl = TopPeopleControl;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var ActionCommandsManager = (function () {
            function ActionCommandsManager(context) {
                this._context = {};
                this.commandFetchCompleted = false;
                this.callbackQueue = [];
                this.fetchIsInprogress = false;
                this.fetchCounter = 0;
                this.actionCommands = {};
                this.buttonCommandMap = {};
                this.ccfScope = context;
                this._context = this.ccfScope._context;
                this.loadActionCardCommands();
            }
            ActionCommandsManager.prototype.loadActionCardCommands = function () {
                if (sessionStorage) {
                    var serverVersion = void 0;
                    var ribbonCommandsCache = void 0;
                    try {
                        var xrmGlobalContext = Xrm.Utility.getGlobalContext();
                        serverVersion = xrmGlobalContext.getVersion();
                        ribbonCommandsCache = { version: "", buttonCommandMap: "" };
                        ribbonCommandsCache = JSON.parse(sessionStorage.getItem("actioncardscommandscache"));
                    }
                    catch (ex) {
                    }
                    if (ribbonCommandsCache &&
                        ribbonCommandsCache.version == serverVersion &&
                        !$.isEmptyObject(ribbonCommandsCache.buttonCommandMap)) {
                        this.buttonCommandMap = ribbonCommandsCache.buttonCommandMap;
                    }
                }
                if ($.isEmptyObject(this.buttonCommandMap)) {
                    this.fetchButtonCommandsMap();
                }
            };
            ActionCommandsManager.prototype.fetchButtonCommandsMap = function () {
                var that = this;
                var ribbonTabToCommandmapXml = "<fetch mapping='logical'><entity name='ribbontabtocommandmap'><attribute name='command'/><attribute name='controlid'/><filter type='and'><condition attribute='entity' operator='eq' value='actioncard'/></filter></entity></fetch>";
                this.ccfScope._context.webAPI
                    .retrieveMultipleRecords("ribbontabtocommandmap", "?fetchXml=" + ribbonTabToCommandmapXml)
                    .then(function (records) {
                    _.forEach(records.entities, function (entry) {
                        if (entry.command && entry.controlid) {
                            if (that.buttonCommandMap[entry.command]) {
                                if (!_.isArray(that.buttonCommandMap[entry.command])) {
                                    that.buttonCommandMap[entry.command] = [that.buttonCommandMap[entry.command]];
                                }
                                that.buttonCommandMap[entry.command].push(entry.controlid);
                            }
                            else {
                                that.buttonCommandMap[entry.command] = entry.controlid;
                            }
                        }
                    });
                    var xrmGlobalContext = Xrm.Utility.getGlobalContext();
                    var actioncardsCommandsJSON = {
                        version: xrmGlobalContext.getVersion(),
                        buttonCommandMap: that.buttonCommandMap,
                    };
                    sessionStorage.setItem("actioncardscommandscache", JSON.stringify(actioncardsCommandsJSON));
                });
            };
            ActionCommandsManager.prototype.fetchCommands = function (index, callback) {
                var _this = this;
                var commands;
                var self = this;
                this.commandFetchCompleted = false;
                this.fetchIsInprogress = true;
                var keys = Object.keys(this.subGrid.records);
                if (keys.length > 0) {
                    var curRecord_1 = this.subGrid.records[keys[index]];
                    if (curRecord_1) {
                        var commandList = [];
                        if (curRecord_1.actions == null || curRecord_1.actions == undefined) {
                            commandList = [];
                        }
                        else {
                            if (curRecord_1.actions.WebClient != null || curRecord_1.actions.WebClient != undefined) {
                                var vals = Object.keys(curRecord_1.actions.WebClient.Actions).map(function (key) {
                                    return curRecord_1.actions.WebClient.Actions[key];
                                });
                                commandList = commandList.concat(vals);
                            }
                            if (curRecord_1.actions.Mobile != null || curRecord_1.actions.Mobile != undefined) {
                                var vals = Object.keys(curRecord_1.actions.Mobile.Actions).map(function (key) {
                                    return curRecord_1.actions.Mobile.Actions[key];
                                });
                                commandList = commandList.concat(vals);
                            }
                        }
                        var buttonList = [];
                        for (var i in commandList) {
                            if (this.buttonCommandMap[commandList[i]] == undefined) {
                                buttonList = [];
                                break;
                            }
                            buttonList = buttonList.concat(this.buttonCommandMap[commandList[i]]);
                        }
                        if (buttonList.length > 0) {
                            buttonList = buttonList.concat([
                                "Mscrm.HomepageGrid.actioncard.Snooze",
                                "Mscrm.SubGrid.actioncard.Snooze",
                                "Mscrm.SubGrid.actioncard.Dismiss",
                                "Mscrm.HomepageGrid.actioncard.Dismiss",
                            ]);
                            buttonList = $.unique(buttonList);
                        }
                        this.subGrid.retrieveRecordCommand(curRecord_1.getValue("actioncardid").guid, buttonList).then(function (data) {
                            var arrIndex = [];
                            _this.actionCommands[curRecord_1.getValue("actioncardid").guid] = data;
                            for (var commandIndex in data) {
                                if (data[commandIndex].canExecute == true) {
                                    arrIndex.push(data[commandIndex]);
                                }
                            }
                            _this.actionCommands[curRecord_1.getValue("actioncardid").toString()] = arrIndex;
                            if (keys.length - 1 <= index) {
                                self.fetchActionCommandsCompleted(callback);
                            }
                        }, function (e) {
                            if (keys.length - 1 > index) {
                                self.fetchCommands(index + 1, callback);
                            }
                        });
                    }
                    if (keys.length - 1 > index) {
                        self.fetchCommands(index + 1, callback);
                    }
                }
            };
            ActionCommandsManager.prototype.getCommandByCardId = function (cardId) {
                if (this.actionCommands)
                    return this.actionCommands[cardId];
                else
                    return [];
            };
            ActionCommandsManager.prototype.fetchActionCommandsCompleted = function (callback) {
                if (this.callbackQueue.length > 0) {
                    this.fetchIsInprogress = false;
                    this.actionCommands = {};
                    var cb = this.callbackQueue[this.callbackQueue.length - 1];
                    this.callbackQueue = [];
                    this.fetchCommands(0, cb);
                }
                else {
                    this.commandFetchCompleted = true;
                    this.fetchIsInprogress = false;
                    this.callbackQueue = [];
                    callback(this.ccfScope);
                }
            };
            ActionCommandsManager.prototype.checkCommandAvailable = function (cardId, callback) {
                var commands;
                var self = this;
                var curRecord = this._context.parameters.SubGrid.records[cardId];
                if (curRecord) {
                    this._context.parameters.SubGrid.retrieveRecordCommand(curRecord.getValue("actioncardid").guid).then(function (data) {
                        callback(true);
                    }, function (e) {
                        if (self.fetchCounter < 3) {
                            self.fetchCounter++;
                            window.setTimeout(function () {
                                self.checkCommandAvailable(cardId, callback);
                            }, 600);
                        }
                        else
                            callback(false);
                    });
                }
            };
            ActionCommandsManager.prototype.fetchCardCommand = function (cardData, callback) {
                var commands;
                var self = this;
                var curRecord = this._context.parameters.SubGrid.records[cardData.cardId];
                if (curRecord) {
                    this._context.parameters.SubGrid.setSelectedRecordId(curRecord.getValue("actioncardid").toString());
                    this._context.parameters.SubGrid.commanding
                        .getRecordCommands(curRecord.getValue("actioncardid").toString())
                        .then(function (data) {
                        callback(data, cardData);
                    }, function (e) {
                        console.error(e);
                    });
                }
            };
            return ActionCommandsManager;
        }());
        CardFeedContainer.ActionCommandsManager = ActionCommandsManager;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var ProductivityCardControl = (function () {
            function ProductivityCardControl(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
                var locationTitle = this._context.factory.createElement("LABEL", {
                    key: "locationTitle",
                    id: "locationTitle",
                    title: CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location"),
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location")),
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location"));
                var locationContainer = this._context.factory.createElement("CONTAINER", {
                    key: "locationContainer",
                    id: "locationContainer",
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure050,
                    },
                    accessKey: "",
                }, locationTitle);
                this.mapContainer = this._context.factory.createElement("CONTAINER", {
                    key: "mapContainer",
                    id: "mapContainer",
                    style: {
                        display: "block",
                        height: "10em",
                        position: "relative",
                    },
                    accessKey: "",
                }, "");
                var mapMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer2",
                    id: "cardWithActionsContainer2",
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this._context.resources.getString("ActionCard.CFC.Meeting.Location")),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(2) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, 2, "card", null, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        display: "block",
                    },
                    accessKey: "",
                }, [locationContainer, this.mapContainer]);
                this.mapList = this._context.factory.createElement("LISTITEM", {
                    key: "mapMainContainer" + this.ccfScope.mapFocusId,
                    id: "mapMainContainer" + this.ccfScope.mapFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "block",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, mapMainContainer);
            }
            ProductivityCardControl.prototype.getParameterInfo = function (cardData, isRegarding) {
                if (!isRegarding) {
                    var data = [];
                    var cardContextDetails = cardData.data.cardContextDetails;
                    for (var key in cardContextDetails) {
                        var context = cardContextDetails[key].contextObject;
                        data.push({ logicalName: context.entityName, entityId: context.guid });
                    }
                    return data;
                }
                else {
                    var data = {};
                    if (cardData.regardingobjectid) {
                        data = { logicalName: cardData.regardingobjectid.etn, entityId: cardData.regardingobjectid.id.guid };
                    }
                    return data;
                }
            };
            ProductivityCardControl.prototype.generateAdditionalData = function (cardData, args) {
                if (args === void 0) { args = {}; }
                this.cardData = cardData;
                var children = [];
                args["cardData"] = cardData;
                var attParams = this.getParameterInfo(cardData, true);
                attParams["logicalName"] = "meetingData";
                var regParams = this.getParameterInfo(cardData, true);
                var promises = [];
                var newsParams = this.getParameterInfo(cardData, false);
                promises.push(CardFeedContainer.CardService.getAttendeesData(attParams, args, this.ccfScope));
                promises.push(CardFeedContainer.CardService.getRegardingData(regParams, args, this.ccfScope));
                promises.push(CardFeedContainer.CardService.getNewsData(newsParams, args));
                promises.push(CardFeedContainer.CardService.getStocksData(newsParams, args));
                promises.push(CardFeedContainer.CardService.getNearbyCustomers(cardData.data.cardRelatedInfo.address, cardData.data.cardRelatedInfo.bingApiKey, args));
                return Promise.all(promises);
            };
            ProductivityCardControl.prototype.generateGenericAdditionalData = function (cardData, args) {
                if (args === void 0) { args = {}; }
                var params = this.getParameterInfo(cardData, true);
                args["cardData"] = cardData;
                var promise = CardFeedContainer.CardService.getRegardingData(params, args, this.ccfScope);
                return promise;
            };
            ProductivityCardControl.prototype.generateAgendaAdditionalData = function (cardData, args) {
                if (args === void 0) { args = {}; }
                var promises = [];
                var params = this.getParameterInfo(cardData, true);
                var newsParams = this.getParameterInfo(cardData, false);
                args["cardData"] = cardData;
                promises.push(CardFeedContainer.CardService.getRegardingData(params, args, this.ccfScope));
                promises.push(CardFeedContainer.CardService.getNewsData(newsParams, args));
                promises.push(CardFeedContainer.CardService.getStocksData(newsParams, args));
                return Promise.all(promises);
            };
            ProductivityCardControl.prototype.callLocationService = function (request, callback) {
                jQuery.ajax({
                    url: request,
                    dataType: "jsonp",
                    jsonp: "jsonp",
                    success: function (r) {
                        callback(r);
                    },
                    error: function (e) { },
                });
            };
            ProductivityCardControl.prototype.refreshFrame = function (data) {
                var el;
                if (data != undefined && data != null && data.resourceSets.length > 0 && data.resourceSets[0].resources) {
                    var resources = data.resourceSets[0].resources;
                    el = document.getElementById(CardFeedContainer.CardService.cfcscope._context.accessibility.getUniqueId("mapContainer"));
                    if (resources.length > 0) {
                        var location_1 = resources[0].point.coordinates;
                        if (location_1) {
                            var mapOptions = {
                                credentials: CardFeedContainer.CardFeedContainer.cardData.data.cardRelatedInfo.bingApiKey
                                    ? CardFeedContainer.CardFeedContainer.cardData.data.cardRelatedInfo.bingApiKey
                                    : "",
                                center: new Microsoft.Maps.Location(location_1[0], location_1[1]),
                                zoom: 11,
                                showScalebar: false,
                                enableSearchLogo: false,
                                disableKeyboardInput: true,
                                showDashboard: false,
                            };
                            var map = new Microsoft.Maps.Map(el, mapOptions);
                            Microsoft.Maps.Events.addHandler(map, "click", this.handleMapclick);
                            Microsoft.Maps.Events.addHandler(map, "keypress", this.handleMapEnterKey);
                            var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), null);
                            map.entities.push(pushpin);
                        }
                    }
                    else {
                        jQuery(el).hide();
                    }
                }
                else {
                    jQuery(el).hide();
                }
            };
            ProductivityCardControl.prototype.handleMapclick = function (event) {
                var data;
                var action;
                if (this.cardData.data.cardRelatedInfo.address) {
                    action = "GetDirections";
                    data = { address: encodeURIComponent(this.cardData.data.cardRelatedInfo.address) };
                }
            };
            ProductivityCardControl.prototype.handleMapEnterKey = function (event) {
                if (event.keyCode == 13) {
                    this.handleMapclick.call(null, event);
                }
            };
            ProductivityCardControl.prototype.renderStockCardView = function (card, accessibilityFocusId) {
                this.stockData = CardFeedContainer.CardService.stockData[0];
                if (!this.stockData) {
                    return null;
                }
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "stockcardGroupTitle" + accessibilityFocusId,
                    id: "stockcardGroupTitle" + accessibilityFocusId,
                    title: this.stockData.softTitle,
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.stockData.cardName),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        padding: this._context.theming.measures.measure100,
                        width: "calc(100% - 3.5rem)",
                        display: "block",
                    },
                }, this.stockData.softTitle);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + this.stockData.cardId,
                    key: "imginfo_key" + this.stockData.cardId,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                });
                var cardIcon = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + this.stockData.cardId,
                    key: "cardIcon" + this.stockData.cardId,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure015,
                        fontSize: this._context.theming.measures.measure100,
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: this._context.theming.measures.measure150,
                        backgroundColor: "#e2e2e2",
                        display: "block",
                    },
                }, imginfoControl);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + this.stockData.cardId,
                    key: "iconContainer" + this.stockData.cardId,
                    style: {
                        textAlign: "center",
                        display: "inline",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                    },
                }, cardIcon);
                var LoczExName = this._context.factory.createElement("LABEL", {
                    key: "LoczExName" + this.stockData.cardId,
                    id: "LoczExName" + this.stockData.cardId,
                    title: this.stockData.data.cardRelatedInfo.LoczExName + ": " + this.stockData.data.cardRelatedInfo.Ticker,
                    accessibilityLabel: this.stockData.data.cardRelatedInfo.LoczExName + ": " + this.stockData.data.cardRelatedInfo.Ticker,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    style: {
                        color: this._context.theming.colors.base.black,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        display: "block",
                    },
                }, this.stockData.data.cardRelatedInfo.LoczExName + ": " + this.stockData.data.cardRelatedInfo.Ticker);
                var ShtName = this._context.factory.createElement("LABEL", {
                    key: "ShtName" + this.stockData.cardId,
                    id: "ShtName" + this.stockData.cardId,
                    title: this.stockData.data.cardRelatedInfo.ShtName,
                    accessibilityLabel: this.stockData.data.cardRelatedInfo.ShtName,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    style: {
                        color: this._context.theming.colors.grays.gray07,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        display: "block",
                    },
                }, this.stockData.data.cardRelatedInfo.ShtName);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + this.stockData.cardId,
                    id: "cardLabelsContainer" + this.stockData.cardId,
                    style: {
                        display: "block",
                        paddingLeft: this._context.theming.measures.measure075,
                        flexGrow: 1,
                        paddingRight: this._context.theming.measures.measure075,
                    },
                }, [LoczExName, ShtName]);
                var curr = Math.round(this.stockData.data.cardRelatedInfo.Lp * 100) / 100;
                var stockValue = this.stockData.data.cardRelatedInfo.Ch ? this.stockData.data.cardRelatedInfo.Ch : "";
                var stockPercentage = this.stockData.data.cardRelatedInfo.Chp
                    ? Math.round(this.stockData.data.cardRelatedInfo.Chp * 100) / 100 + "%"
                    : "";
                var stockInfo = stockValue + "(" + stockPercentage + ")";
                var currElement = this._context.factory.createElement("LABEL", {
                    key: "curr" + this.stockData.cardId,
                    id: "curr" + this.stockData.cardId,
                    style: {
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        display: "block",
                    },
                }, curr);
                var currSymbol = this._context.factory.createElement("LABEL", {
                    key: "currSymbol" + this.stockData.cardId,
                    id: "currSymbol" + this.stockData.cardId,
                    style: {
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        display: "block",
                        paddingLeft: this._context.theming.measures.measure050,
                    },
                }, this.stockData.data.cardRelatedInfo.Cur);
                var currContainer = this._context.factory.createElement("CONTAINER", {
                    key: "currContainer" + this.stockData.cardId,
                    id: "currContainer" + this.stockData.cardId,
                    title: curr + " " + this.stockData.data.cardRelatedInfo.Cur,
                    accessibilityLabel: curr + " " + this.stockData.data.cardRelatedInfo.Cur,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    style: {
                        display: "flex",
                    },
                }, [currElement, currSymbol]);
                var stockInfoElement = this._context.factory.createElement("LABEL", {
                    key: "stockInfoElement" + this.stockData.cardId,
                    id: "stockInfoElement" + this.stockData.cardId,
                    title: stockInfo,
                    accessibilityLabel: stockInfo,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.stockData.cardName),
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        display: "block",
                    },
                }, stockInfo);
                var stockInfoContainer = this._context.factory.createElement("CONTAINER", {
                    key: "stockInfoContainer" + this.stockData.cardId,
                    id: "stockInfoContainer" + this.stockData.cardId,
                    style: {
                        paddingLeft: this._context.theming.measures.measure075,
                        flexShrink: "1",
                        display: "flex",
                        flexDirection: "column",
                    },
                }, [currContainer, stockInfoElement]);
                var cardLabelsStockContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsStockContainer" + this.stockData.cardId,
                    id: "cardLabelsStockContainer" + this.stockData.cardId,
                    style: {
                        display: "flex",
                        width: "60%",
                        flex: "60% 1 1",
                        flexWrap: "wrap",
                    },
                }, [cardLabelsContainer, stockInfoContainer]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + this.stockData.cardId,
                    id: "cardLabelsMainContainer" + this.stockData.cardId,
                    style: {
                        display: "flex",
                        padding: this._context.theming.measures.measure100,
                    },
                }, [cardIconContainer, cardLabelsStockContainer]);
                var anchorElement = this._context.factory.createElement("HYPERLINK", {
                    key: "stockItemLink" + this.stockData.cardId,
                    id: "stockItemLink" + this.stockData.cardId,
                    href: this.stockData.data.cardRelatedInfo.link,
                    target: "_blank",
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    style: {
                        display: "block",
                        textDecoration: "none",
                        ":visited": { color: this._context.theming.colors.basecolor.black },
                    },
                }, cardLabelsMainContainer);
                var stockCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.stockData.softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [groupTitle, anchorElement]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "stockCards" + accessibilityFocusId,
                    id: "stockCards" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure150,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, stockCardsMainContainer);
            };
            ProductivityCardControl.prototype.renderAttendeeCardView = function (card, accessibilityFocusId) {
                this.attendeeData = CardFeedContainer.CardService.attData;
                if (this.attendeeData.length == 0) {
                    return null;
                }
                return this.renderAttendeeGroupCardView(card, accessibilityFocusId);
            };
            ProductivityCardControl.prototype.renderAttendeeIndividualCardView = function (index, accessibilityFocusId) {
                var attendeeCards = [];
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var img_entity = this.attendeeData[index].data.cardContextDetails[0].contextObject.entityImgUrl;
                var entityName = this.attendeeData[index].title;
                var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                    key: "userImageElement" + index,
                    id: "userImageElement" + index,
                    style: {
                        color: this._context.theming.colors.basecolor.white,
                        fontSize: this._context.theming.fontsizes.font100,
                        margin: "0 auto",
                        width: "100%",
                    },
                    hasPrimaryImageField: true,
                    tabIndex: 0,
                    mode: entityImageMode,
                    imageSrc: img_entity,
                    entityPrimaryField: entityName,
                });
                var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                    id: "entityImageContainer" + index,
                    key: "entityImageContainer" + index,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure075,
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        float: "left",
                        textAlign: "center",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#e2e2e2",
                    },
                }, userImageElement);
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + this.attendeeData[index].cardId,
                    id: "cardDueTitle" + this.attendeeData[index].cardId,
                    title: this.attendeeData[index].title,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    accessibilityLabel: this.attendeeData[index].title,
                    style: {
                        color: this._context.theming.colors.base.black,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, this.attendeeData[index].title);
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + this.attendeeData[index].cardId,
                    id: "cardTitleDescriptionId" + this.attendeeData[index].cardId,
                    accessibilityLabel: this.attendeeData[index].description,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + this.attendeeData[index].cardId,
                    id: "cardDescription" + this.attendeeData[index].cardId,
                    title: this.attendeeData[index].description,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure015,
                        marginTop: this._context.theming.measures.measure015,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.grays.gray07,
                        textOverflow: "ellipsis",
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                }, this.attendeeData[index].description);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + this.attendeeData[index].cardId,
                    id: "cardLabelsContainer" + this.attendeeData[index].cardId,
                    style: {
                        display: "block",
                    },
                }, [cardDueTitle, cardDescription, cardTitleDescriptionId]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + this.attendeeData[index].cardId,
                    id: "cardLabelsMainContainer" + this.attendeeData[index].cardId,
                    style: {
                        display: "flex",
                        padding: this._context.theming.measures.measure050,
                    },
                    onClick: this.openCardForm.bind(this, {
                        entityName: this.attendeeData[index].data.cardContextDetails[0].contextObject.entityName,
                        entityId: this.attendeeData[index].data.cardContextDetails[0].contextObject.guid,
                    }),
                }, [entityImageContainer, cardLabelsContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", null, this.ccfScope, null),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        marginBottom: this._context.theming.measures.measure100,
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                        boxSizing: "border-box",
                    },
                }, [cardLabelsMainContainer]);
            };
            ProductivityCardControl.prototype.renderAttendeeGroupCardView = function (card, accessibilityFocusId) {
                var attendeeCards = [];
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var groupTitlePlusIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitlePlusIcon" + accessibilityFocusId,
                    key: "groupTitlePlusIcon" + accessibilityFocusId,
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: "0.65rem",
                        paddingRight: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 198,
                });
                var groupTitleRightArrowIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitleRightArrowIcon" + accessibilityFocusId,
                    key: "groupTitleRightArrowIcon" + accessibilityFocusId,
                    tabIndex: 0,
                    role: "button",
                    accessibilityLabel: this.ccfScope._context.resources.getString("ActionCard.GroupCardView.ShowMore_AccessibilityText"),
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 62,
                });
                var static3Label = this._context.factory.createElement("LABEL", {
                    key: "static3Label" + accessibilityFocusId,
                    id: "static3Label" + accessibilityFocusId,
                    style: {
                        color: this._context.theming.colors.base.black,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, "3");
                var groupcount = this._context.factory.createElement("CONTAINER", {
                    key: "groupcount" + accessibilityFocusId,
                    id: "groupcount" + accessibilityFocusId,
                    style: {
                        fontSize: this._context.theming.measures.measure100,
                        padding: this._context.theming.measures.measure050,
                    },
                }, [static3Label, groupTitlePlusIcon, groupTitleRightArrowIcon]);
                if (this.attendeeData.length == 3) {
                    groupTitlePlusIcon = null;
                }
                else if (this.attendeeData.length < 3) {
                    groupcount = null;
                }
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "attendeeGroupTitle" + accessibilityFocusId,
                    id: "attendeeGroupTitle" + accessibilityFocusId,
                    title: this.attendeeData[0].softTitle,
                    tabIndex: 0,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.attendeeData[0].cardName),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "calc(100% - 7rem)",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, this.attendeeData[0].softTitle);
                var groupTitleContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitleContainer" + accessibilityFocusId,
                    id: "groupTitleContainer" + accessibilityFocusId,
                    style: {
                        display: "flex",
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                    onClick: groupcount
                        ? this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, this.attendeeData, this.ccfScope, "Attendees")
                        : null,
                }, [groupTitle, groupcount]);
                var firstThreeCards = [];
                firstThreeCards = this.attendeeData.slice(0, 3);
                var cardData;
                for (cardData in firstThreeCards) {
                    var img_entity = this.attendeeData[cardData].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = this.attendeeData[cardData].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + card,
                        id: "userImageElement" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + card,
                        key: "entityImageContainer" + card,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: "#333333",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, userImageElement);
                    var cardDueTitle = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + this.attendeeData[cardData].cardId,
                        id: "cardDueTitle" + this.attendeeData[cardData].cardId,
                        title: this.attendeeData[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        accessibilityLabel: this.attendeeData[cardData].title,
                        style: {
                            color: this._context.theming.colors.base.black,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                        },
                    }, this.attendeeData[cardData].title);
                    var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                        key: "cardTitleDescriptionId" + this.attendeeData[cardData].cardId,
                        id: "cardTitleDescriptionId" + this.attendeeData[cardData].cardId,
                        accessibilityLabel: this.attendeeData[cardData].description,
                        style: {
                            display: "none",
                        },
                    }, "");
                    var cardDescription = this._context.factory.createElement("LABEL", {
                        key: "cardDescription" + this.attendeeData[cardData].cardId,
                        id: "cardDescription" + this.attendeeData[cardData].cardId,
                        title: this.attendeeData[cardData].description,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            marginTop: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            color: this._context.theming.colors.grays.gray07,
                            textOverflow: "ellipsis",
                            paddingBottom: this._context.theming.measures.measure075,
                        },
                    }, this.attendeeData[cardData].description);
                    var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsContainer" + this.attendeeData[cardData].cardId,
                        id: "cardLabelsContainer" + this.attendeeData[cardData].cardId,
                        style: {
                            display: "block",
                        },
                    }, [cardDueTitle, cardDescription, cardTitleDescriptionId]);
                    var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsMainContainer" + this.attendeeData[cardData].cardId,
                        id: "cardLabelsMainContainer" + this.attendeeData[cardData].cardId,
                        style: {
                            display: "flex",
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                        },
                        onClick: this.openCardForm.bind(this, {
                            entityName: this.attendeeData[cardData].data.cardContextDetails[0].contextObject.entityName,
                            entityId: this.attendeeData[cardData].data.cardContextDetails[0].contextObject.guid,
                        }),
                    }, [entityImageContainer, cardLabelsContainer]);
                    var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                        key: "swipeContentContainer" + this.attendeeData[cardData].cardId,
                        id: "swipeContentContainer" + this.attendeeData[cardData].cardId,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [cardLabelsMainContainer]);
                    attendeeCards.push(swipeContentContainer);
                }
                var attendeeCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "attendeeCards" + this.attendeeData[cardData].cardId,
                    id: "attendeeCards" + this.attendeeData[cardData].cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, attendeeCards);
                var attendeeCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.attendeeData[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [groupTitleContainer, attendeeCardsContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "attendeeMCards" + accessibilityFocusId,
                    id: "attendeeMCards" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, attendeeCardsMainContainer);
            };
            ProductivityCardControl.prototype.renderRegardingCardView = function (card, accessibilityFocusId) {
                this.regardingData = CardFeedContainer.CardService.regData;
                var regardingCards = [];
                if (this.regardingData.length == 0) {
                    return null;
                }
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "regardingGroupTitle" + accessibilityFocusId,
                    id: "regardingGroupTitle" + accessibilityFocusId,
                    title: this.regardingData[0].softTitle,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.regardingData[0].cardName),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "calc(100% - 1rem)",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                }, this.regardingData[0].softTitle);
                var cardData;
                for (cardData in this.regardingData) {
                    var img_entity = this.regardingData[cardData].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = this.regardingData[cardData].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + card,
                        id: "userImageElement" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + card,
                        key: "entityImageContainer" + card,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: "#333333",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, userImageElement);
                    var cardDueTitle = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + this.regardingData[cardData].cardId,
                        id: "cardDueTitle" + this.regardingData[cardData].cardId,
                        title: this.regardingData[cardData].title,
                        accessibilityLabel: this.regardingData[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        style: {
                            color: this._context.theming.colors.base.black,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                        },
                    }, this.regardingData[cardData].title);
                    var cardDueTitleCont = this._context.factory.createElement("CONTAINER", {
                        key: "cardDueTitleCont" + this.regardingData[cardData].cardId,
                        id: "cardDueTitleCont" + this.regardingData[cardData].cardId,
                        title: this.regardingData[cardData].title,
                        accessibilityLabel: this.regardingData[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        style: {
                            color: this._context.theming.colors.base.black,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            width: "100%",
                            cursor: "pointer",
                        },
                    }, cardDueTitle);
                    var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                        key: "cardTitleDescriptionId" + this.regardingData[cardData].cardId,
                        id: "cardTitleDescriptionId" + this.regardingData[cardData].cardId,
                        accessibilityLabel: this.regardingData[cardData].description,
                        style: {
                            display: "none",
                        },
                    }, "");
                    var cardDescription = this._context.factory.createElement("LABEL", {
                        key: "cardDescription" + this.regardingData[cardData].cardId,
                        id: "cardDescription" + this.regardingData[cardData].cardId,
                        title: this.regardingData[cardData].description,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            marginTop: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            color: this._context.theming.colors.grays.gray07,
                            textOverflow: "ellipsis",
                            paddingBottom: this._context.theming.measures.measure075,
                        },
                    }, this.regardingData[cardData].description);
                    var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsContainer" + this.regardingData[cardData].cardId,
                        id: "cardLabelsContainer" + this.regardingData[cardData].cardId,
                        style: {
                            display: "block",
                            maxWidth: "calc(100% - 4rem)",
                        },
                    }, [cardDueTitleCont, cardDescription, cardTitleDescriptionId]);
                    var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsMainContainer" + this.regardingData[cardData].cardId,
                        id: "cardLabelsMainContainer" + this.regardingData[cardData].cardId,
                        style: {
                            display: "flex",
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                        },
                        onClick: this.openCardForm.bind(this, {
                            entityName: this.regardingData[cardData].regardingobjectid.etn,
                            entityId: this.regardingData[cardData].regardingobjectid.Id,
                        }),
                    }, [entityImageContainer, cardLabelsContainer]);
                    var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                        key: "swipeContentContainer" + this.regardingData[cardData].cardId,
                        id: "swipeContentContainer" + this.regardingData[cardData].cardId,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [cardLabelsMainContainer]);
                    regardingCards.push(swipeContentContainer);
                }
                var regardingCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "regardingCards" + this.regardingData[cardData].cardId,
                    id: "regardingCards" + this.regardingData[cardData].cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, regardingCards);
                var regardingCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.regardingData[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                        paddingTop: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                    },
                }, [groupTitle, regardingCardsContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "regardingMCards" + accessibilityFocusId,
                    id: "regardingMCards" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        marginBottom: this._context.theming.measures.measure050,
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, regardingCardsMainContainer);
            };
            ProductivityCardControl.prototype.renderNewsCardView = function (card, accessibilityFocusId) {
                this.news = CardFeedContainer.CardService.news;
                var newsCards = [];
                if (this.news.length == 0) {
                    return null;
                }
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var groupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "newsGroupTitle" + accessibilityFocusId,
                    id: "newsGroupTitle" + accessibilityFocusId,
                    title: this.news[0].softTitle,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.news[0].cardName),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                }, this.news[0].softTitle);
                var cardData;
                for (cardData in this.news) {
                    var imageElement = void 0;
                    if (this.news[cardData].data.cardRelatedInfo.newsImage !== "") {
                        imageElement = this._context.factory.createElement("IMG", {
                            key: "imageElement" + cardData,
                            id: "imageElement" + cardData,
                            source: this.news[cardData].data.cardRelatedInfo.newsImage,
                            style: {
                                fontSize: this._context.theming.fontsizes.font100,
                                cursor: "pointer",
                                width: this._context.theming.measures.measure300,
                                height: this._context.theming.measures.measure300,
                            },
                        });
                    }
                    else {
                        imageElement = this._context.factory.createElement("MICROSOFTICON", {
                            id: "imginfo_id" + this.news[cardData].cardId,
                            key: "imginfo_key" + this.news[cardData].cardId,
                            style: {
                                margin: "0 auto",
                                fontSize: this._context.theming.fontsizes.lfontsize,
                            },
                            type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                        });
                    }
                    var cardIcon = this._context.factory.createElement("CONTAINER", {
                        id: "cardIcon" + cardData,
                        key: "cardIcon" + cardData,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure015,
                            fontSize: this._context.theming.fontsizes.font100,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            overflow: "hidden",
                            alignItems: "center",
                            backgroundColor: "#e2e2e2",
                            display: "block",
                            color: this._context.theming.colors.base.black,
                        },
                    }, imageElement);
                    var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                        id: "iconContainer" + cardData,
                        key: "iconContainer" + cardData,
                        style: {
                            textAlign: "center",
                            marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                            paddingRight: this._context.theming.measures.measure075,
                        },
                    }, cardIcon);
                    var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                        key: "cardTitleDescriptionId" + cardData,
                        id: "cardTitleDescriptionId" + cardData,
                        accessibilityLabel: this.news[cardData].title,
                        style: {
                            display: "none",
                        },
                    }, "");
                    var cardDescription = this._context.factory.createElement("LABEL", {
                        key: "cardDescription" + cardData,
                        id: "cardDescription" + cardData,
                        title: this.news[cardData].title,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            marginTop: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            color: this._context.theming.colors.grays.gray07,
                            textOverflow: "ellipsis",
                            paddingBottom: this._context.theming.measures.measure075,
                        },
                    }, this.news[cardData].title);
                    var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsContainer" + cardData,
                        id: "cardLabelsContainer" + cardData,
                        style: {
                            display: "block",
                        },
                    }, [cardDescription, cardTitleDescriptionId]);
                    var anchorElement = this._context.factory.createElement("HYPERLINK", {
                        key: "newsItemLink" + cardData,
                        id: "newsItemLink" + cardData,
                        href: this.news[cardData].data.cardRelatedInfo.link,
                        accessibilityLabel: this.news[cardData].title,
                        title: this.news[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                        onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                        target: "_blank",
                        style: {
                            display: "block",
                            "text-decoration": "none",
                        },
                    }, cardLabelsContainer);
                    var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsMainContainer" + cardData,
                        id: "cardLabelsMainContainer" + cardData,
                        style: {
                            display: "flex",
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                        },
                    }, [cardIconContainer, anchorElement]);
                    var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                        key: "swipeContentContainer" + cardData,
                        id: "swipeContentContainer" + cardData,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [cardLabelsMainContainer]);
                    newsCards.push(swipeContentContainer);
                }
                var newsCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "newsCards" + cardData,
                    id: "newsCards" + cardData,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, newsCards);
                var newsCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.news[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                        padding: this._context.theming.measures.measure100,
                    },
                }, [groupTitle, newsCardsContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, newsCardsMainContainer);
            };
            ProductivityCardControl.prototype.renderNearByGroupCardView = function (card, accessibilityFocusId) {
                this.nearyByData = CardFeedContainer.CardService.nearByCust;
                if (this.nearyByData.length == 0) {
                    return null;
                }
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var nearByGgroupTitlePlusIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitlePlusIcon" + accessibilityFocusId,
                    key: "groupTitlePlusIcon" + accessibilityFocusId,
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: "0.65rem",
                        paddingRight: this._context.theming.measures.measure050,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 198,
                });
                var nearByGgroupTitleRightArrowIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "groupTitleRightArrowIcon" + accessibilityFocusId,
                    key: "groupTitleRightArrowIcon" + accessibilityFocusId,
                    tabIndex: 0,
                    role: "button",
                    accessibilityLabel: this.ccfScope._context.resources.getString("ActionCard.GroupCardView.ShowMore_AccessibilityText"),
                    style: {
                        margin: "0",
                        fontWeight: "bold",
                        lineHeight: this._context.theming.measures.measure150,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray05,
                    },
                    type: 62,
                });
                var nearByGstatic3Label = this._context.factory.createElement("LABEL", {
                    key: "static3Label" + accessibilityFocusId,
                    id: "static3Label" + accessibilityFocusId,
                    style: {
                        color: this._context.theming.colors.base.black,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                    },
                }, "3");
                var nearByGgroupcount = this._context.factory.createElement("CONTAINER", {
                    key: "groupcount" + accessibilityFocusId,
                    id: "groupcount" + accessibilityFocusId,
                    style: {
                        fontSize: this._context.theming.measures.measure100,
                        padding: this._context.theming.measures.measure050,
                    },
                }, [nearByGstatic3Label, nearByGgroupTitlePlusIcon, nearByGgroupTitleRightArrowIcon]);
                if (this.nearyByData.length == 3) {
                    nearByGgroupTitlePlusIcon = null;
                }
                else if (this.nearyByData.length < 3) {
                    nearByGgroupcount = null;
                }
                if (this.nearyByData.length == 0) {
                    return null;
                }
                var nearByGgroupTitle = this._context.factory.createElement("CONTAINER", {
                    key: "nearByGGroupTitle" + accessibilityFocusId,
                    id: "nearByGGroupTitle" + accessibilityFocusId,
                    tabIndex: 0,
                    title: this.nearyByData[0].softTitle,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(this.attendeeData && this.attendeeData.length > 0 ? this.attendeeData[0].cardName : ""),
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                }, this.nearyByData[0].softTitle);
                var nearByGgroupTitleContainer = this._context.factory.createElement("CONTAINER", {
                    key: "groupTitleContainer" + accessibilityFocusId,
                    id: "groupTitleContainer" + accessibilityFocusId,
                    style: {
                        display: "flex",
                    },
                    onClick: nearByGgroupcount
                        ? this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, this.nearyByData, this.ccfScope, "nearby")
                        : null,
                }, [nearByGgroupTitle, nearByGgroupcount]);
                var firstThreeCards = [];
                var gncards = [];
                firstThreeCards = this.nearyByData.slice(0, 3);
                var cardData;
                for (cardData in firstThreeCards) {
                    var img_entity = this.nearyByData[cardData].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = this.nearyByData[cardData].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var nearByGuserImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + card,
                        id: "userImageElement" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var nearByGentityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + card,
                        key: "entityImageContainer" + card,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: "#333333",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, nearByGuserImageElement);
                    var nearByGcardDueTitle = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + this.nearyByData[cardData].cardId,
                        id: "cardDueTitle" + this.nearyByData[cardData].cardId,
                        title: this.nearyByData[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        accessibilityLabel: this.nearyByData[cardData].title,
                        style: {
                            color: this._context.theming.colors.base.black,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                        },
                    }, this.nearyByData[cardData].title);
                    var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                        key: "cardTitleDescriptionId" + this.nearyByData[cardData].cardId,
                        id: "cardTitleDescriptionId" + this.nearyByData[cardData].cardId,
                        accessibilityLabel: this.nearyByData[cardData].description,
                        style: {
                            display: "none",
                        },
                    }, "");
                    var nearByGcardDescription = this._context.factory.createElement("LABEL", {
                        key: "cardDescription" + this.nearyByData[cardData].cardId,
                        id: "cardDescription" + this.nearyByData[cardData].cardId,
                        title: this.nearyByData[cardData].description,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            marginTop: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            color: this._context.theming.colors.grays.gray07,
                            textOverflow: "ellipsis",
                            paddingBottom: this._context.theming.measures.measure075,
                        },
                    }, this.nearyByData[cardData].description);
                    var nearByGcardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsContainer" + this.nearyByData[cardData].cardId,
                        id: "cardLabelsContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            display: "block",
                        },
                    }, [nearByGcardDueTitle, nearByGcardDescription, cardTitleDescriptionId]);
                    var nearByGcardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsMainContainer" + this.nearyByData[cardData].cardId,
                        id: "cardLabelsMainContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            display: "flex",
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                        },
                        onClick: nearByGgroupcount
                            ? this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, this.nearyByData, this.ccfScope, "nearby")
                            : this.openCardForm.bind(this, {
                                entityName: this.nearyByData[cardData].data.cardContextDetails[0].contextObject.entityName,
                                entityId: this.nearyByData[cardData].data.cardContextDetails[0].contextObject.guid,
                            }),
                    }, [nearByGentityImageContainer, nearByGcardLabelsContainer]);
                    var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                        key: "swipeContentContainer" + this.nearyByData[cardData].cardId,
                        id: "swipeContentContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [nearByGcardLabelsMainContainer]);
                    gncards.push(swipeContentContainer);
                }
                var nearByGContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearByGCards" + this.nearyByData[cardData].cardId,
                    id: "nearByGCards" + this.nearyByData[cardData].cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, gncards);
                var nearByGCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.nearyByData[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                        paddingTop: this._context.theming.measures.measure100,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                    },
                }, [nearByGgroupTitleContainer, nearByGContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "nearByGMCards" + accessibilityFocusId,
                    id: "nearByGMCards" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, nearByGCardsMainContainer);
            };
            ProductivityCardControl.prototype.renderNearByCardView = function (cards, accessibilityFocusId) {
                this.nearyByData = cards;
                var nearByCards = [];
                if (this.nearyByData.length == 0) {
                    return null;
                }
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var cardData;
                for (cardData in this.nearyByData) {
                    var img_entity = this.nearyByData[cardData].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = this.nearyByData[cardData].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + this.nearyByData[cardData].cardId,
                        id: "userImageElement" + this.nearyByData[cardData].cardId,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var userImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "userImageContainer" + this.nearyByData[cardData].cardId,
                        key: "userImageContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: "#333333",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, userImageElement);
                    var cardDueTitle = this._context.factory.createElement("LABEL", {
                        key: "cardDueTitle" + this.nearyByData[cardData].cardId,
                        id: "cardDueTitle" + this.nearyByData[cardData].cardId,
                        title: this.nearyByData[cardData].title,
                        accessibilityLabel: this.nearyByData[cardData].title,
                        focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                        tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                        style: {
                            color: this._context.theming.colors.base.black,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            fontWeight: "400",
                            lineHeight: "1.4rem",
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                        },
                    }, this.nearyByData[cardData].title);
                    var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                        key: "cardTitleDescriptionId" + this.nearyByData[cardData].cardId,
                        id: "cardTitleDescriptionId" + this.nearyByData[cardData].cardId,
                        accessibilityLabel: this.nearyByData[cardData].description +
                            " " +
                            CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.NearbyCustomers.Employees.Text"),
                        style: {
                            display: "none",
                        },
                    }, "");
                    var cardDescription = this._context.factory.createElement("LABEL", {
                        key: "cardDescription" + this.nearyByData[cardData].cardId,
                        id: "cardDescription" + this.nearyByData[cardData].cardId,
                        title: this.nearyByData[cardData].description,
                        style: {
                            display: "block",
                            padding: this._context.theming.measures.measure015,
                            marginTop: this._context.theming.measures.measure015,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            fontSize: this._context.theming.fontsizes.font100,
                            cursor: "pointer",
                            color: this._context.theming.colors.grays.gray07,
                            textOverflow: "ellipsis",
                            paddingBottom: this._context.theming.measures.measure075,
                        },
                    }, this.nearyByData[cardData].description +
                        " " +
                        CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.NearbyCustomers.Employees.Text"));
                    var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsContainer" + this.nearyByData[cardData].cardId,
                        id: "cardLabelsContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            display: "block",
                        },
                    }, [cardDueTitle, cardDescription, cardTitleDescriptionId]);
                    var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                        key: "cardLabelsMainContainer" + this.nearyByData[cardData].cardId,
                        id: "cardLabelsMainContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            display: "flex",
                            padding: this._context.theming.measures.measure050,
                        },
                        onClick: this.openCardForm.bind(this, {
                            entityName: this.nearyByData[cardData].data.cardContextDetails[0].contextObject.entityName,
                            entityId: this.nearyByData[cardData].data.cardContextDetails[0].contextObject.guid,
                        }),
                    }, [userImageContainer, cardLabelsContainer]);
                    var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                        key: "swipeContentContainer" + this.nearyByData[cardData].cardId,
                        id: "swipeContentContainer" + this.nearyByData[cardData].cardId,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            borderTop: this._context.theming.borders.border02,
                            width: "100%",
                            display: "block",
                            position: "relative",
                            cursor: "pointer",
                        },
                    }, [cardLabelsMainContainer]);
                    nearByCards.push(swipeContentContainer);
                }
                var nearyByCardsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearByCards" + this.nearyByData[cardData].cardId,
                    id: "nearByCards" + this.nearyByData[cardData].cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, nearByCards);
                var nearByCardsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearByCardsContainer" + this.nearyByData[cardData].cardId,
                    id: "nearByCardsContainer" + this.nearyByData[cardData].cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [nearyByCardsContainer]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this.nearyByData[0].softTitle),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", null, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                    },
                }, nearByCardsMainContainer);
            };
            ProductivityCardControl.prototype.openCardForm = function (formDetails) {
                this._context.navigation.openForm(formDetails);
            };
            return ProductivityCardControl;
        }());
        CardFeedContainer.ProductivityCardControl = ProductivityCardControl;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var RelationshipAssitantSdkContracts;
(function (RelationshipAssitantSdkContracts) {
    var Guid = (function () {
        function Guid(userId) {
            this.guid = userId;
        }
        return Guid;
    }());
    RelationshipAssitantSdkContracts.Guid = Guid;
    var PopulateCardRequest = (function () {
        function PopulateCardRequest(userId) {
            this.UserId = new Guid(userId);
        }
        PopulateCardRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    UserId: {
                        typeName: "Edm.Guid",
                        structuralProperty: 1,
                    },
                },
                operationName: "PopulateCard",
                operationType: 0,
            };
            return metadata;
        };
        return PopulateCardRequest;
    }());
    RelationshipAssitantSdkContracts.PopulateCardRequest = PopulateCardRequest;
    var RetrieveCardDataRequest = (function () {
        function RetrieveCardDataRequest(cardTypeId, additionalParameter) {
            this.CardTypeId = new Guid(cardTypeId);
            this.AdditionalParameter = additionalParameter;
        }
        RetrieveCardDataRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    CardTypeId: {
                        typeName: "Edm.Guid",
                        structuralProperty: 1,
                    },
                    AdditionalParameter: {
                        typeName: "Edm.String",
                        structuralProperty: 1,
                    },
                },
                operationName: "RetrieveCardData",
                operationType: 0,
            };
            return metadata;
        };
        return RetrieveCardDataRequest;
    }());
    RelationshipAssitantSdkContracts.RetrieveCardDataRequest = RetrieveCardDataRequest;
})(RelationshipAssitantSdkContracts || (RelationshipAssitantSdkContracts = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var FlightCardControl = (function () {
            function FlightCardControl(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
            }
            FlightCardControl.prototype.generateAdditionalData = function (cardData) {
                var promises = [];
                promises.push(CardFeedContainer.CardService.getNearbyCustomers(cardData.data.cardRelatedInfo.arrivalAirport.name, cardData.data.cardRelatedInfo.bingApiKey, "", cardData));
                var params = { logicalName: "flightMeeting", dateTime: cardData.data.cardRelatedInfo.arrivalTime };
                promises.push(CardFeedContainer.CardService.getFlightRegardingData(params, cardData));
                return Promise.all(promises);
            };
            FlightCardControl.prototype.renderCards = function (card, accessibilityFocusId) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + card.cardId,
                    key: "imginfo_key" + card.cardId,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                });
                var cardIcon = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + card.cardId,
                    key: "cardIcon" + card.cardId,
                    style: {
                        width: "3rem",
                        height: "3rem",
                        lineHeight: "3rem",
                        marginRight: "0.15rem",
                        fontSize: "1rem",
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "1.5rem",
                        backgroundColor: "#e2e2e2",
                        display: "block",
                    },
                }, imginfoControl);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + card.cardId,
                    key: "iconContainer" + card.cardId,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                        paddingRight: this._context.theming.measures.measure075,
                    },
                }, cardIcon);
                var departureTimeUTC = new Date(CardFeedContainer.CardUtils.getCCFUserTime(moment.utc(card.data.cardRelatedInfo.departureTime)));
                var cardheadtitle = card.softTitle
                    ? MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartInfo"), CardFeedContainer.CardUtils.getCCFLocaleFormat(departureTimeUTC, "MMM dd"), CardFeedContainer.CardUtils.getCCFLocaleFormat(departureTimeUTC, "t"))
                    : "";
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + card.cardId,
                    id: "cardDueTitle" + card.cardId,
                    tabIndex: 0,
                    title: card.softTitle
                        ? MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartInfo"), CardFeedContainer.CardUtils.getCCFLocaleFormat(departureTimeUTC, "MMM dd"), CardFeedContainer.CardUtils.getCCFLocaleFormat(departureTimeUTC, "t"))
                        : "",
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(card.cardName),
                        fontSize: "1rem",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        width: "calc(100% - 3.5rem)",
                        display: "block",
                    },
                }, cardheadtitle);
                var cardTitle = this._context.factory.createElement("LABEL", {
                    key: "cardTitle" + card.cardId,
                    id: "cardTitle" + card.cardId,
                    title: card.data.cardRelatedInfo.provider.name +
                        " . " +
                        card.data.cardRelatedInfo.provider.iataCode +
                        " " +
                        card.data.cardRelatedInfo.flightNumber,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                    },
                }, card.data.cardRelatedInfo.provider.name +
                    " . " +
                    card.data.cardRelatedInfo.provider.iataCode +
                    " " +
                    card.data.cardRelatedInfo.flightNumber);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                        width: "calc(100% - 4rem)",
                    },
                }, [cardDueTitle, cardTitle]);
                var cardLabelsIconContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsIconContainer" + card.cardId,
                    id: "cardLabelsIconContainer" + card.cardId,
                    style: {
                        display: "flex",
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, [cardIconContainer, cardLabelsContainer]);
                var diffInMinutes = moment.utc(card.data.cardRelatedInfo.departureTime).diff(moment.utc(), "minutes");
                var hours = 0;
                var description;
                var descrpText;
                hours = diffInMinutes / 60;
                hours = hours | 0;
                var minutes = diffInMinutes - hours * 60;
                if (diffInMinutes < 0) {
                    diffInMinutes = diffInMinutes * -1;
                    hours = hours * -1;
                    minutes = minutes * -1;
                    descrpText =
                        hours > 0
                            ? CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartedHMText")
                            : CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartedText");
                    descrpText =
                        hours > 0
                            ? MscrmCommon.ControlUtils.String.Format(descrpText, hours, minutes)
                            : MscrmCommon.ControlUtils.String.Format(descrpText, diffInMinutes);
                }
                else {
                    if (hours > 0) {
                        descrpText = CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartHMText");
                        descrpText = MscrmCommon.ControlUtils.String.Format(descrpText, hours, minutes);
                    }
                    else {
                        descrpText = CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.DepartMText");
                        descrpText = MscrmCommon.ControlUtils.String.Format(descrpText, minutes);
                    }
                }
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + card.cardId,
                    id: "cardTitleDescriptionId" + card.cardId,
                    accessibilityLabel: descrpText,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + card.cardId,
                    id: "cardDescription" + card.cardId,
                    title: descrpText,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.grays.gray07,
                        textOverflow: "ellipsis",
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, descrpText);
                var arrivalTimeUTC = new Date(CardFeedContainer.CardUtils.getCCFUserTime(moment.utc(card.data.cardRelatedInfo.arrivalTime)));
                var arrivalTime = CardFeedContainer.CardUtils.getCCFLocaleFormat(arrivalTimeUTC, "t");
                var depTimeUTC = new Date(CardFeedContainer.CardUtils.getUserTime(moment.utc(card.data.cardRelatedInfo.departureTime), "", CardFeedContainer.CardFeedContainer.cfcContext));
                var depTime = depTimeUTC.localeFormat("t");
                var arrivalIataCode = card.data.cardRelatedInfo.arrivalAirport.iataCode.toUpperCase();
                var arrivalAirport = this._context.factory.createElement("LABEL", {
                    key: "arrivalAirport" + card.cardId,
                    id: "arrivalAirport" + card.cardId,
                    title: card.data.cardRelatedInfo.arrivalAirport.iataCode,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.semilight,
                        fontSize: this._context.theming.fontsizes.font175,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        textOverflow: "ellipsis",
                    },
                }, arrivalIataCode);
                var arrivalAirportTime = this._context.factory.createElement("LABEL", {
                    key: "arrivalAirportTime" + card.cardId,
                    id: "arrivalAirportTime" + card.cardId,
                    title: arrivalTime,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font085,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        textOverflow: "ellipsis",
                    },
                }, arrivalTime);
                var arrivalContainer = this._context.factory.createElement("CONTAINER", {
                    key: "arrivalContainer" + card.cardId,
                    id: "arrivalContainer" + card.cardId,
                    style: {
                        display: "block",
                        marginLeft: this._context.theming.measures.measure075,
                        width: "20%",
                    },
                }, [arrivalAirport, arrivalAirportTime]);
                var depIataCode = card.data.cardRelatedInfo.departureAirport.iataCode.toUpperCase();
                var depAirport = this._context.factory.createElement("LABEL", {
                    key: "depAirport" + card.cardId,
                    id: "depAirport" + card.cardId,
                    title: card.data.cardRelatedInfo.departureAirport.iataCode,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.semilight,
                        fontSize: this._context.theming.fontsizes.font175,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        textOverflow: "ellipsis",
                    },
                }, depIataCode);
                var depAirportTime = this._context.factory.createElement("LABEL", {
                    key: "depAirportTime" + card.cardId,
                    id: "depAirportTime" + card.cardId,
                    title: depTime,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font085,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        textOverflow: "ellipsis",
                    },
                }, depTime);
                var depContainer = this._context.factory.createElement("CONTAINER", {
                    key: "depContainer" + card.cardId,
                    id: "depContainer" + card.cardId,
                    style: {
                        display: "block",
                        marginRight: this._context.theming.measures.measure075,
                        width: "20%",
                    },
                }, [depAirport, depAirportTime]);
                var depLine = this._context.factory.createElement("CONTAINER", {
                    key: "depLine" + card.cardId,
                    id: "depLine" + card.cardId,
                    style: {
                        display: "block",
                        height: "1px",
                        width: "45%",
                        marginTop: this._context.theming.measures.measure150,
                        backgroundColor: this._context.theming.colors.grays.gray05,
                    },
                }, "");
                var flightinfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "flightinfoControl" + card.cardId,
                    key: "flightinfoControl" + card.cardId,
                    style: {
                        fontSize: "16px",
                        color: this._context.theming.colors.grays.gray07,
                        marginTop: this._context.theming.measures.measure100,
                        marginLeft: this._context.theming.measures.measure075,
                        marginRight: this._context.theming.measures.measure075,
                    },
                    type: 184,
                });
                var arrLine = this._context.factory.createElement("CONTAINER", {
                    key: "arrLine" + card.cardId,
                    id: "arrLine" + card.cardId,
                    style: {
                        display: "block",
                        height: "1px",
                        width: "45%",
                        marginTop: this._context.theming.measures.measure150,
                        backgroundColor: this._context.theming.colors.grays.gray05,
                    },
                }, "");
                var depLineMinContainer = this._context.factory.createElement("CONTAINER", {
                    key: "depLineMinContainer" + card.cardId,
                    id: "depLineMinContainer" + card.cardId,
                    style: {
                        display: "flex",
                    },
                }, [depLine, flightinfoControl, arrLine]);
                var depLineContainer = this._context.factory.createElement("CONTAINER", {
                    key: "depLineContainer" + card.cardId,
                    id: "depLineContainer" + card.cardId,
                    style: {
                        display: "block",
                        width: "100%",
                    },
                }, [depLineMinContainer]);
                var nearByCust = CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId];
                var nearbyIcons = [];
                for (var cardData in nearByCust) {
                    var img_entity = nearByCust[cardData].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = nearByCust[cardData].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + nearByCust[cardData].cardId,
                        id: "userImageElement" + nearByCust[cardData].cardId,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + nearByCust[cardData].cardId,
                        key: "entityImageContainer" + nearByCust[cardData].cardId,
                        style: {
                            width: "3rem",
                            height: "3rem",
                            lineHeight: "3rem",
                            marginRight: "0.75rem",
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            color: "#333333",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, userImageElement);
                    nearbyIcons.push(entityImageContainer);
                }
                var airportInfoContainer = this._context.factory.createElement("CONTAINER", {
                    key: "airportInfoContainer" + card.cardId,
                    id: "airportInfoContainer" + card.cardId,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    title: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.FlightCard_Label"), card.data.cardRelatedInfo.departureAirport.iataCode, depTime, card.data.cardRelatedInfo.arrivalAirport.iataCode, arrivalTime),
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.FlightCard_Label"), card.data.cardRelatedInfo.departureAirport.iataCode, depTime, card.data.cardRelatedInfo.arrivalAirport.iataCode, arrivalTime),
                    style: {
                        display: "flex",
                        borderBottom: nearbyIcons.length > 0 ? "1px solid #ccc" : "",
                        paddingBottom: this._context.theming.measures.measure075,
                        ":focus": {
                            border: "2px dashed #000",
                        },
                    },
                }, [depContainer, depLineContainer, arrivalContainer]);
                var nearByIconsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearByIconsContainer" + card.cardId,
                    id: "nearByIconsContainer" + card.cardId,
                    style: {
                        display: "flex",
                        ":focus": {
                            border: "2px dashed #000",
                        },
                    },
                }, nearbyIcons);
                var nearBylabel = this._context.factory.createElement("LABEL", {
                    key: "nearBylabel" + card.cardId,
                    id: "nearBylabel" + card.cardId,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.grays.gray07,
                        textOverflow: "ellipsis",
                        margin: "0 auto",
                        width: "100%",
                        lineHeight: "2.5rem",
                    },
                }, MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.FlightCard.NearbyCustomers.Text"), CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId] ? CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId].length : "", card.data.cardRelatedInfo.arrivalAirport.iataCode));
                var nearBylabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearBylabelContainer" + card.cardId,
                    id: "nearBylabelContainer" + card.cardId,
                    style: {
                        display: "flex",
                        ":focus": {
                            border: "2px dashed #000",
                        },
                    },
                }, nearBylabel);
                var nearByContainer = this._context.factory.createElement("CONTAINER", {
                    key: "nearByContainer" + card.cardId,
                    id: "nearByContainer" + card.cardId,
                    title: MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.FlightCard.NearbyCustomers.Text"), CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId]
                        ? CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId].length
                        : "", card.data.cardRelatedInfo.arrivalAirport.iataCode),
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.FlightCard.NearbyCustomers.Text"), CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId]
                        ? CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId].length
                        : "", card.data.cardRelatedInfo.arrivalAirport.iataCode),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    style: {
                        display: "flex",
                        paddingTop: this._context.theming.measures.measure050,
                        paddingBottom: this._context.theming.measures.measure050,
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        width: "calc(100 % - 30px)",
                        ":focus": {
                            border: "2px dashed #000",
                        },
                    },
                    onClick: this.ccfScope.cardEvents.groupCardClickHandler.bind(this, accessibilityFocusId, CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId], this.ccfScope, "nearby"),
                }, [nearByIconsContainer, nearBylabelContainer]);
                var cardHeadar = [
                    cardLabelsIconContainer,
                    cardDescription,
                    cardTitleDescriptionId,
                    airportInfoContainer,
                ];
                var flightMeetingCards = [];
                var fmcards = [];
                if (CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId])
                    flightMeetingCards = CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId];
                if (CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId] &&
                    CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId].length > 3)
                    flightMeetingCards = CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId].slice(0, 3);
                for (var index = 0; index < flightMeetingCards.length; index++) {
                    cardHeadar.push(this.renderflightMeetingCardView(card, flightMeetingCards[index]));
                }
                var mailLink = this._context.factory.createElement("HYPERLINK", {
                    key: "mailLink" + card.cardId,
                    id: "mailLink" + card.cardId,
                    href: card.data.mailweblink,
                    target: "_blank",
                    tabIndex: -1,
                    style: {
                        display: "block",
                        textDecoration: "none",
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        ":visited": { color: this._context.theming.colors.basecolor.black },
                    },
                }, cardHeadar);
                var cardHeadContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                    },
                }, [mailLink, nearbyIcons.length > 0 ? nearByContainer : ""]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + card.cardId,
                    id: "cardLabelsMainContainer" + card.cardId,
                    style: {
                        alignItems: "center",
                        paddingBottom: this._context.theming.measures.measure050,
                        display: "block",
                        width: "100%",
                    },
                }, cardHeadContainer);
                var deptMin = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.CFC.UpcomingFlight.DepartedText"), moment.utc().diff(moment.utc(card.data.cardRelatedInfo.departureTime), "minutes"));
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cardheadtitle + " " + deptMin),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: "1px solid #ccc",
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: "translate3d(0px, 0px, 0px)",
                        transformStyle: "preserve-3d",
                        transition: "transform .3s linear",
                        width: "calc(100 % - 2px)",
                        ":focus": {
                            border: "1px dashed #000",
                        },
                        overflow: "auto",
                    },
                }, cardLabelsMainContainer);
            };
            FlightCardControl.prototype.renderflightMeetingCardView = function (card, mCard) {
                var img_entity = mCard.data.cardContextDetails[0].contextObject.entityImgUrl;
                var entityName = mCard.title;
                var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                    key: "userImageElement" + mCard.cardId,
                    id: "userImageElement" + mCard.cardId,
                    style: {
                        color: this._context.theming.colors.basecolor.white,
                        fontSize: this._context.theming.fontsizes.font100,
                        margin: "0 auto",
                        width: "100%",
                    },
                    hasPrimaryImageField: true,
                    tabIndex: 0,
                    mode: entityImageMode,
                    imageSrc: img_entity,
                    entityPrimaryField: entityName,
                });
                var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                    id: "entityImageContainer" + mCard.cardId,
                    key: "entityImageContainer" + mCard.cardId,
                    style: {
                        width: "3rem",
                        height: "3rem",
                        lineHeight: "3rem",
                        marginRight: "0.75rem",
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        float: "left",
                        textAlign: "center",
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#e2e2e2",
                    },
                }, userImageElement);
                var formatedTitle = CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.SoftTitle");
                if (formatedTitle.indexOf(":") != -1) {
                    var titleArray = formatedTitle.split(":");
                    if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                        formatedTitle = titleArray[1];
                    }
                }
                if (mCard.data && mCard.data.cardRelatedInfo && mCard.data.cardRelatedInfo.starttime) {
                    var startTime = moment.utc(mCard.data.cardRelatedInfo.starttime).toISOString();
                    formatedTitle = CardFeedContainer.Utils.softTitleGenerator(formatedTitle, startTime, this._context);
                }
                else {
                    formatedTitle = CardFeedContainer.Utils.softTitleGenerator(formatedTitle, mCard.startDate, this._context);
                }
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + mCard.cardId,
                    id: "cardDueTitle" + mCard.cardId,
                    title: formatedTitle,
                    accessibilityLabel: formatedTitle,
                    style: {
                        color: this._context.theming.colors.base.black,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, formatedTitle);
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + mCard.cardId,
                    id: "cardTitleDescriptionId" + mCard.cardId,
                    accessibilityLabel: mCard.description,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + mCard.cardId,
                    id: "cardDescription" + mCard.cardId,
                    title: mCard.data.cardContextDetails[0].contextPrimaryInfo.title,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure015,
                        marginTop: this._context.theming.measures.measure015,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.grays.gray07,
                        textOverflow: "ellipsis",
                        paddingBottom: this._context.theming.measures.measure075,
                    },
                }, mCard.data.cardContextDetails[0].contextPrimaryInfo.title);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + mCard.cardId,
                    id: "cardLabelsContainer" + mCard.cardId,
                    style: {
                        display: "block",
                    },
                }, [cardDueTitle, cardDescription, cardTitleDescriptionId]);
                var clmc = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + mCard.cardId,
                    id: "cardLabelsMainContainer" + mCard.cardId,
                    style: {
                        display: "flex",
                    },
                }, [entityImageContainer, cardLabelsContainer]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "fmMainContainer" + mCard.cardId,
                    id: "fmMainContainer" + mCard.cardId,
                    style: {
                        display: "flex",
                        paddingTop: this._context.theming.measures.measure050,
                        paddingBottom: this._context.theming.measures.measure050,
                        borderBottom: CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId].length > 0 ? "1px solid #ccc" : "",
                    },
                }, clmc);
            };
            return FlightCardControl;
        }());
        CardFeedContainer.FlightCardControl = FlightCardControl;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var GettingStarted = (function () {
            function GettingStarted(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
            }
            GettingStarted.prototype.renderLetsGoCard = function () {
                var container1 = [];
                var container2 = [];
                var welcomeMessage1 = this._context.resources.getString("ActionCard.CFC.Common.WelcomeMessage1");
                var welcomeMessage2 = this._context.resources.getString("ActionCard.CFC.Common.WelcomeMessage2");
                var welcomeMessage3 = this._context.resources.getString("ActionCard.CFC.Common.WelcomeMessage3");
                var letsGobtnLabel = this._context.resources.getString("ActionCard.CFC.Common.LetsGoBtnText");
                var contentToBeLoaded;
                var emptyStateImg = this._context.factory.createElement("CONTAINER", {
                    key: "emptyStateImg",
                    id: "emptyStateImg",
                    style: {
                        backgroundImage: "url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAUTAAAFEwBRo1vywAAABZ0RVh0Q3JlYXRpb24gVGltZQAwOC8wOC8xNhj+FZwAAAAcdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3JrcyBDUzbovLKMAAAUSklEQVR4nOWde2xb133HP/fBxz28VxYpUjL1sOIkqqM4dlo3Mfp00q3D1hXt0G4YsBbFBqxA+1+BYQPatejQbthaFFjXx7B22No07dJn+sjaFW2zNm0cN1ZjJ27qV9RYli2blijSlHh1SZG85P44JE0pevBxKdnaFwigSPee8zO/PL/X+f3OUSqVCjsdjuO8B/gj4OfAZ4UQS9ss0rpQdjohjuN8APhrIASogAP8K/ApIcTcdsq2FnY0IY7jjALHgdjS0tIvg8GgrmnaK5HEXAe+AnxGCPHidsrZiJ1OyCeAv3Jd95l0On0YQNf1C5ZlXdV1/TCgARngO8AnhBAvbKO4wA4mxHGcEHAFsDKZzNlisbi/8e+aps1YlnXB5/O9EggAy8DjwEeB54UQxS0XGrl0dyr+BjDL5fJzq8kAcF13OJPJHEmlUkuFQuEoUAbeAhwFfuQ4zuu3WF5gh64Qx3GiwPNA/+Li4qnl5eVXbPaOoigLlmU9GwgEDgBhoIi0Px8SQjzZXYkb5NihhHwI+HClUjk/Pz9/TyvvKoqyFAqFnjEM42XAAFACzgAfB34ghMh6L3HD/DuNEMdx+oBfAXuy2eyJfD5/uM2hiqFQ6GkhxDCwB3CBF4HPAo8IITLeSLwSO5GQ9wKfrlQqF+bn5/d5MKRrGMbxUCgUVRTlDiQxV4DPAJ8TQuQ8mKOOnUjIBWDUtu3juVzu1V6OHQwGJ0zTFIqi3A1UgCzwz8C/CSHmvZhjRxHiOM7bgK8DV5LJ5B665EX6/f7nLMtyVVWtOQvzwCPAvwghpjsZe6cRch6403Gcp5aWlrrutvp8vjOWZS1qmnZf9VcZ4NvAx4QQU+2MuWMIcRzn7cDXgLlkMtkP+LZq7lXRvwosAT8C/g54QQhRbnasHUGI4zgB4JfAvblc7knbth/YDjlWRf9BoIAMND8shHi6mTF2CiFvBh4FsvPz82alUglupzyqqs5ZlnXG7/ffBwhkWmYCeP9mxNzyhDiO4wOeAF6Vz+efzGaz27I61kJD9H8PN6L/E8CHgaNCiMJL3rlVCFEUZc3fLy0tvQ74CZCbn5/XKpVKz5YK1gRWRf/9yOj/PPBJ4LuNQeZOIOSnwJHl5eUnFxcXH9xSoVpHLfofAUaQQeYMMpb5ghAid0sTsrS0dB9yW7acSqUK5XI5suWCtYfG6P9OZKY5BXzwpibEcZwg8CbgncAhpGF8bygUygAsLS19D3hzoVA4urCwcNPYjlZQjf4NRVHuAYo3JSGO4zwAvA/4HcBA7uxVkN+k48BbkQm/o4A/lUplyuXywDaJ6wmCweCEZVn36dstCIDjOAZwBHgH8PtABEkClUrl8sLCwtSVK1d279u3r1gNvh4A3gWEisXi0XK5fGS7ZPcKuq7nALaNEMdxepEf7B8DDyK9Dx3paNRJyGazdwGjAMlk8hfxeFwD3gO8Hihls9nbtkN+j1E0DONOwN1SQqokPIhcCa8GokgS1EqlcjmTyUxdvXp1BQmNSCQS++LxeAVJZMB13add133t1v0LugMhxHHgNcCxrhNSJeGNSBIOI9WRjyZJaEShUBgoFovP+3y+A0B5cXEx3m35twAVIUQcGTR+oCuENHhHf4FcCRYtrISNkE6n+wYGBqhUKoulUul2r2XfagSDwQlFUe4DTgohjnpKiOM4vwe8G6lSemmwCZ2Q0IirV6/GBwYGACxVVSmXm06krgnbtkmlUti2TaEgMxmGYWCaJn19fRiG0dH4m8E0TYGM3D8KHRp1x3EE0rj+GXJFhJHpZ6VSqVzKZDIXvSChEcvLy0qxWFzSdT3k9/vJ5/NtjVMoFJiensa27frv/H4/ALlcjlwuRzKZJBaLEY/H0TTNC/FXwO/3P6coykFkGuVn0AYhDd7RO5BkhJE2YS3v6DavhG/E3NwcQ0NDBAKBtgjJ5XJMTk7iui5+v594PE4kciPILxQK2LbNzMwMyWQS27YZGxvznBTLskrI9MlnagXgTQWG1UqO30W6qK9Bekd1Elapo67D5/Nx6NAhANLpdEtqy3Vdzp07R6FQIBKJMDq6/sJ1XZcLFy5g2zaGYXDXXd7983w+3/ne3t4xIAHcU0swrrtCGryjdwKv4oZN6Ngwd4pisYjjOIRCIQKBALlc84UfiUSCQqGAaZobkgGgaRpjY2OcPn2aXC5HOp1esZI6gWVZKWAM2R5Rz/auIKQaMT+IVEdv5CYiYTVSqVTLhLiuSzKZRNM0br+9eQdtdHSUyclJ5ubmPCFE07RL1X3468DnG/+mw5rekcZNSEIjZmdnGRkZQdd1mvW2agbcNM2W7IFpmhiGQS6Xw3Xdjm2JZVkXgSHgi0KI641/0x3HeRGZqFPoonfkNVzXxbZtLMsiGAziOM6m79SeMU2z5flqhORyubber0FV1bnqnvt14FOr/64DeyqVytVMJnOhgYTb2p5xC5FKpbAsi0Ag0BQhnaDmEncKy7LOAK9DlqPOrP67DiinTp1S8vn8g57MuIWYm5tjz549aJqGpmm4rrvh84FAAKAeALaCVhyH9aAoyqLf778XsJHF2y+BCihDQ0MXOp5tG1Aul1laWkJRlPqHvRFqUXc7H27N/nQSuZum+SwyjfST9droVKAQiURibc+yzZibk32bweDmlT+GYeD3+1smZGFhAdd12bVrV9sGXVGU5WAwuA9Zq/VP6z2nArOapt1lGMbFtmbaZiSTSVzXRVVVdH3zxIPf78d13abVVi3FAtDf39+2nEKICeSez1FkM9GaUJE5lPLQ0NDFtmfbZmSz2abVVs1DaoYQ27brKZZIJNKJd1Wu9pkUgX8QQpTWe1BFVm0XI5HILbu3kEwmgeY8oZq62sgWFAoFJicnmZycbCrFshkMwziODB/OAxtWLurVB2ZVVR0TQkw5jrO37Zm3CalUittvvx1N09B1nVJp3S8gtm3XvbLVcF2XmZkZ0uk0wJqJx3YQCoXCyCTi327W3atWe+Z+jlRbHfU2bCcWFxdRFGVD427bdt01np6eXqG2XNdlcnKSdDqNpmmMjo6yf//+jskIBAInFEV5GXBeCPGDzZ6vWcFHgD8Nh8MjHc2+jZidnSUcDuP3+1EUhbWy2IlEov5zOp2uJwv7+/uZnp4ml8sRiUQYHh72LNVumqaKXB0faeb5WofRMWBOVdW9oVDot55IssXIZDKUSqV1vS3btutp9P3797N79278fj/pdJpz586Ry+UwDIPR0VHPyPD5fKdVVb0X2Sz6/WbeUQGEEDaywaQ8NDT0knD+VsHCwsK63lYmIzPc/f39aJpGPB5n//79DA0NAbScAW4GlmVlkduznxNCNLWT1vhVehh4Vzgcvs1TqVYhFothmibhcJhcLkc+n8e27bqn1AlmZ2fp6+tb09uqfeuz2eyKAK9mU2KxmGf5KpBdVdUUewL4atPvNfz8DDCnKMoey7LOeb37F4/H2bt37wqj29vbW/+5VCpx9uzZjohZXFykWCyi6zo+n49i8YZD09fXRzKZXGE7ent76/P19fW1Pe9asCzrCrLC/aFWjoFasYXrOM7ngb+8fv36k+fPn3/QK+HGx8eJx2WYMz8/z+XLlwEZE4TDYWKxGNFoFJCG9+zZs23PdccddxCLxcjn82SzKw9dcF2Xubm5enRfQywWY3h4uO05V0PTtEQkEgkDOWBMCJFq9t3V1u+LwJ/39vZ6FouMjY0Rj8frUe/16yv2Y0gkEiQSCWKxWJ0427brpLWKa9eurat+arajv7+fVCpFoVBACOHZtmwNpmmeR9Yqf6kVMmBVH3e1/y2lKMpIT0/P6U4FC4fDjIyMUCqVOHPmzEvIaEQymeTkyZOUSiXGxsaaShauhaWlJQqFAqqq4vOt3YiraRr9/f0MDw97Toaqqtf9fv8rkatj3STiuu+v8bvHgMrQ0FDHVnZkRIY1k5OTK+qf1kPjyti7t/1FWiO+20Vua8E0zVPI4wS/1c4hAmsR8hBQ6OnpGetEMF3XiUajlEqlFQHZZpiamiKfz9dtTju4du0aQD1I3CooiuJUGzyzwD+2M8ZLCKlWYl9WFCW+a9eu37QrnGVZwA3/vxXUit/C4XBbc+dyOZaXl1EUZV211Q2EQqFnkEUiPwuFQm0dF7jeWSDfQgaJLRmktbDa0+nWO6tRSxC2a4vaQMkwjNuRKfaPtjvIeoQ8AixblvUyZCtZ26itlFbQzEbTZthqtVXVLHHg6VAo9Gy746xJiBDiNDClKEp/b2/vurtbG6FmWNv5hsZicke5k5WyvLxMLpdreuOqUwgh+pGro6kk4nrY6PiiHyLV1vq+6iawbbueJmkWpmmi63o9WdgJal+KbhNS7fG4A7kBdbyTsTYi5JtAwTTNcWT3a8uoubDj4+NNv1NbHa14ZushkUhQqVTq1Y3dgmmaQWSK/eOhUKi9/ogqNpLyFDCtKEpfJBI51c7giUQC27YJBoMcOnSoKfVVI8SLZGOxWKyrLS8Th43w+/2/rvaYX0EeyNwR1iWkejDKt4ByPB5vW5mfPHmSTCZDb28vhw8frn/g68E0TWzb7lhd1ZBKpbpqRyzLWkZqkPd3ujpg8yPwvgrkTdO8W1GUtj6hUqnEyZMnmZqaQtd1Dhw4wNjY2IaelFdkgPS2KpUKPp/Pc7Wl6/oLqqoeAi6HQqGvezHmZhL+FphUFCXSrtqqYWpqiomJCfL5PCMjIxw8eHDN5/L5fEfFzKvhum5L1Y2toKenJ4kMCz7p1ZgbElKtH/ofwB0cHOy4mtm2bSYmJuoqrJav0nWdeDzO4cOHCQaD6LruaUBXCxK9JETTtBlN0+4HZoFvVioVVv/XDppZw98ACqFQqG211Yha5rdUKrF3714OHjzIkSNHGB8fxzTNetpkM1vTCmpqy0tvy7KsF5EtHI8IIa55MijNEXIOmAbCfX19bUegjcjn83WXOBqN1v//2LFjnDx5EqCj5OJqlMtlbNv2TG2pqpry+Xz3AYus0ePR0dibPVAt7HoMqAwODi57NXGNkHw+z7Fjx5icnCSfz9f32L20I3DDjfZCFZqm+TzykMvvCSGudDxgA5pdv18B8kKIexRFab25Yg2USiXm5+cJBoMrPvx4PN6VhOD8/Hy9Ha2TMh9FUZYCgcDLgTzwMc8ErKIpQqq5rReBnmg02pG31Yjat/buu+9mfHy8bkt0XW97C3c9eKW2TNN8BugBfoz8TDxFKxbuK0B5cHDQkxUCNyJ50zTrNiORSDAxMcHk5KRX09ThgdoqVns8loGPtHJAcrNo+kS5ahH2KUCZmJjQy+WyZ3qllnzcaM/dK9x///2oqtpW8jIUCj0phHgt8h6Rt3ZDvqZXSPUs8xcAIxaLPeelENevX98SMuBGL0kbq6RiGMYw1dXhvWQSrTrl3wDKu3fv9nypbhVqLXCtJhsNwziuKMoe4IQQ4kQXRANaJ+RRwDEM46CqqjftbZkbIZ1Ot9QCV0MoFOpB1um2VbzQLFoipNo5+mvAGBgY+HV3ROo+stlsthW1FQgETiqKsg95F9X/dlO2dvIIXwPc6iFitySSyaQFEAwG84qibNzcDpimWUGujs+udV67l2iHkMeApWAweMuqrVQqRblcriiKEoxGo/Omaf5CUZQ19zJ8Pt/Z6k06V5CXtXQVLRNSPQ7iN0Bw9+7dnnpbW4lMJnMGmTqPGobx2mg0mu3p6XlCUZSFxucsy8ogN6BWHKPULbSb+nwEqba2rgrNY8zMzAjkB51AdpCJQCBwJBqNqrt27XpCVdVZXdcvapp2GEgDn9sKudol5LuAEwgEDmia1tWLFrsFx3H2uq57Hnls7d8jj6b6HqD5/f4H+vr6enp7e8tI0j7o9fV466EtQkKh0DVkO7X/Vva20ul0EnlU4Z8IIU4IId4OvAJ5R2FWURQDeLcQ4j+2SqZOdmv+C3B3797d/Sq0LmFmZqZWUF4/HVsI8YIQ4n1CiAEhxKAQ4uGtlKmTms3vAzm/339A1/VMqVTq3fSNmwSqquYGBgaejcfjOlJlnd9umWro6LoKx3EeB94wMzNzbGZm5nXeidUVlPv6+p4dGhrKCSFejrysy0UmTP+g1U6nbqHTquYvAw/09/cHZ2Zuzm5qy7LODg8Pz/X09OxTFOUVSCOdB54CvoS8A+qmIAM6J+S/Acfv99/r8/lSxWLR21bWNhEMBi8PDw+/GIlE9qiqug+4E1kIfRbpsn/By8IEL9HxDTuO4/wIeOPVq1efunTpUtevO10PPp8vPTg4+JtYLBbWdf1u5EooIS/degz4AvK8kU1TJdsJLw7jfxh4QywWC126dMmD4ZpHo3GunmX4GuRKuAz8FEnCiWZPUbgZ4MUKCQEXgV0nTpzIFIvFbh8X2Gic70Ua5xIymv4lcqv5Z1uR5ugGPLkUzHGc7wBvSSQST01PT3flPqienp4zw8PDScuyxhVFiSI9pCzwLDIm+uHNahdagVf3hzwCvCkWi+2qnU/oBQzDuDQ8PHwhHA7vUVX1LqBWYFAj4dud3l9+s8ErQh4H0rqu7/f7/bOFQqHtzRKfz5caHBw8HYvFIlXjXLsOaBKZQ/tytSxpR8Kzewwdx3kUeOu1a9eeunjxYkuXPKqq6gwMDDwXj8d9fr//IPLs+SJyD+JxpF14RgjhWeXkzQovrzz6NvCH0Wi07+LFi808XzPOeSHEQeSFYS6QQQZt/wn8onqW1/8beEnIj4EFXdfHA4HA1eXl5cG1HlplnF+OjBeyyGbJLyGN800TOW81PL161XGcbwJvm52dPTo1NVVXWw3GeVRV1VHkTl0OWVn/MPCoEOKqZ4LcwvD62ryHgLdEo9HozMxMzTiHdV3fj7wvo4iMWb6MPLpoyuP5b3l4vUJ6kI2iDyBXQc04J5F97/8OPNeNmtidAs9vi66S8mmkkf4Vsmzoia3aAr3V8X/w/V3Xzk5wTQAAAABJRU5ErkJggg==')",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        width: "100px",
                        height: "100px",
                        margin: "0 auto",
                    },
                });
                var emptyStateDesc = this._context.factory.createElement("CONTAINER", {
                    key: "emptyStateDesc",
                    id: "emptyStateDesc",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        margin: this._context.theming.measures.measure100,
                        display: "block",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        textAlign: "center",
                    },
                }, welcomeMessage1);
                var startButton = this._context.factory.createElement("BUTTON", {
                    key: "startButton",
                    id: "startButton",
                    tabIndex: 0,
                    onClick: this.ccfScope.cardEvents.letsGetStartedHandler.bind(this),
                    onKeyDown: this.ccfScope.cardEvents.letsGetStartedKeyPressHandler.bind(this),
                    style: {
                        color: "#0072C6",
                        border: "1px solid #0072C6",
                        fontSize: this._context.theming.fontsizes.font100,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050,
                        backgroundColor: this._context.theming.colors.whitebackground,
                        margin: "0 auto",
                        height: "36px",
                        lineHeight: "33px",
                        cursor: "pointer",
                    },
                }, letsGobtnLabel);
                var imgLoaderContainer = this._context.factory.createElement("CONTAINER", {
                    key: "imgLoaderContainer",
                    id: "imgLoaderContainer",
                    style: {
                        backgroundImage: "url('data:image/gif;base64,R0lGODlhZABkAMQfAF8xk8/ZsIxssvf082KCAedoUq2WyNxSH4SdOLXb10+onffQx/G4ou/n4gGCc8Sz1+iLafamrdrs6ieViOswQNg7AegRI+uega+/fvOIkX/AuJqamtrP5pmZmf///////yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6Q0RGODg5MUQ2MzQ3MTFFNkJFMzRDOEJCMkYyN0JCQjQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6Q0RGODg5MUU2MzQ3MTFFNkJFMzRDOEJCMkYyN0JCQjQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpDREY4ODkxQjYzNDcxMUU2QkUzNEM4QkIyRjI3QkJCNCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpDREY4ODkxQzYzNDcxMUU2QkUzNEM4QkIyRjI3QkJCNCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAUyAB8ALAAAAABkAGQAAAX/4CeOZGmeaKqubOu+cCzPdG3feK7vfO//wKBwSCwaj8ikcslsOp/QqHRKrVprnax2y+16v+CweBy+ms9JsnrNbrs76Lhc9/Zu3Pd1vs72+P+AgYKDhIWGh4iJg1mKjY6PkJCMkZSVlo2Tl5qbmpmcn6CKnqGkpYCjpqmgqKqtl6yusZIdsrWVsLa5hbi6vae0vsGEHRvCxoG8x7Z3ysrJoAcV0tPU0sLPnAsVBRfd3t4FFdfArhAVDIUX4sHYm9ED6eu+7ZfaBYbq47Hm6PH6ru/wyetFz1KFA98uwPOwoFu4f62iUTvgh0E1iLIabPNgscKFBSAxxrJ4oWO/Pw0v1OgquEmduXOBOnrMxVKTOmknK0ozp9JWTZsfY+JUlzPWT1I30YVrQJNcr2r9JE6j6Ooop23dFvgZkDCaUae6ZhYacPCrMLGELEIwGwztoHBaq4LN5TYQWapyz/YcpFaW1U1YE3qLFjdv22qI7/md22wl48Y+H0NePJmd5Mqt/mK+dXmzKc2eJRULXQs0aUydT38yrRoR69aGXsMelnq2Jdm2kdXOHQk3bz++fwfnPTx3cdtc9vBZzrx5ljnQo0ufTr269evYs2vfzr279+/gw4sfnyIEACH5BAUyAB8ALCYAJgAYABgAAAWYoCeOZGme5iM0aCs+QAysbgnHwj2zrg5wIx0tJRMIYoZBsMgTGXA8zhGQXMZIT6RSJNV2r6Pnt8qdIp9YQFnrGSvRYfXoOyW3DWlT146Cl/wkHHhxJ4BcOIQmhhwyM05yf5BtjYiGjyQwAmKOTw+Kkm0eaA1KOp6JkSUNZqdwq4OWHqsyD0+zVJcot5SnoqAmu725NQ3CqCEAIfkEBTIAHwAsJgAmABgAGAAABWqgJ3qZNZ6olZ1ZmxWqK8tWQVt4ru98vpImlFAlKhE9i5+QtSjilMuos0et1mbYbAt2lEqNP6P1OQ3HtK0j2OkVqcnAMXyNRM+acWgbRRePzW92aYBme2+HcoQiSYIteHR7Qn5yVY2NkW0hACH5BAUyAB8ALCYAJgAYABcAAAV1oCeOZGmaWKqubDsScCzP9IuduIgRKoG0QJVnRysah7Bb7rRD+oJQBMFprMacymWpSbwBA0MVGIn1FG8yJTdpzrZxa97bFk6N42i3PK2bducickx+bIKBXikkeIBvVyOLZ3AziCxjKDwphlqPU4FWVo9QolkhACH5BAUyAB8ALCYAJgAYABgAAAWSoCeOVlkWY6quhVVklNWsdBpZmXejdT1YFFFs1qO1FjpXkXbLeYZL1S+Y5NEyWCzScxTKajETtSna1TKWCNdUoj7ZpsJgoWxkswPR4o6NoWJ5USoxb4GCI0N1fBmBe3x+aGotbG5hcBQDlkAiDDhlSld3W11vRIcUY6CHZKWHIl1mrk9UUK6dObGuLS+1rppWPSEAIfkEBTIAHwAsJgAmABgAGAAABYmgJ47kOGBEig1lWw4IgWAxwrouGowBgeEuWSkGbPlKqGJJSCIqRzre8SmCyWiyG7URS6UQDdfJu2qowg0UIUyyzmox9siMQBJ2ot7ULvcwR3EuZj8jeyJJOBh4In8iTlRReYZKblg2VCJcXl99RWY+aGqdOIEkdE+DOWtKKKMeqUUBhDmLmLYiIQAh+QQFMgAfACwmACYAGAAYAAAFqKAnjg10VGh1FMzovgOUFnSRHu07LudxDa+FrALReXhEoPF4KroGp9zuAjtRRzKn61LRIRuihkq57eq4Tpm0vDwB3UbuUu2pFJZyI6NCteP5F4ELO3x1d3EpKFdHhX5LjwuFJ4+PF042g5ReI3tamm0VmZ8jUC17B2SfUBU5MgeilAM2a66LLgs5q2siXCoQDAsLQLOyrEsliWOrUZoDDIGCHrqjS846IQAh+QQFMgAfACwmACYAGAAYAAAFmKAnjmRpnujwGMYzoHADzDQHm8MscJww36UHQEDyPYAjA8A24gAMSJGSKXJCo0LiyBj15IY8H+DVFdJmx5OK5fI4deKl6X1+X6WzRkkXpt2TQyRZRT8nhXhUboEnPiRTJFZliyJcJxx/Xzs9M2QmSkFnaDCfTTQCcYluLD4sBjJPjnmxoUOwJUpatwAjh3u7nr8ekyWNwCMhACH5BAUyAB8ALCYAJwAYABcAAAWBoCeOZGmeaKquROuuJya/6RCcA0Lj+k3mBASGgAK2fB4gYjDkBYeEm3LgaZamnkALo1vWulSRtuWtIkVTWzYbHKgJmB/YI/REs9Q6fIS1x/cje4BpN4JxGIV/cVh6in6Pe3OQjoaQS2+UmY9ejZOee2GVopqYn5qRp6mmq6OsqnshACH5BAUyAB8ALCYAJwAYABcAAAV8oCeO43Kd10KurNccVSwXarsyccEsC1PEDFsJyMJVajZYsIU7CBeVgtDzQ64ulaUNd7FBjlNot/WdegaVMQtr9qRtbPO7FZ/O15X2/ZqXq/l6fyR1QnuDfXaCIjKMjY5rKCcVBwU/FRCRiiyTDAwHTm03jFqhJSdWpakeIQAh+QQFMgAfACwmACcAGAAWAAAFbqAnjmRpnmg6EmzrvvCKYHRt3zRCrJh6YjsRoQcrsjxAVw/HpCGHuqHPBHxKi8TX00qc1aS4bZLY46GqY4/UHEOzyCTwTfxWl4X3kvsKy7rocjcBSHMNSwQ6A1MmDToBRpAvg4ZNlTQNi5mam5ohACH5BAUyAB8ALCYAJgAYABgAAAWKoCeO4mAAqDCQbCsKgGDAQOPepzFy8e3CrNPKRwLoSDwOsSgI1paj02PXg5ZggscJoLR6ODQUamp9oAyc9KxKNKtYAyyxEbP9uL5T1zVgt4BwAl0nPkYtPHhmeywcNgKPkGIcA5NLkJEoi1BdiHZeZjpxmktmRmmnQ0t0Yqx4ZWOnaalQoF43ozchACH5BAUyAB8ALCcAJgAXABgAAAWeoCdqjmieHol6iaYpjivPb+yapKPvfL/jJdUKmCqNSq2hKSksKpXNnG/KA9KuNBjxuYoaj06V+NtkaczmBKy2hU58EvC4CJskBh5JLq5K+t8KIkl5DhMDZScTE20JNkGPLA4JbR6KfWdMDnhHLnwxXydlUpMkUlNxSjAtWKVKAw6BTzCoKKpcEjqTJgNrXCISbxMuMDG+uxpvOgq6HiEAIfkEBTIAHwAsJgAmABgAGAAABZwgII5kaZKCoa5s2wqi4c10bdtGfO97DsizwWrAq/mAA5hIQCx6jrOcgAMD+kpPXZbj4fxmHJcMmp1Wndlvt8R1QhsjJaDRNTy6Rh1MQNtvHwB5XyI2hDQid1E6djYPQB6AhmmPTogAiWROgHeGPiliKpwAYZtJJyYcmzkehDBoM4Srm68zs6usgbSGDW2zaL63uK8xKlXFl5qnJSEAIfkEBTIAHwAsJgAmABgAGAAABaWgJ45kaZ5oqq5sW15wLM90XN14ru/5USwu0aKAO9x+rOHNWLkoK8jT83e5XYREKLC06G6rTdJ062HEGiLwlUuEeC5MXKGxMK5NQEjlwBh4FnoHXWEoVW5/a3UHA4QnBwcjVSMMTY0llAyRFSSPliRVfmmbI3qemp+jojw3C1VkJgUHNTALDRWHiCOMuChEX6m+K7Z8JANtLXV7EBdZvCsDzEsQZCEAIfkEBTIAHwAsJgAmABgAGAAABZOgJY5kSTJe6llF5r7wy2ZWpq72ras1fve7XQ+YIgZ5NqPx6FPmmMXk03dbTIuFhVNH21Eo2sjv2tUxFp7rsrxD69aWYIQiJMe9FvFYZ91FRHR7UClff3pRXHcqhh5fgip9N19WjIhQhl2OlkyOXZVLOoxlmqCSgQ1ujKUplWyOMzEZKBQ1LgW1Gbd/JiILu7wjFCEAIfkEBTIAHwAsJgAmABgAGAAABaagJ47k2AhACghP6ZKPKqBp+5Zcagxevnq2m6gm8gk8qOArduyljrTmzQBoGZEqgNBD5TgBBhoHte0Wsw2sMAbwntueQerGVvbS3J+rvk7hYUR0gYBVW32FJBwGi4yNI3wlVFmTIpCPIjMlMV6WlVp5bpgAAz52bCINRAMoBh6DnohfeU16j68oRz5etUCvTCZzKW6dWDwjXWwzr1+NYT9swi6SkyohACH5BAUyAB8ALCYAJgAYABgAAAVvoCeOZGmeJ8Og7MgcVXWsbfnKKjzX3r27OprJJ7QFSURe8sgDymKLZmkRix2iUs8CFivIsLyGzFu5bCsN3nlxiV203Kp8fvW0yyL2Zc/v87F3b1kkgYOEboYjhYl2iIyLiZCGd3OVlnN+mZqZjCUhACH5BAUyAB8ALCYAJgAYABgAAAWJICCOZEk+XuoBguG+8MsagKGu9q2rNX73u10PmCIGeTaj8ehT5pjF5NN340yjHKeOthOwACjkFrDLsnRL7o7GQV/VY+GbDP1drdVYbLk2leY6AgI6DwBZd3NtKl4DfDsNIigDXlJ1KWYeNINUdV6DZm2OhGcpkGSiN4w3bDN6Lx5mMZ5+JZm0IiEAIfkEBTIAHwAsJgAmABgAGAAABZWgJ47jgBAEMpBsO54I7M7ikIonPdsITuitBgYVQ2EaQFEDxWwSkMAAAcMaDAPJIZUlxQK1rW52GiZ4dWCuebwlib9k9Zm2RFAx9xMU3ot5Tm1JfoM/SR4DAYN9Zis0iUx9i0RzSicpGIp/U5YIe5qdOJGalTcvTyOYf6JKpSJDUwGNLYivgR5SkDG6RZMzAZhOkBiUIQAh+QQFMgAfACwmACYAGAAYAAAFY6AnepoznqijnVqrKaory45CO3iu73y+kiaUUCUqET2Jn5CVKOKUy6izR63WZthsC3aUSo1QVjAKJo+XZfRZmGavUW34W9yVe+Ned/2UvD/Nfnt5dGGDI3iGU1aLT1qOWIleIQAh+QQFMgAfACwmACYAGAAYAAAFqKAnelc1nmh1nVd7Faory1VBV3iu73y+kiaUUCUqET2Ln5C1KOKUy6izR63WZthsC3aUSo2/0ujY4NYa03DQQ2wcKofC+4AGO8crGGQEqQGPYiJEcChvf2p4bAUoMId3giuEJ4Z2QIl6fH6VgSRNbnBycHVPjyw9KwtviCMDcxALsBBzAwxHSScwBQMorRV7XSe1B7tCvbU8ezBNUQtXWGiSUoZRfl4wIQAh+QQFMgAfACwmACYAGAAYAAAFuqAnjp7mnKhDrqyXaJriwFprk6ad3N4QpwrNQCTbtUyOSTA2Of0UrUFTYSQlZA4oSzrzSBTNrsg0Ga6KpVNQLEpkV+6aTCERsceOqkc2cGvtNSQDbyISXRMTK3d4dS55bnoei45GJj4OjSMpKEJiOTkrNDRdniqWPIadgZCQPKx5hYeJN4hpmXwmf2d5g7pxe1mZXnNpkWhIS1g1fltNNV9hSnVkZitcVCxXSdVHJ0owYE48Iz5YakItIQAh+QQFMgAfACwnACYAFgAYAAAFfKAnjmRpnsulrupyllclz/L1QnRl5hB5VKqCLnVxVQqqymE0OIpinhjQM/X8BiJGpRfVlaoxhggnvghZSWRDy70ucvAKo7lsFl6vKxt/Cof5JlpJcYQ0SWiIiUBQgDtJjY6MkCOLXpMilZeUj5pUnJqVhaIXDImmaC6dJCEAIfkEBTIAHwAsJgAmABgAGAAABZCgJ3qZNZ6olZ1ZmxWqK8tWQVt4ru98vpImlFAlKhE9i5+QtSjilMuos0et1mbYbAt2lEqN0JEuPAIvr91m+XleHSMUFnvoE1EskXWX5WpGcHFTZEsUFH95QHtRhx6Fgl52FEmMZl6HJY1xlVKOmIcLc4t4QJEeMIMjjh4Nap9WC4ykpVotjTEvtzCIolYWFCEAIfkEBTIAHwAsJgAmABgAGAAABY0gII5kaZKCoa5s2wqi4c10bdtGfO856fWynY2jGv10whtMdAQEkzRYCtB8QqXHao3IsWE9RC14Get+a0DO0kAkAwS8kmFQaxgE8HiMDtVb+zhIgDYPI381Ayp8M4Ukhx6JjgONTj15NJFvHJR7TSICD5kCXTQPKYuWbqODQIxsgzOtsIFvLra2bie6JiEAIfkEBTIAHwAsJgAmABgAGAAABbugJ47k2EBHpRZM6ZJMWhWF3L7lol6Dt6QQzw0nSt1+lSCkMnwxZiKkckX0XJg+oGd5SFWXC58Kwl0UKt9K2NOQHcJn4lM90r09g8oBN2/61ldBLn0ua08HDYMqfkJ7S1glhC5GP2swi5ENc3tOmDAFHl1PjJIjTwujoZymnqygXQsXqSKltCqoTFeqI0aRmF1WaLN6vlipurseUKyQwGyGWCnQkLPIu3M1rSkX3GfcF2ctMSp3tirn6OQhADs=')",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        width: "100px",
                        height: "100px",
                        margin: "0 auto",
                    },
                });
                var allCardsTitle = this._context.factory.createElement("CONTAINER", {
                    key: "allCardsTitle",
                    id: "allCardsTitle",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        margin: this._context.theming.measures.measure100,
                        display: "block",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        textAlign: "center",
                    },
                }, welcomeMessage2);
                var allCardsDesc = this._context.factory.createElement("CONTAINER", {
                    key: "allCardsDesc",
                    id: "allCardsDesc",
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        margin: this._context.theming.measures.measure100,
                        display: "block",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        textAlign: "center",
                    },
                }, welcomeMessage3);
                if (this.ccfScope.isGetStartedClicked) {
                    contentToBeLoaded = [imgLoaderContainer, allCardsTitle, allCardsDesc];
                }
                else {
                    contentToBeLoaded = [emptyStateImg, emptyStateDesc, startButton];
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "letsGoContainer",
                    id: "letsGoContainer",
                    tabIndex: 0,
                    accessibilityLabel: welcomeMessage1,
                    style: {
                        display: "block",
                        width: "100%",
                        height: "auto",
                        margin: "0 auto",
                    },
                }, contentToBeLoaded);
            };
            return GettingStarted;
        }());
        CardFeedContainer.GettingStarted = GettingStarted;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var UpcomingMeeting = (function () {
            function UpcomingMeeting(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
            }
            UpcomingMeeting.prototype.callLocationService = function (requests, callback) {
                var promises = [];
                var _loop_1 = function (i) {
                    var card = requests[i].card;
                    promises.push(new Promise(function (resolve, reject) {
                        jQuery.ajax({
                            url: requests[i].geocodeRequest,
                            dataType: "jsonp",
                            jsonp: "jsonp",
                            success: function (data) {
                                data.mainCard = card;
                                resolve(data);
                            },
                            error: function (xhr) {
                                reject(xhr);
                            },
                        });
                    }));
                };
                for (var i = 0; i < requests.length; i++) {
                    _loop_1(i);
                }
                Promise.all(promises).then(function (results) {
                    callback(results);
                }, function (rejectReason) {
                    console.log(rejectReason);
                });
            };
            UpcomingMeeting.prototype.refreshFrame = function (result) {
                var mapData = [];
                for (var _i = 0, result_1 = result; _i < result_1.length; _i++) {
                    var data = result_1[_i];
                    var el = void 0;
                    if (data != undefined && data != null && data.resourceSets.length > 0 && data.resourceSets[0].resources) {
                        var resources = data.resourceSets[0].resources;
                        el = document.getElementById(CardFeedContainer.CardService.cfcscope._context.accessibility.getUniqueId("mapContainer" + data.mainCard.cardId));
                        if (resources.length > 0) {
                            var location_2 = resources[0].point.coordinates;
                            if (location_2) {
                                var mapOptions = {
                                    credentials: data.mainCard.data.cardRelatedInfo.bingApiKey
                                        ? data.mainCard.data.cardRelatedInfo.bingApiKey
                                        : "",
                                    center: new Microsoft.Maps.Location(location_2[0], location_2[1]),
                                    zoom: 11,
                                    showScalebar: false,
                                    enableSearchLogo: false,
                                    disableKeyboardInput: true,
                                    showDashboard: false,
                                };
                                mapData.push({ el: el, mapOptions: mapOptions });
                            }
                        }
                        else {
                            jQuery(el).hide();
                        }
                    }
                    else {
                        jQuery(el).hide();
                    }
                }
                for (var _a = 0, mapData_1 = mapData; _a < mapData_1.length; _a++) {
                    var d = mapData_1[_a];
                    var map = new Microsoft.Maps.Map(d.el, d.mapOptions);
                    var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), null);
                    map.entities.push(pushpin);
                }
            };
            UpcomingMeeting.prototype.getMapElement = function (card) {
                var locationTitle = this._context.factory.createElement("LABEL", {
                    key: "locationTitle" + card.cardId,
                    id: "locationTitle" + card.cardId,
                    title: CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location"),
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location")),
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        fontWeight: "400",
                        lineHeight: "1.4rem",
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.Meeting.Location"));
                var locationContainer = this._context.factory.createElement("CONTAINER", {
                    key: "locationContainer" + card.cardId,
                    id: "locationContainer" + card.cardId,
                    style: {
                        display: "block",
                        padding: this._context.theming.measures.measure050,
                    },
                    accessKey: "",
                }, locationTitle);
                var mapContainer = this._context.factory.createElement("CONTAINER", {
                    key: "mapContainer" + card.cardId,
                    id: "mapContainer" + card.cardId,
                    style: {
                        display: "block",
                        height: "10em",
                        position: "relative",
                    },
                    accessKey: "",
                }, "");
                return this._context.factory.createElement("CONTAINER", {
                    key: "mapMainContainer" + card.cardId,
                    id: "mapMainContainer" + card.cardId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), this._context.resources.getString("ActionCard.CFC.Meeting.Location")),
                    style: {
                        display: "block",
                    },
                    accessKey: "",
                }, mapContainer);
            };
            UpcomingMeeting.prototype.getAccountIcon = function (card) {
                var img_entity = card.data.cardContextDetails[0].contextObject.entityImgUrl;
                var entityName = card.data.cardContextDetails[0].contextPrimaryInfo
                    ? card.data.cardContextDetails[0].contextPrimaryInfo.title
                    : card.title;
                var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                    key: "accuserImageElement" + card.cardId,
                    id: "accuserImageElement" + card.cardId,
                    style: {
                        color: this._context.theming.colors.basecolor.white,
                        fontSize: this._context.theming.fontsizes.font100,
                        margin: "0 auto",
                        width: "100%",
                    },
                    hasPrimaryImageField: true,
                    tabIndex: 0,
                    mode: entityImageMode,
                    imageSrc: img_entity,
                    entityPrimaryField: entityName,
                });
                var accentityImageContainer = this._context.factory.createElement("CONTAINER", {
                    id: "accentityImageContainer" + card.cardId,
                    key: "accentityImageContainer" + card.cardId,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure075,
                        marginTop: "0rem",
                        marginLeft: "0rem",
                        float: "left",
                        textAlign: "center",
                        overflow: "hidden",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#e2e2e2",
                    },
                }, userImageElement);
                return this._context.factory.createElement("CONTAINER", {
                    key: "accImgCont" + card.cardId,
                    id: "accImgCont" + card.cardId,
                    style: {
                        display: "flex",
                    },
                }, accentityImageContainer);
            };
            UpcomingMeeting.prototype.getAttendeesElements = function (cardData, accessibilityFocusId) {
                var attendeeData = [];
                if (CardFeedContainer.CardFeedContainer.nextMeetingAttendees && CardFeedContainer.CardFeedContainer.nextMeetingAttendees[cardData.cardId])
                    attendeeData = CardFeedContainer.CardFeedContainer.nextMeetingAttendees[cardData.cardId];
                var attEle = [];
                for (var card = 0; card < attendeeData.length && card < 3; card++) {
                    var img_entity = attendeeData[card].data.cardContextDetails[0].contextObject.entityImgUrl;
                    var entityName = attendeeData[card].title;
                    var entityImageMode = img_entity == null || img_entity == "" ? 1 : 0;
                    var userImageElement = this._context.factory.createElement("ENTITYIMAGE", {
                        key: "userImageElement" + card,
                        id: "userImageElement" + card,
                        style: {
                            color: this._context.theming.colors.basecolor.white,
                            fontSize: this._context.theming.fontsizes.font100,
                            margin: "0 auto",
                            width: "100%",
                        },
                        hasPrimaryImageField: true,
                        tabIndex: 0,
                        mode: entityImageMode,
                        imageSrc: img_entity,
                        entityPrimaryField: entityName,
                    });
                    var entityImageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "entityImageContainer" + card,
                        key: "entityImageContainer" + card,
                        style: {
                            width: this._context.theming.measures.measure300,
                            height: this._context.theming.measures.measure300,
                            lineHeight: this._context.theming.measures.measure300,
                            marginRight: this._context.theming.measures.measure075,
                            marginTop: "0rem",
                            marginLeft: "0rem",
                            float: "left",
                            textAlign: "center",
                            overflow: "hidden",
                            alignItems: "center",
                            borderRadius: "50%",
                            backgroundColor: "#e2e2e2",
                        },
                    }, userImageElement);
                    attEle.push(entityImageContainer);
                }
                var attTitle = this._context.factory.createElement("LABEL", {
                    key: "attTitle" + cardData.cardId,
                    id: "attTitle" + cardData.cardId,
                    style: {
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: this._context.theming.fontsizes.font085,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, attendeeData.length > 0 ? attendeeData.length + " Attendees" : "");
                var Cont = this._context.factory.createElement("CONTAINER", {
                    key: "Cont" + cardData.cardId,
                    id: "Cont" + cardData.cardId,
                    style: {
                        display: "flex",
                    },
                }, attEle);
                if (attendeeData.length > 0) {
                    return this._context.factory.createElement("CONTAINER", {
                        key: "imgCont" + cardData.cardId,
                        id: "imgCont" + cardData.cardId,
                        style: {
                            display: "flex",
                            paddingLeft: this._context.theming.measures.measure100,
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                            borderTop: this._context.theming.borders.border02,
                        },
                    }, [
                        Cont,
                        this._context.factory.createElement("CONTAINER", {
                            key: "attTitlecont" + cardData.cardId,
                            id: "attTitlecont" + cardData.cardId,
                            style: {
                                alignItems: "center",
                                paddingLeft: this._context.client.isRTL ? "" : this._context.theming.measures.measure075,
                                paddingRight: this._context.client.isRTL ? this._context.theming.measures.measure075 : "",
                                display: "block",
                                width: "100%",
                                lineHeight: this._context.theming.measures.measure250,
                                borderLeft: this._context.client.isRTL ? "" : "1px solid #d8d8d8",
                                borderRight: this._context.client.isRTL ? "1px solid #d8d8d8" : "",
                            },
                        }, attTitle),
                    ]);
                }
                else
                    return;
            };
            UpcomingMeeting.prototype.renderCardView = function (card, accessibilityFocusId, columntype) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var formatedTitle;
                if (card.softTitle.indexOf(":") != -1) {
                    var titleArray = card.softTitle.split(":");
                    if (titleArray[1] != undefined && titleArray[1] != "" && titleArray[1].length > 0) {
                        formatedTitle = titleArray[1];
                    }
                    else {
                        formatedTitle = card.softTitle;
                    }
                }
                else {
                    formatedTitle = card.softTitle;
                }
                var now = new Date();
                var startDateTime = new Date(card.data.cardRelatedInfo.starttime);
                var diff = startDateTime - now;
                var minutes = Math.floor(diff / 1000 / 60);
                if (minutes < 0)
                    return "";
                if (card.data) {
                    formatedTitle = card.data.cardRelatedInfo
                        ? MscrmCommon.ControlUtils.String.Format(formatedTitle, minutes + " " + this._context.resources.getString("ActionCard.CFC.Common.Minutes"))
                        : formatedTitle;
                }
                var cardTitleLabel = card.title ? card.title : CardFeedContainer.Utils.getReferenceTokenDataTitle(card, this._context);
                var cardTitleDescription = formatedTitle + " " + cardTitleLabel;
                var cardDescriptionLabel = card.description
                    ? card.description
                    : CardFeedContainer.Utils.getReferenceTokenDataDescription(card, this._context);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + card.cardId,
                    key: "imginfo_key" + card.cardId,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                });
                var cardIcon = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + card.cardId,
                    key: "cardIcon" + card.cardId,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure015,
                        fontSize: this._context.theming.fontsizes.font100,
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#e2e2e2",
                        display: "block",
                    },
                }, imginfoControl);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "cardIconContainer" + card.cardId,
                    key: "cardIconContainer" + card.cardId,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                    },
                }, cardIcon);
                var cardDueTitle = this._context.factory.createElement("LABEL", {
                    key: "cardDueTitle" + card.cardId,
                    id: "cardDueTitle" + card.cardId,
                    tabIndex: 0,
                    title: formatedTitle,
                    style: {
                        color: CardFeedContainer.CardUtils.defaultCardTitleColor(card.cardName),
                        fontSize: this._context.theming.fontsizes.font100,
                        fontFamily: this._context.theming.fontfamilies.regular,
                        maxWidth: "100%",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                    },
                }, formatedTitle);
                var cardTitle = this._context.factory.createElement("LABEL", {
                    key: "cardTitle" + card.cardId,
                    id: "cardTitle" + card.cardId,
                    title: cardTitleLabel,
                    style: {
                        display: "block",
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                        color: this._context.theming.colors.base.black,
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, cardTitleLabel);
                var cardTitleDescriptionId = this._context.factory.createElement("LABEL", {
                    key: "cardTitleDescriptionId" + card.cardId,
                    id: "cardTitleDescriptionId" + card.cardId,
                    accessibilityLabel: cardTitleDescription,
                    style: {
                        display: "none",
                    },
                }, "");
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + card.cardId,
                    id: "cardDescription" + card.cardId,
                    title: cardDescriptionLabel,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray07,
                        lineHeight: this._context.theming.measures.measure150,
                        maxHeight: this._context.theming.measures.measure450,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        position: "relative",
                        wordBreak: "break-word",
                        display: "block",
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                    },
                }, cardDescriptionLabel);
                var descriptionElipsis = this._context.factory.createElement("LABEL", {
                    key: "descriptionElipsis" + card.cardId,
                    id: "descriptionElipsis" + card.cardId,
                    style: {
                        display: "block",
                        position: "absolute",
                        right: "0",
                        bottom: "0",
                        paddingLeft: this._context.theming.measures.measure100,
                    },
                }, "...");
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                        position: "relative",
                    },
                }, [cardDueTitle, cardTitle, cardDescription, cardTitleDescriptionId]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + card.cardId,
                    id: "cardLabelsMainContainer" + card.cardId,
                    style: {
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        display: "block",
                        width: "100%",
                    },
                }, cardLabelsContainer);
                var buttonContainer = this._context.factory.createElement("CONTAINER", {
                    key: "buttonContainer" + card.cardId,
                    id: "buttonContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray01,
                        whiteSpace: "normal",
                        display: "block",
                        maxHeight: this._context.theming.measures.measure250,
                        boxSizing: "border-box",
                    },
                }, this.getButtonContainer(card, accessibilityFocusId));
                var cardDetailsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardDetailsContainer" + card.cardId,
                    id: "cardDetailsContainer" + card.cardId,
                    style: {
                        justifyContent: "space-between",
                        paddingTop: this._context.theming.measures.measure100,
                        paddingBottom: this._context.theming.measures.measure075,
                        whiteSpace: "normal",
                        width: "100%",
                    },
                    onClick: this.ccfScope.cardEvents.cardClickHandler.bind(this, accessibilityFocusId, card, this.ccfScope),
                }, [
                    cardIconContainer,
                    cardLabelsMainContainer,
                    this.ccfScope.dataFactories["Generic"].renderMenuForCardView(card, accessibilityFocusId),
                ]);
                var isAccount = false;
                var accountMContainer;
                if (card.data.cardContextDetails && card.data.cardContextDetails.length > 0) {
                    var accountName = this._context.factory.createElement("LABEL", {
                        key: "accountName" + card.cardId,
                        id: "accountName" + card.cardId,
                        style: {
                            color: this._context.theming.colors.grays.gray07,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.regular,
                            maxWidth: "100%",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            cursor: "pointer",
                        },
                    }, card.data.cardContextDetails[0].contextPrimaryInfo.title);
                    var acEntName = card.data.cardContextDetails[0].contextObject.entityName;
                    var acEntId = card.data.cardContextDetails[0].contextObject.guid;
                    var accountContainer = this._context.factory.createElement("CONTAINER", {
                        key: "accountContainer" + card.cardId,
                        id: "accountContainer" + card.cardId,
                        style: {
                            display: "flex",
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                            width: "90%",
                            borderBottom: this._context.theming.borders.border02,
                        },
                    }, [
                        this.getAccountIcon(card),
                        this._context.factory.createElement("CONTAINER", {
                            key: "anamecont" + card.cardId,
                            id: "anamecont" + card.cardId,
                            style: {
                                alignItems: "center",
                                display: "block",
                                lineHeight: this._context.theming.measures.measure250,
                            },
                        }, accountName),
                    ]);
                    isAccount = true;
                    if (card.data.cardContextDetails[0].contextPrimaryInfo) {
                        if (card.data.cardContextDetails[0].contextPrimaryInfo.title.length == 0)
                            isAccount = false;
                    }
                    accountMContainer = this._context.factory.createElement("CONTAINER", {
                        key: "accountMContainer" + card.cardId,
                        id: "accountMContainer" + card.cardId,
                        style: {
                            paddingLeft: this._context.theming.measures.measure100,
                            paddingRight: this._context.theming.measures.measure100,
                        },
                        onClick: this.openAccountForm.bind(this, { entityName: acEntName, entityId: acEntId }),
                    }, accountContainer);
                }
                var cardContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardContainer" + card.cardId,
                    id: "cardContainer" + card.cardId,
                    style: {
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                    },
                }, cardDetailsContainer);
                var attContainer = this.getAttendeesElements(card, accessibilityFocusId);
                var mainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "mainContainer" + card.cardId,
                    id: "mainContainer" + card.cardId,
                    onPointerDown: this.ccfScope.cardEvents.swipeStartHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerUp: this.ccfScope.cardEvents.swipeEndHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerMove: this.ccfScope.cardEvents.elementMoveHandle.bind(this, card, accessibilityFocusId, "card"),
                    onPointerLeave: this.ccfScope.cardEvents.resetCard.bind(this),
                }, [
                    cardContainer,
                    isAccount ? accountMContainer : "",
                    attContainer,
                    this.ccfScope.viewType == "Card" ||
                        card.data.cardRelatedInfo.address == "" ||
                        (this.ccfScope.twoColumnLayout && columntype === "SecondColumn")
                        ? ""
                        : this.getMapElement(card),
                    buttonContainer,
                ]);
                var mainContainerWrapper = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: 0,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, ""),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        border: this._context.theming.borders.border02,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, mainContainer);
                var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "swipeContentContainer" + card.cardId,
                    id: "swipeContentContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.ccfScope.dataFactories["Generic"].rendersnoozeContainer(card, accessibilityFocusId),
                    mainContainerWrapper,
                    this.ccfScope.dataFactories["Generic"].renderdismissContainer(card, accessibilityFocusId),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    accessibilityLabel: MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("ActionCard.RelationshipAssistance.Navigation_HelpText"), cardTitleDescription),
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    autoFocus: true,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "flex",
                        marginBottom: this._context.theming.measures.measure050,
                        transform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        webkitTransform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        transition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                        WebkitTransition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                        transformStyle: "preserve-3d",
                        boxSizing: "border-box",
                        width: "100%",
                        paddingRight: "2px",
                    },
                }, swipeContentContainer);
            };
            UpcomingMeeting.prototype.getButtonContainer = function (card, accessibilityFocusId) {
                var cardActions = this.ccfScope.getActionData();
                var commands = this.ccfScope.getActionCommands(card);
                var actions;
                if (commands && commands.length > 0) {
                    actions = this.ccfScope.retrieveActionData(card);
                }
                var buttonsArray = [];
                for (var action in actions) {
                    var descriptionContainer = this._context.factory.createElement("CONTAINER", {
                        key: action + "descriptionContainer" + accessibilityFocusId,
                        id: action + "descriptionContainer" + accessibilityFocusId,
                        style: {
                            display: "none",
                        },
                        tabIndex: -1,
                    }, this._context.resources.getString("ActionCard.CFC.Common.ButtonPressText") + " " + actions[action].label);
                    if ((card.cardName =
                        "UPCOMING_MEETING_EXCHANGE" || actions[action].command == "Mscrm.Modern.EmailAttendeesCommand")) {
                        var buttonClose = this._context.factory.createElement("BUTTON", {
                            key: card.cardId + "button" + action,
                            id: card.cardId + "button" + action,
                            title: actions[action].label,
                            focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                            tabIndex: this.ccfScope.dismissClickedCardIndex != accessibilityFocusId ? 0 : -1,
                            autoFocus: true,
                            style: {
                                border: "none",
                                display: "block",
                                overflow: "hidden",
                                whiteSpace: "nowrap",
                                backgroundColor: this._context.theming.colors.grays.gray01,
                                color: this._context.theming.colors.grays.gray07,
                                paddingTop: this._context.theming.measures.measure050,
                                paddingBottom: this._context.theming.measures.measure050,
                                paddingLeft: this._context.theming.measures.measure100,
                                paddingRight: this._context.theming.measures.measure100,
                                textAlign: "left",
                                fontFamily: this._context.theming.fontfamilies.regular,
                                fontSize: this._context.theming.fontsizes.font100,
                                width: "100%",
                                textOverflow: "ellipsis",
                                cursor: "pointer",
                            },
                            onClick: this.ccfScope.cardEvents.handleActionClickEvent.bind(this, card, actions[action]),
                            onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, ""),
                        }, actions[action].label);
                        var buttonContainer = this._context.factory.createElement("CONTAINER", {
                            key: card.cardId + "buttonContainer" + action,
                            id: card.cardId + "buttonContainer" + action,
                            style: {
                                display: "inline-block",
                                maxWidth: "calc(50% - 1rem)",
                                marginLeft: this._context.theming.measures.measure015,
                                cursor: "pointer",
                            },
                        }, [buttonClose, descriptionContainer]);
                        buttonsArray.push(buttonContainer);
                    }
                }
                return buttonsArray;
            };
            UpcomingMeeting.prototype.openAccountForm = function (formDetails) {
                this._context.navigation.openForm(formDetails);
                if (this.ccfScope.isGlobalPanelEnabled) {
                    this._context.utils.fireEvent("close", {});
                }
            };
            return UpcomingMeeting;
        }());
        CardFeedContainer.UpcomingMeeting = UpcomingMeeting;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var TeaserCard = (function () {
            function TeaserCard(context, ccfScope) {
                this._context = context;
                this.ccfScope = ccfScope;
                var teasersArray = this.getTeasersArray();
                var teaserIndex = 0;
                if (sessionStorage) {
                    var lastTeaserIndex = sessionStorage.getItem("lastTeaserIndex");
                    if (lastTeaserIndex) {
                        if (parseInt(lastTeaserIndex) != NaN) {
                            teaserIndex = (parseInt(lastTeaserIndex) + 1) % teasersArray.length;
                        }
                    }
                    sessionStorage.setItem("lastTeaserIndex", teaserIndex);
                    this.tearInfo = teasersArray[teaserIndex];
                }
            }
            TeaserCard.prototype.getTeasersArray = function () {
                return [
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.EnableExchangeCards"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.EnableExchangeCards.SummaryText"),
                        forwardLink: "https://aka.ms/sales.ai",
                    },
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.WhoKnowsWho"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.WhoKnowsWho.SummaryText"),
                        forwardLink: "https://go.microsoft.com/fwlink/p/?linkid=2006419",
                    },
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.TalkingPoints"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.TalkingPoints.SummaryText"),
                        forwardLink: "https://go.microsoft.com/fwlink/p/?linkid=2006505",
                    },
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.NotesAnalysis"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.NotesAnalysis.SummaryText"),
                        forwardLink: "https://go.microsoft.com/fwlink/p/?linkid=824710",
                    },
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.PLS"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.PLS.SummaryText"),
                        forwardLink: "https://go.microsoft.com/fwlink/p/?linkid=870068",
                    },
                    {
                        title: this._context.resources.getString("ActionCard.CFC.Teaser.POS"),
                        description: this._context.resources.getString("ActionCard.CFC.Teaser.POS.SummaryText"),
                        forwardLink: "https://go.microsoft.com/fwlink/p/?linkid=2028194",
                    },
                ];
            };
            TeaserCard.prototype.prepareExchangeTeaserCardView = function (card, accessibilityFocusId) {
                this.ccfScope.cardEvents.pushrenderedElements(accessibilityFocusId, this.ccfScope);
                var formatedTitle = this.tearInfo["title"];
                var cardDescriptionLabel = this.tearInfo["description"];
                var learnMoreText = this._context.resources.getString("ActionCard.CFC.Teaser.LearnMore");
                var actionCardDisplay = new ActionCardDisplay("prepareExchangeTeaserCardView " + this.tearInfo, card["cardtype"], card["cardId"]);
                this._context.reporting.reportEvent(actionCardDisplay);
                var imginfoControl = this._context.factory.createElement("MICROSOFTICON", {
                    id: "imginfo_id" + card.cardId,
                    key: "imginfo_key" + card.cardId,
                    style: {
                        margin: "0 auto",
                        fontSize: "large",
                    },
                    type: CardFeedContainer.CardUtils.defaultCardIcon(card.cardName),
                });
                var cardIcon = this._context.factory.createElement("CONTAINER", {
                    id: "cardIcon" + card.cardId,
                    key: "cardIcon" + card.cardId,
                    style: {
                        width: this._context.theming.measures.measure300,
                        height: this._context.theming.measures.measure300,
                        lineHeight: this._context.theming.measures.measure300,
                        marginRight: this._context.theming.measures.measure015,
                        fontSize: this._context.theming.measures.measure100,
                        overflow: "hidden",
                        color: "#ffffff",
                        alignItems: "center",
                        borderRadius: "50%",
                        backgroundColor: "#0CBF68",
                        display: "block",
                    },
                }, imginfoControl);
                var cardIconContainer = this._context.factory.createElement("CONTAINER", {
                    id: "iconContainer" + card.cardId,
                    key: "iconContainer" + card.cardId,
                    style: {
                        textAlign: "center",
                        marginRight: this._context.client.isRTL ? this._context.theming.measures.measure015 : "0",
                    },
                }, cardIcon);
                var cardTitle = this._context.factory.createElement("LABEL", {
                    key: "cardTitle" + card.cardId,
                    id: "cardTitle" + card.cardId,
                    title: formatedTitle,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        maxWidth: "calc(100% - 1rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        color: this._context.theming.colors.base.black,
                        paddingBottom: this._context.theming.measures.measure050,
                    },
                }, formatedTitle);
                var cardDescription = this._context.factory.createElement("LABEL", {
                    key: "cardDescription" + card.cardId,
                    id: "cardDescription" + card.cardId,
                    title: cardDescriptionLabel,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.grays.gray07,
                        lineHeight: this._context.theming.measures.measure150,
                        maxHeight: this._context.theming.measures.measure450,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        position: "relative",
                        wordBreak: "break-word",
                        display: "block",
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word",
                        fontSize: this._context.theming.fontsizes.font100,
                        cursor: "pointer",
                    },
                }, cardDescriptionLabel);
                var learMoreLink = this._context.factory.createElement("HYPERLINK", {
                    id: "learn_more_link",
                    key: "learn_more_link",
                    title: learnMoreText,
                    target: "_new",
                    tabIndex: 0,
                    href: this.tearInfo["forwardLink"],
                    role: "link",
                    accessibilityLabel: learnMoreText,
                    style: {
                        color: "#41b2f4",
                        textDecoration: "none",
                    },
                }, [learnMoreText]);
                var cardLabelsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsContainer" + card.cardId,
                    id: "cardLabelsContainer" + card.cardId,
                    style: {
                        display: "block",
                        position: "relative",
                        width: "100%",
                        overflow: "hidden",
                        cursor: "pointer",
                    },
                }, [cardTitle, cardDescription, learMoreLink]);
                var cardLabelsMainContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardLabelsMainContainer" + card.cardId,
                    id: "cardLabelsMainContainer" + card.cardId,
                    style: {
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        display: "block",
                        width: "calc(100% - 4rem)",
                        overflow: "hidden",
                    },
                }, cardLabelsContainer);
                var buttonContainer = this._context.factory.createElement("CONTAINER", {
                    key: "buttonContainer" + card.cardId,
                    id: "buttonContainer" + card.cardId,
                    style: {
                        whiteSpace: "normal",
                        display: "block",
                        boxSizing: "border-box",
                    },
                }, this.getButtonContainer(card, accessibilityFocusId));
                var cardDetailsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardDetailsContainer" + card.cardId,
                    id: "cardDetailsContainer" + card.cardId,
                    style: {
                        justifyContent: "space-between",
                        paddingLeft: this._context.theming.measures.measure100,
                        paddingRight: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        paddingBottom: this._context.theming.measures.measure075,
                        whiteSpace: "normal",
                    },
                }, [cardIconContainer, cardLabelsMainContainer]);
                var cardWithActionsContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsContainer" + accessibilityFocusId,
                    id: "cardWithActionsContainer" + accessibilityFocusId,
                    focus: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId),
                    tabIndex: this.ccfScope.cardEvents.isfocusedElement(accessibilityFocusId) ? 0 : -1,
                    autoFocus: true,
                    style: {
                        whiteSpace: "normal",
                        flexDirection: "column",
                        width: "100%",
                    },
                }, [cardDetailsContainer, buttonContainer]);
                var cardContainer = this._context.factory.createElement("CONTAINER", {
                    key: "cardWithActionsMainContainer" + card.cardId,
                    id: "cardWithActionsMainContainer" + card.cardId,
                    onPointerDown: this.ccfScope.cardEvents.swipeStartHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerUp: this.ccfScope.cardEvents.swipeEndHandler.bind(this, card, accessibilityFocusId, "card"),
                    onPointerMove: this.ccfScope.cardEvents.elementMoveHandle.bind(this, card, accessibilityFocusId, "card"),
                    onPointerLeave: this.ccfScope.cardEvents.resetCard.bind(this),
                    onKeyDown: this.ccfScope.cardEvents.navigateKeyHandler.bind(this, accessibilityFocusId, "card", card, this.ccfScope, null),
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        border: this._context.theming.borders.border02,
                        boxSizing: "border-box",
                        position: "relative",
                        width: "100%",
                        borderColor: "#0CBF68",
                    },
                }, cardWithActionsContainer);
                var swipeContentContainer = this._context.factory.createElement("CONTAINER", {
                    key: "swipeContentContainer" + card.cardId,
                    id: "swipeContentContainer" + card.cardId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        display: "block",
                        position: "relative",
                        cursor: "pointer",
                    },
                }, [
                    this.ccfScope.dataFactories["Generic"].rendersnoozeContainer(card),
                    cardContainer,
                    this.ccfScope.dataFactories["Generic"].renderdismissContainer(card, accessibilityFocusId),
                ]);
                return this._context.factory.createElement("LISTITEM", {
                    key: "listItemCardContainer" + accessibilityFocusId,
                    id: "listItemCardContainer" + accessibilityFocusId,
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        display: "flex",
                        boxSizing: "border-box",
                        boxShadow: "0 0 0.2px 0.2px #0CBF68",
                        width: "100%",
                        marginBottom: "0.5rem",
                        transform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        webkitTransform: this.ccfScope.dismissClickedCardIndex === accessibilityFocusId &&
                            "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? "translate3d(-" + this.ccfScope.cardBoundary.width + "px, 0px, 0px)"
                            : CardFeedContainer.CardFeedContainer.swipingCardId == accessibilityFocusId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                                ? CardFeedContainer.CardFeedContainer.cardTransform
                                : "translate3d(0px, 0px, 0px)",
                        transition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                        WebkitTransition: CardFeedContainer.CardFeedContainer.cardTransition == card.cardId && "card" == CardFeedContainer.CardFeedContainer.swipeCardType
                            ? CardFeedContainer.CardFeedContainer.cardTransition
                            : "transform 0s ease-out",
                    },
                }, swipeContentContainer);
            };
            TeaserCard.prototype.getButtonContainer = function (card, accessibilityFocusId) {
                var buttonsArray = [];
                var remindLaterText = this._context.resources.getString("ActionCard.CFC.Teaser.RemindLater");
                var buttonClose = this._context.factory.createElement("BUTTON", {
                    key: "remind_later" + accessibilityFocusId,
                    id: "remind_later" + accessibilityFocusId,
                    title: remindLaterText,
                    tabIndex: 0,
                    autoFocus: true,
                    style: {
                        border: "none",
                        display: "block",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        backgroundColor: "#0CBF68",
                        color: "#ffffff",
                        textAlign: "left",
                        fontFamily: this._context.theming.fontfamilies.regular,
                        width: "100%",
                        textOverflow: "ellipsis",
                        cursor: "pointer",
                        padding: "0.3rem 1rem",
                    },
                    onClick: this.ccfScope.cardEvents.handleSnoozeEvent.bind(this, card.cardId),
                }, remindLaterText);
                var buttonContainer = this._context.factory.createElement("CONTAINER", {
                    key: card.cardId + "remindlaterbuttonContainer",
                    id: card.cardId + "remindlaterbuttonContainer",
                    style: {
                        display: "inline",
                        cursor: "pointer",
                    },
                }, buttonClose);
                buttonsArray.push(buttonContainer);
                return buttonsArray;
            };
            return TeaserCard;
        }());
        CardFeedContainer.TeaserCard = TeaserCard;
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CardFeedContainer;
    (function (CardFeedContainer) {
        var CardService;
        (function (CardService) {
            CardService.CrmSoapServiceCall = "CrmSoapServiceCall";
            CardService.staticStockId = "2DC1CA86-7141-4B02-8050-7A07973B8468";
            CardService.staticNewsId = "4A5DD3AA-BA13-417F-959A-B94875803BC2";
            CardService.staticNearbyCustomersId = "0E8288AA-A9DC-4FAF-AF7A-AEA6E9E4E757";
            CardService.staticRegardingId = "CAC83683-0E44-4FDE-8951-A3FFDC702861";
            CardService.staticUpcomingMeeting = "CAC83683-0E44-4FDE-8951-A3FFDC702861";
            CardService.geocodeRequest = window.location.href.toLocaleLowerCase().indexOf("https://") != -1
                ? "https://dev.virtualearth.net/REST/v1/Locations?query={0}&key={1}"
                : "http://dev.virtualearth.net/REST/v1/Locations?query={0}&key={1}";
            CardService.attData = [];
            CardService.regData = [];
            CardService.nearByCust = [];
            CardService.news = [];
            CardService.stockData = [];
            function getCurrentUserId() {
                var userId = CardFeedContainer.CardFeedContainer.cfcContext.userSettings.userId;
                return userId.substr(1, userId.length - 2);
            }
            function callPopulateCards(callback) {
                var userId = getCurrentUserId();
                if (userId != null) {
                    var populateCardRequest = new RelationshipAssitantSdkContracts.PopulateCardRequest(userId);
                    CardFeedContainer.CardFeedContainer.cfcContext.webAPI.execute(populateCardRequest);
                }
            }
            CardService.callPopulateCards = callPopulateCards;
            function getStocksData(parameterInfo, args) {
                var json = JSON.stringify(parameterInfo);
                var deferred1 = retrieveCardData(CardService.staticStockId, json);
                return deferred1.then(function (res) {
                    return res.json().then(function (odataResponse) {
                        var data;
                        if (odataResponse.Data && odataResponse.Data.length > 0) {
                            data = JSON.parse(odataResponse.Data);
                            var today = new Date();
                            data = data.map(function (curCardData) {
                                var publishedDate = moment(moment(curCardData.Data.cardRelatedInfo.Ld, "DD-MM-YYYY").format("MM/DD/YYYY") +
                                    " " +
                                    curCardData.Data.cardRelatedInfo.Lt);
                                var publishedDateCalculated = moment(publishedDate).toDate();
                                var dat = CardFeedContainer.CardUtils.getCCFLocaleFormat(publishedDateCalculated, "MMM dd") +
                                    " " +
                                    CardFeedContainer.CardUtils.getCCFLocaleFormat(publishedDateCalculated, "t") +
                                    " " +
                                    curCardData.Data.cardRelatedInfo.tz;
                                var softTitle = MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.GroupCard.Stock.SoftTitle"), [dat]);
                                var cardData = {};
                                cardData.cardId = curCardData.CardId;
                                cardData.cardName = "STOCK_ACTIVITY";
                                cardData.data = curCardData.Data;
                                cardData.description = curCardData.Description;
                                cardData.expiryDate = curCardData.ExpiryDate;
                                cardData.priority = curCardData.Priority;
                                cardData.softTitle = softTitle;
                                cardData.startDate = curCardData.StartDate;
                                cardData.title = curCardData.Title;
                                cardData.visibility = curCardData.Visibility;
                                return cardData;
                            });
                            CardService.stockData = data;
                        }
                    });
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getStocksData = getStocksData;
            function getNewsData(parameterInfo, args) {
                var json = JSON.stringify(parameterInfo);
                var deferred2 = retrieveCardData(CardService.staticNewsId, json);
                return deferred2.then(function (res) {
                    return res.json().then(function (odataResponse) {
                        var data;
                        if (odataResponse.Data && odataResponse.Data.length > 0) {
                            data = JSON.parse(odataResponse.Data);
                            var today_1 = moment(new Date());
                            data = data.map(function (curCardData) {
                                var publishedDate = moment(new Date(curCardData.Data.cardRelatedInfo.publishedDate));
                                var duration = moment.duration(today_1.diff(publishedDate));
                                var refreshTime = "";
                                if (duration.days() > 0) {
                                    refreshTime = duration.days().toString() + "d";
                                }
                                else {
                                    refreshTime = duration.hours().toString() + "h " + duration.minutes().toString() + "m";
                                }
                                var softTitle = MscrmCommon.ControlUtils.String.Format(CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.GroupCard.News.SoftTitle"), refreshTime);
                                var cardData = {};
                                cardData.cardId = curCardData.CardId;
                                cardData.cardName = "RELEVANT_NEWS";
                                cardData.data = curCardData.Data;
                                cardData.description = curCardData.Description;
                                cardData.expiryDate = curCardData.ExpiryDate;
                                cardData.priority = curCardData.Priority;
                                cardData.softTitle = softTitle;
                                cardData.startDate = curCardData.StartDate;
                                cardData.title = curCardData.Title;
                                cardData.visibility = curCardData.Visibility;
                                cardData.summaryText = "Updated " + refreshTime + " ago";
                                return cardData;
                            });
                            CardService.news = data;
                        }
                    });
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getNewsData = getNewsData;
            function getNearbyCustomers(address, bingMapsApiKey, args, card) {
                var jQuery = $;
                var resultDeferred = jQuery.Deferred();
                var userId = getCurrentUserId();
                return CardService.callLocationService(address, bingMapsApiKey).then(function (r) {
                    if (r.status) {
                        var data = r.data;
                        if (data != undefined && data != null && data.resourceSets.length > 0 && data.resourceSets[0].resources) {
                            var resources = data.resourceSets[0].resources;
                            if (resources.length == 0)
                                return;
                            var address_1 = resources[0].address;
                            var city = address_1.locality;
                            var state = address_1.adminDistrict;
                            var country = address_1.countryRegion;
                            var json = JSON.stringify({
                                userId: userId,
                                city: city,
                                stateOrProvince: state,
                                country: country,
                            });
                            var deferred2 = retrieveCardData(CardService.staticNearbyCustomersId, json);
                            return deferred2.then(function (res) {
                                return res.json().then(function (odataResponse) {
                                    var data;
                                    if (odataResponse.Data && odataResponse.Data.length > 0) {
                                        data = JSON.parse(odataResponse.Data);
                                        data = data.map(function (curCardData, index) {
                                            var cardData = {};
                                            cardData.cardId = curCardData.CardId + index;
                                            cardData.cardName = "NEARBY_CUSTOMERS";
                                            cardData.data = curCardData.Data;
                                            cardData.description = curCardData.Description;
                                            cardData.expiryDate = curCardData.ExpiryDate;
                                            cardData.priority = curCardData.Priority;
                                            cardData.softTitle = CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.GroupCard.NearbyCustomers.SoftTitle");
                                            cardData.startDate = curCardData.StartDate;
                                            cardData.title = curCardData.Title;
                                            cardData.visibility = curCardData.Visibility;
                                            return cardData;
                                        });
                                        CardService.nearByCust = data;
                                        if (card) {
                                            CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId] = data;
                                        }
                                        var recordsEntityImageArray_1 = [];
                                        for (var key in data) {
                                            var cardData = data[key];
                                            if (cardData["data"]) {
                                                var contextObject = cardData["data"].cardContextDetails[0] != undefined
                                                    ? cardData["data"].cardContextDetails[0].contextObject
                                                    : "";
                                                if (contextObject &&
                                                    contextObject.guid != null &&
                                                    contextObject.guid != undefined &&
                                                    contextObject.entityName != null &&
                                                    contextObject.entityName != undefined) {
                                                    var getEntityImg = CardFeedContainer.CardUtils.getEntityImage(contextObject.entityName, contextObject.guid);
                                                    recordsEntityImageArray_1.push({
                                                        entityGuid: contextObject.guid,
                                                        index: key,
                                                        entityName: contextObject.entityName,
                                                    });
                                                    getEntityImg.then(function (data) {
                                                        if (data && data.entities && data.entities.length > 0) {
                                                            var img = data.entities[0].entityimage_url ? data.entities[0].entityimage_url : "";
                                                            for (var entity in recordsEntityImageArray_1) {
                                                                var entityId = recordsEntityImageArray_1[entity].entityName;
                                                                if (recordsEntityImageArray_1[entity].entityGuid == data.entities[0][entityId + "id"]) {
                                                                    if (card) {
                                                                        CardFeedContainer.CardFeedContainer.flightNearByData[card.cardId][recordsEntityImageArray_1[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = img;
                                                                    }
                                                                    else {
                                                                        CardService.nearByCust[recordsEntityImageArray_1[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = img;
                                                                    }
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }, function (failure) {
                                                        console.log("Error:" + failure);
                                                    });
                                                }
                                            }
                                        }
                                    }
                                });
                            }, function (e) {
                                console.error(e);
                            });
                        }
                        else {
                        }
                    }
                    else {
                    }
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getNearbyCustomers = getNearbyCustomers;
            function getRegardingData(parameterInfo, args, ccfScope) {
                var json = JSON.stringify(parameterInfo);
                var deferred2 = retrieveCardData(CardService.staticRegardingId, json, ccfScope);
                CardService.regData = [];
                return deferred2.then(function (res) {
                    return res.json().then(function (odataResponse) {
                        var data;
                        if (odataResponse.Data && odataResponse.Data.length > 0) {
                            data = JSON.parse(odataResponse.Data);
                            var promises = [];
                            var recordsEntityImageArray_2 = [];
                            for (var key in data) {
                                var curCardData = data[key];
                                if (curCardData.Title != null) {
                                    var cardData = {};
                                    cardData.cardId = curCardData.CardId + Object.keys(data).indexOf(key);
                                    cardData.cardName = curCardData.CardName;
                                    cardData.data = curCardData.Data;
                                    cardData.description = ccfScope._context.resources.getString(curCardData.Description);
                                    cardData.expiryDate = curCardData.ExpiryDate;
                                    cardData.priority = curCardData.Priority;
                                    cardData.softTitle = ccfScope._context.resources.getString("ActionCard.CFC.UpcomingMeeting.RegardingText");
                                    cardData.startDate = curCardData.StartDate;
                                    cardData.title = curCardData.Title;
                                    cardData.visibility = curCardData.Visibility;
                                    if (!curCardData.RegardingObjectId &&
                                        curCardData.Data.cardContextDetails &&
                                        curCardData.Data.cardContextDetails.length > 0) {
                                        var contextObject = curCardData.Data.cardContextDetails[0].contextObject;
                                        cardData.regardingobjectid = { etn: contextObject.entityName, Id: contextObject.guid };
                                    }
                                    var index = CardService.regData.push(cardData);
                                    if (cardData["data"]) {
                                        var contextObject = cardData["data"].cardContextDetails[0] != undefined
                                            ? cardData["data"].cardContextDetails[0].contextObject
                                            : "";
                                        if (contextObject &&
                                            contextObject.guid != null &&
                                            contextObject.guid != undefined &&
                                            contextObject.entityName != null &&
                                            contextObject.entityName != undefined) {
                                            var getEntityImg = CardFeedContainer.CardUtils.getEntityImage(contextObject.entityName, contextObject.guid);
                                            recordsEntityImageArray_2.push({
                                                entityGuid: contextObject.guid,
                                                index: index - 1,
                                                entityName: contextObject.entityName,
                                            });
                                            promises.push(getEntityImg.then(function (data) {
                                                if (data && data.entities && data.entities.length > 0) {
                                                    var img = data.entities[0].entityimage_url ? data.entities[0].entityimage_url : "";
                                                    for (var entity in recordsEntityImageArray_2) {
                                                        var entityId = recordsEntityImageArray_2[entity].entityName;
                                                        if (recordsEntityImageArray_2[entity].entityGuid == data.entities[0][entityId + "id"]) {
                                                            CardService.regData[recordsEntityImageArray_2[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = img;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }, function (failure) {
                                                console.log("Error:" + failure);
                                            }));
                                        }
                                    }
                                }
                            }
                            Promise.all(promises).then(function () {
                                CardFeedContainer.CardFeedContainer.cfcContext.utils.requestRender();
                            });
                        }
                    });
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getRegardingData = getRegardingData;
            function getFlightRegardingData(parameterInfo, card) {
                var json = JSON.stringify(parameterInfo);
                var deferred2 = retrieveCardData(CardService.staticRegardingId, json);
                var promises = [];
                var recordsEntityImageArray = [];
                return deferred2.then(function (res) {
                    return res.json().then(function (odataResponse) {
                        var data = JSON.parse(odataResponse.Data);
                        data = data.map(function (curCardData, index) {
                            var cardData = {};
                            cardData.cardId = curCardData.CardId + index;
                            cardData.cardName = curCardData.CardName;
                            cardData.data = curCardData.Data;
                            cardData.description = curCardData.Description;
                            cardData.expiryDate = curCardData.ExpiryDate;
                            cardData.priority = curCardData.Priority;
                            cardData.softTitle = CardFeedContainer.CardFeedContainer.cfcContext.resources.getString("ActionCard.CFC.UpcomingFlight.Meeting.SoftTitle");
                            cardData.startDate = curCardData.StartDate;
                            cardData.title = curCardData.Title;
                            cardData.visibility = curCardData.Visibility;
                            return cardData;
                        });
                        CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId] = data;
                        var recordsEntityImageArray = [];
                        for (var key in data) {
                            var cardData = data[key];
                            if (cardData["data"]) {
                                var contextObject = cardData["data"].cardContextDetails[0] != undefined
                                    ? cardData["data"].cardContextDetails[0].contextObject
                                    : "";
                                if (contextObject &&
                                    contextObject.guid != null &&
                                    contextObject.guid != undefined &&
                                    contextObject.entityName != null &&
                                    contextObject.entityName != undefined) {
                                    var getEntityImg = CardFeedContainer.CardUtils.getEntityImage(contextObject.entityName, contextObject.guid);
                                    recordsEntityImageArray.push({
                                        entityGuid: contextObject.guid,
                                        index: key,
                                        entityName: contextObject.entityName,
                                    });
                                    getEntityImg.then(function (data) {
                                        if (data && data.entities && data.entities.length > 0) {
                                            var img = data.entities[0].entityimage_url ? data.entities[0].entityimage_url : "";
                                            for (var entity in recordsEntityImageArray) {
                                                var entityId = recordsEntityImageArray[entity].entityName;
                                                if (recordsEntityImageArray[entity].entityGuid == data.entities[0][entityId + "id"]) {
                                                    CardFeedContainer.CardFeedContainer.flightMeetingData[card.cardId][recordsEntityImageArray[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = img;
                                                    break;
                                                }
                                            }
                                        }
                                    }, function (failure) {
                                        console.log("Error:" + failure);
                                    });
                                }
                            }
                        }
                    });
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getFlightRegardingData = getFlightRegardingData;
            function getAttendeesData(parameterInfo, args, ccfScope) {
                var json = JSON.stringify(parameterInfo);
                var deferred2 = retrieveCardData(CardService.staticRegardingId, json, ccfScope);
                CardService.attData = [];
                CardFeedContainer.CardFeedContainer.nextMeetingAttendees[args.cardData.cardId] = [];
                return deferred2.then(function (res) {
                    return res.json().then(function (odataResponse) {
                        var data;
                        if (odataResponse.Data && odataResponse.Data.length > 0) {
                            data = JSON.parse(odataResponse.Data);
                            var recordsEntityImageArray_3 = [];
                            var entityGUIDMappings = {};
                            if (data.cardRelatedInfo && data.cardRelatedInfo.attendees) {
                                for (var i in data.cardRelatedInfo.attendees) {
                                    var curAttendee = data.cardRelatedInfo.attendees[i];
                                    var cardData = {};
                                    cardData.mode = "small";
                                    cardData.cardData = args.cardData;
                                    cardData.cardId = "ATTENDEE" + i.toString();
                                    cardData.cardName = "ATTENDEE";
                                    cardData.softTitle = ccfScope._context.resources.getString("ActionCard.CFC.UpcomingMeeting.AttendeesText");
                                    cardData.title = curAttendee.contextPrimaryInfo.title;
                                    cardData.description = curAttendee.contextPrimaryInfo.description;
                                    cardData.cardTypeIcon = curAttendee.contextIcon;
                                    cardData.cardOptionIcon =
                                        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAHRJREFUWIXtlDEOgDAMAw/E1K3iC3yGF/Oqio21LGZgTIuAwTfVkdpaSWQw5mOGjrszkHQ+gPKmgRnYgCxdgBXYow9NjQaSPl+kq2phA2Ojgcdo7cA18ypdVAvTs4SZ+xKG22/AOeAccA4Y54BzwDlgzA84AVMHKhzbfPhRAAAAAElFTkSuQmCC";
                                    cardData.groupBackIcon =
                                        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAArCAYAAAAUo/pwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAIgSURBVFhH7ZZNSxtBGMf/k0w2b7a0pYYepCZ4qFBb2kNV0B76GVoQvRUVT578BH4DQT0qKIgfoMcei5Q2KlLvvtCglECTaJLVJDvxmbBCKWJm4iwssr/LLuwy+5vnZfZhTQI+hF1Uzv0pdrD33Z9iR/tZX4qF3KvvCMR0CcR0CcR0ub9ijLk3hrmTWCTMcFJycNloGhfsWCzGGXZzNcx/LeO44IAbLoqOlouSVPZ3DYtbVYy9iSPzhKMh3IeG0BaTUtuu1MTbOEbTFiwOmJ7qtMRaUpS+JZIaJ6kRj6QkymIWSe2Q1LKbvvcZ76QkSvNYmPT3T+tY27bx6XUcH/oscOrI9lM5gyOasKlrZQ3qNK6SWI6OhLkvZ3Q0CLx8xhGiL6hEqkZSL7o5Pr6KoT8VQd1RD6+SWOlCYOFbBVtHdUwPJRANA/TNtkiPp8kQBmgzqa4QRc99oICSmIzQn3OBzT2b0sowO5JA0qI0KcgJkqnRiyob+RflmV+e8rliA6tZu3W4zgwn8CAma8h9wTDKXSnro+cRx+d3cVTrAis/qyjZzVZjeIHWslLuOclNDiZQpLpb37FR8EhOe0lZL72POaZILl9xsLFrI18WoEwbpaO9ymkiTf9H2aFnFLnypfnpQrn4b8KiMP2tCsQizB/TxTUyrQ+pMyN+qLH/kedTxyG/BQ/2aoZATJdATJdATJdATJdATBd2+OuHF7+6OwJcAfQP04PXKjyQAAAAAElFTkSuQmCC";
                                    cardData.data = {
                                        cardContextDetails: [curAttendee],
                                    };
                                    var index = CardService.attData.push(cardData);
                                    CardFeedContainer.CardFeedContainer.nextMeetingAttendees[args.cardData.cardId].push(cardData);
                                    if (cardData["data"]) {
                                        var contextObject = cardData["data"].cardContextDetails[0] != undefined
                                            ? cardData["data"].cardContextDetails[0].contextObject
                                            : "";
                                        if (contextObject &&
                                            contextObject.guid != null &&
                                            contextObject.guid != undefined &&
                                            contextObject.entityName != null &&
                                            contextObject.entityName != undefined) {
                                            recordsEntityImageArray_3.push({
                                                entityGuid: contextObject.guid,
                                                index: index - 1,
                                                entityName: contextObject.entityName,
                                            });
                                            var imageRequestsForEntity = entityGUIDMappings[contextObject.entityName];
                                            if (imageRequestsForEntity) {
                                                imageRequestsForEntity.push(contextObject.guid);
                                            }
                                            else {
                                                entityGUIDMappings[contextObject.entityName] = [contextObject.guid];
                                            }
                                        }
                                    }
                                }
                            }
                            if (!$.isEmptyObject(entityGUIDMappings)) {
                                var promises = CardFeedContainer.CardUtils.fetchEntityImages(entityGUIDMappings);
                                promises.forEach(function (promise) {
                                    promise.then(function (data) {
                                        if (data && data.entities && data.entities.length > 0) {
                                            data.entities.forEach(function (img) {
                                                var imgUrl = img ? img.entityimage_url : "";
                                                for (var entity in recordsEntityImageArray_3) {
                                                    var entityId = recordsEntityImageArray_3[entity].entityName;
                                                    if (recordsEntityImageArray_3[entity].entityGuid == img[entityId + "id"]) {
                                                        CardService.attData[recordsEntityImageArray_3[entity].index].data.cardContextDetails[0].contextObject.entityImgUrl = imgUrl;
                                                        break;
                                                    }
                                                }
                                            });
                                        }
                                    }, function (failure) {
                                        console.log("Error:" + failure);
                                    });
                                });
                                Promise.all(promises).then(function () {
                                    CardFeedContainer.CardFeedContainer.cfcContext.utils.requestRender();
                                });
                            }
                        }
                    });
                }, function (e) {
                    console.error(e);
                });
            }
            CardService.getAttendeesData = getAttendeesData;
            function callLocationService(address, bingMapsApiKey) {
                var jQuery = $;
                var deferred = jQuery.Deferred();
                if (address && bingMapsApiKey && address != "" && bingMapsApiKey != "") {
                    var request = MscrmCommon.ControlUtils.String.Format(CardService.geocodeRequest, encodeURIComponent(address), bingMapsApiKey);
                    $.ajax({
                        url: request,
                        dataType: "jsonp",
                        jsonp: "jsonp",
                        success: function (r) {
                            deferred.resolve({ status: true, error: null, data: r });
                        },
                        error: function (e) {
                            deferred.resolve({ status: false, error: e, data: null });
                        },
                    });
                }
                else {
                    deferred.resolve({ status: false, error: "No address or bingMapsApiKey specified", data: null });
                }
                return deferred;
            }
            CardService.callLocationService = callLocationService;
            function retrieveCardData(guid, data, ccfScope) {
                var r = new RelationshipAssitantSdkContracts.RetrieveCardDataRequest(guid, data);
                var genericRequest = r;
                var deferred = CardFeedContainer.CardFeedContainer.cfcContext.webAPI.execute(genericRequest);
                return deferred;
            }
        })(CardService = CardFeedContainer.CardService || (CardFeedContainer.CardService = {}));
    })(CardFeedContainer = MscrmControls.CardFeedContainer || (MscrmControls.CardFeedContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var ActionOnRACard = "ActionOnRelationshipAssistantCard";
var RAEntryPoint = "RelationshipAssistantEntryPoint";
var RAActionCardFeedback = "ActionCardFeedback";
var ActionCardDisplayEvent = "ActionCardDisplay";
var CardEventParameter = (function () {
    function CardEventParameter(name, value) {
        this.name = name;
        this.value = value;
    }
    return CardEventParameter;
}());
var ActionOnRelationshipAssistantCard = (function () {
    function ActionOnRelationshipAssistantCard(cardType, actionTaken, entryPoint, appName, isUCI, deviceName) {
        this.eventParameters = [];
        this.eventName = ActionOnRACard;
        this.addEventParameter("cardType", cardType);
        this.addEventParameter("actionTaken", actionTaken);
        this.addEventParameter("cardEntryPoint", entryPoint);
        this.addEventParameter("appName", appName);
        this.addEventParameter("isUCI", isUCI);
        this.addEventParameter("deviceName", deviceName);
    }
    ActionOnRelationshipAssistantCard.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionOnRelationshipAssistantCard;
}());
var RelationshipAssistantEntryPoint = (function () {
    function RelationshipAssistantEntryPoint(entryPoint, appName) {
        this.eventParameters = [];
        this.eventName = RAEntryPoint;
        this.addEventParameter("entryPoint", entryPoint);
        this.addEventParameter("appName", appName);
    }
    RelationshipAssistantEntryPoint.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return RelationshipAssistantEntryPoint;
}());
var ActionCardFeedback = (function () {
    function ActionCardFeedback(cardType, response, reason) {
        this.eventParameters = [];
        this.eventName = RAActionCardFeedback;
        this.addEventParameter("cardType", cardType);
        this.addEventParameter("response", response);
        this.addEventParameter("reason", reason);
    }
    ActionCardFeedback.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionCardFeedback;
}());
var ActionCardDisplay = (function () {
    function ActionCardDisplay(entryPoint, cardType, cardId) {
        this.eventParameters = [];
        this.eventName = ActionCardDisplayEvent;
        this.addEventParameter("cardId", cardId);
        this.addEventParameter("cardType", cardType);
        this.addEventParameter("entryPoint", entryPoint);
    }
    ActionCardDisplay.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionCardDisplay;
}());
var ActionCardAlertsAndErrors = (function () {
    function ActionCardAlertsAndErrors(functionName, errStr) {
        this.eventParameters = [];
        this.eventName = RAActionCardFeedback;
        this.addEventParameter("function", functionName);
        this.addEventParameter("errorString", errStr);
    }
    ActionCardAlertsAndErrors.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionCardAlertsAndErrors;
}());
var ActionCardPerformance = (function () {
    function ActionCardPerformance(functionName, timeSpent) {
        this.eventParameters = [];
        this.eventName = RAActionCardFeedback;
        this.addEventParameter("function", functionName);
        this.addEventParameter("timeSpent", timeSpent);
    }
    ActionCardPerformance.prototype.addEventParameter = function (parameterName, value) {
        var event = new CardEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionCardPerformance;
}());
