﻿/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */

module MscrmControls.HierarchyCommandBar {
	import HierarchyState = HierarchyControl.HierarchyState;

	export class commandBarStyle {
		private _theme: Mscrm.Theme;
		private _context: Mscrm.ControlData<IInputBag>;

		public constructor(context: Mscrm.ControlData<IInputBag>) {
			this._theme = context.theming;
			this._context = context;
		}

		// Todo: Currently redlines not available, It will be changed in future.
		public get commandBarStyle() {
			const currentState: HierarchyState = Utility.getInputStateParameter(this._context);

			return {
				container: {
					height: this._theme.measures.measure300,
					color: this._theme.colors.basecolor.grey["grey1"],
					marginLeft: "0px",
					marginRight: "0px",
					borderColor: this._theme.colors.basecolor.grey["grey1"],
					borderStyle: "none",
					borderWidth: "1px",
					backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					width: currentState.parentControlWidth,
				},
				list: {
					marginLeft: "0px",
					marginRight: this._theme.measures.measure100,
					marginTop: "0px",
					marginBottom: "0px",
					color: this._theme.colors.basecolor.grey["grey1"],
					listStyleType: "none",
				},
				listItem: {
					lineHeight: this._theme.measures.measure100,
					height: this._theme.measures.measure300,
					marginRight: "0px",
					":last-child": {
						marginLeft: "0px",
						marginRight: "0px",
					},
					"[aria-expanded=true]": {
						backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					},
					"[data-expanded= true]": {
						backgroundColor: this._theme.colors.basecolor.grey["grey2"],
					},
					"[data-expanded=true]": {
						backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					},
				},
				moreIcon: {
					marginRight: this._theme.measures.measure100,
					marginLeft: this._theme.measures.measure100,
					color: this._theme.colors.basecolor.white,
				},
				overflowFlyoutMoreButton: {
					backgroundColor: "transparent",
					lineHeight: this._theme.measures.measure100,
					height: this._theme.measures.measure300,
					borderWidth: 0,
					padding: 0,
					cursor: "pointer",
					alignItems: "center",
					":hover": {
						backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					},
				},
				listItemBody: {
					button: {
						backgroundColor: "transparent",
						lineHeight: this._theme.measures.measure100,
						height: this._theme.measures.measure300,
						borderWidth: "0px",
						cursor: "pointer",
						":hover": {
							backgroundColor: this._theme.colors.basecolor.blue["blue3"],
						},
						alignItems: "center",
						paddingLeft: this._theme.measures.measure100,
						paddingRight: this._theme.measures.measure100,
					},
					icon: {
						lineHeight: this._theme.measures.measure150,
						height: "16px",
						color: this._theme.colors.basecolor.white,
						width: "16px",
					},
					text: {
						fontSize: this._theme.measures.measure100,
						color: this._theme.colors.basecolor.white,
						lineHeight: this._theme.measures.measure150,
						whiteSpace: "nowrap",
						overflow: "hidden",
						textOverflow: "ellipsis",
						maxWidth: "150px",
						fontFamily: "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'",
					},
					iconWrapperStyles: {
						marginRight: this._theme.measures.measure100,
						fontSize: this._theme.measures.measure100,
						lineHeight: this._theme.measures.measure150,
						minWidth: "16px",
						color: this._theme.colors.basecolor.white,
					},
					splitButtonChevronIconWrapper: {
						lineHeight: this._theme.measures.measure100,
						minWidth: "16px",
						borderStyle: "solid",
						borderLeftWidth: "1px",
						borderLeftColor: this._theme.colors.basecolor.white,
						paddingLeft: this._theme.measures.measure050,
						paddingRight: this._theme.measures.measure050,
					},
					flyoutButtonChevronIconWrapper: {
						lineHeight: this._theme.measures.measure100,
						minWidth: "16px",
						paddingLeft: this._theme.measures.measure050,
						paddingRight: this._theme.measures.measure050,
					},
					buttonContentWrapperStyle: {
						flexGrow: 1,
					},
				},
				primaryOfSplitButton: {
					lineHeight: this._theme.measures.measure100,
					height: this._theme.measures.measure100,
					paddingRight: "0px",
				},
				splitbuttonicon: {
					height: "8px",
					width: "8px",
					color: this._theme.colors.basecolor.white,
					marginRight: this._theme.measures.measure200,
					marginLeft: this._theme.measures.measure050,
				},
				splitbuttonOverflowButton: {
					minWidth: this._theme.measures.measure250,
					marginLeft: "0px",
					"[aria-expanded=true]": {
						backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					},
					"[data-expanded=true]": {
						backgroundColor: this._theme.colors.basecolor.blue["blue3"],
					},
				},
				flyoutStyles: {
					flyoutContainerStyles: {},
					flyoutListItemBody: {
						text: {
							fontSize: this._theme.measures.measure100,
							color: this._theme.colors.basecolor.grey["grey7"],
							lineHeight: this._theme.measures.measure150,
							fontFamily: "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'",
							whiteSpace: "nowrap",
							overflow: "hidden",
							textOverflow: "ellipsis",
							maxWidth: "180px",
						},
						icon: {
							lineHeight: this._theme.measures.measure100,
							height: "16px",
							color: this._theme.colors.basecolor.grey["grey7"],
							width: "16px",
						},
						iconWrapperStyles: {
							lineHeight: this._theme.measures.measure100,
							marginRight: this._theme.measures.measure100,
							minWidth: "16px",
						},
						splitButtonChevronIconWrapper: {
							lineHeight: this._theme.measures.measure100,
							minWidth: "16px",
							borderStyle: "solid",
							borderLeftWidth: "1px",
							borderLeftColor: this._theme.colors.basecolor.grey["grey4"],
							paddingLeft: this._theme.measures.measure050,
							paddingRight: this._theme.measures.measure050,
							color: this._theme.colors.basecolor.white,
							":hover": {
								backgroundColor: this._theme.colors.basecolor.grey["grey3"],
							},
						},
						flyoutButtonChevronIconWrapper: {
							lineHeight: this._theme.measures.measure100,
							minWidth: "16px",
							paddingLeft: this._theme.measures.measure050,
							paddingRight: this._theme.measures.measure050,
							color: this._theme.colors.basecolor.white,
							paddingTop: this._theme.measures.measure025,
						},
						button: {
							lineHeight: this._theme.measures.measure150,
							height: this._theme.measures.measure250,
							backgroundColor: "transparent",
							borderWidth: 0,
							cursor: "pointer",
							paddingLeft: this._theme.measures.measure150,
							paddingRight: this._theme.measures.measure075,
							paddingTop: this._theme.measures.measure050,
							paddingBottom: this._theme.measures.measure050,
							width: "100%",
							alignItems: "center",
							":hover": {
								backgroundColor: this._theme.colors.basecolor.grey["grey3"],
							},
						},
					},
					flyoutListItemStyles: {
						height: this._theme.measures.measure250,
					},
					flyoutListStyles: {
						":first-child": {
							marginTop: this._theme.measures.measure100,
						},
						":last-child": {
							marginBottom: this._theme.measures.measure100,
						},
						listStyleType: "none",
						display: "flex",
						flexDirection: "column",
						cursor: "pointer",
						marginBottom: this._theme.measures.measure075,
					},
					flyoutChevronStyle: {
						minWidth: "16px",
						lineHeight: this._theme.measures.measure100,
						color: this._theme.colors.basecolor.grey["grey6"],
					},
					flyoutPrimaryOfSplitButton: {
						lineHeight: this._theme.measures.measure100,
						height: this._theme.measures.measure100,
						flexGrow: 1,
					},
					flyoutBackButtonStyle: {
						marginTop: this._theme.measures.measure150,
						minWidth: "16px",
						minHeight: this._theme.measures.measure250,
						cursor: "pointer",
						display: "flex",
						paddingLeft: this._theme.measures.measure100,
						paddingRight: this._theme.measures.measure100,
						":hover": {
							backgroundColor: this._theme.colors.basecolor.grey["grey3"],
						},
						alignItems: "center",
					},
					flyoutBackButtonTextStyle: {
						color: this._theme.colors.basecolor.black,
						fontWeight: this._theme.fontfamilies.bold,
						paddingLeft: this._theme.measures.measure075,
					},
				},
			};
		}
	}
}
