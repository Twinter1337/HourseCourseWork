/// <reference path="../../../../../../src/Typings/jquery.d.ts" />
declare module MscrmControls.KbArticleControl {
    class Constants {
        static NumberOfViewsIconToolTip: string;
        static ModifiedOnLabelToolTip: string;
        static RatingIconToolTip: string;
        static ModifiedOnLabel: string;
    }
}
declare module MscrmControls.KbArticleControl {
    interface IInputBag {
        article: Mscrm.IKbSearchRecord;
        enableRating: string;
    }
    interface IOutputBag {
    }
}
declare module MscrmControls.KbArticleControl {
    class KbArticleControl implements Mscrm.Control<IInputBag, IOutputBag> {
        KbSearchResultLegendsObject: KbSearchResultLegends;
        private _context;
        constructor();
        init(context: Mscrm.ControlData<IInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        updateView(context: Mscrm.ControlData<IInputBag>): Mscrm.Component;
        renderArticleMetadata(): Mscrm.Component;
        renderArticleTitle(title: string): Mscrm.Component;
        renderControlBlock(isPopupControl?: boolean): Mscrm.Component;
        render(isPopupControl: boolean): Mscrm.Component;
        getOutputs(): Mscrm.ControlData<IOutputBag>;
        destroy(): void;
    }
}
declare module MscrmControls.KbArticleControl {
    class KbSearchResultLegends {
        private _context;
        constructor();
        init(context: Mscrm.ControlData<IInputBag>, notifyOutputChanged?: () => void, state?: Mscrm.Dictionary, container?: HTMLDivElement): void;
        render(kbSearchRecord: Mscrm.IKbSearchRecord): Mscrm.Component;
        getOutputs(): Mscrm.ControlData<IOutputBag>;
        destroy(): void;
        onPreNavigation(): void;
    }
}
