﻿/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */

module MscrmControls.HierarchyControl {
	export class style {
		private _context: Mscrm.ControlData<IInputBag>;
		private _theme: Mscrm.Theme;

		public constructor(context: Mscrm.ControlData<IInputBag>) {
			this._context = context;
			this._theme = context.theming;
		}

		public get accountWholeContainer() {
			return {
				width: "100%",
				height: "100%",
				display: "block",
			};
		}

		public get flexbox() {
			return {
				display: "block",
			};
		}

		public get enableScroll() {
			return {
				overflow: "auto",
			};
		}

		public get flex() {
			return {
				display: "flex",
			};
		}

		public get mainContainer() {
			return {
				width: "100%",
				height: "calc(100% - 10.5rem)",
				position: "absolute",
			};
		}

		public get headerContainerStyle() {
			return {
				minHeight: this._theme.measures.measure350,
				paddingLeft: this._theme.measures.measure150,
				paddingRight: this._theme.measures.measure150,
				backgroundColor: this._theme.colors.basecolor.white,
				paddingTop: this._theme.measures.measure200,
				paddingBottom: this._theme.measures.measure200,
			};
		}

		public get commandBarContainerStyle() {
			return {
				paddingLeft: this._theme.measures.measure150,
				paddingRight: this._theme.measures.measure150,
				paddingTop: this._theme.measures.measure200,
				paddingBottom: this._theme.measures.measure200,
			};
		}

		public get entityNameTextStyle() {
			return {
				fontFamily: "'SegoeUI', 'Segoe UI'",
				fontSize: this._theme.measures.measure150,
				lineHeight: this._theme.measures.measure200,
				color: this._theme.colors.basecolor.grey["grey7"],
				height: this._theme.measures.measure200,
				fontWeight: "normal",
			};
		}

		public get entityTypeTextStyle() {
			return {
				fontFamily: "'SegoeUI', 'Segoe UI'",
				fontSize: this._theme.measures.measure100,
				color: this._theme.colors.basecolor.grey["grey7"],
				textOverflow: "ellipsis",
				lineHeight: this._theme.measures.measure150,
				border: "0",
			};
		}

		public get headerIconTextStyle() {
			return {
				height: this._theme.measures.measure350,
				fontSize: "1.15rem",
				lineHeight: this._theme.measures.measure350,
				color: this._theme.colors.basecolor.white,
				textTransform: "uppercase",
				fontWeight: this._theme.fontfamilies.bold,
			};
		}

		public get splitterStyle() {
			return {
				position: "relative",
				height: "100%",
				width: "1px",
				"background-color": this._theme.colors.basecolor.grey["grey3"],
				"border-left": "0.1px solid " + this._theme.colors.basecolor.grey["grey3"],
				cursor: "col-resize",
			};
		}
		public get splitterHelperStyle() {
			return {
				height: "100%",
				"margin-left": "-5px",
				cursor: "col-resize",
			};
		}
		public get splitterResizeStyle() {
			return {
				height: "100%",
				width: "10px",
				cursor: "col-resize",
			};
		}
		public get splitterInnerDivStyle() {
			return {
				width: "10px",
				top: "40%",
				position: "absolute",
				left: "-2px",
				cursor: "col-resize",
			};
		}
		public get splitterInnerHelperStyle() {
			return {
				width: "5px",
				height: "26px",
				"background-color": this._theme.colors.basecolor.grey["grey3"],
				border: "1px solid " + this._theme.colors.basecolor.grey["grey3"],
				cursor: "pointer",
			};
		}
		public get flexColumn() {
			return {
				"flex-flow": "column",
			};
		}
		public get rightContainer() {
			return {
				wordWrap: "break-word",
				height: "100%",
				overflow: "auto !important",
			};
		}
		public get leftContainer() {
			return {
				height: "100%",
				background: this._theme.colors.basecolor.white,
				border: "1px solid " + this._theme.colors.basecolor.grey["grey3"],
				display: "block",
				wordWrap: "break-word",
				overflow: "auto !important",
			};
		}

		public get entityImageStyle() {
			return {
				borderRadius: "50%",
				height: this._theme.measures.measure350,
				width: this._theme.measures.measure350,
				minWidth: this._theme.measures.measure350,
				textAlign: "center",
				fontWeight: this._theme.fontfamilies.bold,
				color: this._theme.colors.basecolor.white,
				lineHeight: this._theme.measures.measure350,
				marginleft: this._context.client.isRTL ? this._theme.measures.measure100 : 0,
				marginRight: this._context.client.isRTL ? 0 : this._theme.measures.measure100,
				fontSize: this._theme.fontsizes.font115,
				border: "1px solid",
			};
		}

		public get closeIconStyle() {
			return {
				cursor: "pointer",
				position: "absolute",
				right: "10px",
			};
		}

		public get toggleIconStyle() {
			return {
				cursor: "pointer",
				position: "absolute",
				left: this._context.client.isRTL ? "20px" : "unset" /*Icon width is 16px*/,
				right: this._context.client.isRTL ? "unset" : "20px" /*Icon width is 16px*/,
			};
		}
	}
}
