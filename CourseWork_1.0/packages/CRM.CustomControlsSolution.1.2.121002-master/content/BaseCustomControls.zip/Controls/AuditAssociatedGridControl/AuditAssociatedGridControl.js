/** @license Copyright (c) Microsoft Corporation. All rights reserved. */
var MscrmControls;
(function (MscrmControls) {
    var AuditAssociatedGrid;
    (function (AuditAssociatedGrid) {
        "use strict";
        var CONTROL_PREFIX = "MscrmControls.AuditAssociatedGrid.AuditControl-";
        var HYBRID_AUDIT_CONTAINER_ID = "hybrid_audit_container";
        var AUDIT_IFRAME_ID = "audit_iframe";
        var IFRAME_MIN_HEIGHT = 300;
        var CONTAINER_DEPTH = 5;
        var AuditControl = (function () {
            function AuditControl() {
                this._clientUrl = Xrm.Utility.getGlobalContext().getClientUrl();
                this._isLoading = true;
                this._associatedGridContainerHeight = -1;
                this._addEventHandlers = this._addEventHandlers.bind(this);
            }
            AuditControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
            };
            AuditControl.prototype._createUrl = function (base, path, params) {
                var url = base + "/" + path + "?";
                for (var i = 0; i < params.length; i++) {
                    var param = params[i];
                    url += "" + (i > 0 ? "&" : "") + encodeURIComponent(param.key) + "=" + encodeURIComponent(param.value);
                }
                return url;
            };
            AuditControl.prototype._addEventHandlers = function () {
                var iframe = document.getElementById(AUDIT_IFRAME_ID);
                var contentWindowDocument = iframe.contentWindow.document;
                var layoutLites = contentWindowDocument.getElementsByClassName("ms-crm-Form-AssociatedGrid-Layout-Lite");
                if (layoutLites && layoutLites[0]) {
                    layoutLites[0].style.margin = 0;
                    layoutLites[0].style.width = "100%";
                    layoutLites[0].style.height = "100%";
                }
                var lookupElements = contentWindowDocument.getElementsByClassName("ms-crm-LookupItem-Name");
                var _loop_1 = function (i) {
                    var lookupElement = lookupElements[i];
                    var clickableElement = lookupElement && lookupElement.parentElement && lookupElement.parentElement.parentElement;
                    var path = "main.aspx";
                    var oid = clickableElement.getAttribute("oid");
                    var appId = this_1._context.page.appId;
                    var params = [
                        { key: "appid", value: appId },
                        { key: "pagetype", value: "entityrecord" },
                        { key: "etn", value: "systemuser" },
                        { key: "id", value: oid.replace("{", "").replace("}", "") },
                    ];
                    var userUrl = this_1._createUrl(this_1._clientUrl, path, params);
                    var clickHandler = function () { return window.open(userUrl, "_self"); };
                    clickableElement.addEventListener("click", clickHandler, false);
                };
                var this_1 = this;
                for (var i = 0; i < lookupElements.length; i++) {
                    _loop_1(i);
                }
            };
            AuditControl.prototype._mutationObserver = function () {
                var _this = this;
                var auditIframe = document.querySelector("#" + AUDIT_IFRAME_ID);
                var target = auditIframe && auditIframe.contentWindow.document;
                this._observer = new MutationObserver(function (mutations) {
                    mutations.forEach(function (mutation) {
                        if (mutation.type == "childList") {
                            _this._addEventHandlers();
                        }
                    });
                });
                var config = {
                    childList: true,
                    subtree: true,
                };
                this._observer.observe(target, config);
            };
            AuditControl.prototype._onLoad = function (e) {
                if (this._isLoading) {
                    this._isLoading = false;
                    this._mutationObserver();
                    var hybridAuditContainer = document.getElementById(CONTROL_PREFIX + HYBRID_AUDIT_CONTAINER_ID);
                    var formContainer = hybridAuditContainer;
                    for (var i = 0; i < CONTAINER_DEPTH; i++) {
                        formContainer = formContainer && formContainer.parentElement;
                    }
                    this._associatedGridContainerHeight = formContainer.clientHeight;
                    AuditAssociatedGridTelemetry.AuditAssociatedGridTelemetry.reportOnLoadSuccess(this._context, this._clientUrl);
                    this._context.utils.requestRender();
                }
                this._addEventHandlers();
            };
            AuditControl.prototype._renderHybridAuditAssociatedGrid = function (context) {
                var path = "userdefined/areas.aspx";
                var entityId = context.page.entityId;
                var formId = context.parameters.FormId && context.parameters.FormId.raw;
                var oType = context.parameters.OType && context.parameters.OType.raw;
                var params = [
                    { key: "formid", value: formId },
                    { key: "inlineEdit", value: "1" },
                    { key: "navItemName", value: "Audit History" },
                    { key: "oId", value: "" + entityId },
                    { key: "oType", value: oType },
                    { key: "pagemode", value: "iframe" },
                    { key: "rof", value: "true" },
                    { key: "security", value: "852023" },
                    { key: "tabSet", value: "areaAudit" },
                    { key: "theme", value: "Outlook15White" },
                ];
                var url = this._createUrl(this._clientUrl, path, params);
                var properties = {
                    id: AUDIT_IFRAME_ID,
                    src: url,
                    onLoad: this._onLoad.bind(this),
                    style: {
                        flex: "1 1 auto",
                        flexDirection: "column",
                        height: "100%",
                        width: "100%",
                    },
                };
                return context.factory.createElement("IFRAME", properties);
            };
            AuditControl.prototype.updateView = function (context) {
                var key = "AuditGridLoading";
                var progressIndicator = context.factory.createElement("PROGRESSINDICATOR", {
                    id: key,
                    key: key,
                    progressType: "ring",
                    active: true,
                    style: {
                        width: 40,
                        height: 40,
                    },
                });
                var auditHybridAssociatedGridContainer = context.factory.createElement("CONTAINER", {
                    key: "hybrid_audit",
                    id: "hybrid_audit",
                    isRequestedMeasuring: false,
                    onMeasuring: null,
                    style: {
                        flex: "1 1 auto",
                        flexDirection: "column",
                        width: "100%",
                        height: "100%",
                        visibility: this._isLoading ? "hidden" : "visible",
                        boxSizing: "border-box",
                        paddingTop: context.theming.measures.measure150,
                        paddingRight: context.theming.measures.measure200,
                        paddingBottom: 0,
                        paddingLeft: context.theming.measures.measure200,
                        backgroundColor: context.theming.colors.whitebackground,
                    },
                }, this._renderHybridAuditAssociatedGrid(context));
                var _associatedGridContainerHeight = this._associatedGridContainerHeight
                    ? Math.max(this._associatedGridContainerHeight, IFRAME_MIN_HEIGHT) + "px"
                    : "100%";
                var auditHybridControlContainer = context.factory.createElement("CONTAINER", {
                    key: HYBRID_AUDIT_CONTAINER_ID,
                    id: HYBRID_AUDIT_CONTAINER_ID,
                    isRequestedMeasuring: false,
                    onMeasuring: null,
                    style: {
                        display: "flex",
                        flex: 1,
                        minHeight: _associatedGridContainerHeight,
                    },
                }, [this._isLoading ? progressIndicator : null, auditHybridAssociatedGridContainer]);
                return auditHybridControlContainer;
            };
            AuditControl.prototype.getOutputs = function () {
                return null;
            };
            AuditControl.prototype.destroy = function () {
                if (this._observer) {
                    this._observer.disconnect();
                }
            };
            return AuditControl;
        }());
        AuditAssociatedGrid.AuditControl = AuditControl;
    })(AuditAssociatedGrid = MscrmControls.AuditAssociatedGrid || (MscrmControls.AuditAssociatedGrid = {}));
})(MscrmControls || (MscrmControls = {}));
var AuditAssociatedGridTelemetry;
(function (AuditAssociatedGridTelemetry_1) {
    var AuditAssociatedGridTelemetry = (function () {
        function AuditAssociatedGridTelemetry() {
        }
        AuditAssociatedGridTelemetry.reportSuccess = function (context, actionName, params) {
            var componentName = this.auditAssociatedGrid + "." + actionName;
            context.reporting.reportSuccess(componentName, params);
        };
        AuditAssociatedGridTelemetry.reportFailure = function (context, actionName, error, suggestedMitigation, params) {
            var componentName = this.auditAssociatedGrid + "." + actionName;
            context.reporting.reportFailure(componentName, error, suggestedMitigation, params);
        };
        AuditAssociatedGridTelemetry.reportOnLoadSuccess = function (context, clientUrl) {
            var eventParams = new Array();
            var clientUrlParam = {
                name: this.clientUrl,
                value: clientUrl,
            };
            eventParams.push(clientUrlParam);
            var timeStampParam = {
                name: this.timeStamp,
                value: new Date().toString(),
            };
            eventParams.push(timeStampParam);
            var browserTypeParam = {
                name: this.browserType,
                value: this.getBrowserType(context),
            };
            eventParams.push(browserTypeParam);
            var orgId = context.client && context.client.orgSettings && context.client.orgSettings.organizationId;
            var orgIdParam = {
                name: this.orgId,
                value: orgId && orgId.replace("{", "").replace("}", ""),
            };
            eventParams.push(orgIdParam);
            var userId = context.userSettings && context.userSettings.userId;
            var userIdParam = {
                name: this.userId,
                value: userId && userId.replace("{", "").replace("}", ""),
            };
            eventParams.push(userIdParam);
            this.reportSuccess(context, this.renderEmbeddedAuditAssociatedGrid, eventParams);
        };
        AuditAssociatedGridTelemetry.getBrowserType = function (context) {
            var userAgent = context.client && context.client.userAgent;
            if (!userAgent) {
                return "Unknown browser type";
            }
            if (userAgent.isBrowserChrome) {
                return "Chrome";
            }
            if (userAgent.isBrowserFirefox) {
                return "Firefox";
            }
            if (userAgent.isBrowserSafari) {
                return "Safari";
            }
            if (userAgent.isBrowserIE) {
                return "IE";
            }
            return "Other";
        };
        AuditAssociatedGridTelemetry.auditAssociatedGrid = "AuditAssociatedGrid";
        AuditAssociatedGridTelemetry.clientUrl = "ClientUrl";
        AuditAssociatedGridTelemetry.renderEmbeddedAuditAssociatedGrid = "renderEmbeddedAuditAssociatedGrid";
        AuditAssociatedGridTelemetry.timeStamp = "timeStamp";
        AuditAssociatedGridTelemetry.browserType = "browserType";
        AuditAssociatedGridTelemetry.orgId = "orgId";
        AuditAssociatedGridTelemetry.userId = "userId";
        return AuditAssociatedGridTelemetry;
    }());
    AuditAssociatedGridTelemetry_1.AuditAssociatedGridTelemetry = AuditAssociatedGridTelemetry;
})(AuditAssociatedGridTelemetry || (AuditAssociatedGridTelemetry = {}));
