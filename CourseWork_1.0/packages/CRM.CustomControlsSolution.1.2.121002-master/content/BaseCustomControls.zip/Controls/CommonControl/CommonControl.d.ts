/// <reference path="../../../../../../src/Typings/Wijmo/wijmo.d.ts" />
/// <reference path="../../../../../../src/Shared/mscrm.d.ts" />
/// <reference path="../../../../../../src/Shared/mscrmcomponents.d.ts" />
/// <reference path="../../../../../../src/Typings/jquery.d.ts" />
declare module MscrmCommon.ErrorHandling {
    class ErrorCode {
        static ValueOutOfRangeId: string;
        static InvalidInputMaskId: string;
        static MaxLengthExceededId: string;
    }
}
declare module MscrmCommon.ErrorHandling {
    class NotificationHandler {
        private setNotification;
        private clearNotification;
        constructor(setNotification: (message: string, id: string) => boolean, clearNotification: (id: string) => boolean);
        notify(message: string, id: string): void;
        clear(id: string): void;
    }
}
declare module MscrmCommon.ErrorHandling {
    class ExceptionHandler {
        static throwException(message: string): void;
    }
}
declare module MscrmCommon {
    enum ProgressIndicatorType {
        Bar = 0,
        Ring = 1,
    }
}
declare module Mscrm {
    enum AttributeSourceType {
        Unknown = -1,
        Persistent = 0,
        Calculated = 1,
        Rollup = 2,
    }
}
declare module Mscrm {
    enum UpdateEventType {
        DataSet = 0,
        Layout = 1,
        Activation = 2,
        Theming = 3,
    }
    class UpdateEvents {
        private ignoredEvents;
        constructor();
        static getEventType(event: string): Mscrm.UpdateEventType;
        static getEventCode(event: Mscrm.UpdateEventType): string;
        shouldIgnoreEvent(event: Mscrm.UpdateEventType, shouldIgnore: boolean): void;
        isIgnoredEvent(event: Mscrm.UpdateEventType): boolean;
        static hasEvent(updatedProperties: string[], event: Mscrm.UpdateEventType): boolean;
    }
}
declare module MscrmCommon {
    class AttributeConstants {
        static Checked: string;
        static ReadOnly: string;
        static Disabled: string;
        static Style: string;
        static Layout: string;
    }
}
declare module MscrmControls.Common {
    enum ControlState {
        Disabled = 0,
        Enabled = 1,
    }
}
declare module MscrmCommon {
    class CommonControl<TParams, TOutput> implements Mscrm.StandardControl<TParams, TOutput> {
        static ClassName: string;
        static ClassRtl: string;
        static PointerDownEventName: string;
        static PointerMoveEventName: string;
        static PointerUpEventName: string;
        static TouchEndEventName: string;
        static DefaultValueLabel: string;
        static NullOrUndefinedInitContainer: string;
        static NullOrUndefinedInitValueContainer: string;
        static NullOrUndefinedInitNotifyOutputChangedDelegate: string;
        static UninitializedErrorMessage: string;
        static UninitializedDataBagMessage: string;
        static InvalidDataBagKeyFormat: string;
        static UninitializedControl: string;
        static InvalidInputParamMinMax: string;
        static InvalidInputParamStep: string;
        static InvalidInputParamValue: string;
        static NotGreaterThanZeroInputParamValue: string;
        static InvalidInputParam: string;
        static MethodNotOverridenFormat: string;
        static MethodNotImplementedInControl: string;
        private static accessibilityOutlineClassName;
        private lastKeyPress;
        notificationHandler: MscrmCommon.ErrorHandling.NotificationHandler;
        protected container: HTMLDivElement;
        protected controlWrapperContainer: HTMLDivElement;
        protected eventGuard: MscrmCommon.EventGuard;
        protected shouldNotifyOutputChanged: boolean;
        protected notifyOutputChanged: () => void;
        protected shouldPreventMultipleEventTypes: boolean;
        protected preventEditModePanoramaEvents: boolean;
        protected htmlEncode: (rawString: string) => string;
        protected updateEvents: Mscrm.UpdateEvents;
        private isInitialized;
        private isEnabled;
        private isInReadMode;
        private disablePanoramaScroll;
        constructor();
        isControlInitialized: boolean;
        init(context: Mscrm.ControlData<TParams>, notifyOutputChanged: () => void, state: Mscrm.Dictionary, container: HTMLDivElement): void;
        updateView(context: Mscrm.ControlData<TParams>): void;
        getOutputs(): TOutput;
        onPreNavigation(): void;
        destroy(): void;
        createWrapperContainer(className?: string, isRtl?: boolean): HTMLDivElement;
        protected initCore(context: Mscrm.ControlData<TParams>, state?: Mscrm.Dictionary): void;
        protected updateCore(context: Mscrm.ControlData<TParams>): void;
        protected destroyCore(): void;
        protected renderReadMode(context: Mscrm.ControlData<TParams>): void;
        protected renderEditMode(context: Mscrm.ControlData<TParams>): void;
        protected getOutputsCore(): TOutput;
        protected notifyEnabledControlOutputChanged(): void;
        protected isControlEnabled(context: Mscrm.ControlData<TParams>): boolean;
        protected showDefaultLabelCore(context: Mscrm.ControlData<TParams>): boolean;
        private toggleContainerVisibility(value);
        private initializeControl(context, state?);
        private shouldIgnoreUpdate(context);
        private throwIfPropertyBagNotValid(context);
        private cleanup();
        private handleEditToReadModeTransition(context);
        private removePanoramaEventsHandlers();
        private addPanoramaEventsHandlers();
        protected bindFocusVisibility(focusElement: JQuery, container: JQuery): void;
        protected unbindFocusVisibility(focusElement: JQuery, container: JQuery): void;
    }
}
declare module MscrmCommon {
    class FieldControlBase<TParams, TOutput> extends CommonControl<TParams, TOutput> {
        constructor();
    }
}
declare module MscrmCommon {
    class EventConstants {
        static Change: string;
        static Click: string;
        static JQueryKnobConfigure: string;
        static JQuerySwipeLeft: string;
        static JQuerySwipeRight: string;
        static KeyUp: string;
        static KeyDown: string;
        static MouseUp: string;
        static MouseDown: string;
        static MouseOver: string;
        static MouseMove: string;
        static MouseOut: string;
        static PointerDown: string;
        static PointerMove: string;
        static PointerUp: string;
        static PointerOut: string;
        static MSPointerOver: string;
        static MSPointerDown: string;
        static MSPointerOut: string;
        static MSPointerUp: string;
        static MSPointerMove: string;
        static TouchStart: string;
        static TouchMove: string;
        static TouchEnd: string;
        static WijmoValueChangedEvent: string;
        static WijmoIsDroppedDownChangedEvent: string;
        static WijmoSelectedIndexChangedEvent: string;
        static VMouseMove: string;
        static Focus: string;
        static FocusIn: string;
        static FocusOut: string;
        static FocusEvents: string;
    }
}
declare module MscrmCommon {
    class EventGuard {
        private static focusRemoveEvent;
        private static hasUserInteractedEventName;
        private static hasUserInteractedWithElementEventName;
        private shouldPreventMouseEvents;
        private shouldPreventTouchEvents;
        private userInteractedInEditModeWithAnInputElement;
        private userInteractedInEditMode;
        private removeClickEventHandler;
        private removeMultipleEventHandlers;
        private container;
        private userAgent;
        constructor(container: HTMLElement, userAgent: Mscrm.UserAgent);
        destroy(): void;
        preventClicksUntilUserInteracted(): void;
        stopPreventingClicks(): void;
        preventEditModeTransitionFocus(): void;
        stopPreventingFocus(): void;
        preventMultipleEventTypes(): void;
        stopPreventingMultipleEventTypes(): void;
        private stopPreventingFocusEvents(element);
        private static handleEditModeClickEvents(element, eventGuard);
        private static preventTouchEventsAfterMouseDown(element, eventGuard);
        private static preventMouseEventsAfterTouchStart(element, eventGuard);
    }
}
declare module MscrmCommon {
    class MethodConstants {
        static Destroy: string;
        static Refresh: string;
        static Value: string;
        static Option: string;
        static Disable: string;
        static Enable: string;
    }
}
declare module MscrmCommon.ControlUtils {
    class ControlGuidGenerator {
        static newGuid(controlName: string): string;
    }
}
declare module MscrmCommon.ControlUtils {
    class Enum {
        static getFromString(enumArray: Array<string>, stringValue: string): number;
    }
}
declare module MscrmCommon.ControlUtils {
    class Event {
        static createName(eventName: string, eventNamespace: string): string;
    }
}
declare module MscrmCommon.ControlUtils {
    class HitTarget {
        private static initialEvents;
        private static subsequentEvents;
        private static mouseUpHitTargetEventName;
        static exists(container: JQuery, hitTargetClassSelector: string): boolean;
        static create(container: JQuery, controlDomElement: JQuery, hitTargetClass: string, trackElementClassSelector: string, paddingLeftPx: number, min: number, max: number, setControlValue: (value: number) => any): void;
        private static removeHitTargetSubsequentEvents(hitTargetElement);
    }
}
declare module MscrmCommon.ControlUtils {
    class NumericInterval {
        static StepDefaultValue: number;
        static provideDefaultValuesIfNullDataBagParameters(context: {
            parameters: {
                step?: Mscrm.NumberProperty;
                min: Mscrm.NumberProperty;
                max: Mscrm.NumberProperty;
            };
        }, hasStep?: boolean): void;
        static throwIfNullDataBagParameters(context: {
            parameters: {
                value: Mscrm.NumberProperty;
                step?: Mscrm.NumberProperty;
                min: Mscrm.NumberProperty;
                max: Mscrm.NumberProperty;
            };
        }, hasStep?: boolean): void;
        static processPropertyBagValues(context: {
            parameters: {
                value: Mscrm.NumberProperty;
                step?: Mscrm.NumberProperty;
                min: Mscrm.NumberProperty;
                max: Mscrm.NumberProperty;
            };
            resources: {
                getString(id: string): string;
            };
        }, notificationHandler: ErrorHandling.NotificationHandler, roundValues?: boolean): void;
        static createOptionalNumberPropery(value: number): Mscrm.NumberProperty;
        static moveValueToMultipleOfStep(value: number, context: Mscrm.ControlData<any>): number;
        static getFormattedValue(value: Mscrm.NumberProperty): string;
        static isPercent(formattedValue: string): boolean;
        static setValueContainer(container: HTMLDivElement, value: string): void;
        static getPrecision(property: any): number;
        static isNumber(value: number): boolean;
        static trunc(x: number): number;
        static isNumeric(value: number): boolean;
    }
}
declare module MscrmCommon.ControlUtils {
    class WijmoGlobalization {
        private static formatting;
        private static wijmoFormatNumber;
        static setCrmNumberFormatting(crmFormatting: any): void;
        private static formatNumber(value, format, trim);
        static getFormat(context: Mscrm.ControlData<any>): string;
        static getFormattedValue(value: number, format: string): string;
        static setWijmoNumberFormatStructure(crmNumberFormat: Mscrm.NumberFormattingInfo, numberType: string, isPercent: boolean, overriddenPrecision: number): void;
    }
}
declare module MscrmCommon.ControlUtils {
    class Object {
        static isNullOrUndefined(object: any): boolean;
    }
}
declare module MscrmCommon.ControlUtils {
    class Property {
        static isNullOrEmpty(property: Mscrm.BaseProperty): boolean;
    }
}
declare module MscrmCommon.ControlUtils {
    class String {
        static Empty: string;
        static isNullOrEmpty(s: string): boolean;
        static isNullOrWhitespace(s: string): boolean;
        static isNullUndefinedOrWhitespace(s: string): boolean;
        static Format(format: string, ...args: any[]): string;
        static EqualsIgnoreCase(string1: string, string2: string): boolean;
        static ReplaceLineBreaksWithBrTags(text: string): string;
    }
}
declare module MscrmCommon {
    class ThemingHelper {
        static InvalidContainerMessage: string;
        static InvalidCssMessage: string;
        static InvalidCssValueMessage: string;
        static ReadModeClassName: string;
        static EditModeClassName: string;
        static injectStyle(container: HTMLDivElement, css: string): void;
        static removeStyles(container: HTMLDivElement): void;
        static getProcessNonSelectedColor(theming: Mscrm.Theme): string;
        static getGlobalLinkColor(theming: Mscrm.Theme): string;
        static getHoverLinkColor(theming: Mscrm.Theme): string;
        static getProcessControlColor(theming: Mscrm.Theme): string;
        static getShadeControlColor(theming: Mscrm.Theme): string;
        static getFontFamily(theming: Mscrm.Theme): string;
        static getFontColor(theming: Mscrm.Theme): string;
        static getFontSize(theming: Mscrm.Theme): string;
        static validateCssColor(value: string): string;
        static validateCssFontFamily(value: string): string;
        static validateCssSize(value: string): string;
        private static isHeaderCell(scope);
        static getEditModeStyle(theming: Mscrm.Theme, scope: Mscrm.BaseProperty, deviceSizeMode: Mscrm.BaseProperty, error: boolean): {
            [key: string]: any;
        };
        static getReadModeStyle(theming: Mscrm.Theme, scope: Mscrm.BaseProperty, deviceSizeMode: Mscrm.BaseProperty, error: boolean, isControlDisabled?: boolean): {
            [key: string]: any;
        };
        static getDisableStyle(theming: Mscrm.Theme): {
            [key: string]: any;
        };
        static convertHexColorToRGBA(hex: string, opacity: number): string;
        private static getMarginLeftFromDeviceSizeMode(measures, deviceSizeMode);
        private static getHighContrastEnabled();
    }
}
declare module MscrmCommon {
    class FullscreenHelper {
        static supportsFullscreenApi: boolean;
        static fullscreenElement: any;
        static requestFullscreen(fullscreenTarget: any): void;
        static requestFullscreenUsingStyling(fullscreenTarget: HTMLElement): void;
        static exitFullscreen(): void;
        static exitFullscreenUsingStyling(fullscreenTarget: HTMLElement): void;
    }
}
declare module MscrmCommon {
    class DataSetColumnSortStatus implements Mscrm.DataSetColumnSortStatus {
        name: string;
        sortDirection: Mscrm.ColumnSortDirection;
    }
}
declare module MscrmCommon {
    class ConditionExpression implements Mscrm.ConditionExpression {
        attributeName: string;
        conditionOperator: Mscrm.ConditionOperator;
        value: string | Array<string>;
    }
}
declare module MscrmCommon {
    class FilterExpression implements Mscrm.FilterExpression {
        conditions: ConditionExpression[];
        filterOperator: Mscrm.FilterOperator;
        filters: FilterExpression[];
    }
}
declare module MscrmCommon {
    class PrimitiveValue<T> implements Mscrm.DataTypes.PrimitiveValue<T> {
        value: T;
        dataType: string;
        constructor(value: T, dataType: string);
    }
}
declare module MscrmCommon.Globalization {
    class CrmNumberType {
        static CrmDecimalTypeName: string;
        static CrmDoubleTypeName: string;
        static CrmIntegerTypeName: string;
        static CrmMoneyTypeName: string;
    }
}
declare module MscrmCommon.Globalization {
    class NumberPatternFactory {
        static NoSuchPatternError: string;
        private currencyPositivePatternArray;
        private currencyNegativePatternArray;
        private percentPositivePatternArray;
        private percentNegativePatternArray;
        getCurrencyPositivePattern(patternValue: number): string;
        getCurrencyNegativePattern(patternValue: number): string;
        getPercentPositivePattern(patternValue: number): string;
        getPercentNegativePattern(patternValue: number): string;
        private getPattern(patternArray, patternValue);
    }
}
declare module MscrmCommon.Globalization {
    class WijmoNumberFormatFactory {
        static InvalidSymbolErrorMessage: string;
        static getWijmoNumberFormatStructure(numberFormatInfo: Mscrm.NumberFormattingInfo, crmNumberType: string, isPercent: boolean, overriddenPrecision?: number): any;
        static getNumberFormatString(numberFormatInfo: Mscrm.NumberFormattingInfo, crmNumberType: string, isPercent: boolean, overriddenPrecision?: number): string;
        private static validateSymbolLength(value, maxLength);
    }
}
declare module MscrmCommon {
    class ArrayQuery {
        private data;
        constructor(data: any[]);
        select(selector: (item: any, index?: any) => any): ArrayQuery;
        transform(selector: (item: any, index: any) => {
            key: any;
            value: any;
        }): ArrayQuery;
        each(delegate: (item: any, index?: any) => void): ArrayQuery;
        where(selector: (item: any) => any): ArrayQuery;
        firstOrDefault(selector: (item: any) => any): any;
        contains(selector: (item: any) => any): boolean;
        items(): any[];
    }
}
declare module MscrmCommon {
    interface OOBControl<TParams> {
        context: Mscrm.ControlData<TParams>;
    }
    class DisplayMode {
        static UNKNOWN: string;
        static READ: string;
        static EDIT: string;
        static EDITHINT: string;
    }
    class ModeSwitchEventName {
        static fromReadToEdit: string;
    }
    class DisplayModeManager<TParams> {
        private instance;
        private currentMode;
        constructor(ins: OOBControl<TParams>);
        getMode(): string;
        setMode(newMode: string, params: Mscrm.Dictionary): void;
    }
}
declare module MscrmCommon {
    const enum ClientApiFormFactor {
        Unknown = 0,
        Desktop = 1,
        Tablet = 2,
        Phone = 3,
    }
}
declare module MscrmCommon {
    class GridHelper {
        static shouldRenderAsReadOnlyGridOnPhone(context: Mscrm.ControlData<any>, customControlConfiguration: Mscrm.ICustomControlConfiguration, deviceFormFactor: MscrmCommon.ClientApiFormFactor): boolean;
    }
}
declare class Guid implements Mscrm.Guid {
    private static braceAndHyphenGuidVerifierPattern;
    private static contiguousGuidVerifierPattern;
    _guid: string;
    guid: string;
    static EMPTY: Guid;
    constructor(value: string);
    static toString(guid: Mscrm.Guid): string;
    toString(): string;
    static equals(x: Mscrm.Guid, y: Mscrm.Guid): boolean;
    static tryParse(value: string): Guid;
    static tryParseOrNull(value: string): Guid;
    private static _formatGuidString(value);
}
declare module MscrmCommon {
    class KMPerformanceTelemetry {
        private static instance;
        private stopwatches;
        private constructor();
        static readonly Instance: KMPerformanceTelemetry;
        GetStopwatchKeys(): string[];
        AddStartMarker(eventId: string, ...params: string[]): void;
        AddEndMarker<TParams>(eventId: string, context: Mscrm.ControlData<TParams>, ...params: string[]): void;
        AddActionLogForUsageCalculations<TParams>(actionName: string, context: Mscrm.ControlData<TParams>, ...params: any[]): void;
        AddErrorLog<TParams>(context: Mscrm.ControlData<TParams>, errorMessage: string, errorDetails: string): void;
    }
}
declare module MscrmCommon {
    class KMTelemetryConstants {
        static KBSEARCH_CONTROL_PERFORMANCE: string;
        static WATERMARK_ACTION_LOAD_KBSEARCH_CONTROL: string;
        static WATERMARK_ACTION_LOAD_SEARCH_RESULTS: string;
        static WATERMARK_ACTION_OPEN_ARTICLE_TO_READ: string;
        static WATERMARK_ACTION_LINK_KBARTICLE: string;
        static WATERMARK_ACTION_UNLINK_KBARTICLE: string;
        static WATERMARK_ACTION_EMAIL_ARTICLE_CONTENT: string;
        static WATERMARK_ACTION_EMAIL_ARTICLE_URL: string;
        static WATERMARK_ACTION_SEE_MORE_OPTION_CLICKED: string;
        static WATERMARK_ACTION_KBSEARCH_PERFORMED: string;
        static WATERMARK_ACTION_KBSEARCH_CONTROL_INITIALIZED: string;
        static WATERMARK_ACTION_SORT_ORDER_CHANGED: string;
        static WATERMARK_ACTION_STATUS_FILTER_CHANGED: string;
        static WATERMARK_ACTION_LANGUAGE_FILTER_CHANGED: string;
    }
}
declare module Mscrm {
    interface IDisposable {
        dispose: () => void;
    }
}
